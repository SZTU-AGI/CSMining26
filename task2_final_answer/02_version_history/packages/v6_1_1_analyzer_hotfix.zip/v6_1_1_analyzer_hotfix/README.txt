V6.1.1 analyzer hotfix

Fixes repair target selection:
- only UNKNOWN coordinates are eligible for bounded repair;
- zero accepted decisive bases does NOT exclude a coordinate if it still has
  open goals and unassessed candidates (FIND_SUPPORT/FIND_ATTACK can proceed);
- settled PROVEN_COMPLIANT/CONFLICTING coordinates are not selected just
  because they contain decisive bases.

Replace code/analyze_batch_v6.py with this file and rerun the analyzer.
