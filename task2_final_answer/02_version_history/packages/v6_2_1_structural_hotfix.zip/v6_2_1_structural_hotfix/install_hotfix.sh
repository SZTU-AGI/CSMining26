#!/usr/bin/env bash
set -euo pipefail
: "${V61:?Set V61 to the v6 release directory}"
cp "$(dirname "$0")/structured_witness_v6_2_1.py" "$V61/code/structured_witness_v6_2_1.py"
cp "$(dirname "$0")/replay_postrepair_v6_2_1.py" "$V61/code/replay_postrepair_v6_2_1.py"
python -m py_compile "$V61/code/structured_witness_v6_2_1.py" "$V61/code/replay_postrepair_v6_2_1.py"
echo "V6.2.1 structural witness hotfix installed."
