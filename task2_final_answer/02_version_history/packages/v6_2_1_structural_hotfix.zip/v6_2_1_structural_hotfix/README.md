# V6.2.1 structural witness hotfix

Zero-API structural replay for the remaining CP1/CP26 gaps.

- CP26: audits the complete Station Code / Station Condition table from cached evidence chunks. Any explicit defective station is a counterexample; all-positive rows can support the universal working-order requirement.
- CP1: joins the Registered Export Operations narrative with its Activity / Description / Scope Status table. Domestic-only non-registered rows are excluded; export-relevant non-registered rows attack; complete export-scope coverage supports.
- CP15 is intentionally unchanged.

This package does not call an API and does not mutate original run artifacts.
