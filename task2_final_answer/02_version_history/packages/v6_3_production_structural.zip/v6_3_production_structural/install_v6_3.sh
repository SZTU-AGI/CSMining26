#!/usr/bin/env bash
set -euo pipefail

PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC="$PKG_DIR/files"
V61="${V61:-/home/MeggieYu/freca/v6_1_release/v6_witness_reachability_20260830}"
CORE="${FRECA_PROJECT_ROOT:-/home/MeggieYu/freca/core_v1}"
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP="$V61/backups/v6_3_before_$STAMP"
mkdir -p "$BACKUP/v61_code" "$BACKUP/core_v1" "$BACKUP/config"

common=(
  freca_core_v1.py
  evidence_reasoning_v2.py
  evidence_nature_v1.py
  fact_candidate_v1.py
  coverage_policy_v2.py
  proof_gate_applicability_v2.py
  production_runner_v2.py
  production_stop_gate_v1.py
  structured_witness_v6_3.py
  production_runner_v6_3.py
)

for f in "${common[@]}"; do
  [[ -f "$V61/code/$f" ]] && cp -p "$V61/code/$f" "$BACKUP/v61_code/$f"
  [[ -f "$CORE/$f" ]] && cp -p "$CORE/$f" "$BACKUP/core_v1/$f"
  cp "$SRC/$f" "$V61/code/$f"
  cp "$SRC/$f" "$CORE/$f"
done

v61_only=(
  semantic_replay_v6_1.py
  analyze_batch_v6.py
  replay_full_batch_v6_3.py
  v6_3_structural_regression_selftest.py
  eval20_cases_v6_3.txt
  run_eval20_v6_3.sh
)
for f in "${v61_only[@]}"; do
  [[ -f "$V61/code/$f" ]] && cp -p "$V61/code/$f" "$BACKUP/v61_code/$f"
  cp "$SRC/$f" "$V61/code/$f"
done
chmod +x "$V61/code/production_runner_v6_3.py" "$CORE/production_runner_v6_3.py" \
  "$V61/code/replay_full_batch_v6_3.py" "$V61/code/v6_3_structural_regression_selftest.py" \
  "$V61/code/run_eval20_v6_3.sh"

[[ -f "$V61/config/production_repair_policy_v2.json" ]] && \
  cp -p "$V61/config/production_repair_policy_v2.json" "$BACKUP/config/production_repair_policy_v2.json"
cp "$SRC/production_repair_policy_v2.json" "$V61/config/production_repair_policy_v2.json"

python -m compileall -q "$V61/code" "$CORE"

echo "V6.3 production structural integration installed."
echo "Backup: $BACKUP"
echo "V61:   $V61"
echo "CORE:  $CORE"
