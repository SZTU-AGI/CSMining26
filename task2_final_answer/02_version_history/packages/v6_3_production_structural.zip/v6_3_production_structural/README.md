# FRECA V6.3 — production structural aggregation

V6.3 promotes the validated CP1/CP26 structural witnesses from a post-hoc replay into a versioned production evidence path.

## Design

- `production_runner_v6_3.py` wraps the existing manifest-aware V1 runner instead of overwriting it, so V1 remains an ablation baseline.
- After ordinary parsing/retrieval/LLM alignment, `structured_witness_v6_3.py` deterministically audits recognised tables and appends ordinary validated alignment artifacts.
- Structural artifacts do **not** emit labels. They still pass through the common temporal, reliability, coverage, proof, four-valued outcome and fold layers.
- CP1 uses a complete registered-export-operation scope-table audit and single explicit export-scope counterexamples.
- CP26 uses a complete station/trap condition-register audit and single explicit defective-unit counterexamples.
- CP15 is intentionally unchanged. With N/A inference disabled, an unproven conditional guard remains UNKNOWN.

## Evaluation split

`eval20_cases_v6_3.txt` is a fixed-seed sample of 20 cases from the 95 cases not used in the five-case debugging set. The seed is fixed in the package provenance. The recommended first independent batch is CP1, CP12, CP26 and CP35 only.
