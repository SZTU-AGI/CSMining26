# FRECA V6.2 semantic hotfix

This hotfix targets the three post-repair diagnoses observed after two bounded rounds.

## What is fixed

1. **FactCandidate context restoration**
   - Typed predicate compatibility now evaluates the complete grounded FactCandidate rather than only the model-selected `exact_quote` substring.
   - `exact_quote` is still required for grounding/audit and the model relation is not rewritten.

2. **CP1 registration-scope adverse facts**
   - `Not registered` is no longer a direct attack unless the grounded fact has an explicit export nexus.
   - Explicit domestic-only operations are rejected as CP1 scope violations.
   - Genuine export-scope registration defects are typed as ACTUAL adverse facts.
   - A grounded explicit adverse fact can establish the ATTACK direction without exhausting the whole attack candidate universe; the opposite SUPPORT direction remains independently discoverable, preserving BOTH.

3. **CP26 equipment-condition register rows**
   - Spreadsheet-style rows such as `Enclosed bait station ... Good — bait present, lid secure` can be admitted as equipment-condition facts even when the model quotes only the status cell.
   - Additional conservative condition cues include serviceable, operational, intact, undamaged, lid secure, bait present, etc., but only with a station/trap subject in the grounded FactCandidate.

## What is intentionally NOT changed

**CP15 remains fail-closed** when the conditional antecedent cannot be established.
`If screening is carried out ...` is an IF-THEN obligation. With N/A/non-applicability inference disabled, no screening-event witness and no explicit evidence that screening did not occur is not enough to claim compliance or non-applicability. V6.2 does not infer `screening did not occur` from missing evidence.

## Validation

- V6.2 targeted self-tests: 5/5 PASS.
- Existing V6.1 semantic-closure self-tests: 7/7 PASS.
- Python compile checks: PASS.

Use `replay_postrepair_v6_2.py` on the already-completed round-2 artifacts before making any new API calls.
