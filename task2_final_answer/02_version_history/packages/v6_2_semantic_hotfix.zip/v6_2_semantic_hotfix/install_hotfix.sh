#!/usr/bin/env bash
set -euo pipefail

V61="${V61:-/home/MeggieYu/freca/v6_1_release/v6_witness_reachability_20260830}"
PROJECT="${FRECA_PROJECT_ROOT:-/home/MeggieYu/freca/core_v1}"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAMP="v6_2_$(date +%Y%m%d_%H%M%S)"

if [[ ! -d "$V61/code" ]]; then
  echo "ERROR: V61 code directory not found: $V61/code" >&2
  exit 2
fi

FILES=(evidence_nature_v1.py evidence_reasoning_v2.py fact_candidate_v1.py coverage_policy_v2.py)

mkdir -p "$V61/code/backup_$STAMP"
for f in "${FILES[@]}"; do
  [[ -f "$V61/code/$f" ]] && cp -p "$V61/code/$f" "$V61/code/backup_$STAMP/$f"
  cp "$SRC_DIR/$f" "$V61/code/$f"
done
cp "$SRC_DIR/v6_2_fact_context_selftest.py" "$V61/code/v6_2_fact_context_selftest.py"
cp "$SRC_DIR/replay_postrepair_v6_2.py" "$V61/code/replay_postrepair_v6_2.py"

if [[ -d "$PROJECT" ]]; then
  mkdir -p "$PROJECT/backup_$STAMP"
  for f in "${FILES[@]}"; do
    if [[ -f "$PROJECT/$f" ]]; then
      cp -p "$PROJECT/$f" "$PROJECT/backup_$STAMP/$f"
      cp "$SRC_DIR/$f" "$PROJECT/$f"
    fi
  done
fi

python -m py_compile \
  "$V61/code/evidence_nature_v1.py" \
  "$V61/code/evidence_reasoning_v2.py" \
  "$V61/code/fact_candidate_v1.py" \
  "$V61/code/coverage_policy_v2.py" \
  "$V61/code/v6_2_fact_context_selftest.py" \
  "$V61/code/replay_postrepair_v6_2.py"

(
  cd "$V61/code"
  PYTHONPATH=. python v6_2_fact_context_selftest.py
)

echo "V6.2 semantic hotfix installed."
echo "V61 backup: $V61/code/backup_$STAMP"
[[ -d "$PROJECT/backup_$STAMP" ]] && echo "core_v1 backup: $PROJECT/backup_$STAMP"
