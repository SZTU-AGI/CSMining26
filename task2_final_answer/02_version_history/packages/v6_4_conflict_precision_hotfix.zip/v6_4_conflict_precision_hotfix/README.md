# FRECA V6.4 conflict-precision hotfix

This patch follows the V6.3 25-coordinate conflict audit.

## Why V6.4 exists

V6.3 established structural witnesses for CP1 and CP26, but the conflict audit
showed a remaining precision risk: local positive features could still be
promoted to DIRECT proof of a holistic proposition (especially CP12), while
CP35 accepted generic hygiene statements too readily as proof that the overall
contamination/infestation risk was at an acceptable level.

V6.4 does **not** suppress contradictions.  Genuine support + attack remains
`BOTH/CONFLICTING` under the paraconsistent semantics.

## Changes

1. **CP12 positive proof completeness**
   - A local design feature (steel frame, one sealed opening, etc.) is only
     CORROBORATIVE for the whole-establishment design proposition.
   - Deterministic structural aggregation combines the Cleanability (C4) and
     Contamination/Pest Harbourage Minimisation (C5) sections.
   - Explicit construction-level defects are universal counterexamples.

2. **CP12 maintenance state aggregation**
   - Positive support combines current Hygiene/Cleanliness (C8) and Pest
     Condition (C9) evidence.
   - Explicit repeated pest activity / delayed escalation or relevant current
     maintenance defects can attack the maintenance proposition.
   - Contradictory current-state evidence is preserved as BOTH.

3. **CP35 acceptable-risk precision**
   - Generic `hygiene compliant` text is not enough for DIRECT support.
   - DIRECT positive evidence must express an outcome such as acceptable range,
     below threshold, pest-free, negative live-insect monitoring, etc.
   - Generic local defects are not automatically proof of unacceptable risk.
   - Deterministic structural audit adds explicit current pest-risk support and
     repeated-pest-activity/delayed-escalation attack evidence.

4. **Existing CP1 / CP26 structural semantics are retained.**

## Offline regression

- Existing V6.1 semantic closure tests: 7/7 PASS.
- Existing V6.3 CP1/CP26 structural regression: 10/10 PASS.
- New V6.4 CP12/CP35 precision regression: 13/13 PASS.

The full `run_all_self_tests.sh` requires the server's `freca-core` conda
environment; the package installer runs syntax checks and the core semantic
self-test, and a separate regression command is provided below.

## Recommended next step

Do **not** rerun DeepSeek yet.  Install V6.4 and rerun the existing 25
coordinates with `replay_full_batch_v6_4.py`.  Inspect the final conflicts.  If
they are preserved by proposition-complete structural support/attack, treat them
as real contradictions rather than a reason to force a single direction.

Only after the 25-coordinate precision replay should the fixed 20-case / 4-CP
independent evaluation be started.
