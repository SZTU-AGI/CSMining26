#!/usr/bin/env bash
set -euo pipefail
: "${V61:?Set V61 to /home/MeggieYu/freca/v6_1_release/v6_witness_reachability_20260830}"
CORE="${FRECA_PROJECT_ROOT:-/home/MeggieYu/freca/core_v1}"
SRC="$(cd "$(dirname "$0")" && pwd)/files"
STAMP="$(date +%Y%m%d_%H%M%S)"

mkdir -p "$V61/backups/v6_4_$STAMP" "$CORE/backup_v6_4_$STAMP"

for f in evidence_nature_v1.py structured_witness_v6_3.py; do
  [[ -f "$V61/code/$f" ]] && cp -p "$V61/code/$f" "$V61/backups/v6_4_$STAMP/$f"
  [[ -f "$CORE/$f" ]] && cp -p "$CORE/$f" "$CORE/backup_v6_4_$STAMP/$f"
  cp "$SRC/$f" "$V61/code/$f"
  cp "$SRC/$f" "$CORE/$f"
done

for f in production_runner_v6_4.py replay_full_batch_v6_4.py v6_4_precision_regression_selftest.py run_eval20_v6_4.sh; do
  cp "$SRC/$f" "$V61/code/$f"
done
cp "$SRC/production_runner_v6_4.py" "$CORE/production_runner_v6_4.py"
chmod +x "$V61/code/run_eval20_v6_4.sh" "$V61/code/production_runner_v6_4.py" "$CORE/production_runner_v6_4.py"

python -m py_compile \
  "$V61/code/evidence_nature_v1.py" \
  "$V61/code/structured_witness_v6_3.py" \
  "$V61/code/production_runner_v6_4.py" \
  "$V61/code/replay_full_batch_v6_4.py" \
  "$V61/code/v6_4_precision_regression_selftest.py"

cd "$V61/code"
PYTHONPATH=. python v6_1_semantic_closure_selftest.py

echo "V6.4 conflict-precision hotfix installed."
echo "V61 backup: $V61/backups/v6_4_$STAMP"
echo "CORE backup: $CORE/backup_v6_4_$STAMP"
