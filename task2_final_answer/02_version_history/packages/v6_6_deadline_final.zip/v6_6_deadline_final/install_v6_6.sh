#!/usr/bin/env bash
set -Eeuo pipefail
V61="${V61:-/home/MeggieYu/freca/v6_1_release/v6_witness_reachability_20260830}"
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$V61/code"
for f in fast_final_adjudicator_v6_6.py finalize_v6_6_submission.py summarize_v6_6.py run_v6_6_smoke_parallel.sh run_v6_6_full_parallel.sh monitor_v6_6.sh; do cp -f "$HERE/$f" "$V61/code/$f"; done
chmod +x "$V61/code"/*.sh "$V61/code/fast_final_adjudicator_v6_6.py "$V61/code/finalize_v6_6_submission.py "$V61/code/summarize_v6_6.py"
python -m py_compile "$V61/code/fast_final_adjudicator_v6_6.py" "$V61/code/finalize_v6_6_submission.py"
echo 'V6.6 deadline-final installed.'
echo "Run root: $V61/results/final4100_v6_6_deadline"
