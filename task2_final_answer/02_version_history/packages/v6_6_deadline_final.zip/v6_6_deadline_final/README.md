# V6.6 Deadline Final

Purpose: produce a complete 100 x 41 FRECA submission before deadline without folding unresolved proof states blindly to zero.

- One model call per case x compliance element (4 primary calls/case; ~400 primary calls total).
- Official checking-point text is loaded verbatim from the competition workbook.
- Policy context is retrieved automatically from the supplied Rules PDF.
- Evidence context is BM25-retrieved automatically from all nine case files.
- Prompt contains no hand-written per-CP rules.
- 1 requires grounded evidence.
- conflicting/failed/insufficient applicable evidence => 0, consistent with task definition.
- N/A requires positive non-applicability and a separate verification call; ambiguity => 0.
- Exact prompts and raw model JSON are persisted per element for reproducibility/method verification.
- Resume safe at element and case level.

Smoke results are stored in the same final run root and reused by the full run.
