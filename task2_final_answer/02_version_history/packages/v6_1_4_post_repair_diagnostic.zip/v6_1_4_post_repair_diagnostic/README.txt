Zero-API post-repair diagnostic for FRECA V6.1.x.
Reads existing initial, round-1 and round-2 artifacts only. It never calls DeepSeek.
