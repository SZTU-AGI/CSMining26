#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, re
from collections import Counter
from pathlib import Path
from typing import Any


def load(p: Path):
    if not p.is_file(): return None
    try: return json.loads(p.read_text(encoding='utf-8'))
    except Exception as e: return {'__load_error__': str(e)}


def walk(x: Any):
    if isinstance(x, dict):
        yield x
        for v in x.values(): yield from walk(v)
    elif isinstance(x, list):
        for v in x: yield from walk(v)


def alignments(rr):
    return (rr or {}).get('alignments') or []


def fact_id(a):
    fc=a.get('fact_candidate') or {}
    return str(fc.get('candidate_id') or fc.get('fact_candidate_id') or fc.get('artifact_id') or fc.get('evidence_id') or a.get('alignment_id') or '')


def quote(a):
    fc=a.get('fact_candidate') or {}
    return str(fc.get('exact_quote') or fc.get('quote') or fc.get('text') or a.get('exact_quote') or '')


def summarize_rr(rr):
    als=alignments(rr)
    rel=Counter(str(a.get('relation')) for a in als)
    pred=Counter(str(a.get('predicate_compatibility')) for a in als)
    pred_reason=Counter(str(a.get('predicate_compatibility_reason')) for a in als)
    tb=[a for a in als if a.get('argument_truth_bearing') is True]
    direct=[a for a in als if a.get('predicate_compatibility')=='DIRECT']
    screening=[a for a in als if re.search(r'(?i)\b(screen(?:ed|ing)?|siev(?:e|ed|ing)|scalp(?:ed|ing)?)\b', quote(a))]
    equip=[a for a in als if re.search(r'(?i)\b(bait station|station|trap|serviceable|operational|good working order|fit for purpose)\b', quote(a))]
    return {
        'alignment_count':len(als), 'relations':dict(rel), 'truth_bearing':len(tb),
        'direct_compatibility':len(direct), 'predicate_counts':dict(pred),
        'predicate_reason_top':pred_reason.most_common(8),
        'screening_mentions':len(screening), 'equipment_mentions':len(equip),
        'truth_bearing_examples':[{'relation':a.get('relation'),'predicate':a.get('predicate_compatibility'),'fact_id':fact_id(a),'quote':quote(a)[:260]} for a in tb[:8]],
        'direct_examples':[{'relation':a.get('relation'),'fact_id':fact_id(a),'quote':quote(a)[:260]} for a in direct[:8]],
    }


def summarize_proof(p):
    if not p: return {}
    reps=p.get('requirement_reports') or []
    failures=Counter(); accepted_basis=0; raw=Counter(); accepted=Counter()
    rows=[]
    for r in reps:
        raw[str(r.get('raw_state'))]+=1; accepted[str(r.get('accepted_state'))]+=1
        failures.update(r.get('failure_codes') or [])
        s=r.get('support_proof') or {}; a=r.get('attack_proof') or {}
        accepted_basis += (len(s.get('basis_artifact_ids') or []) if s.get('accepted_direction') else 0)
        accepted_basis += (len(a.get('basis_artifact_ids') or []) if a.get('accepted_direction') else 0)
        rows.append({'requirement_id':r.get('requirement_id'),'raw_state':r.get('raw_state'),'accepted_state':r.get('accepted_state'),
                     'support_accepted':s.get('accepted_direction'),'support_basis':len(s.get('basis_artifact_ids') or []),'support_failures':s.get('failure_codes') or [],
                     'attack_accepted':a.get('accepted_direction'),'attack_basis':len(a.get('basis_artifact_ids') or []),'attack_failures':a.get('failure_codes') or []})
    return {'internal_outcome':p.get('internal_outcome'),'coverage_complete':p.get('coverage_complete'),'evaluation_locked':p.get('evaluation_locked'),
            'raw_states':dict(raw),'accepted_states':dict(accepted),'accepted_basis_count':accepted_basis,'failure_counts':dict(failures),'requirements':rows}


def summarize_open_goals(g):
    if not g: return {}
    goals=g.get('goals') or []
    kinds=Counter(str(x.get('goal_type') or x.get('action_type') or x.get('objective_type')) for x in goals)
    return {'count':len(goals),'types':dict(kinds),'terminal_limitations':g.get('terminal_limitations') or []}


def recursive_field_counts(obj, names):
    out=Counter()
    for d in walk(obj):
        for n in names:
            v=d.get(n)
            if isinstance(v,(int,float)): out[n]+=v
    return dict(out)


def load_stage(base: Path, kind: str):
    if kind=='initial-v1':
        rr=load(base/'requirement_result.json')
        proof=load(base/'layer7'/'proof_standard_v1_1.json')
        goals=load(base/'layer7'/'open_goals_v1.json')
        cov=load(base/'layer7'/'coverage_v1_1.json')
    else:
        rr=load(base/'requirement_result_v2.json')
        proof=load(base/'proof_standard_v2.json')
        goals=load(base/'open_goals_v2.json')
        cov=load(base/'coverage_v2.json')
    return {'rr':rr,'proof':proof,'goals':goals,'coverage':cov}


def stage_summary(s):
    return {'rr':summarize_rr(s['rr']), 'proof':summarize_proof(s['proof']), 'open_goals':summarize_open_goals(s['goals']),
            'coverage_numeric':recursive_field_counts(s['coverage'], ['unassessed_candidate_count','assessed_candidate_count','candidate_count','remaining_candidate_count'])}


def ids(rr): return {fact_id(a) for a in alignments(rr) if fact_id(a)}


def classify(cp, fin):
    rr=fin['rr']; pr=fin['proof']; goals=fin['open_goals']
    tb=rr.get('truth_bearing',0); direct=rr.get('direct_compatibility',0); fails=Counter(pr.get('failure_counts') or {})
    if cp=='CP15' and tb==0:
        return 'CP15_APPLICABILITY_OR_EVENT_WITNESS_GAP'
    if cp=='CP26' and tb==0:
        if rr.get('equipment_mentions',0)>0:
            return 'CP26_EQUIPMENT_MENTIONS_EXIST_BUT_NOT_ADMITTED_DIRECTLY'
        return 'CP26_NO_ADMISSIBLE_EQUIPMENT_FITNESS_WITNESS'
    if tb>0 and pr.get('accepted_basis_count',0)==0:
        if fails.get('TEMPORAL_ASSESSMENT_MISSING') or fails.get('INFORMATION_RELIABILITY_MISSING'):
            return 'PROOF_ADMISSION_TEMPORAL_RELIABILITY_GAP'
        if fails.get('COVERAGE_INCOMPLETE'):
            return 'PROOF_ADMISSION_COVERAGE_GAP'
        return 'TRUTH_BEARING_NOT_PROMOTED_TO_ACCEPTED_BASIS'
    return 'UNRESOLVED_AFTER_BOUNDED_SEARCH'


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--run',type=Path,required=True)
    ap.add_argument('--repair1',type=Path,required=True)
    ap.add_argument('--repair2',type=Path,required=True)
    ap.add_argument('--targets',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--markdown',type=Path,required=True)
    a=ap.parse_args()
    targets=[]
    for line in a.targets.read_text().splitlines():
        if not line.strip(): continue
        case,cp=line.split()[:2]; targets.append((case,cp))
    report=[]
    for case,cp in targets:
        s0=load_stage(a.run/'tasks'/case/cp/'initial','initial-v1')
        s1=load_stage(a.repair1/case/cp/'repair'/'round-1'/'after','v2')
        s2=load_stage(a.repair2/case/cp/'repair'/'round-1'/'after','v2')
        z0,z1,z2=stage_summary(s0),stage_summary(s1),stage_summary(s2)
        i0,i1,i2=ids(s0['rr']),ids(s1['rr']),ids(s2['rr'])
        row={'case':case,'cp':cp,'initial':z0,'round1':z1,'round2':z2,
             'new_fact_ids_round1':len(i1-i0),'new_fact_ids_round2':len(i2-i1),
             'diagnosis':classify(cp,z2)}
        report.append(row)
    out={'schema':'freca-v6.1.4-post-repair-diagnostic','coordinate_count':len(report),'rows':report,
         'diagnosis_counts':dict(Counter(r['diagnosis'] for r in report))}
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    lines=['# V6.1.4 post-repair diagnostic','',f'- Coordinates: {len(report)}',f'- Diagnosis counts: `{out["diagnosis_counts"]}`','',
           '| Case | CP | TB init→r1→r2 | accepted basis init→r1→r2 | new facts r1/r2 | diagnosis |','|---|---|---:|---:|---:|---|']
    for r in report:
        def tb(k): return r[k]['rr'].get('truth_bearing',0)
        def ab(k): return r[k]['proof'].get('accepted_basis_count',0)
        lines.append(f"| {r['case']} | {r['cp']} | {tb('initial')}→{tb('round1')}→{tb('round2')} | {ab('initial')}→{ab('round1')}→{ab('round2')} | {r['new_fact_ids_round1']}/{r['new_fact_ids_round2']} | {r['diagnosis']} |")
    lines += ['','## Final blockers']
    for r in report:
        lines += ['',f"### {r['case']} / {r['cp']}",f"- Diagnosis: **{r['diagnosis']}**",f"- Final proof failures: `{r['round2']['proof'].get('failure_counts',{})}`",f"- Final predicate reasons: `{r['round2']['rr'].get('predicate_reason_top',[])}`",f"- Final open goals: `{r['round2']['open_goals'].get('types',{})}`"]
        ex=r['round2']['rr'].get('truth_bearing_examples') or r['round2']['rr'].get('direct_examples') or []
        for e in ex[:4]: lines.append(f"  - `{e.get('relation')}` `{e.get('predicate','')}` {e.get('fact_id')}: {e.get('quote')}")
    a.markdown.write_text('\n'.join(lines)+'\n')
    print(json.dumps({'coordinate_count':len(report),'diagnosis_counts':out['diagnosis_counts'],'output':str(a.output),'markdown':str(a.markdown)},ensure_ascii=False,indent=2))

if __name__=='__main__': main()
