V6.1.3 bounded-search continuation hotfix

Problem:
  V2 max_rounds=2 was effectively unreachable for UNKNOWN witness-search cases.
  production_stop_gate_v1 treated NO_GOAL_STATE_CHANGE as an unconditional
  immediate stop even when a complete round added novel alignments and many
  unassessed candidates remained.

Change:
  - Policy sets no_goal_state_change_is_hard_stop=false for V2 repair.
  - Stop gate permits exactly one further budgeted round when
    NO_GOAL_STATE_CHANGE is the sole stop reason and the completed round made
    novel search progress.
  - All other safety stops remain hard: no artifact/alignment, repeated hash,
    new conflict, model/tool failure, and budget exhaustion.
  - Default function behavior remains backward compatible (hard stop=true).

Install:
  export V61=/home/MeggieYu/freca/v6_1_release/v6_witness_reachability_20260830
  bash install_hotfix.sh
