#!/usr/bin/env bash
set -euo pipefail
: "${V61:?Set V61=/home/MeggieYu/freca/v6_1_release/v6_witness_reachability_20260830}"
SRC="$(cd "$(dirname "$0")" && pwd)"
TS="$(date +%Y%m%d_%H%M%S)"
mkdir -p "$V61/backup_v6_1_3_$TS"
for f in production_stop_gate_v1.py production_runner_v2.py; do
  cp -p "$V61/code/$f" "$V61/backup_v6_1_3_$TS/$f"
  cp "$SRC/$f" "$V61/code/$f"
done
cp -p "$V61/config/production_repair_policy_v2.json" "$V61/backup_v6_1_3_$TS/production_repair_policy_v2.json"
cp "$SRC/production_repair_policy_v2.json" "$V61/config/production_repair_policy_v2.json"
cd "$V61/code"
python -m py_compile production_stop_gate_v1.py production_runner_v2.py
python production_stop_gate_v1.py --self-test
printf '\nV6.1.3 bounded-search hotfix installed.\nBackup: %s\n' "$V61/backup_v6_1_3_$TS"
