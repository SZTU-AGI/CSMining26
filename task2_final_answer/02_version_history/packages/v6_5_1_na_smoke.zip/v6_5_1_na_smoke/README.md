# V6.5.1 N/A smoke helper

This package changes **no production semantics**. It runs a small 4-case x 41-CP pilot using the already-installed V6.5 final runner and summarizes whole-CP applicability plus N/A evidence.

Default cases: `case-001 case-020 case-058 case-098`, four parallel workers.

Override cases if needed:

```bash
export FRECA_NA_SMOKE_CASES="case-005 case-014 case-028 case-076"
```

An N/A is considered healthy only when the summary shows grounded non-applicability evidence and a passed independent countercheck. Zero N/A in a small smoke does not justify loosening the semantics.
