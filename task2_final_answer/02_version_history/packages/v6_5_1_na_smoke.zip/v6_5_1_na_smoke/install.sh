#!/usr/bin/env bash
set -Eeuo pipefail
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
V61="${V61:-/home/MeggieYu/freca/v6_1_release/v6_witness_reachability_20260830}"
mkdir -p "$V61/code"
cp -a "$HERE/files/run_na_smoke_v6_5_parallel.sh" "$V61/code/"
cp -a "$HERE/files/summarize_na_smoke_v6_5.py" "$V61/code/"
chmod +x "$V61/code/run_na_smoke_v6_5_parallel.sh" "$V61/code/summarize_na_smoke_v6_5.py"
echo "V6.5.1 N/A smoke helpers installed. No production semantics changed."
echo "Run: bash $V61/code/run_na_smoke_v6_5_parallel.sh"
