# FRECA V6 Witness Reachability

这是一个独立实验版本，不覆盖 `core_v1`，也不写入冻结的 V1 结果树。

## 本版解决的问题

- 固定 thinking/non-thinking 两条 API 分支的 `temperature=0`；
- 修复 N/A countercheck 接线与缓存指纹，但根据现有测量保持关闭；
- repair 模式必须显式选择，witness 试验固定为开启；
- 把 V6 明确标为现有定版的 challenger，而不是自动替代品；
- 按 `source -> retrieved -> aligned -> truth-bearing -> decisive basis`
  输出证据漏斗；
- 非可执行 temporal/reliability blocker 会在 API 前硬阻断；
- 只有真实 decisive goal 被解决并形成有来源的 substantive outcome，才允许
  推荐扩大样本；
- 单坐标 API 调用、HTTP 尝试和 token 都有冻结上限。

## 目录

- `code/`：本版全部运行与验证代码；
- `config/`：决策、单 witness 输入和 repair policy；
- `testing/reference_core/`：真实 reference core 源码副本；
- `results/`：只存本版生成的预检或试验产物；
- `run_v6.sh`：统一入口。

没有复制 `.env`、API key、原案例文件、contracts 或旧结果；这些只作为带哈希的
只读输入引用。

## 运行

```bash
bash run_v6.sh self-test
bash run_v6.sh preflight
bash run_v6.sh run
```

`run` 不会绕过 preflight。若目标期间或其来源未冻结，程序会在发出 API 请求前
拒绝运行，并把原因写入 `results/case-011__CP19/preflight.json`。

当前 witness 是 `case-011/CP19`，因为它是现有审计中唯一带明确 adverse route
的缓存坐标。其目标审计期间当前为空，因此预期结果是 fail-closed `NO_GO`；不得
从文件名、当前日期或历史标签猜测该期间。

---

## V6.1 semantic / proof-closure correction (2026-08-30)

The initial 5-case × 5-CP diagnostic exposed a systematic `UNKNOWN -> 0`
collapse. V6.1 fixes the deterministic causes without changing the model's
persisted relation labels and without making absence infer violation.

### What changed

1. **Typed retrieval now uses the EvidenceRequirement proposition.**
   V6 accidentally inferred the typed target from `query_facets[-1]`, which is
   normally the last RULES quote. A rule containing `carried out` could therefore
   turn CP1 into `ACTIVITY_PERFORMED`. V6.1 carries
   `proposition_to_establish` on every retrieval need and uses it as the
   authoritative typed-retrieval input.

2. **Requirement predicate typing is proposition-first.**
   RULES text is now a fallback only. Strong targets added for:
   `REGISTRATION_OPERATION_SCOPE`, `EQUIPMENT_FITNESS`, and
   `RISK_CONTROL_STATE`.

3. **CORROBORATIVE evidence is no longer truth-bearing.**
   `CORROBORATIVE + ADMIT_DIRECT` previously became argument `DIRECT` despite
   the layer contract saying only typed `DIRECT` may seed a four-valued state.
   It now remains `CONDITIONAL`.

4. **Directional existence proof is separated from exhaustive countercheck.**
   A grounded direct SUPPORT or explicit ATTACK may establish its own direction
   after its registered discovery procedure completes. The opposite-direction
   countercheck stays open and may later produce `BOTH`; it no longer erases an
   already-grounded direction. Absence-based inference remains strict and still
   requires explicit closure plus a burden rule.

5. **Temporal/reliability deadlock removed conservatively.**
   When frozen contracts omit redundant temporal applicability metadata, V6.1
   derives temporal applicability from the typed requirement profile. Row-level
   temporal fit and information reliability are then derived only from grounded,
   direct, typed artifacts. Missing or non-actual evidence still fails closed.

6. **Current-state evidence can support an ongoing current condition.**
   A statement such as a current pest status or a recent inspection explicitly
   confirming clean/no-infestation can establish the positive direction at the
   evaluation point. A bare cleaning/inspection event remains corroborative.

7. **Entity/action anchors were tightened.**
   CP26 must actually mention the relevant stations/traps; CP15 screening cannot
   be satisfied by an unrelated cleaning activity; CP35 risk-state evidence must
   name contamination/infestation/pest/hygiene-like subject matter.

### Zero-API replay of an existing requirement result

This does **not** add evidence or call a model. It only revalidates the persisted
model relation and grounded quote under V6.1 deterministic semantics.

```bash
cd /home/MeggieYu/freca/v6_witness_reachability_20260830/code
PYTHONPATH=. python semantic_replay_v6_1.py \
  --requirement-result /path/to/initial/requirement_result.json \
  --contract /home/MeggieYu/freca/core_v1/contracts_v2/CP26.json \
  --output-dir /path/to/replay_v6_1
```

### Re-analyse the completed 5×5 batch without API calls

```bash
cd /home/MeggieYu/freca/v6_witness_reachability_20260830/code
PYTHONPATH=. python analyze_batch_v6.py \
  --run-root /home/MeggieYu/freca/v6_witness_reachability_20260830/results/batch_5cases_5cps_initial/shard-001 \
  --contracts /home/MeggieYu/freca/core_v1/contracts_v2 \
  --output /home/MeggieYu/freca/v6_witness_reachability_20260830/results/batch_5cases_5cps_initial/analysis_v6_1.json \
  --markdown /home/MeggieYu/freca/v6_witness_reachability_20260830/results/batch_5cases_5cps_initial/analysis_v6_1.md
```

The analyzer first performs semantic replay, then explicitly reports whether the
old typed-retrieval universe is stale. If it is stale, do a **fresh initial run
before repair**; repairing a candidate universe generated for the wrong typed
predicate is not meaningful.

### Regression checks

```bash
cd /home/MeggieYu/freca/v6_witness_reachability_20260830/code
bash run_all_self_tests.sh
```

V6.1 adds `v6_1_semantic_closure_selftest.py` to lock the corrected invariants.
