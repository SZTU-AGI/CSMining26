# V6.1 offline semantic replay diagnostic

- API calls: **0**
- New evidence: **none**
- Real `contracts_v2` in archive: **no**
- Full CP outcomes computed: **no**

This report reuses old persisted model relations/quotes and reruns corrected deterministic semantics only. It is not an accuracy/F1 result.

## Aggregate

- Requirement states after replay: `{'UNKNOWN': 20, 'TRUE': 8, 'BOTH': 2}`
- Raw requirement states: `{'UNKNOWN': 20, 'TRUE': 8, 'BOTH': 2}`
- Direct truth-bearing alignments: **37**
- Conditional alignments: **119**
- Semantic replay validation failures: **0**
- Stale typed-retrieval coordinates: **20/25**

## Per coordinate

| case | CP | accepted requirement states | direct truth-bearing | conditional | stale retrieval |
|---|---|---|---:|---:|---|
| case-023 | CP1 | `{'UNKNOWN': 1}` | 0 | 13 | True |
| case-023 | CP12 | `{'TRUE': 2}` | 9 | 5 | True |
| case-023 | CP15 | `{'UNKNOWN': 1}` | 0 | 1 | False |
| case-023 | CP26 | `{'UNKNOWN': 1}` | 0 | 1 | True |
| case-023 | CP35 | `{'UNKNOWN': 1}` | 0 | 2 | True |
| case-035 | CP1 | `{'UNKNOWN': 1}` | 0 | 11 | True |
| case-035 | CP12 | `{'TRUE': 1, 'BOTH': 1}` | 7 | 5 | True |
| case-035 | CP15 | `{'UNKNOWN': 1}` | 0 | 0 | False |
| case-035 | CP26 | `{'UNKNOWN': 1}` | 0 | 1 | True |
| case-035 | CP35 | `{'UNKNOWN': 1}` | 0 | 5 | True |
| case-038 | CP1 | `{'UNKNOWN': 1}` | 0 | 15 | True |
| case-038 | CP12 | `{'TRUE': 1, 'BOTH': 1}` | 5 | 9 | True |
| case-038 | CP15 | `{'UNKNOWN': 1}` | 0 | 3 | False |
| case-038 | CP26 | `{'UNKNOWN': 1}` | 0 | 2 | True |
| case-038 | CP35 | `{'UNKNOWN': 1}` | 0 | 5 | True |
| case-065 | CP1 | `{'UNKNOWN': 1}` | 0 | 13 | True |
| case-065 | CP12 | `{'TRUE': 2}` | 9 | 6 | True |
| case-065 | CP15 | `{'UNKNOWN': 1}` | 0 | 0 | False |
| case-065 | CP26 | `{'TRUE': 1}` | 1 | 1 | True |
| case-065 | CP35 | `{'UNKNOWN': 1}` | 0 | 3 | True |
| case-074 | CP1 | `{'UNKNOWN': 1}` | 0 | 8 | True |
| case-074 | CP12 | `{'TRUE': 1, 'UNKNOWN': 1}` | 6 | 7 | True |
| case-074 | CP15 | `{'UNKNOWN': 1}` | 0 | 0 | False |
| case-074 | CP26 | `{'UNKNOWN': 1}` | 0 | 1 | True |
| case-074 | CP35 | `{'UNKNOWN': 1}` | 0 | 2 | True |
