#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
CODE="$ROOT/code"
MODE="${1:-}"

if [[ "$MODE" != "self-test" && "$MODE" != "preflight" && "$MODE" != "run" ]]; then
  printf '%s\n' \
    "Usage: bash $0 self-test" \
    "       bash $0 preflight" \
    "       bash $0 run"
  exit 2
fi

run_python() {
  if [[ "${CONDA_DEFAULT_ENV:-}" == "freca-core" ]]; then
    python "$@"
  else
    conda run --no-capture-output -n freca-core python "$@"
  fi
}

export FRECA_REFERENCE_CORE_SRC="$ROOT/testing/reference_core/freca_reference_core_20260828/src"
export FRECA_PROJECT_ROOT="$ROOT"
export FRECA_ENABLE_NA_COUNTERCHECK=0
export FRECA_API_PROVIDER=deepseek
export FRECA_ALIGNMENT_MODEL=deepseek-v4-flash

cd "$CODE"
if [[ "$MODE" == "self-test" ]]; then
  bash run_all_self_tests.sh --with-shim
  exit 0
fi

if [[ "$MODE" == "preflight" ]]; then
  run_python v6_witness_runner.py preflight --repair-enabled on
  exit 0
fi

ENV_FILE="/home/MeggieYu/freca/core_v1/.env.deepseek"
if [[ ! -f "$ENV_FILE" ]]; then
  printf 'RUN_BLOCKED: missing %s\n' "$ENV_FILE" >&2
  exit 4
fi
set -a
# shellcheck disable=SC1090
source "$ENV_FILE"
set +a
: "${DEEPSEEK_API_KEY:?RUN_BLOCKED: DEEPSEEK_API_KEY missing from env file}"
run_python v6_witness_runner.py run --repair-enabled on --allow-api YES
