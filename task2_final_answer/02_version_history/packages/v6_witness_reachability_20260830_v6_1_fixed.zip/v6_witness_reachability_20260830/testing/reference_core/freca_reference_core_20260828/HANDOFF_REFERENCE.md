# FRECA reference core handoff

## Purpose

This folder is a **reference implementation**, not a finished submission system.
It preserves the parts that are already useful and tested without forcing the full
research architecture into one large production pipeline.

Use it to reuse schemas, validators, deterministic parsers, audit records and A/B
interfaces.  Build a smaller experiment driver around only the components needed by
the next experiment.

## Verified baseline

The snapshot was closed with:

```text
200 pytest tests passed
18 unittest subtests passed
selected Ruff checks passed
```

The implemented reference components include:

- input whitelisting, source hashes, immutable run records and prompt/method bundles;
- deterministic parsing of the official Rules PDF into page-aware policy units;
- strict parsing of the official horizontal 41-CP workbook;
- CP-independent exact/BM25/heading/definition/reference retrieval with an auditable
  candidate ledger;
- four-valued logic, four independent contract roots and deterministic DAG validation;
- Carneades-style argument graph projection plus a flat indexed shadow view;
- explicit condition/false-trigger representations and `{1, N/A}` fold-policy A/B arms;
- search-method registry and A/B interfaces retaining ToT, RAP, LATS and related arms;
- provenance, semantic-taint, transformation-conservation and blast-radius utilities;
- the earlier evidence parsing/adjudication pipeline retained for comparison.

The official local integration run used these reproducible outputs:

```text
PolicyIndex: sha256:c9092cf99bf790c5a20d56663ddfff27cacb271c29b1383f336111b550445152
OfficialCPBundle: sha256:5ba460109c7cfe4cf5e0e9300a83122f8de715861303f9112e305dbf225f95a8
Official evidence files: 898 (698 DOCX + 200 XLSX)
```

These hashes are diagnostics for the exact admitted source files. They are not
embedded legal answers and do not replace server-side source verification.

## Deliberately unfinished

Do not treat the following as production-complete:

- automatic candidate-relation classification for all 41 CPs;
- bounded legal closure, span-to-NormEvent extraction and complete CPContract compilation;
- independent parser/query/model anchor-conformance compilation;
- end-to-end case evidence alignment through all four roots for all 4,100 cells;
- calibrated `ANSWER / DEFER / REQUEST_EVIDENCE` learning without labels;
- a selected and pinned embedding/model adapter;
- a gold-validated final scoring policy.

Unresolved candidates remain `UNRESOLVED` or `REVIEW_REQUIRED` by design. The code must
not silently convert those states into legal conclusions.

## Server setup

The code requires Python 3.12 or 3.13 and Poppler command-line tools (`pdftotext` and
`pdfinfo`) for the deterministic PDF parser.

Ubuntu/Debian example:

```bash
sudo apt-get update
sudo apt-get install -y poppler-utils
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e '.[dev]'
python -m pytest -q
```

The official PDF, official CP workbook and case evidence are **not included** in this
portable reference folder. Upload them separately and admit them through the source
catalog; do not place historical artificial labels or hand-authored CP rules in the
runtime input path.

## Recommended way to continue

Start with a small, observable experiment rather than completing every layer at once:

1. choose a small CP slice without writing CP-specific branches;
2. run official CP loading and legal retrieval;
3. inspect `CandidateLedger` and keep unresolved relations visible;
4. add one deterministic transformation at a time, with a round-trip or shadow check;
5. compare A/B arms through the existing registry;
6. only then connect case evidence and final label folding.

The full design remains in `docs/architecture-implementation-draft.md`. It is a design
reference, not a requirement to implement every component in the first server run.

## Important directories

```text
src/freca/governance/   source and replay governance
src/freca/policy/       official policy/CP parsing and legal retrieval
src/freca/logic/        four-valued typed logic DAG
src/freca/argument/     graph projection and independent evaluators
src/freca/evidence/     DOCX/XLSX evidence readers and provenance atoms
src/freca/search/       retained search A/B registry and gates
src/freca/evaluation/   experiment/A-B registry and run gates
tests/                  unit and official-input integration tests
docs/                   architecture and earlier implementation notes
```
