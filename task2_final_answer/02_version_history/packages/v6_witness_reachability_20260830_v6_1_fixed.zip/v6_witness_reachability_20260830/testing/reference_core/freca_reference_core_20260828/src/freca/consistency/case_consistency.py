"""P0-P1: case-level contradiction detection across the 41 per-checking-point verdicts.

Why this stage exists
---------------------
C0-C7 adjudicates one ``(case, checking point)`` pair at a time. That is the right
unit for retrieval and for the audit argument, but it means 41 verdicts per case are
reached independently, and independent decisions can contradict one another. The
submission is scored per cell, so a contradiction does not *automatically* cost a
point — but it is a reliable signal that at least one of the two cells is wrong, and
it is computable with **no gold labels at all**. On an unlabelled dataset that makes
it the most informative check available.

What counts as a contradiction — and what does not
--------------------------------------------------
The hard part of this stage is not detecting disagreement, it is *not* detecting
disagreement that is correct. Three tempting rules were considered and rejected,
because each fires on sound work:

* *"Two checking points disagree."* They should, when they ask different questions.
* *"Two verdicts cite the same evidence atom but reached opposite labels."* An
  inspection record can satisfy one duty and breach another. Sharing an atom is
  not sharing a question.
* *"A subsection mixes N/A with substantive verdicts."* Subsections group checking
  points by topic, not by applicability. "1.2 Plans and specifications" can contain
  one duty that does not bind this occupier and another that does.

What survives is anchored on a *shared legal question*:

* **P0a — identical policy basis, opposite substantive verdicts.** Two checking
  points whose packs were built from the *same set* of obligation units are
  interrogating the same requirement of the same instrument. Measured on the 2021
  compilation, the 41 checking points produce only 26 distinct unit-sets, so these
  groups are real and non-trivial. If two members return 1 and 0, one misread a
  provision both of them read.
* **P0b — shared obligation unit, conflicting applicability.** Applicability is a
  property of ``(farm, obligation unit)``: either the duty binds this occupier or it
  does not. Two checking points resting on *any* common unit that disagree on
  ``APPLICABLE`` vs ``NOT_APPLICABLE`` disagree about the law's reach, not about the
  farm. This is deliberately weaker in its trigger (shared unit, not identical set)
  because applicability is a property of the unit alone, whereas compliance depends
  on which facts the pack asked for.
* **P1 — evidence polarity flip.** ``FinalDecision`` already refuses to let one atom
  be both supporting and contrary *within* a decision. The cross-chain analogue is
  the same principle applied one level up: within a group that shares a policy
  basis, an atom cited as supporting by one verdict and contrary by another means
  the two chains read the same document in opposite directions. Restricting this to
  shared-basis groups is what keeps it from firing on the legitimate case above.

Nothing here rewrites a verdict. Auto-repair is out of scope on purpose: with no
expert labels, a repair that resolves a contradiction by flipping the *correct* cell
improves consistency and worsens accuracy, and we could not tell which happened. The
MVP prohibition on the agent auto-merging its own changes applies to this stage too.

References
----------
* Self-consistency (Wang et al., 2023) samples one question many times. This is the
  complementary check that a compliance audit actually affords: one sample across
  many *related* questions, where the relation is derived from the policy chain
  rather than assumed.
* VeriCoT (arXiv:2511.04662) validates a chain of thought against explicit premises
  and reports ``CONTRADICTION``. P0/P1 lift that from within-chain to across-chain —
  the same premise must not license opposite conclusions in two chains.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from freca.domain.enums import Applicability, FinalLabel


class ConsistencyRule(str, Enum):
    IDENTICAL_BASIS_OPPOSITE_VERDICT = "P0a_IDENTICAL_BASIS_OPPOSITE_VERDICT"
    SHARED_UNIT_APPLICABILITY_CONFLICT = "P0b_SHARED_UNIT_APPLICABILITY_CONFLICT"
    EVIDENCE_POLARITY_FLIP = "P1_EVIDENCE_POLARITY_FLIP"


_SUBSTANTIVE_LABELS = frozenset({FinalLabel.COMPLIANT.value, FinalLabel.NON_COMPLIANT.value})


@dataclass(slots=True, frozen=True)
class ConsistencyFinding:
    """One contradiction, with enough context for a human to adjudicate it.

    ``basis`` names the shared thing that makes the disagreement a contradiction —
    the unit set or the atom id — because a finding a reviewer cannot trace back to
    a provision is not actionable.
    """

    rule: ConsistencyRule
    case_id: str
    cp_ids: tuple[str, ...]
    labels: tuple[str, ...]
    basis: str
    detail: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "rule": self.rule.value,
            "case_id": self.case_id,
            "cp_ids": list(self.cp_ids),
            "labels": list(self.labels),
            "basis": self.basis,
            "detail": self.detail,
        }


@dataclass(slots=True)
class CaseVerdict:
    """The per-checking-point facts P0-P1 need, flattened.

    Deliberately a plain record rather than a reference to ``AdjudicationResult``:
    the consistency stage must be runnable over verdicts reloaded from disk, which
    is how a reviewer will use it after the fact.
    """

    case_id: str
    cp_id: str
    label: str
    applicability: str = Applicability.UNKNOWN.value
    sufficiency: str = ""
    basis: str = ""
    element: str = ""
    subsection: str = ""
    #: Obligation units the pack was built from (``PackExtraction.chosen_unit_ids``).
    unit_ids: tuple[str, ...] = ()
    supporting_atom_ids: tuple[str, ...] = ()
    contrary_atom_ids: tuple[str, ...] = ()
    review_required: bool = False
    blocked_at: str | None = None

    @property
    def is_substantive(self) -> bool:
        """True when the verdict asserts something about the farm.

        ``N/A`` is excluded: "this duty does not bind you" is not the opposite of
        "you complied", so pairing it against 1 or 0 would manufacture conflicts.
        """

        return self.label in _SUBSTANTIVE_LABELS

    @property
    def basis_key(self) -> frozenset[str]:
        """The set of obligation units this verdict rests on."""

        return frozenset(self.unit_ids)


def verdict_from_result(
    result: Any,
    *,
    element: str = "",
    subsection: str = "",
    unit_ids: tuple[str, ...] = (),
) -> CaseVerdict:
    """Flatten an ``AdjudicationResult`` into a :class:`CaseVerdict`.

    ``unit_ids`` is supplied by the caller rather than read off ``result`` because
    the chosen units live on the ``PackExtraction``, not on the adjudication; the
    orchestrator holds both. Passing them in keeps this module from reaching into
    the policy layer.
    """

    decision = result.decision
    if decision is None:
        # A blocked cell still takes part in the completeness accounting, so it is
        # represented rather than dropped. It cannot take part in contradiction
        # detection, because it asserts nothing to contradict.
        return CaseVerdict(
            case_id=result.case_id,
            cp_id=result.cp_id,
            label="",
            element=element,
            subsection=subsection,
            unit_ids=unit_ids,
            blocked_at=result.blocked_at,
        )

    return CaseVerdict(
        case_id=result.case_id,
        cp_id=result.cp_id,
        label=decision.label.value,
        applicability=decision.applicability.value,
        sufficiency=decision.sufficiency.value,
        basis=decision.basis.value,
        element=element,
        subsection=subsection,
        unit_ids=unit_ids,
        supporting_atom_ids=tuple(decision.supporting_evidence_ids),
        contrary_atom_ids=tuple(decision.contrary_evidence_ids),
        review_required=decision.review_required,
        blocked_at=result.blocked_at,
    )


@dataclass(slots=True)
class ConsistencyReport:
    case_id: str
    findings: list[ConsistencyFinding] = field(default_factory=list)
    label_counts: dict[str, int] = field(default_factory=dict)
    n_verdicts: int = 0
    n_blocked: int = 0
    n_review_required: int = 0
    #: How many groups shared an identical policy basis, and how many of those had
    #: at least two substantive verdicts to compare. Without the second number a
    #: "zero contradictions" result is uninterpretable: it may mean the verdicts
    #: agree, or it may mean nothing was ever comparable.
    n_basis_groups: int = 0
    n_comparable_groups: int = 0

    @property
    def ok(self) -> bool:
        return not self.findings

    def by_rule(self) -> dict[str, int]:
        return dict(Counter(finding.rule.value for finding in self.findings))

    def to_dict(self) -> dict[str, Any]:
        return {
            "case_id": self.case_id,
            "ok": self.ok,
            "n_verdicts": self.n_verdicts,
            "n_blocked": self.n_blocked,
            "n_review_required": self.n_review_required,
            "n_basis_groups": self.n_basis_groups,
            "n_comparable_groups": self.n_comparable_groups,
            "label_counts": self.label_counts,
            "findings_by_rule": self.by_rule(),
            "findings": [finding.to_dict() for finding in self.findings],
        }


def _format_basis(units: frozenset[str]) -> str:
    return "+".join(sorted(units)) if units else "<no units>"


def _check_identical_basis(
    group: list[CaseVerdict], units: frozenset[str], case_id: str
) -> list[ConsistencyFinding]:
    """P0a — same unit set, opposite substantive verdicts."""

    findings: list[ConsistencyFinding] = []
    substantive = [verdict for verdict in group if verdict.is_substantive]
    for index, first in enumerate(substantive):
        for second in substantive[index + 1 :]:
            if first.label == second.label:
                continue
            findings.append(
                ConsistencyFinding(
                    rule=ConsistencyRule.IDENTICAL_BASIS_OPPOSITE_VERDICT,
                    case_id=case_id,
                    cp_ids=(first.cp_id, second.cp_id),
                    labels=(first.label, second.label),
                    basis=_format_basis(units),
                    detail=(
                        f"{first.cp_id} returned {first.label} and {second.cp_id} returned "
                        f"{second.label}, but both packs were built from the same obligation "
                        f"unit(s) {_format_basis(units)}; the same requirement cannot be both "
                        "satisfied and breached by one farm"
                    ),
                )
            )
    return findings


def _check_polarity_flip(
    group: list[CaseVerdict], units: frozenset[str], case_id: str
) -> list[ConsistencyFinding]:
    """P1 — one atom supporting in one chain, contrary in another, on a shared basis.

    Scoped to a shared-basis group on purpose. Across unrelated checking points an
    atom may legitimately support one duty and undercut another; within a group that
    reads the same provision it cannot.
    """

    findings: list[ConsistencyFinding] = []
    supporters: dict[str, list[CaseVerdict]] = defaultdict(list)
    objectors: dict[str, list[CaseVerdict]] = defaultdict(list)
    for verdict in group:
        for atom_id in verdict.supporting_atom_ids:
            supporters[atom_id].append(verdict)
        for atom_id in verdict.contrary_atom_ids:
            objectors[atom_id].append(verdict)

    for atom_id in sorted(set(supporters) & set(objectors)):
        for first in supporters[atom_id]:
            for second in objectors[atom_id]:
                if first.cp_id == second.cp_id:
                    # Already impossible: FinalDecision rejects this within one
                    # decision. Guarded anyway so a future relaxation there cannot
                    # turn into a self-contradiction reported here.
                    continue
                findings.append(
                    ConsistencyFinding(
                        rule=ConsistencyRule.EVIDENCE_POLARITY_FLIP,
                        case_id=case_id,
                        cp_ids=(first.cp_id, second.cp_id),
                        labels=(first.label, second.label),
                        basis=atom_id,
                        detail=(
                            f"atom {atom_id} supports {first.cp_id} ({first.label}) but is "
                            f"cited as contrary evidence by {second.cp_id} ({second.label}), "
                            f"and both rest on {_format_basis(units)}; one chain has the "
                            "document's polarity backwards"
                        ),
                    )
                )
    return findings


def _check_applicability(verdicts: list[CaseVerdict], case_id: str) -> list[ConsistencyFinding]:
    """P0b — checking points sharing any unit must agree on whether it binds.

    Reported once per ``(unit, pair)`` rather than once per unit so the output names
    the two checking points a reviewer has to open.
    """

    findings: list[ConsistencyFinding] = []
    by_unit: dict[str, list[CaseVerdict]] = defaultdict(list)
    for verdict in verdicts:
        if verdict.applicability in {
            Applicability.APPLICABLE.value,
            Applicability.NOT_APPLICABLE.value,
        }:
            for unit_id in verdict.unit_ids:
                by_unit[unit_id].append(verdict)

    for unit_id, sharing in sorted(by_unit.items()):
        applicable = [
            verdict for verdict in sharing if verdict.applicability == Applicability.APPLICABLE.value
        ]
        inapplicable = [
            verdict
            for verdict in sharing
            if verdict.applicability == Applicability.NOT_APPLICABLE.value
        ]
        for first in applicable:
            for second in inapplicable:
                findings.append(
                    ConsistencyFinding(
                        rule=ConsistencyRule.SHARED_UNIT_APPLICABILITY_CONFLICT,
                        case_id=case_id,
                        cp_ids=(first.cp_id, second.cp_id),
                        labels=(first.label, second.label),
                        basis=unit_id,
                        detail=(
                            f"{unit_id} is APPLICABLE for {first.cp_id} but NOT_APPLICABLE for "
                            f"{second.cp_id}; whether a provision binds this occupier is a "
                            "property of the provision and the farm, not of the checking point"
                        ),
                    )
                )
    return findings


def check_case(verdicts: list[CaseVerdict]) -> ConsistencyReport:
    """Run P0-P1 over one case's verdicts."""

    if not verdicts:
        return ConsistencyReport(case_id="")

    report = ConsistencyReport(
        case_id=verdicts[0].case_id,
        n_verdicts=len(verdicts),
        n_blocked=sum(1 for verdict in verdicts if not verdict.label),
        n_review_required=sum(1 for verdict in verdicts if verdict.review_required),
        label_counts=dict(Counter(verdict.label or "<blocked>" for verdict in verdicts)),
    )

    # Group by identical policy basis. Verdicts with no units (a blocked cell, or a
    # pack that never resolved a unit) are excluded: an empty basis is not evidence
    # that two checking points read the same provision, it is absence of evidence,
    # and grouping on it would pair everything with everything.
    groups: dict[frozenset[str], list[CaseVerdict]] = defaultdict(list)
    for verdict in verdicts:
        if verdict.unit_ids:
            groups[verdict.basis_key].append(verdict)

    report.n_basis_groups = len(groups)
    for units, group in sorted(groups.items(), key=lambda item: sorted(item[0])):
        if sum(1 for verdict in group if verdict.is_substantive) >= 2:
            report.n_comparable_groups += 1
        report.findings.extend(_check_identical_basis(group, units, report.case_id))
        report.findings.extend(_check_polarity_flip(group, units, report.case_id))

    report.findings.extend(_check_applicability(verdicts, report.case_id))
    return report


def check_all(verdicts: list[CaseVerdict]) -> tuple[list[ConsistencyReport], dict[str, Any]]:
    """Run P0-P1 per case and summarise across cases."""

    grouped: dict[str, list[CaseVerdict]] = defaultdict(list)
    for verdict in verdicts:
        grouped[verdict.case_id].append(verdict)

    reports = [check_case(group) for _, group in sorted(grouped.items())]
    rule_counts: Counter[str] = Counter()
    for report in reports:
        for rule, count in report.by_rule().items():
            rule_counts[rule] += count

    n_cells = sum(report.n_verdicts for report in reports)
    n_blocked = sum(report.n_blocked for report in reports)
    summary = {
        "n_cases": len(reports),
        "n_cases_with_findings": sum(1 for report in reports if not report.ok),
        "findings_by_rule": dict(rule_counts),
        "n_findings": sum(len(report.findings) for report in reports),
        "n_cells": n_cells,
        # A low contradiction count means nothing if most cells never produced a
        # verdict, or if no two checking points were ever comparable. Both
        # denominators travel with the numerator so the figure cannot be quoted
        # without them.
        "n_blocked_cells": n_blocked,
        "n_review_required_cells": sum(report.n_review_required for report in reports),
        "n_comparable_groups": sum(report.n_comparable_groups for report in reports),
        "contradiction_rate_per_case": (
            round(sum(len(report.findings) for report in reports) / len(reports), 3)
            if reports
            else 0.0
        ),
    }
    return reports, summary
