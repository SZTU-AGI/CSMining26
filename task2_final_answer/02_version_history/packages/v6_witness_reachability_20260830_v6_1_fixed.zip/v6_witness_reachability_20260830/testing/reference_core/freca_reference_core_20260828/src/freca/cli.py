"""FRECA command line: reproduce every stage from a clean checkout.

    python -m freca.cli manifest  --cases <dir>
    python -m freca.cli evidence  --cases <dir> --policy differentiated
    python -m freca.cli policy    --rules <pdf> --checkpoints <xlsx>
    python -m freca.cli run       --config configs/default.yaml

Design rules this file follows
-------------------------------
* **Every stage writes artefacts and a report** under ``artifacts/runs/<run_id>/``.
  Nothing is printed and discarded, because the freeze document requires that an
  observation only counts as an experiment once its inputs, outputs and config
  are on disk.
* **A failed gate is a non-zero exit code.** M0 returning 99 cases instead of 100
  must stop the run, not colour a log line — silent continuation past a broken
  manifest is how 4 100 decisions get built on the wrong case list.
* **Read-only inputs stay read-only.** The dataset directory is only ever opened
  for reading; all writes go under the run directory.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from collections import Counter
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any

from freca.evidence.admissibility import IdentityPolicy
from freca.evidence.pipeline import build_case_evidence
from freca.manifest.build import build_manifest, validate_manifest

DEFAULT_RUN_ROOT = Path("artifacts/runs")


def _default(value: Any) -> Any:
    if is_dataclass(value) and not isinstance(value, type):
        return asdict(value)
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json")
    if isinstance(value, set):
        return sorted(value)
    return str(value)


def write_json(path: Path, payload: Any) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True, default=_default),
        encoding="utf-8",
    )
    return path


def write_jsonl(path: Path, rows: list[Any]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as stream:
        for row in rows:
            stream.write(json.dumps(row, ensure_ascii=False, default=_default) + "\n")
    return path


def _run_dir(run_id: str | None, root: Path) -> Path:
    run_id = run_id or time.strftime("%Y%m%dT%H%M%S")
    path = root / run_id
    path.mkdir(parents=True, exist_ok=True)
    return path


# --------------------------------------------------------------------------
# M0
# --------------------------------------------------------------------------


def cmd_manifest(args: argparse.Namespace) -> int:
    out = _run_dir(args.run_id, Path(args.run_root))
    manifest = build_manifest(args.cases, hash_files=not args.no_hash)
    report = validate_manifest(manifest, args.cases)

    write_json(out / "manifest.json", manifest.to_dict())
    write_json(out / "manifest_report.json", report.to_dict())

    print(f"logical cases : {report.n_logical_cases}")
    print(f"files indexed : {report.n_files}  (skipped {report.n_skipped_files})")
    print(f"track counts  : {report.track_counts}")
    print(f"incomplete    : {report.incomplete_cases or 'none'}")
    print(f"split folders : {report.split_cases or 'none'}")
    print(f"artefacts     : {out}")
    if not report.ok:
        print("\nM0 GATE FAILED:", file=sys.stderr)
        for failure in report.failures:
            print(f"  - {failure}", file=sys.stderr)
        return 2
    print("M0 gate: PASS")
    return 0


# --------------------------------------------------------------------------
# E0-E3
# --------------------------------------------------------------------------


def cmd_evidence(args: argparse.Namespace) -> int:
    out = _run_dir(args.run_id, Path(args.run_root))
    manifest = build_manifest(args.cases, hash_files=False)
    report = validate_manifest(manifest, args.cases)
    if not report.ok and not args.force:
        print("M0 gate failed; refusing to build evidence on a broken case list.", file=sys.stderr)
        for failure in report.failures:
            print(f"  - {failure}", file=sys.stderr)
        return 2

    policy = IdentityPolicy(args.policy)
    cases = manifest.cases[: args.limit] if args.limit else manifest.cases

    summaries: list[dict[str, Any]] = []
    totals = Counter()
    reasons = Counter()
    started = time.perf_counter()

    for case in cases:
        evidence = build_case_evidence(case, policy=policy)
        summaries.append(evidence.to_dict())
        totals["admissible_atoms"] += len(evidence.admissible_atoms)
        totals["inadmissible_atoms"] += len(evidence.inadmissible_atoms)
        totals["parse_errors"] += sum(1 for d in evidence.documents if d.parse_error)
        for document in evidence.documents:
            reasons[document.admissibility.reason.value] += 1
        if args.dump_atoms:
            write_jsonl(
                out / "atoms" / f"{case.case_id}.jsonl",
                [atom.model_dump(mode="json") for atom in evidence.admissible_atoms],
            )

    elapsed = time.perf_counter() - started
    summary = {
        "identity_policy": policy.value,
        "n_cases": len(cases),
        "totals": dict(totals),
        "admissibility_reasons": dict(reasons),
        "seconds": round(elapsed, 1),
    }
    write_json(out / f"evidence_summary_{policy.value}.json", summary)
    write_jsonl(out / f"evidence_cases_{policy.value}.jsonl", summaries)

    print(f"policy        : {policy.value}")
    print(f"cases         : {len(cases)}")
    print(f"atoms         : {totals['admissible_atoms']} admissible / "
          f"{totals['inadmissible_atoms']} inadmissible")
    print(f"reasons       : {dict(reasons)}")
    print(f"parse errors  : {totals['parse_errors']}")
    print(f"elapsed       : {elapsed:.1f}s")
    print(f"artefacts     : {out}")
    return 1 if totals["parse_errors"] else 0


def cmd_identity_ablation(args: argparse.Namespace) -> int:
    """Run all three identity policies side by side — frozen decision (7)."""

    out = _run_dir(args.run_id, Path(args.run_root))
    manifest = build_manifest(args.cases, hash_files=False)
    cases = manifest.cases[: args.limit] if args.limit else manifest.cases

    table: dict[str, dict[str, Any]] = {}
    for policy in IdentityPolicy:
        totals = Counter()
        reasons = Counter()
        excluded_tracks = Counter()
        for case in cases:
            evidence = build_case_evidence(case, policy=policy)
            totals["admissible_atoms"] += len(evidence.admissible_atoms)
            totals["inadmissible_atoms"] += len(evidence.inadmissible_atoms)
            for document in evidence.documents:
                reasons[document.admissibility.reason.value] += 1
                if not document.admissibility.admissible:
                    excluded_tracks[document.track] += 1
        table[policy.value] = {
            "totals": dict(totals),
            "reasons": dict(reasons),
            "excluded_tracks": dict(sorted(excluded_tracks.items())),
        }

    write_json(out / "identity_ablation.json", table)
    print(f"{'policy':16} {'admissible':>12} {'inadmissible':>14}  excluded tracks")
    for name, row in table.items():
        print(
            f"{name:16} {row['totals'].get('admissible_atoms', 0):>12} "
            f"{row['totals'].get('inadmissible_atoms', 0):>14}  {row['excluded_tracks']}"
        )
    print(f"\nartefacts     : {out}")
    return 0


# --------------------------------------------------------------------------
# R0-R1
# --------------------------------------------------------------------------


def cmd_policy(args: argparse.Namespace) -> int:
    from freca.policy.anchor import (
        ANCHOR_CONFIGS,
        _pool_for_config,
        anchor_checking_points,
        dump_anchor_run,
        load_checking_points,
        out_of_scope_rate,
    )
    from freca.policy.norm_graph import NormGraph
    from freca.policy.sectionize import load_regulation_text, sectionize

    out = _run_dir(args.run_id, Path(args.run_root))
    sections = sectionize(load_regulation_text(args.rules))
    checking_points = load_checking_points(args.checkpoints)
    graph = NormGraph(sections)

    results = anchor_checking_points(sections, checking_points, top_k=args.top_k)
    paths = dump_anchor_run(out / "policy", sections, checking_points, results)

    print(f"sections parsed : {len(sections)}")
    print(f"checking points : {len(checking_points)}")
    print(f"{'config':8} {'pool':>6} {'out-of-scope top-1':>20}")
    summary: dict[str, Any] = {}
    for config in ANCHOR_CONFIGS:
        count, offenders = out_of_scope_rate(results[config], graph)
        pool = len(_pool_for_config(graph, config))
        summary[config] = {"pool": pool, "out_of_scope": count, "offenders": offenders}
        print(f"{config:8} {pool:>6} {f'{count}/{len(checking_points)}':>20}")
    write_json(out / "policy" / "anchor_summary_cli.json", {"paths": paths, "configs": summary})
    print(f"artefacts       : {out / 'policy'}")
    return 0


# --------------------------------------------------------------------------


def cmd_packs(args: argparse.Namespace) -> int:
    """Build R1 PolicyPacks and report the pack-construction ablation.

    The three configs are reported side by side because the choice between them is
    an empirical one, not a preference: ``section_level`` implements the discarded
    "one obligation per section" reading, ``unit_level`` addresses obligations at
    their own subsection path, and the model-assisted variant adds gap-filling
    whose paraphrase-rejection rate is reported rather than assumed to be zero.
    """

    from freca.llm.backends import FakeJSONLLM
    from freca.policy.anchor import anchor_checking_points, load_checking_points
    from freca.policy.norm_graph import NormGraph
    from freca.policy.pack import PACK_CONFIGS, extract_pack
    from freca.policy.sectionize import load_regulation_text, sectionize

    out = _run_dir(args.run_id, Path(args.run_root))
    sections = sectionize(load_regulation_text(args.rules))
    checking_points = load_checking_points(args.checkpoints)
    graph = NormGraph(sections)
    anchors = anchor_checking_points(
        sections, checking_points, configs=(args.anchor_config,), top_k=args.top_k
    )[args.anchor_config]

    configs = PACK_CONFIGS if args.config == "all" else (args.config,)
    # The offline fake keeps the model-assisted path runnable with no key and no
    # network. A real backend is opted into explicitly; it is never the default,
    # so a run can never quietly depend on credentials that are not in the ZIP.
    backend = FakeJSONLLM() if "unit_level_model_assisted" in configs else None

    summary: dict[str, Any] = {}
    for config in configs:
        rows: list[dict[str, Any]] = []
        adjudicable = 0
        review = 0
        multi = 0
        consulted = 0
        rejected: list[dict[str, str]] = []
        unfilled = Counter()
        facts = 0
        for checking_point, anchor in zip(checking_points, anchors, strict=True):
            extraction = extract_pack(
                checking_point=checking_point,
                anchor_section_ids=anchor.ranking,
                graph=graph,
                policy_version=args.policy_version,
                backend=backend,
                config=config,
            )
            rows.append({"cp_id": checking_point.cp_id, **extraction.to_dict()})
            if extraction.model_consulted:
                consulted += 1
            if extraction.adjudicable:
                adjudicable += 1
                facts += len(extraction.pack.required_facts) + len(
                    extraction.pack.violation_facts
                )
                if len(extraction.chosen_unit_ids) > 1:
                    multi += 1
            else:
                for slot in extraction.unfilled_slots:
                    unfilled[slot] += 1
            if extraction.review_required:
                review += 1
            for unit_id, reason in extraction.rejected_companions:
                rejected.append(
                    {"cp_id": checking_point.cp_id, "unit_id": unit_id, "reason": reason}
                )

        write_jsonl(out / "policy" / f"packs_{config}.jsonl", rows)
        summary[config] = {
            "adjudicable": adjudicable,
            "n_checking_points": len(checking_points),
            "review_required": review,
            "multi_unit_packs": multi,
            "mean_facts_per_pack": round(facts / adjudicable, 3) if adjudicable else 0.0,
            "model_consulted": consulted,
            "model_paraphrase_rejections": sum(
                len(row["model_rejected"]) for row in rows
            ),
            "model_abstentions": sum(len(row["model_abstained"]) for row in rows),
            "unfilled_slots": dict(unfilled),
            "rejected_companions": rejected,
        }

    write_json(out / "policy" / "pack_summary.json", summary)
    if backend is not None and getattr(backend, "call_records", None):
        write_jsonl(out / "policy" / "model_calls.jsonl", backend.call_records)

    print(f"sections parsed : {len(sections)}")
    print(f"checking points : {len(checking_points)}")
    print(f"anchor config   : {args.anchor_config} (top-{args.top_k})")
    print(f"\n{'config':30}{'adjudicable':>12}{'review':>8}{'multi':>7}{'facts/pack':>12}")
    for config, row in summary.items():
        coverage = f"{row['adjudicable']}/{row['n_checking_points']}"
        print(
            f"{config:30}{coverage:>12}{row['review_required']:>8}"
            f"{row['multi_unit_packs']:>7}{row['mean_facts_per_pack']:>12}"
        )
    for config, row in summary.items():
        if row["unfilled_slots"]:
            print(f"\n{config} could not fill: {row['unfilled_slots']}")
        if config != "section_level" and "model" in config:
            # State this plainly. A model-assisted config that was never consulted
            # scoring the same as the deterministic one is not evidence that the
            # model helped; it is evidence that it was not asked.
            print(
                f"\n{config}: model consulted on {row['model_consulted']}/"
                f"{row['n_checking_points']} checking points, "
                f"{row['model_paraphrase_rejections']} paraphrase rejection(s), "
                f"{row['model_abstentions']} abstention(s)"
            )
            if not row["model_consulted"]:
                print(
                    "  → deterministic patterns filled every slot, so this config "
                    "is currently identical to unit_level by construction."
                )
            elif not row["model_paraphrase_rejections"] and row["model_abstentions"]:
                print(
                    "  → the backend declined every slot it was asked for. With the "
                    "offline fake this is expected (it answers from a hash, not from "
                    "the statute); the grounding check is untested until a real "
                    "backend is configured."
                )
        for item in row["rejected_companions"]:
            print(f"  {config}: excluded {item['unit_id']} from {item['cp_id']} — {item['reason']}")
    print(f"\nartefacts       : {out / 'policy'}")

    # A config that adjudicates nothing is a broken run, not a finding.
    return 0 if any(row["adjudicable"] for row in summary.values()) else 2


# --------------------------------------------------------------------------


# --------------------------------------------------------------------------
# C0-C7 + P0-P2
# --------------------------------------------------------------------------


def _build_audit_backend(args: argparse.Namespace) -> Any:
    """Construct the reading backend for an audit run, or ``None``.

    Keys are read from the environment only, never from a config file or from the
    shipped package — the competition disqualifies a submission that embeds one.
    ``--backend fake`` is the offline path and is what makes the chain runnable on
    a server with no network; the run-mode gate is what stops its output from
    being mistaken for a result.
    """

    from freca.llm.backends import build_backend

    if args.backend == "none":
        return None
    spec: dict[str, Any] = {
        "backend": args.backend,
        "model_name": args.model_name,
        "temperature": args.temperature,
    }
    if args.base_url:
        spec["base_url"] = args.base_url
    if args.api_key_env:
        spec["api_key_env"] = args.api_key_env
    return build_backend(spec)


def cmd_audit(args: argparse.Namespace) -> int:
    """Run the full chain for every case and assemble the submission.

    This is the command that produces the graded artefact, so it is also the
    command that has to be honest about what it produced. Its output passes
    through :func:`freca.evaluation.assess_run` before anything is exported, and
    in ``--mode production`` or ``--mode evaluation`` a run that reached its
    verdicts without a real model reading is ``RUN_INVALID``: no workbook is
    written and the exit code is non-zero.

    That is deliberately harsher than the previous behaviour, which printed
    warnings above a perfectly well-formed workbook. Warnings were not enough —
    a measured run produced 120 synthetic decisions, 98% of them labelled "1",
    with every gate reporting PASS and the file passing every format check.
    """

    from freca.audit.nodes.adjudicate import adjudicate
    from freca.audit.nodes.farm_profile import build_farm_profile
    from freca.consistency import (
        BLOCKED_FILL,
        assemble_submission,
        check_all,
        verdict_from_result,
    )
    from freca.evaluation import RunMode, assess_run
    from freca.evidence.pipeline import build_case_evidence
    from freca.policy.anchor import anchor_checking_points, load_checking_points
    from freca.policy.norm_graph import NormGraph
    from freca.policy.pack import extract_pack
    from freca.policy.sectionize import load_regulation_text, sectionize
    from freca.retrieval.evidence_index import CaseEvidenceIndex

    mode = RunMode(args.mode)
    out = _run_dir(args.run_id, Path(args.run_root))
    manifest = build_manifest(args.cases, hash_files=False)
    report = validate_manifest(manifest, args.cases)
    if not report.ok and not args.force:
        print("M0 gate failed; refusing to audit on a broken case list.", file=sys.stderr)
        for failure in report.failures:
            print(f"  - {failure}", file=sys.stderr)
        return 2

    try:
        backend = _build_audit_backend(args)
    except Exception as error:  # noqa: BLE001 - surfaced to the operator verbatim
        print(f"cannot construct backend {args.backend!r}: {error}", file=sys.stderr)
        return 2
    # Do not reject ``backend=none`` here.  A strict run with no reader must
    # still traverse the chain and persist ``run_health.json`` with its blocked
    # cells and honest coverage.  Returning early would hide the very failure
    # the run-mode gate is meant to make observable.

    sections = sectionize(load_regulation_text(args.rules))
    checking_points = load_checking_points(args.checkpoints)
    if args.cp_ids:
        requested = tuple(args.cp_ids)
        available = {checking_point.cp_id for checking_point in checking_points}
        missing = [cp_id for cp_id in requested if cp_id not in available]
        if missing:
            print(f"unknown checking point(s): {missing}", file=sys.stderr)
            return 2
        checking_points = [
            checking_point for checking_point in checking_points if checking_point.cp_id in requested
        ]
    graph = NormGraph(sections)
    anchors = anchor_checking_points(
        sections, checking_points, configs=(args.anchor_config,), top_k=args.top_k
    )[args.anchor_config]

    # Packs are built once for all cases: the policy chain does not depend on the
    # farm. Rebuilding them per case would multiply the cost by 100 and, worse,
    # would let a pack differ between cases for no legitimate reason.
    packs: dict[str, Any] = {}
    for checking_point, anchor in zip(checking_points, anchors, strict=True):
        packs[checking_point.cp_id] = (
            extract_pack(
                checking_point=checking_point,
                anchor_section_ids=anchor.ranking,
                graph=graph,
                policy_version=args.policy_version,
                backend=None,
                config=args.pack_config,
            ),
            anchor.ranking,
        )

    cases = manifest.cases[: args.limit] if args.limit else manifest.cases
    policy = IdentityPolicy(args.policy)
    all_verdicts = []
    rows: list[dict[str, Any]] = []
    blocked_nodes = Counter()
    n_cells_attempted = 0
    farm_profiles: list[dict[str, Any]] = []
    started = time.perf_counter()

    for case in cases:
        evidence = build_case_evidence(case, policy=policy)
        index = CaseEvidenceIndex(evidence.admissible_atoms)
        profile_object = build_farm_profile(evidence)
        farm_profiles.append(profile_object.to_dict())
        # Pass the typed A0 profile into C1.  Its mapping boundary remains
        # available for legacy fixtures, but production runs retain the profile
        # object and its provenance throughout the applicability decision.
        profile = profile_object

        for checking_point in checking_points:
            n_cells_attempted += 1
            extraction, anchor_ranking = packs[checking_point.cp_id]
            if extraction.pack is None:
                # No adjudicable pack: recorded as a blocked cell rather than
                # skipped, so the count reaches the submission report.
                blocked_nodes["R1"] += 1
                continue
            result = adjudicate(
                case_id=case.case_id,
                cp_id=checking_point.cp_id,
                pack=extraction.pack,
                anchor_section_ids=anchor_ranking,
                graph=graph,
                profile=profile,
                index=index,
                backend=backend,
                config_name=args.evidence_config,
            )
            if result.blocked_at:
                blocked_nodes[result.blocked_at] += 1
            all_verdicts.append(
                verdict_from_result(
                    result,
                    element=checking_point.element,
                    subsection=checking_point.subsection,
                    unit_ids=tuple(extraction.chosen_unit_ids),
                )
            )
            rows.append(result.to_dict())

    elapsed = time.perf_counter() - started
    write_jsonl(out / "farm_profiles.jsonl", farm_profiles)
    write_jsonl(out / "decisions.jsonl", rows)
    if backend is not None and getattr(backend, "call_records", None):
        write_jsonl(out / "model_calls.jsonl", backend.call_records)

    reports, consistency_summary = check_all(all_verdicts)
    write_jsonl(out / "consistency_cases.jsonl", [item.to_dict() for item in reports])
    write_json(out / "consistency_summary.json", consistency_summary)

    # The run is judged before the workbook is written. Assembling first and then
    # deciding whether to keep it would leave an invalid submission on disk, and a
    # file on disk is a file that eventually gets uploaded.
    n_blocked_cells = sum(1 for verdict in all_verdicts if not verdict.label)
    health = assess_run(
        mode=mode,
        n_cells_attempted=n_cells_attempted,
        decisions=rows,
        n_blocked_filled=n_blocked_cells,
    )

    print(f"cases          : {len(cases)}")
    print(f"decisions      : {len(all_verdicts)}  in {elapsed:.1f}s")
    for line in health.summary_lines():
        print(line)

    if health.export_blocked:
        write_json(
            out / "run_health.json",
            {
                "health": health.to_dict(),
                "n_cases": len(cases),
                "cp_ids": [checking_point.cp_id for checking_point in checking_points],
                "n_decisions": len(all_verdicts),
                "consistency": consistency_summary,
                "blocked_at_nodes": dict(blocked_nodes),
                "submission_written": False,
                "seconds": round(elapsed, 1),
            },
        )
        print(
            "\nRUN_INVALID — no submission written. The chain completed and the "
            "artefacts are on disk for inspection, but these numbers do not measure "
            "the system and must not be exported or scored.",
            file=sys.stderr,
        )
        print(f"artefacts      : {out}")
        return 3

    submission = assemble_submission(
        all_verdicts,
        cases,
        template_path=args.template,
        output_path=out / "submission.xlsx",
        expected_cases=None if args.limit else 100,
        allow_missing_verdicts=True,
    )
    write_json(out / "submission_report.json", submission.to_dict())
    write_json(
        out / "run_health.json",
        {
            "health": health.to_dict(),
            "n_cases": len(cases),
            "cp_ids": [checking_point.cp_id for checking_point in checking_points],
            "n_decisions": len(all_verdicts),
            "label_counts": submission.label_counts,
            "blocked_at_nodes": dict(blocked_nodes),
            "n_blocked_cells": submission.n_blocked,
            "n_review_cells": len(submission.review_cells),
            "candidate_only": submission.candidate_only,
            "consistency": consistency_summary,
            "submission_written": True,
            "seconds": round(elapsed, 1),
        },
    )

    print(f"label counts   : {submission.label_counts}")
    print(
        f"blocked cells  : {submission.n_blocked} filled with {BLOCKED_FILL!r} placeholder "
        "(each one listed in submission_report.json, none counted in scored cells)"
    )
    if blocked_nodes:
        print(f"blocked at     : {dict(blocked_nodes)}")
    print(f"review cells   : {len(submission.review_cells)}")
    print(f"contradictions : {consistency_summary['n_findings']} across "
          f"{consistency_summary['n_cases_with_findings']} case(s); "
          f"{consistency_summary['n_comparable_groups']} comparable group(s)")
    if consistency_summary["findings_by_rule"]:
        print(f"  by rule      : {consistency_summary['findings_by_rule']}")
    elif not consistency_summary["n_comparable_groups"]:
        print("  → zero contradictions with zero comparable groups means the check "
              "never had anything to compare, not that the verdicts agree.")
    if submission.candidate_only:
        print("  → submission marked CANDIDATE ONLY; see notes in submission_report.json")
    print(f"artefacts      : {out}")
    return 0


# --------------------------------------------------------------------------
# V0 evaluation
# --------------------------------------------------------------------------


def cmd_evaluate(args: argparse.Namespace) -> int:
    """Evaluate an existing run without changing its original artefacts."""

    from freca.evaluation import evaluate_run_directory

    run_dir = Path(args.run_dir)
    if not run_dir.is_dir():
        print(f"run directory not found: {run_dir}", file=sys.stderr)
        return 2
    try:
        report = evaluate_run_directory(
            run_dir,
            gold_path=args.gold,
            perturbed_decisions_path=args.perturbed_decisions,
            prompt_path=args.prompts,
        )
    except (OSError, ValueError, json.JSONDecodeError) as error:
        print(f"V0 evaluation failed: {error}", file=sys.stderr)
        return 2
    output = write_json(run_dir / "v0_report.json", report)
    write_json(run_dir / "summary.json", report)
    write_json(run_dir / "stage_metrics.json", report["stage_metrics"])
    write_jsonl(run_dir / "predictions.jsonl", report["predictions"])
    write_jsonl(run_dir / "error_cases.jsonl", report["error_cases"])
    print(f"gold status   : {report['gold']['status']}")
    if report["gold"]["accuracy"] is not None:
        print(f"accuracy      : {report['gold']['accuracy']:.1%}")
    else:
        print("accuracy      : not scored")
    if "perturbation" in report:
        print(f"stability     : {report['perturbation']['stability']}")
    print(f"leakage       : {report['leakage']['status']}")
    print(f"artefacts     : {output}")
    return 3 if report["leakage"]["status"] == "FAIL" else 0


# --------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    # Imported here rather than at module scope so that ``freca.cli manifest``
    # does not pay for the policy stack, but at function scope rather than inside
    # a command because the choices below are part of the parser's contract.
    from freca.evaluation import RunMode
    from freca.policy.anchor import ANCHOR_CONFIGS
    from freca.policy.pack import PACK_CONFIGS

    parser = argparse.ArgumentParser(prog="freca", description=__doc__)
    parser.add_argument("--run-root", default=str(DEFAULT_RUN_ROOT))
    parser.add_argument("--run-id", default=None)
    sub = parser.add_subparsers(dest="command", required=True)

    manifest = sub.add_parser("manifest", help="build and gate the 100 logical cases")
    manifest.add_argument("--cases", required=True)
    manifest.add_argument("--no-hash", action="store_true", help="skip file hashing (faster)")
    manifest.set_defaults(func=cmd_manifest)

    evidence = sub.add_parser("evidence", help="parse documents into evidence atoms")
    evidence.add_argument("--cases", required=True)
    evidence.add_argument(
        "--policy",
        default=IdentityPolicy.DIFFERENTIATED.value,
        choices=[policy.value for policy in IdentityPolicy],
    )
    evidence.add_argument("--limit", type=int, default=0)
    evidence.add_argument("--dump-atoms", action="store_true")
    evidence.add_argument("--force", action="store_true", help="continue past a failed M0 gate")
    evidence.set_defaults(func=cmd_evidence)

    ablation = sub.add_parser("identity-ablation", help="compare the three identity policies")
    ablation.add_argument("--cases", required=True)
    ablation.add_argument("--limit", type=int, default=0)
    ablation.set_defaults(func=cmd_identity_ablation)

    policy = sub.add_parser("policy", help="sectionise the rules and anchor the checking points")
    policy.add_argument("--rules", required=True)
    policy.add_argument("--checkpoints", required=True)
    policy.add_argument("--top-k", type=int, default=5)
    policy.set_defaults(func=cmd_policy)

    packs = sub.add_parser("packs", help="build R1 policy packs and run the pack ablation")
    packs.add_argument("--rules", required=True)
    packs.add_argument("--checkpoints", required=True)
    packs.add_argument(
        "--config",
        default="all",
        choices=["all", *PACK_CONFIGS],
        help="pack construction config; 'all' runs the ablation",
    )
    packs.add_argument(
        "--anchor-config",
        default="PC",
        choices=list(ANCHOR_CONFIGS),
        help="which anchoring config supplies the candidate sections",
    )
    packs.add_argument("--top-k", type=int, default=3)
    packs.add_argument("--policy-version", default="2021")
    packs.set_defaults(func=cmd_packs)

    evaluate = sub.add_parser("evaluate", help="run V0 evaluation on an existing audit run")
    evaluate.add_argument("--run-dir", required=True)
    evaluate.add_argument("--gold", default=None, help="JSONL/JSON/CSV/TSV gold labels")
    evaluate.add_argument(
        "--perturbed-decisions",
        default=None,
        help="decisions.jsonl from a controlled perturbation run",
    )
    evaluate.add_argument(
        "--prompts",
        default=None,
        help="persisted prompt records for explicit leakage checks",
    )
    evaluate.set_defaults(func=cmd_evaluate)

    audit = sub.add_parser("audit", help="run C0-C7 + P0-P2 and assemble the submission")
    audit.add_argument("--cases", required=True)
    audit.add_argument("--rules", required=True)
    audit.add_argument("--checkpoints", required=True)
    audit.add_argument("--template", required=True, help="official submission_template.xlsx")
    audit.add_argument(
        "--policy",
        default=IdentityPolicy.DIFFERENTIATED.value,
        choices=[policy.value for policy in IdentityPolicy],
    )
    audit.add_argument("--pack-config", default="unit_level", choices=list(PACK_CONFIGS))
    audit.add_argument("--anchor-config", default="PC", choices=list(ANCHOR_CONFIGS))
    audit.add_argument("--evidence-config", default="full_identity_aware")
    audit.add_argument(
        "--mode",
        default="dev",
        choices=[item.value for item in RunMode],
        help=(
            "dev permits synthetic decisions and still writes a workbook; "
            "evaluation/production hard-block export when any decision was "
            "reached without a real model reading"
        ),
    )
    audit.add_argument(
        "--backend",
        default="none",
        choices=["none", "fake", "openai", "openai_compatible", "vllm", "ollama"],
        help="'none' produces blocked cells only; 'fake' is the deterministic offline backend",
    )
    audit.add_argument("--model-name", default="fake-offline-v1")
    audit.add_argument("--base-url", default=None, help="OpenAI-compatible endpoint")
    audit.add_argument(
        "--api-key-env",
        default="FRECA_LLM_API_KEY",
        help="name of the environment variable holding the key; the key itself is never an argument",
    )
    audit.add_argument("--temperature", type=float, default=0.0)
    audit.add_argument("--top-k", type=int, default=3)
    audit.add_argument(
        "--cp-ids",
        nargs="+",
        default=None,
        help="optional CP subset for a reproducible vertical-slice run (e.g. CP2 CP10 CP22)",
    )
    audit.add_argument("--policy-version", default="2021")
    audit.add_argument(
        "--limit",
        type=int,
        default=0,
        help="audit only the first N cases; also waives the 100-case submission gate",
    )
    audit.add_argument("--force", action="store_true", help="continue past a failed M0 gate")
    audit.set_defaults(func=cmd_audit)

    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
