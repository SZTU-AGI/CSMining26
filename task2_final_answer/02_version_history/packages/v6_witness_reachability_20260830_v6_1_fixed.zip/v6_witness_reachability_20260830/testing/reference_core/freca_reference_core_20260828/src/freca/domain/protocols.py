"""Stable interfaces that keep workflow nodes and retrieval backends replaceable."""

from __future__ import annotations

from typing import Any, Protocol

from freca.domain.models import ArtifactEnvelope, ArtifactRecord, ArtifactRef, GateReport


class ArtifactStore(Protocol):
    def put(self, envelope: ArtifactEnvelope, payload: Any) -> ArtifactRef: ...

    def get(self, artifact_type: str, artifact_id: str) -> ArtifactRecord: ...


class Validator(Protocol):
    name: str

    def validate(self, value: Any) -> GateReport: ...

