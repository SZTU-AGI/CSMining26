"""V0 evaluation primitives.

V0 never treats a missing gold set as a score.  It returns an explicit
``NO_GOLD`` status and keeps the run-health/coverage numbers separate from
accuracy.  The module is dependency-light so it can run in the server-side
JupyterLab environment before optional spreadsheet tooling is installed.
"""

from __future__ import annotations

import csv
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Mapping

VALID_LABELS = frozenset({"1", "0", "N/A"})
Key = tuple[str, str]


def _key(row: Mapping[str, Any]) -> Key:
    case_id = str(row.get("case_id", "")).strip()
    cp_id = str(row.get("cp_id", "")).strip()
    if not case_id or not cp_id:
        raise ValueError("evaluation rows require non-empty case_id and cp_id")
    return case_id, cp_id


def _label(value: Any) -> str:
    label = str(value).strip()
    if label not in VALID_LABELS:
        raise ValueError(f"invalid evaluation label: {label!r}")
    return label


def _read_rows(path: str | Path) -> list[dict[str, Any]]:
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix in {".jsonl", ".ndjson"}:
        return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if suffix == ".json":
        payload = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(payload, dict):
            payload = payload.get("rows", payload.get("labels", payload))
        if not isinstance(payload, list):
            raise ValueError("JSON gold/decision input must be a list or an object containing rows")
        return payload
    if suffix in {".csv", ".tsv"}:
        delimiter = "\t" if suffix == ".tsv" else ","
        with path.open("r", encoding="utf-8", newline="") as stream:
            return list(csv.DictReader(stream, delimiter=delimiter))
    raise ValueError(f"unsupported V0 input format {suffix!r}; use JSONL, JSON, CSV, or TSV")


def load_labels(path: str | Path) -> dict[Key, str]:
    """Load and validate ``case_id, cp_id, label`` rows."""

    labels: dict[Key, str] = {}
    for row in _read_rows(path):
        key = _key(row)
        if key in labels:
            raise ValueError(f"duplicate evaluation row: {key}")
        raw_label = row.get("label")
        if raw_label is None or not str(raw_label).strip():
            raw_label = row.get("gold_label")
        labels[key] = _label(raw_label)
    return labels


@dataclass(slots=True)
class GoldEvaluation:
    status: str
    n_gold: int = 0
    n_compared: int = 0
    n_correct: int = 0
    missing_predictions: list[str] = field(default_factory=list)
    extra_predictions: list[str] = field(default_factory=list)
    confusion: dict[str, dict[str, int]] = field(default_factory=dict)
    note: str | None = None

    @property
    def accuracy(self) -> float | None:
        return self.n_correct / self.n_compared if self.n_compared else None

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "n_gold": self.n_gold,
            "n_compared": self.n_compared,
            "n_correct": self.n_correct,
            "accuracy": round(self.accuracy, 4) if self.accuracy is not None else None,
            "missing_predictions": list(self.missing_predictions),
            "extra_predictions": list(self.extra_predictions),
            "confusion": self.confusion,
            "note": self.note,
        }


def evaluate_gold(
    decisions: Iterable[Mapping[str, Any]],
    gold: Mapping[Key, str] | None,
) -> GoldEvaluation:
    """Score only non-blank predictions; blocked cells never become 0."""

    if gold is None:
        return GoldEvaluation(
            status="NO_GOLD",
            note="no gold labels supplied; report run health and coverage, not accuracy",
        )

    predictions: dict[Key, str] = {}
    for row in decisions:
        label = str(row.get("label", "")).strip()
        if not label:
            continue
        key = _key(row)
        if key in predictions:
            raise ValueError(f"duplicate decided cell: {key}")
        predictions[key] = _label(label)

    missing = sorted(gold.keys() - predictions.keys())
    extra = sorted(predictions.keys() - gold.keys())
    confusion: dict[str, dict[str, int]] = {
        expected: {predicted: 0 for predicted in sorted(VALID_LABELS)}
        for expected in sorted(VALID_LABELS)
    }
    correct = 0
    for key in sorted(gold.keys() & predictions.keys()):
        expected = _label(gold[key])
        predicted = predictions[key]
        confusion[expected][predicted] += 1
        correct += predicted == expected

    return GoldEvaluation(
        status="SCORED" if not missing and not extra else "PARTIAL",
        n_gold=len(gold),
        n_compared=len(gold.keys() & predictions.keys()),
        n_correct=correct,
        missing_predictions=[f"{case}/{cp}" for case, cp in missing],
        extra_predictions=[f"{case}/{cp}" for case, cp in extra],
        confusion=confusion,
        note=(
            "accuracy denominator is compared, non-blank decisions only; "
            "report alongside decision coverage"
        ),
    )


@dataclass(slots=True)
class PerturbationEvaluation:
    n_pairs: int
    n_changed: int
    changed_cells: list[str] = field(default_factory=list)
    note: str = "stability is descriptive; it is not accuracy without gold labels"

    @property
    def stability(self) -> float | None:
        return 1.0 - self.n_changed / self.n_pairs if self.n_pairs else None

    def to_dict(self) -> dict[str, Any]:
        return {
            "n_pairs": self.n_pairs,
            "n_changed": self.n_changed,
            "stability": round(self.stability, 4) if self.stability is not None else None,
            "changed_cells": list(self.changed_cells),
            "note": self.note,
        }


def compare_perturbations(
    baseline: Iterable[Mapping[str, Any]],
    perturbed: Iterable[Mapping[str, Any]],
) -> PerturbationEvaluation:
    """Compare labels for the same cells before/after a controlled perturbation."""

    def decided(rows: Iterable[Mapping[str, Any]]) -> dict[Key, str]:
        result: dict[Key, str] = {}
        for row in rows:
            label = str(row.get("label", "")).strip()
            if label:
                result[_key(row)] = _label(label)
        return result

    left = decided(baseline)
    right = decided(perturbed)
    keys = sorted(left.keys() & right.keys())
    changed = [f"{case}/{cp}" for case, cp in keys if left[(case, cp)] != right[(case, cp)]]
    return PerturbationEvaluation(len(keys), len(changed), changed)


LEAKAGE_MARKERS = (
    "gold label",
    "ground truth",
    "answer key",
    "expected answer",
    "reference label",
    "oracle label",
)


@dataclass(slots=True)
class LeakageFinding:
    location: str
    marker: str

    def to_dict(self) -> dict[str, str]:
        return {"location": self.location, "marker": self.marker}


def detect_prompt_leakage(records: Iterable[Mapping[str, Any]]) -> list[LeakageFinding]:
    """Find explicit label-oracle language in persisted prompt records."""

    findings: list[LeakageFinding] = []
    for index, record in enumerate(records):
        text = json.dumps(record, ensure_ascii=False, sort_keys=True).lower()
        for marker in LEAKAGE_MARKERS:
            if marker in text:
                findings.append(LeakageFinding(location=f"row[{index}]", marker=marker))
    return findings


def evaluate_run_directory(
    run_dir: str | Path,
    *,
    gold_path: str | Path | None = None,
    perturbed_decisions_path: str | Path | None = None,
    prompt_path: str | Path | None = None,
) -> dict[str, Any]:
    """Build a serializable V0 report from an existing run directory."""

    run_dir = Path(run_dir)
    decisions = _read_rows(run_dir / "decisions.jsonl")
    health_path = run_dir / "run_health.json"
    health = json.loads(health_path.read_text(encoding="utf-8")) if health_path.exists() else None
    gold = load_labels(gold_path) if gold_path else None
    gold_result = evaluate_gold(decisions, gold)
    decided = [row for row in decisions if str(row.get("label", "")).strip()]
    blocked = [row for row in decisions if not str(row.get("label", "")).strip()]
    blocked_by_node: dict[str, int] = {}
    for row in blocked:
        node = str(row.get("blocked_at") or "UNKNOWN")
        blocked_by_node[node] = blocked_by_node.get(node, 0) + 1

    trace_gate_counts: dict[str, dict[str, int]] = {}
    for row in decisions:
        for trace in row.get("traces", []):
            node = str(trace.get("node", "UNKNOWN"))
            gate_decision = str(trace.get("decision", "UNKNOWN"))
            trace_gate_counts.setdefault(node, {})[gate_decision] = (
                trace_gate_counts.setdefault(node, {}).get(gate_decision, 0) + 1
            )

    error_cases: list[dict[str, Any]] = [
        {
            "case_id": row.get("case_id"),
            "cp_id": row.get("cp_id"),
            "kind": "BLOCKED",
            "blocked_at": row.get("blocked_at"),
        }
        for row in blocked
    ]
    if gold is not None:
        predicted = {
            _key(row): str(row.get("label", "")).strip()
            for row in decided
        }
        for key in sorted(gold):
            expected = gold[key]
            actual = predicted.get(key, "")
            if actual != expected:
                error_cases.append(
                    {
                        "case_id": key[0],
                        "cp_id": key[1],
                        "kind": "MISSING_PREDICTION" if not actual else "MISCLASSIFIED",
                        "expected": expected,
                        "predicted": actual or None,
                    }
                )

    stage_metrics = {
        "n_rows": len(decisions),
        "n_decided": len(decided),
        "n_blocked": len(blocked),
        "blocked_by_node": blocked_by_node,
        "trace_gate_decisions": trace_gate_counts,
        "label_counts": {
            label: sum(1 for row in decided if str(row.get("label")) == label)
            for label in sorted(VALID_LABELS)
        },
        "coverage": (health or {}).get("health", {}).get("decision_coverage"),
        "scored_cells": (health or {}).get("health", {}).get("scored_cells"),
        "synthetic_rate": (health or {}).get("health", {}).get("synthetic_rate"),
        "model_calls": sum(1 for _ in _read_rows(run_dir / "model_calls.jsonl"))
        if (run_dir / "model_calls.jsonl").exists()
        else 0,
    }
    report: dict[str, Any] = {
        "v0_version": "0.1",
        "gold": gold_result.to_dict(),
        "run_health": health,
        "stage_metrics": stage_metrics,
        "predictions": decisions,
        "error_cases": error_cases,
    }
    if perturbed_decisions_path:
        report["perturbation"] = compare_perturbations(
            decisions, _read_rows(perturbed_decisions_path)
        ).to_dict()
    prompt_source = Path(prompt_path) if prompt_path else run_dir / "model_calls.jsonl"
    if prompt_source.exists():
        findings = detect_prompt_leakage(_read_rows(prompt_source))
        report["leakage"] = {
            "status": "FAIL" if findings else "PASS",
            "findings": [finding.to_dict() for finding in findings],
            "source": str(prompt_source),
        }
    else:
        report["leakage"] = {
            "status": "NOT_RUN",
            "findings": [],
            "note": "no persisted prompt record supplied",
        }
    return report


__all__ = [
    "GoldEvaluation",
    "LeakageFinding",
    "PerturbationEvaluation",
    "compare_perturbations",
    "detect_prompt_leakage",
    "evaluate_gold",
    "evaluate_run_directory",
    "load_labels",
]
