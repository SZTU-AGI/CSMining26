"""XLSX reader for the T3/T9 registers, producing addressable rows.

Measured layout (all 200 workbooks, 2026-07-31)
------------------------------------------------
Sheet names are **completely uniform**: every T3 workbook has exactly
``Cover / Pest Activity Log / Bait Station Register / Chemical Storage Register /
Establishment Condition`` and every T9 workbook has exactly
``1. Receival Register … 7. Record Archive Register``. 1 100 of the 1 200 sheets
put their header on **row 3** (row 1 = sheet title, row 2 = an establishment
line); the remaining 100 are precisely the T3 ``Cover`` sheets, which are
key-value rather than tabular.

Even so the header row is **detected, not hardcoded**: a layout change would
otherwise silently shift every column label by one and corrupt every locator.
The detector's answer is exposed as ``header_row`` so a deviation is visible in
the artefacts instead of being absorbed.

Row 2 matters disproportionately: it carries the establishment name
(``Kimberley Cotton Ginning``, ``Establishment: Highplains …``) and is where the
identity-mismatch signal lives for the spreadsheet tracks. It is preserved as
``subtitle`` rather than skipped as decoration.

Locators use real spreadsheet coordinates (``sheet`` + ``cell_range`` such as
``A4:F4``) because that is what a human re-checking the citation would type into
the name box.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

#: A tabular header needs at least this many populated, textual cells.
MIN_HEADER_CELLS = 3
#: Rows searched when looking for the header.
HEADER_SEARCH_ROWS = 6


class XlsxParseError(RuntimeError):
    """Raised when a workbook cannot be read."""


def _cell_to_text(value: object) -> str:
    if value is None:
        return ""
    if isinstance(value, datetime):
        return value.date().isoformat() if value.time() == datetime.min.time() else value.isoformat()
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def _normalise_header(value: str) -> str:
    """Headers wrap across lines (``'Receival\\nDate'``); collapse to one line."""

    return " ".join(value.split())


@dataclass(slots=True)
class SheetRow:
    """One record row, addressable and paired with its column headers."""

    row_index: int
    cell_range: str
    values: list[str]
    headers: list[str]

    def as_mapping(self) -> dict[str, str]:
        return {
            header: value
            for header, value in zip(self.headers, self.values, strict=False)
            if header and value
        }

    def as_text(self) -> str:
        return "; ".join(f"{k}: {v}" for k, v in self.as_mapping().items())


@dataclass(slots=True)
class SheetTable:
    sheet_name: str
    title: str
    subtitle: str
    header_row: int | None
    headers: list[str] = field(default_factory=list)
    rows: list[SheetRow] = field(default_factory=list)
    #: ``Cover``-style sheets: left column is a label, right column a value.
    key_values: dict[str, str] = field(default_factory=dict)

    @property
    def kind(self) -> str:
        return "records" if self.header_row is not None else "key_value"

    def to_dict(self) -> dict[str, object]:
        return {
            "sheet_name": self.sheet_name,
            "kind": self.kind,
            "title": self.title,
            "subtitle": self.subtitle,
            "header_row": self.header_row,
            "headers": self.headers,
            "n_rows": len(self.rows),
            "key_values": self.key_values,
        }


@dataclass(slots=True)
class XlsxDocument:
    path: str
    source_hash: str
    sheets: list[SheetTable] = field(default_factory=list)

    @property
    def file_name(self) -> str:
        return Path(self.path).name

    def sheet(self, name: str) -> SheetTable | None:
        for sheet in self.sheets:
            if sheet.sheet_name == name:
                return sheet
        return None

    def text(self) -> str:
        pieces: list[str] = []
        for sheet in self.sheets:
            pieces.append(f"[{sheet.sheet_name}] {sheet.title} {sheet.subtitle}".strip())
            for key, value in sheet.key_values.items():
                pieces.append(f"{key}: {value}")
            if sheet.headers:
                pieces.append(" | ".join(sheet.headers))
            pieces.extend(" | ".join(row.values) for row in sheet.rows)
        return "\n".join(piece for piece in pieces if piece.strip())


def _sha256_file(path: Path, *, chunk: int = 1 << 20) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(chunk):
            digest.update(block)
    return f"sha256:{digest.hexdigest()}"


def _detect_header_row(grid: list[list[str]]) -> int | None:
    """First row that looks like column labels: >=3 populated, all non-numeric."""

    for offset, row in enumerate(grid[:HEADER_SEARCH_ROWS]):
        populated = [cell for cell in row if cell]
        if len(populated) < MIN_HEADER_CELLS:
            continue
        if any(cell.replace(".", "", 1).replace("-", "", 1).isdigit() for cell in populated):
            continue
        return offset + 1
    return None


def read_xlsx(path: str | Path) -> XlsxDocument:
    """Parse a workbook into per-sheet tables with spreadsheet-native locators."""

    file_path = Path(path)
    try:
        workbook = load_workbook(file_path, data_only=True, read_only=True)
    except Exception as error:  # openpyxl raises a wide range of types
        raise XlsxParseError(f"not a readable xlsx: {file_path}") from error

    document = XlsxDocument(path=str(file_path), source_hash=_sha256_file(file_path))
    try:
        for worksheet in workbook.worksheets:
            grid = [
                [_cell_to_text(cell) for cell in row]
                for row in worksheet.iter_rows(values_only=True)
            ]
            title = grid[0][0] if grid and grid[0] else ""
            subtitle = grid[1][0] if len(grid) > 1 and grid[1] else ""
            header_row = _detect_header_row(grid)

            table = SheetTable(
                sheet_name=worksheet.title,
                title=title,
                subtitle=subtitle,
                header_row=header_row,
            )

            if header_row is None:
                # Key-value sheet: take the first two columns as label/value.
                for row in grid:
                    if len(row) >= 2 and row[0] and row[1]:
                        table.key_values[_normalise_header(row[0])] = row[1]
                document.sheets.append(table)
                continue

            headers = [_normalise_header(cell) for cell in grid[header_row - 1]]
            while headers and not headers[-1]:
                headers.pop()
            table.headers = headers
            width = len(headers)
            last_column = get_column_letter(width) if width else "A"

            for offset, row in enumerate(grid[header_row:], start=header_row + 1):
                values = [row[i] if i < len(row) else "" for i in range(width)]
                if not any(values):
                    continue
                table.rows.append(
                    SheetRow(
                        row_index=offset,
                        cell_range=f"A{offset}:{last_column}{offset}",
                        values=values,
                        headers=headers,
                    )
                )
            document.sheets.append(table)
    finally:
        workbook.close()
    return document
