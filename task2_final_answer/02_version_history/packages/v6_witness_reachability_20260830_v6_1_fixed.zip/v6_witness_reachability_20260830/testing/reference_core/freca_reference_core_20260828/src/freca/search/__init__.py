"""Layer 9 equal-budget search laboratory."""

from freca.search.registry import SearchStrategy, default_search_arm_registry

__all__ = ["SearchStrategy", "default_search_arm_registry"]
