from __future__ import annotations

import unittest

from freca.policy.definitions import build_definition_index
from freca.policy.extract import _page_lines
from freca.policy.furniture import classify_policy_lines
from freca.policy.hierarchy import build_policy_units, build_section_occurrences
from freca.policy.schemas_v2 import ExtractedPolicyText, PolicyPage, PolicyUnitType, ToolFingerprint

HASH = "sha256:" + "1" * 64


def extracted_fixture() -> ExtractedPolicyText:
    page_1 = (
        "Chapter 4—Registered establishments\n"
        "Part 2—Conditions of registration\n\n"
        "4-7A Establishment must be kept in appropriate condition\n"
        "          (1) A registered establishment must be kept in a condition:\n"
        "               (a) appropriate for operations; and\n"
        "                Example: explanatory only.\n"
        "          (2) Without limiting subsection (1):\n"
        "               (a) clean; and\n"
    )
    page_2 = (
        "Chapter 4 Registered establishments\n"
        "Part 2 Conditions of registration\n"
        "Section 4-7B\n\n"
        "                    (b) pests controlled; and\n"
        "                    (c) waste treated.\n\n"
        "4-7B Plants must be traced\n"
        "                Plants must be traced.\n"
    )
    lines_1 = _page_lines(1, page_1)
    lines_2 = _page_lines(2, page_2)
    lines = [*lines_1, *lines_2]
    tool = ToolFingerprint(
        tool="fixture", version="1", executable_path="fixture", executable_sha256=HASH
    )
    extracted = ExtractedPolicyText(
        source_id="source-rules",
        source_pdf_sha256=HASH,
        page_count=2,
        pages=[
            PolicyPage(
                physical_page=1,
                raw_text=page_1,
                normalized_text=page_1,
                raw_sha256=HASH,
                line_ids=[line.line_id for line in lines_1],
            ),
            PolicyPage(
                physical_page=2,
                raw_text=page_2,
                normalized_text=page_2,
                raw_sha256=HASH,
                line_ids=[line.line_id for line in lines_2],
            ),
        ],
        lines=lines,
        pdftotext=tool,
        pdfinfo=tool,
        extraction_sha256=HASH,
    )
    return extracted.model_copy(update={"lines": classify_policy_lines(extracted)})


class PolicyHierarchyV2Tests(unittest.TestCase):
    def test_cross_page_enumeration_stays_under_previous_section(self) -> None:
        extracted = extracted_fixture()
        occurrences, issues, _toc = build_section_occurrences(extracted.lines)
        self.assertFalse(any(issue.severity == "FATAL" for issue in issues))
        units, hierarchy_issues = build_policy_units(
            lines=extracted.lines,
            pages=extracted.pages,
            occurrences=occurrences,
            source_pdf_sha256=HASH,
        )
        self.assertFalse(any(issue.severity == "FATAL" for issue in hierarchy_issues))
        by_citation = {unit.citation: unit for unit in units}
        self.assertEqual(by_citation["4-7A(2)(b)"].unit_type, PolicyUnitType.PARAGRAPH)
        self.assertEqual(by_citation["4-7A(2)(b)"].parent_id, by_citation["4-7A(2)"].unit_id)
        self.assertEqual(by_citation["4-7A(1):example:1"].normative, False)
        self.assertIn("4-7B", by_citation)

    def test_definition_items_are_separate_and_keep_their_children(self) -> None:
        raw = (
            "1-6 Definitions\n"
            "                container means a container that is:\n"
            "                  (a) durable; and\n"
            "                  (b) enclosed.\n"
        )
        lines = _page_lines(1, raw)
        tool = ToolFingerprint(
            tool="fixture", version="1", executable_path="fixture", executable_sha256=HASH
        )
        extracted = ExtractedPolicyText(
            source_id="source-rules",
            source_pdf_sha256=HASH,
            page_count=1,
            pages=[
                PolicyPage(
                    physical_page=1,
                    raw_text=raw,
                    normalized_text=raw,
                    raw_sha256=HASH,
                    line_ids=[line.line_id for line in lines],
                )
            ],
            lines=lines,
            pdftotext=tool,
            pdfinfo=tool,
            extraction_sha256=HASH,
        )
        classified = classify_policy_lines(extracted)
        units = build_policy_units(
            lines=classified,
            pages=extracted.pages,
            occurrences=build_section_occurrences(classified)[0],
            source_pdf_sha256=HASH,
        )[0]
        definitions = build_definition_index(units)
        self.assertEqual([item.defined_term_normalized for item in definitions], ["container"])
        definition_unit = next(
            unit for unit in units if unit.unit_type is PolicyUnitType.DEFINITION_ITEM
        )
        self.assertEqual(len(definition_unit.child_ids), 2)

    def test_uncertain_table_is_preserved_as_raw_nonflattened_unit(self) -> None:
        raw = (
            "1-8 Table provision\n"
            "          (8) The following table sets out amounts.\n"
            "Item      Column 1                  Column 2\n"
            "1         Apples                    400\n"
            "2         Either:                   5\n"
            "              (a) berries; and\n"
            "              (b) cherries.\n"
            "          (9) In the table, apple means fruit.\n"
        )
        lines = _page_lines(1, raw)
        tool = ToolFingerprint(
            tool="fixture", version="1", executable_path="fixture", executable_sha256=HASH
        )
        extracted = ExtractedPolicyText(
            source_id="source-rules",
            source_pdf_sha256=HASH,
            page_count=1,
            pages=[
                PolicyPage(
                    physical_page=1,
                    raw_text=raw,
                    normalized_text=raw,
                    raw_sha256=HASH,
                    line_ids=[line.line_id for line in lines],
                )
            ],
            lines=lines,
            pdftotext=tool,
            pdfinfo=tool,
            extraction_sha256=HASH,
        )
        classified = classify_policy_lines(extracted)
        units, issues = build_policy_units(
            lines=classified,
            pages=extracted.pages,
            occurrences=build_section_occurrences(classified)[0],
            source_pdf_sha256=HASH,
        )
        table = next(unit for unit in units if unit.unit_type is PolicyUnitType.TABLE)
        self.assertIn("(a) berries", table.full_raw_text)
        self.assertIn("(b) cherries", table.full_raw_text)
        self.assertIn("1-8(9)", {unit.citation for unit in units})
        self.assertEqual(
            [issue.issue_code for issue in issues],
            ["L1_TABLE_PARSE_UNCERTAIN"],
        )


if __name__ == "__main__":
    unittest.main()
