"""Definition index derived only from replayable PolicyUnit text."""

from __future__ import annotations

import re

from freca.policy.schemas_v2 import DefinitionEntry, PolicyUnit, PolicyUnitType

_DEFINITION = re.compile(
    r"^\s*(?P<term>.+?)\s+(?P<operator>means|includes)(?::|\s+)"
    r"(?P<definition>.*)$",
    re.I | re.S,
)


def build_definition_index(units: list[PolicyUnit]) -> list[DefinitionEntry]:
    entries: list[DefinitionEntry] = []
    for unit in units:
        if unit.unit_type is not PolicyUnitType.DEFINITION_ITEM:
            continue
        match = _DEFINITION.match(unit.own_raw_text)
        if match is None:
            continue
        term = " ".join(match.group("term").split())
        entries.append(
            DefinitionEntry(
                unit_id=unit.unit_id,
                defined_term_raw=term,
                defined_term_normalized=_normalize_term(term),
                operator=match.group("operator").upper(),
                definition_text=" ".join(match.group("definition").split()),
                child_unit_ids=unit.child_ids,
                locator=unit.locator,
            )
        )
    return sorted(entries, key=lambda item: (item.defined_term_normalized, item.unit_id))


def _normalize_term(value: str) -> str:
    return re.sub(r"\s+", " ", value.casefold()).strip(" ,")
