"""Exclusive immutable RunManifest and RunCompletion persistence."""

from __future__ import annotations

import json
import os
from pathlib import Path

from pydantic import ValidationError

from freca.governance.hashing import normalize_for_hash
from freca.governance.models import RunCompletion, RunManifest


class RunLedgerError(ValueError):
    pass


class RunLedger:
    def __init__(self, run_root: str | Path, run_id: str) -> None:
        self.run_id = run_id
        self.run_dir = Path(run_root).resolve() / run_id
        self.manifest_path = self.run_dir / "run-manifest.json"
        self.completion_path = self.run_dir / "run-completion.json"

    def create_manifest(self, manifest: RunManifest) -> Path:
        if manifest.run_id != self.run_id:
            raise RunLedgerError("manifest run_id does not match ledger")
        self.run_dir.mkdir(parents=True, exist_ok=True)
        self._exclusive_write(self.manifest_path, manifest.model_dump(mode="python"))
        return self.manifest_path

    def write_completion(self, completion: RunCompletion) -> Path:
        if completion.run_id != self.run_id:
            raise RunLedgerError("completion run_id does not match ledger")
        if not self.manifest_path.is_file():
            raise RunLedgerError("cannot complete a run without an immutable manifest")
        self._exclusive_write(self.completion_path, completion.model_dump(mode="python"))
        return self.completion_path

    def read_manifest(self) -> RunManifest:
        try:
            return RunManifest.model_validate_json(self.manifest_path.read_text(encoding="utf-8"))
        except (OSError, ValidationError) as error:
            raise RunLedgerError("cannot read a valid run manifest") from error

    @staticmethod
    def _exclusive_write(path: Path, value: object) -> None:
        encoded = (
            json.dumps(
                normalize_for_hash(value),
                ensure_ascii=False,
                sort_keys=True,
                indent=2,
            )
            + "\n"
        ).encode("utf-8")
        try:
            with path.open("xb") as stream:
                stream.write(encoded)
                stream.flush()
                os.fsync(stream.fileno())
        except FileExistsError as error:
            raise RunLedgerError(f"immutable run file already exists: {path.name}") from error
