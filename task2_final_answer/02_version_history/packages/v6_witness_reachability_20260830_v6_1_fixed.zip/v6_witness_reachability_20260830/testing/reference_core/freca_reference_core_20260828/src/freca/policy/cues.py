"""Neutral cue index; cues are annotations, never semantic attack edges."""

from __future__ import annotations

import re

from freca.governance.hashing import sha256_digest
from freca.policy.schemas_v2 import PolicyCue, PolicyUnit

_CUES: tuple[tuple[str, re.Pattern[str]], ...] = (
    ("DEONTIC", re.compile(r"\b(?:must not|must never|must|may only|is required to)\b", re.I)),
    ("EXCEPTION", re.compile(r"\b(?:unless|except|does not apply)\b", re.I)),
    ("DEEMING", re.compile(r"\b(?:is taken to|taken to have complied)\b", re.I)),
    (
        "TEMPORAL",
        re.compile(r"\b(?:within|for at least|no later than|before the end of|at least)\b", re.I),
    ),
    ("CONDITION", re.compile(r"\b(?:if|where|when|provided that)\b", re.I)),
)


def build_cue_index(units: list[PolicyUnit]) -> list[PolicyCue]:
    cues: list[PolicyCue] = []
    for unit in units:
        for cue_type, pattern in _CUES:
            for match in pattern.finditer(unit.own_raw_text):
                digest = sha256_digest(
                    {
                        "unit_id": unit.unit_id,
                        "cue_type": cue_type,
                        "offset": match.start(),
                        "raw_text": match.group(0),
                    }
                )
                cues.append(
                    PolicyCue(
                        cue_id=f"cue-{digest.split(':', 1)[1][:24]}",
                        unit_id=unit.unit_id,
                        cue_type=cue_type,
                        raw_text=match.group(0),
                        locator=unit.locator,
                    )
                )
    return sorted(cues, key=lambda item: (item.unit_id, item.cue_id))
