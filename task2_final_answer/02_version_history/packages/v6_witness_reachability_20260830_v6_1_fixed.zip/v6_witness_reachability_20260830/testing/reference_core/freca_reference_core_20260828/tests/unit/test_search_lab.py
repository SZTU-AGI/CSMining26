from __future__ import annotations

import unittest

from pydantic import ValidationError

from freca.search.gate import decide_search_route
from freca.search.models import SearchBudget, SearchMove, SearchObservation, SearchState
from freca.search.registry import SearchStrategy, default_search_arm_registry
from freca.search.runner import run_search_arm


class TinyEvidenceEnvironment:
    def initial_state(self) -> SearchState:
        return SearchState(
            state_id="state-root",
            depth=0,
            unresolved_goal_ids=["goal-a", "goal-b"],
        )

    def propose(self, state, *, limit, strategy):
        moves = []
        for goal in state.unresolved_goal_ids[:limit]:
            moves.append(
                SearchMove(
                    move_id=f"move-{state.depth}-{goal}",
                    action_signature=f"sig-{state.depth}-{goal}",
                    action_type="VALIDATE_CITATION",
                    target_goal_id=goal,
                    expected_signal_types=["CITATION_VALIDATION"],
                    model_score=0.99,
                    generated_by_model=True,
                )
            )
        return moves

    def apply(self, state, move):
        unresolved = [goal for goal in state.unresolved_goal_ids if goal != move.target_goal_id]
        signal_id = f"signal-{move.target_goal_id}"
        child = SearchState(
            state_id=f"state-{state.depth + 1}-{move.target_goal_id}",
            depth=state.depth + 1,
            artifact_ids=[*state.artifact_ids, signal_id],
            resolved_goal_ids=[*state.resolved_goal_ids, move.target_goal_id],
            unresolved_goal_ids=unresolved,
            action_history=[*state.action_history, move.action_signature],
            terminal=not unresolved,
        )
        observation = SearchObservation(
            observation_id=f"obs-{move.move_id}",
            move_id=move.move_id,
            verified_external_signal_ids=[signal_id],
            new_artifact_ids=[signal_id],
            validator_passed=True,
            external_reward=1.0,
        )
        return child, observation

    def reflect(self, state, move, observation):
        return "Check the remaining unresolved goal using an independent source."


class SearchRegistryTests(unittest.TestCase):
    def test_every_frozen_b00_to_b17_arm_is_registered_once(self) -> None:
        registry = default_search_arm_registry()
        self.assertEqual(len(registry), 18)
        self.assertEqual({item.strategy for item in registry}, set(SearchStrategy))

    def test_every_registered_arm_runs_under_the_same_budget_and_emits_no_label(self) -> None:
        environment = TinyEvidenceEnvironment()
        budget = SearchBudget(max_expansions=5, max_depth=2, branch_factor=2, beam_width=2)
        for strategy in SearchStrategy:
            with self.subTest(strategy=strategy.value):
                result = run_search_arm(environment, strategy, budget)
                self.assertLessEqual(result.expansions, budget.max_expansions)
                self.assertFalse(result.final_label_emitted)
                self.assertGreaterEqual(result.verified_signal_gain, 1)

    def test_lats_reflection_is_logged_but_never_evidence(self) -> None:
        result = run_search_arm(
            TinyEvidenceEnvironment(),
            SearchStrategy.B16_LATS_MCTS_EXTERNAL_VALUE,
            SearchBudget(max_expansions=3, max_depth=2),
        )
        self.assertTrue(any(step.reflection_text for step in result.trace_steps))
        self.assertTrue(all(not step.reflection_is_evidence for step in result.trace_steps))

    def test_model_score_cannot_create_positive_reward_without_external_signal(self) -> None:
        with self.assertRaises(ValidationError):
            SearchObservation(
                observation_id="obs-self-score",
                move_id="move-self-score",
                validator_passed=True,
                external_reward=1.0,
            )

    def test_search_gate_withholds_pruning_from_unvalidated_discriminator(self) -> None:
        decision = decide_search_route(
            deterministic_repair_available=False,
            task_requires_multistep_planning=True,
            external_signal_environment_available=True,
            discriminator_validated_in_domain=False,
        )
        self.assertEqual(decision.route, "SEARCH_RESEARCH_NO_PRUNING")
        self.assertFalse(decision.permanent_pruning_allowed)


if __name__ == "__main__":
    unittest.main()
