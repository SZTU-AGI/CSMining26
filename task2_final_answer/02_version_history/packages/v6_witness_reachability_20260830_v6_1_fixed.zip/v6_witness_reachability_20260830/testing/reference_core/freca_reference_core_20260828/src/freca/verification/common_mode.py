"""Record shared failure domains instead of treating agreement as truth."""

from __future__ import annotations

from pydantic import Field

from freca.domain.models import SafeId, StrictModel


class CommonModeFailureProfile(StrictModel):
    profile_id: SafeId
    component_a_id: SafeId
    component_b_id: SafeId
    parser_independent: bool
    query_independent: bool
    model_independent: bool
    tool_independent: bool
    shared_training_or_prompt_risk_codes: list[str] = Field(default_factory=list)
    deterministic_source_relation_validator_passed: bool = False
    independence_status: str
    reliance_permitted: bool


def assess_anchor_compiler_independence(
    *,
    profile_id: str,
    component_a_id: str,
    component_b_id: str,
    parser_independent: bool,
    query_independent: bool,
    model_independent: bool,
    deterministic_source_relation_validator_passed: bool,
    shared_training_or_prompt_risk_codes: list[str] | None = None,
) -> CommonModeFailureProfile:
    risks = shared_training_or_prompt_risk_codes or []
    required = (
        parser_independent
        and query_independent
        and model_independent
        and deterministic_source_relation_validator_passed
    )
    return CommonModeFailureProfile(
        profile_id=profile_id,
        component_a_id=component_a_id,
        component_b_id=component_b_id,
        parser_independent=parser_independent,
        query_independent=query_independent,
        model_independent=model_independent,
        tool_independent=False,
        shared_training_or_prompt_risk_codes=risks,
        deterministic_source_relation_validator_passed=(
            deterministic_source_relation_validator_passed
        ),
        independence_status=(
            "SEMANTICALLY_INDEPENDENT" if required else "ENGINEERING_AGREEMENT_ONLY"
        ),
        reliance_permitted=required,
    )
