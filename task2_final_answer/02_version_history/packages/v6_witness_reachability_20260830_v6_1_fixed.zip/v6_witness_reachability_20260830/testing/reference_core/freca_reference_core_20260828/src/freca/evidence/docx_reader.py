"""Dependency-free DOCX reader that preserves addressable coordinates.

Why stdlib instead of ``python-docx``
-------------------------------------
A DOCX is a ZIP of XML, and the target JupyterLab server's installed packages are
not under our control. Removing ``python-docx`` removes an install step from the
critical path of a competition run. The decision was taken only after checking
that the corpus needs none of what ``python-docx`` adds: across 175 sampled
documents there are **zero** occurrences of ``gridSpan``, ``vMerge``, ``w:sdt``
(content controls), ``w:hyperlink``, ``w:drawing``/``w:pict`` (images),
``w:ins``/``w:del`` (tracked changes) and ragged tables. The only inline
construct present is ``w:br``.

Two traps this reader exists to avoid
-------------------------------------
1. **Line breaks vanish under naive text joining.** ``"".join(w:t)`` turns the
   T1 cover block into ``REGISTERED ESTABLISHMENTEXPORT REGISTRATION RECORD``.
   There are 528 ``w:br`` elements in the 140-file sample, so this is not an edge
   case. ``w:br`` maps to ``\\n`` and ``w:tab`` to ``\\t``.
2. **Heading styles are not a reliable section signal.** Measured over 20 cases:
   T1/T4/T5/T6 carry ``Heading1``/``Heading2``, but **T2, T7 and T8 carry no
   heading style at all** — their sections are plain paragraphs numbered
   ``1.``/``2.``. A style-based segmenter would leave three of the seven DOCX
   tracks unsectioned. Segmentation therefore lives in ``segment.py`` and treats
   the numbering pattern as primary evidence with the style as corroboration.

Coordinates
-----------
``paragraph_index`` counts body-level paragraphs only, and ``table_index``
counts body-level tables only; both are stable, zero-based, and independent of
each other, which is what ``EvidenceLocator`` expects. ``block_order`` preserves
the interleaving so a table can be attributed to the heading above it.
"""

from __future__ import annotations

import hashlib
import zipfile
from dataclasses import dataclass, field
from pathlib import Path

from xml.etree import ElementTree as ET

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"

#: Elements that contribute characters to a paragraph's text, in document order.
_TEXT = f"{W}t"
_BREAK = f"{W}br"
_TAB = f"{W}tab"


class DocxParseError(RuntimeError):
    """Raised when a file is not a readable WordprocessingML package."""


@dataclass(slots=True)
class DocxParagraph:
    paragraph_index: int
    block_order: int
    style: str | None
    text: str

    @property
    def is_bullet(self) -> bool:
        return (self.style or "").startswith(("ListBullet", "ListParagraph", "ListNumber"))


@dataclass(slots=True)
class DocxTable:
    table_index: int
    block_order: int
    rows: list[list[str]] = field(default_factory=list)

    @property
    def n_rows(self) -> int:
        return len(self.rows)

    @property
    def n_cols(self) -> int:
        return max((len(row) for row in self.rows), default=0)

    @property
    def header(self) -> list[str]:
        return self.rows[0] if self.rows else []

    @property
    def body_rows(self) -> list[list[str]]:
        return self.rows[1:]

    def as_text(self) -> str:
        return "\n".join(" | ".join(cell.replace("\n", " ") for cell in row) for row in self.rows)


@dataclass(slots=True)
class DocxDocument:
    path: str
    source_hash: str
    paragraphs: list[DocxParagraph] = field(default_factory=list)
    tables: list[DocxTable] = field(default_factory=list)
    #: ``(block_order, kind, index)`` in body order; ``kind`` is ``"p"`` or ``"tbl"``.
    block_order: list[tuple[int, str, int]] = field(default_factory=list)

    @property
    def file_name(self) -> str:
        return Path(self.path).name

    def text(self) -> str:
        """Whole-document plain text in body order, tables rendered as pipe rows."""

        pieces: list[str] = []
        for _order, kind, index in self.block_order:
            if kind == "p":
                pieces.append(self.paragraphs[index].text)
            else:
                pieces.append(self.tables[index].as_text())
        return "\n".join(piece for piece in pieces if piece.strip())


def _paragraph_text(node: ET.Element) -> str:
    """Concatenate a paragraph's inline content, honouring breaks and tabs.

    ``Element.iter`` yields descendants in document order, which is what makes a
    single pass correct here.
    """

    out: list[str] = []
    for element in node.iter():
        if element.tag == _TEXT:
            out.append(element.text or "")
        elif element.tag == _BREAK:
            out.append("\n")
        elif element.tag == _TAB:
            out.append("\t")
    return "".join(out).strip()


def _paragraph_style(node: ET.Element) -> str | None:
    properties = node.find(f"{W}pPr")
    if properties is None:
        return None
    style = properties.find(f"{W}pStyle")
    if style is None:
        return None
    return style.get(f"{W}val")


def _cell_text(cell: ET.Element) -> str:
    """Cell text with one line per contained paragraph."""

    lines = [_paragraph_text(paragraph) for paragraph in cell.iter(f"{W}p")]
    return "\n".join(line for line in lines if line)


def _sha256_file(path: Path, *, chunk: int = 1 << 20) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(chunk):
            digest.update(block)
    return f"sha256:{digest.hexdigest()}"


def read_docx(path: str | Path) -> DocxDocument:
    """Parse a DOCX into paragraphs and tables with stable coordinates."""

    file_path = Path(path)
    try:
        with zipfile.ZipFile(file_path) as archive:
            xml = archive.read("word/document.xml")
    except (zipfile.BadZipFile, KeyError) as error:
        raise DocxParseError(f"not a readable docx: {file_path}") from error

    root = ET.fromstring(xml)
    body = root.find(f"{W}body")
    if body is None:
        raise DocxParseError(f"docx has no body: {file_path}")

    document = DocxDocument(path=str(file_path), source_hash=_sha256_file(file_path))
    for order, element in enumerate(body):
        if element.tag == f"{W}p":
            index = len(document.paragraphs)
            document.paragraphs.append(
                DocxParagraph(
                    paragraph_index=index,
                    block_order=order,
                    style=_paragraph_style(element),
                    text=_paragraph_text(element),
                )
            )
            document.block_order.append((order, "p", index))
        elif element.tag == f"{W}tbl":
            index = len(document.tables)
            rows = [
                [_cell_text(cell) for cell in row.findall(f"{W}tc")]
                for row in element.findall(f"{W}tr")
            ]
            document.tables.append(DocxTable(table_index=index, block_order=order, rows=rows))
            document.block_order.append((order, "tbl", index))
    return document
