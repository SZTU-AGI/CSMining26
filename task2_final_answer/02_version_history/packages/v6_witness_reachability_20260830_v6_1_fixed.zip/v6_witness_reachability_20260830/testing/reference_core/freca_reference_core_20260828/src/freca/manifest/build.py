"""M0: turn 99 physical case folders into 100 logical cases.

Verified dataset facts (bash-checked 2026-07-31 against the real directory)
--------------------------------------------------------------------------
* ``SFRE_cases/SFRE_cases/`` holds **99** folders and **898** substantive files
  (698 DOCX + 200 XLSX). Inside the folders there is exactly one non-evidence
  artefact, the Word lock file
  ``RE-NSW-2022-0130/~$HACCPPlan_26_Narromine_Grain_Storage_Pty_Ltd.docx``; a
  macOS ``.DS_Store`` sits at the root, outside any case folder. Skipped files
  are *reported*, not swallowed — an unexplained file count is a data-integrity
  signal.
* Track counts: T1 = 98, T2..T9 = 100 each.
* 96 folders are standard: 9 files, one per track.
* ``RE-QLD-2022-0077`` and ``RE-SA-2021-0066`` have 8 files — **T1 is absent**.
* ``RE-WA-2021-0077`` holds 18 files: two complete case packages
  (``035 Goldfields Grain Storage`` and ``100 Midwest Grain Holdings``). It must
  be split into two logical cases, giving 100.
* ``submission_template.xlsx`` contains only a 42-column header row, so the
  official case-id list has to be reconstructed here.
* **Independent confirmation of the reconstruction:** the serials carried by the
  filenames form a perfect bijection onto ``1..100`` — 100 distinct values, none
  missing, none duplicated. The dataset therefore declares 100 cases itself, and
  splitting ``RE-WA-2021-0077`` is the only grouping that recovers that bijection
  from 99 folders. ``validate_manifest`` asserts it via ``duplicate_serials``,
  which turns an accidental mis-grouping into a hard failure rather than a
  plausible-looking manifest.

The real filename convention
----------------------------
Not ``<RE number>_<Name>_T<k>_<title>`` (an earlier draft assumed that and
matched zero files). It is::

    <track digit> "_" <document type> "_" [<serial>] <establishment name> [_<serial>]

with the serial appearing *before* the name on tracks 1-3 and *after* it on
tracks 8-9, and absent on tracks 4-7::

    1_Farm_05_Darling_Downs_Grain_Pty_Ltd.docx
    4_Farm-Management-Plan_Darling_Downs_Grain_Pty_Ltd.docx
    8_Phytosanitary_Security_Procedure_Darling_Downs_Grain_Pty_Ltd_005.docx

The document-type prefix is **derived from the corpus**, not hardcoded: for each
track, the longest common ``_``-token prefix over all files of that track. On the
real data this yields exactly one prefix per track (``1_Farm``,
``6_Farms_Hygiene_Sanitation_Plan``, ``9_Traceability_Records``, ...), so the
establishment name is whatever remains. Hardcoding the nine document titles
would silently mis-parse the moment the organisers rename a template; deriving
them means a rename shows up as a prefix change in the report instead.

Why the establishment name is read from the filename
----------------------------------------------------
The split of ``RE-WA-2021-0077`` is only visible at filename level. More
importantly the *in-document* signature is precisely what E3 has to audit, so
reading document content here would leak E3's answer into the manifest. M0 is
therefore deliberately restricted to filesystem-level facts.

No repair
---------
The manifest never repairs, filters, or drops a case. A missing track is
recorded as ``missing_tracks`` and surfaces downstream as
``CASE_PACKAGE_INCOMPLETE`` — and only for those checking points that actually
need the absent track. Deleting an incomplete case, or forcing all of its
checking points to ``0``, would be the silent data repair the project owner
ruled out.
"""

from __future__ import annotations

import hashlib
import re
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path

#: Tracks are the leading ``N_`` of the filename, 1..9.
TRACK_PATTERN = re.compile(r"^(?P<track>[1-9])_")
RE_NUMBER_PATTERN = re.compile(r"RE-[A-Z]{2,3}-\d{4}-\d{4}")
SERIAL_PATTERN = re.compile(r"^\d{1,4}$")
EVIDENCE_SUFFIXES = frozenset({".docx", ".xlsx"})
ALL_TRACKS: tuple[str, ...] = tuple(f"T{i}" for i in range(1, 10))

#: Minimum distinct tracks a second establishment must own before a physical
#: folder is treated as shared. Guards against splitting on one mis-signed file.
SPLIT_MIN_TRACKS = 5


def _sha256_file(path: Path, *, chunk: int = 1 << 20) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(chunk):
            digest.update(block)
    return f"sha256:{digest.hexdigest()}"


def is_evidence_file(path: Path) -> bool:
    """Substantive case evidence, as opposed to OS or editor detritus."""

    name = path.name
    if name.startswith(("~$", ".", "_")):
        return False
    return path.suffix.lower() in EVIDENCE_SUFFIXES and TRACK_PATTERN.match(name) is not None


# --------------------------------------------------------------------------
# Filename parsing
# --------------------------------------------------------------------------


def derive_doc_prefixes(file_names: list[str]) -> dict[str, list[str]]:
    """``track -> longest common ``_``-token prefix`` over the whole corpus.

    Derived rather than declared so that a template rename is visible as a
    changed prefix in the manifest report instead of as silently truncated
    establishment names.
    """

    grouped: dict[str, list[list[str]]] = defaultdict(list)
    for name in file_names:
        match = TRACK_PATTERN.match(name)
        if match is None:
            continue
        stem = Path(name).stem
        grouped[f"T{match.group('track')}"].append(stem.split("_"))

    prefixes: dict[str, list[str]] = {}
    for track, token_lists in grouped.items():
        prefix = token_lists[0]
        for tokens in token_lists[1:]:
            length = 0
            while length < len(prefix) and length < len(tokens) and prefix[length] == tokens[length]:
                length += 1
            prefix = prefix[:length]
        # Token 0 is the track digit; it is always shared and never part of the
        # document type, but keeping it makes the prefix directly strippable.
        prefixes[track] = prefix
    return prefixes


@dataclass(slots=True)
class ParsedName:
    track: str
    doc_type: str
    serial: int | None
    establishment_name: str
    establishment_key: str


def parse_file_name(file_name: str, doc_prefixes: dict[str, list[str]]) -> ParsedName | None:
    """Split a case filename into track, document type, serial and establishment."""

    match = TRACK_PATTERN.match(file_name)
    if match is None:
        return None
    track = f"T{match.group('track')}"
    tokens = Path(file_name).stem.split("_")
    prefix = doc_prefixes.get(track, tokens[:2])
    if tokens[: len(prefix)] != prefix:
        return None
    remainder = tokens[len(prefix) :]

    serial: int | None = None
    while remainder and SERIAL_PATTERN.fullmatch(remainder[0]):
        serial = int(remainder[0])
        remainder = remainder[1:]
    while remainder and SERIAL_PATTERN.fullmatch(remainder[-1]):
        serial = int(remainder[-1]) if serial is None else serial
        remainder = remainder[:-1]
    if not remainder:
        return None

    name = " ".join(remainder)
    return ParsedName(
        track=track,
        doc_type=" ".join(prefix[1:]) or track,
        serial=serial,
        establishment_name=name,
        establishment_key=re.sub(r"[^a-z0-9]+", "", name.lower()),
    )


# --------------------------------------------------------------------------
# Manifest model
# --------------------------------------------------------------------------


@dataclass(slots=True)
class CaseFile:
    track: str
    path: str
    file_name: str
    source_hash: str
    doc_type: str
    declared_serial: int | None
    declared_establishment: str
    establishment_key: str

    def to_dict(self) -> dict[str, object]:
        return {
            "track": self.track,
            "path": self.path,
            "file_name": self.file_name,
            "source_hash": self.source_hash,
            "doc_type": self.doc_type,
            "declared_serial": self.declared_serial,
            "declared_establishment": self.declared_establishment,
            "establishment_key": self.establishment_key,
        }


@dataclass(slots=True)
class LogicalCase:
    case_id: str
    physical_dir: str
    re_number: str
    declared_establishment: str
    declared_serial: int | None
    files: list[CaseFile] = field(default_factory=list)
    missing_tracks: list[str] = field(default_factory=list)
    split_from_shared_dir: bool = False
    notes: list[str] = field(default_factory=list)

    @property
    def available_tracks(self) -> list[str]:
        return sorted({file.track for file in self.files})

    def file_for(self, track: str) -> CaseFile | None:
        for file in self.files:
            if file.track == track:
                return file
        return None

    def to_dict(self) -> dict[str, object]:
        return {
            "case_id": self.case_id,
            "physical_dir": self.physical_dir,
            "re_number": self.re_number,
            "declared_establishment": self.declared_establishment,
            "declared_serial": self.declared_serial,
            "available_tracks": self.available_tracks,
            "missing_tracks": self.missing_tracks,
            "split_from_shared_dir": self.split_from_shared_dir,
            "notes": self.notes,
            "files": [file.to_dict() for file in sorted(self.files, key=lambda f: f.track)],
        }


@dataclass(slots=True)
class Manifest:
    cases: list[LogicalCase]
    doc_prefixes: dict[str, list[str]]
    skipped_files: list[str]

    def to_dict(self) -> dict[str, object]:
        return {
            "doc_prefixes": {k: "_".join(v) for k, v in sorted(self.doc_prefixes.items())},
            "skipped_files": self.skipped_files,
            "n_cases": len(self.cases),
            "cases": [case.to_dict() for case in self.cases],
        }


def build_manifest(cases_root: str | Path, *, hash_files: bool = True) -> Manifest:
    """Scan the case root and return logical cases sorted by ``case_id``."""

    root = Path(cases_root)
    if not root.is_dir():
        raise FileNotFoundError(f"case root not found: {root}")

    directories = sorted(p for p in root.iterdir() if p.is_dir())
    all_paths = [p for directory in directories for p in sorted(directory.iterdir()) if p.is_file()]
    evidence = [p for p in all_paths if is_evidence_file(p)]
    skipped = [str(p.relative_to(root)) for p in all_paths if not is_evidence_file(p)]

    doc_prefixes = derive_doc_prefixes([p.name for p in evidence])

    logical: list[LogicalCase] = []
    for directory in directories:
        groups: dict[str, list[CaseFile]] = defaultdict(list)
        unparsed: list[str] = []
        for path in sorted(directory.iterdir()):
            if not path.is_file() or not is_evidence_file(path):
                continue
            parsed = parse_file_name(path.name, doc_prefixes)
            if parsed is None:
                unparsed.append(path.name)
                continue
            groups[parsed.establishment_key].append(
                CaseFile(
                    track=parsed.track,
                    path=str(path),
                    file_name=path.name,
                    source_hash=_sha256_file(path) if hash_files else "sha256:" + "0" * 64,
                    doc_type=parsed.doc_type,
                    declared_serial=parsed.serial,
                    declared_establishment=parsed.establishment_name,
                    establishment_key=parsed.establishment_key,
                )
            )

        substantial = {
            key: files
            for key, files in groups.items()
            if len({f.track for f in files}) >= SPLIT_MIN_TRACKS
        }
        shared = len(substantial) > 1
        if not shared:
            merged = [f for files in groups.values() for f in files]
            substantial = {"": merged} if merged else {}

        re_match = RE_NUMBER_PATTERN.search(directory.name)
        re_number = re_match.group(0) if re_match else directory.name

        for _key, files in sorted(
            substantial.items(), key=lambda item: min(f.file_name for f in item[1])
        ):
            tracks = {f.track for f in files}
            serials = sorted({f.declared_serial for f in files if f.declared_serial is not None})
            names = sorted({f.declared_establishment for f in files})
            notes: list[str] = []
            if unparsed:
                notes.append(f"filenames not parseable against the derived prefixes: {unparsed}")
            if len(names) > 1:
                notes.append(f"filenames declare multiple establishment names: {names}")
            if len(serials) > 1:
                notes.append(f"filenames declare multiple serials: {serials}")

            serial = serials[0] if serials else None
            if shared:
                suffix = f"{serial:03d}" if serial is not None else re.sub(
                    r"[^A-Za-z0-9]+", "-", names[0]
                ).strip("-")
                case_id = f"{directory.name}__{suffix}"
                notes.append(
                    "logical case split from a shared physical folder; grouping key is the "
                    "establishment name carried by the filename"
                )
            else:
                case_id = directory.name

            logical.append(
                LogicalCase(
                    case_id=case_id,
                    physical_dir=str(directory),
                    re_number=re_number,
                    declared_establishment=names[0] if names else "",
                    declared_serial=serial,
                    files=files,
                    missing_tracks=[t for t in ALL_TRACKS if t not in tracks],
                    split_from_shared_dir=shared,
                    notes=notes,
                )
            )

    return Manifest(
        cases=sorted(logical, key=lambda case: case.case_id),
        doc_prefixes=doc_prefixes,
        skipped_files=skipped,
    )


# --------------------------------------------------------------------------
# Deterministic gate
# --------------------------------------------------------------------------


@dataclass(slots=True)
class ManifestReport:
    n_physical_dirs: int
    n_logical_cases: int
    n_files: int
    n_skipped_files: int
    incomplete_cases: dict[str, list[str]]
    split_cases: list[str]
    duplicate_case_ids: list[str]
    duplicate_serials: list[int]
    duplicate_hashes: dict[str, list[str]]
    track_counts: dict[str, int]
    failures: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.failures

    def to_dict(self) -> dict[str, object]:
        return {
            "ok": self.ok,
            "n_physical_dirs": self.n_physical_dirs,
            "n_logical_cases": self.n_logical_cases,
            "n_files": self.n_files,
            "n_skipped_files": self.n_skipped_files,
            "incomplete_cases": self.incomplete_cases,
            "split_cases": self.split_cases,
            "duplicate_case_ids": self.duplicate_case_ids,
            "duplicate_serials": self.duplicate_serials,
            "duplicate_hashes": self.duplicate_hashes,
            "track_counts": self.track_counts,
            "failures": self.failures,
        }


#: Expectations asserted against the shipped dataset. Kept explicit so that a
#: different dataset drop fails loudly instead of being silently re-interpreted.
EXPECTED_LOGICAL_CASES = 100
EXPECTED_FILES = 898


def validate_manifest(
    manifest: Manifest,
    cases_root: str | Path,
    *,
    expected_cases: int | None = EXPECTED_LOGICAL_CASES,
    expected_files: int | None = EXPECTED_FILES,
) -> ManifestReport:
    """Deterministic M0 gate. Failure means BLOCK — never silent continuation."""

    cases = manifest.cases
    seen: set[str] = set()
    duplicates: list[str] = []
    for case in cases:
        if case.case_id in seen:
            duplicates.append(case.case_id)
        seen.add(case.case_id)

    serial_counts: dict[int, int] = defaultdict(int)
    for case in cases:
        if case.declared_serial is not None:
            serial_counts[case.declared_serial] += 1

    hashes: dict[str, list[str]] = defaultdict(list)
    track_counts: dict[str, int] = defaultdict(int)
    for case in cases:
        for file in case.files:
            track_counts[file.track] += 1
            hashes[file.source_hash].append(f"{case.case_id}/{file.file_name}")

    root = Path(cases_root)
    report = ManifestReport(
        n_physical_dirs=sum(1 for p in root.iterdir() if p.is_dir()),
        n_logical_cases=len(cases),
        n_files=sum(len(case.files) for case in cases),
        n_skipped_files=len(manifest.skipped_files),
        incomplete_cases={
            case.case_id: case.missing_tracks for case in cases if case.missing_tracks
        },
        split_cases=[case.case_id for case in cases if case.split_from_shared_dir],
        duplicate_case_ids=duplicates,
        duplicate_serials=sorted(s for s, n in serial_counts.items() if n > 1),
        duplicate_hashes={h: paths for h, paths in hashes.items() if len(paths) > 1},
        track_counts=dict(sorted(track_counts.items())),
    )

    if duplicates:
        report.failures.append(f"duplicate case ids: {duplicates}")
    if report.duplicate_serials:
        report.failures.append(f"serial collisions across cases: {report.duplicate_serials}")
    if expected_cases is not None and report.n_logical_cases != expected_cases:
        report.failures.append(
            f"expected {expected_cases} logical cases, built {report.n_logical_cases}"
        )
    if expected_files is not None and report.n_files != expected_files:
        report.failures.append(f"expected {expected_files} files, indexed {report.n_files}")
    for case in cases:
        for note in case.notes:
            if "not parseable" in note:
                report.failures.append(f"{case.case_id}: {note}")
    return report
