"""FRECA test suite."""

