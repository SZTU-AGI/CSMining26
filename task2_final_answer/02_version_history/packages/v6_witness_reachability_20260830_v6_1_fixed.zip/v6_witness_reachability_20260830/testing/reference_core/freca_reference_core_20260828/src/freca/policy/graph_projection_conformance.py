"""Conformance gate between the independent index and projected graph."""

from __future__ import annotations

from pydantic import Field

from freca.argument.models import (
    ArgumentGraphTemplate,
    PremiseRole,
    RequiredPolarity,
)
from freca.domain.models import SafeId, Sha256, StrictModel
from freca.harness.artifact_store import sha256_digest
from freca.logic.ast import LogicOperator
from freca.policy.indexed_requirement_view import IndexedRequirementView


class GraphProjectionConformanceReport(StrictModel):
    report_id: SafeId
    interpretation_id: SafeId
    indexed_requirement_view_sha256: Sha256
    argument_graph_template_sha256: Sha256
    missing_decisive_proposition_ids: list[SafeId] = Field(default_factory=list)
    extra_ungrounded_statement_ids: list[SafeId] = Field(default_factory=list)
    operator_mismatch_ids: list[SafeId] = Field(default_factory=list)
    polarity_mismatch_ids: list[SafeId] = Field(default_factory=list)
    premise_role_mismatch_ids: list[SafeId] = Field(default_factory=list)
    modifier_scope_mismatch_ids: list[SafeId] = Field(default_factory=list)
    root_mapping_mismatch_ids: list[SafeId] = Field(default_factory=list)
    duplicate_semantic_projection_ids: list[SafeId] = Field(default_factory=list)
    exact_projection_passed: bool
    report_sha256: Sha256


def _expected_premise_signature(
    operator: LogicOperator, child_ids: list[str]
) -> list[list[tuple[str, str, str]]]:
    def ordinary(child_id: str, polarity: str = "POSITIVE") -> tuple[str, str, str]:
        return (child_id, PremiseRole.ORDINARY.value, polarity)

    if operator is LogicOperator.ATOM:
        return []
    if operator is LogicOperator.ALL_OF:
        return [[ordinary(child_id) for child_id in child_ids]]
    if operator is LogicOperator.ANY_OF:
        return [[ordinary(child_id)] for child_id in child_ids]
    if operator is LogicOperator.NOT:
        return [[ordinary(child_ids[0], RequiredPolarity.NEGATIVE.value)]]
    if operator is LogicOperator.IF_THEN:
        return [
            [ordinary(child_ids[0], RequiredPolarity.NEGATIVE.value)],
            [ordinary(child_ids[1])],
        ]
    if operator in {LogicOperator.UNLESS, LogicOperator.EXCEPTION_GATE}:
        return [
            [ordinary(child_ids[0])]
            + [
                (child_id, PremiseRole.EXCEPTION.value, RequiredPolarity.POSITIVE.value)
                for child_id in child_ids[1:]
            ]
        ]
    raise ValueError(f"unsupported operator {operator}")


def audit_graph_projection(
    view: IndexedRequirementView,
    graph: ArgumentGraphTemplate,
) -> GraphProjectionConformanceReport:
    rows_by_logic = {row.logic_node_id: row for row in view.rows}
    statements_by_logic: dict[str, list] = {}
    for statement in graph.statement_nodes:
        statements_by_logic.setdefault(statement.logic_node_id, []).append(statement)

    missing: set[str] = set()
    extra: set[str] = set()
    operator_mismatch: set[str] = set()
    polarity_mismatch: set[str] = set()
    role_mismatch: set[str] = set()
    scope_mismatch: set[str] = set()
    duplicate: set[str] = set()

    for logic_id, row in rows_by_logic.items():
        projected = statements_by_logic.get(logic_id, [])
        if not projected:
            if row.proposition_id is not None:
                missing.add(row.proposition_id)
            else:
                missing.add(logic_id)
            continue
        if len(projected) > 1:
            duplicate.add(logic_id)
            continue
        statement = projected[0]
        if statement.logic_operator is not row.operator:
            operator_mismatch.add(logic_id)
        if statement.proposition_id != row.proposition_id:
            scope_mismatch.add(logic_id)
        if statement.source_span_ids != row.source_span_ids:
            scope_mismatch.add(logic_id)

        actual_arguments = sorted(
            (
                argument
                for argument in graph.argument_nodes
                if argument.conclusion_statement_id == statement.statement_id
            ),
            key=lambda item: item.argument_id,
        )
        actual = []
        statement_logic = {item.statement_id: item.logic_node_id for item in graph.statement_nodes}
        for argument in actual_arguments:
            signature = []
            for premise in argument.premises:
                signature.append(
                    (
                        statement_logic.get(premise.statement_id, "UNKNOWN"),
                        premise.premise_role.value,
                        premise.required_polarity.value,
                    )
                )
            actual.append(signature)
        expected = _expected_premise_signature(
            row.operator, [child.removeprefix("row-") for child in row.ordered_child_row_ids]
        )
        if actual != expected:
            expected_roles = [[item[1] for item in group] for group in expected]
            actual_roles = [[item[1] for item in group] for group in actual]
            expected_polarities = [[item[2] for item in group] for group in expected]
            actual_polarities = [[item[2] for item in group] for group in actual]
            if actual_roles != expected_roles:
                role_mismatch.add(logic_id)
            if actual_polarities != expected_polarities:
                polarity_mismatch.add(logic_id)
            if actual_roles == expected_roles and actual_polarities == expected_polarities:
                scope_mismatch.add(logic_id)

    for logic_id, statements in statements_by_logic.items():
        if logic_id not in rows_by_logic:
            extra.update(item.statement_id for item in statements)

    expected_roots = {
        name: rows_by_logic[row_id.removeprefix("row-")].logic_node_id
        for name, row_id in view.root_row_ids.items()
    }
    statement_logic = {item.statement_id: item.logic_node_id for item in graph.statement_nodes}
    root_mismatch = {
        name
        for name, logic_id in expected_roots.items()
        if statement_logic.get(graph.root_statement_ids.get(name, "")) != logic_id
    }

    fields = {
        "missing_decisive_proposition_ids": sorted(missing),
        "extra_ungrounded_statement_ids": sorted(extra),
        "operator_mismatch_ids": sorted(operator_mismatch),
        "polarity_mismatch_ids": sorted(polarity_mismatch),
        "premise_role_mismatch_ids": sorted(role_mismatch),
        "modifier_scope_mismatch_ids": sorted(scope_mismatch),
        "root_mapping_mismatch_ids": sorted(root_mismatch),
        "duplicate_semantic_projection_ids": sorted(duplicate),
    }
    passed = not any(fields.values())
    graph_hash = sha256_digest(graph.model_dump(mode="json"))
    payload = {
        "interpretation_id": view.interpretation_id,
        "indexed_requirement_view_sha256": view.view_sha256,
        "argument_graph_template_sha256": graph_hash,
        **fields,
        "exact_projection_passed": passed,
    }
    report_hash = sha256_digest(payload)
    return GraphProjectionConformanceReport(
        report_id=f"gpc-{report_hash.split(':', 1)[1][:20]}",
        report_sha256=report_hash,
        **payload,
    )
