"""Versioned, hash-verified prompt files with strict variable whitelists."""

from __future__ import annotations

import string
import tomllib
from pathlib import Path
from typing import Literal

from pydantic import Field, model_validator

from freca.domain.models import SafeId, Sha256, StrictModel
from freca.governance.hashing import sha256_bytes, sha256_digest


class PromptBundleError(ValueError):
    pass


class PromptTemplateSpec(StrictModel):
    logical_name: SafeId
    role: Literal[
        "POLICY_EXTRACT_SYSTEM",
        "POLICY_EXTRACT_USER",
        "EVIDENCE_READ_SYSTEM",
        "EVIDENCE_READ_USER",
        "RERANK_SYSTEM",
        "RERANK_USER",
        "TEAM_B_SYSTEM",
        "TEAM_B_USER",
    ]
    version: str = Field(min_length=1)
    filename: str = Field(min_length=1)
    sha256: Sha256
    allowed_variables: frozenset[str] = frozenset()

    @model_validator(mode="after")
    def filename_is_local(self) -> PromptTemplateSpec:
        path = Path(self.filename)
        if path.is_absolute() or ".." in path.parts:
            raise ValueError("prompt filename must stay inside the prompt bundle")
        return self


class PromptManifest(StrictModel):
    schema_version: Literal["freca.prompt-manifest.v1"] = "freca.prompt-manifest.v1"
    bundle_version: str = Field(min_length=1)
    template: list[PromptTemplateSpec] = Field(min_length=1)

    @model_validator(mode="after")
    def names_and_roles_are_unique(self) -> PromptManifest:
        if len({item.logical_name for item in self.template}) != len(self.template):
            raise ValueError("prompt logical names must be unique")
        if len({item.role for item in self.template}) != len(self.template):
            raise ValueError("prompt roles must be unique")
        return self


class LoadedPrompt(StrictModel):
    spec: PromptTemplateSpec
    text: str


class PromptRender(StrictModel):
    logical_name: SafeId
    template_sha256: Sha256
    prompt_sha256: Sha256
    text: str


class PromptBundle(StrictModel):
    schema_version: Literal["freca.prompt-bundle.v1"] = "freca.prompt-bundle.v1"
    bundle_version: str
    templates: list[LoadedPrompt]
    bundle_sha256: Sha256

    def render(self, logical_name: str, **variables: str) -> PromptRender:
        try:
            loaded = next(item for item in self.templates if item.spec.logical_name == logical_name)
        except StopIteration as error:
            raise PromptBundleError(f"unknown prompt logical name: {logical_name}") from error
        placeholders = _placeholders(loaded.text)
        supplied = set(variables)
        unknown = supplied - loaded.spec.allowed_variables
        missing = placeholders - supplied
        unused = supplied - placeholders
        if unknown:
            raise PromptBundleError(f"unknown prompt variables: {sorted(unknown)}")
        if missing:
            raise PromptBundleError(f"missing prompt variables: {sorted(missing)}")
        if unused:
            raise PromptBundleError(f"unused prompt variables: {sorted(unused)}")
        rendered = loaded.text.format_map(variables)
        return PromptRender(
            logical_name=loaded.spec.logical_name,
            template_sha256=loaded.spec.sha256,
            prompt_sha256=sha256_bytes(rendered.encode("utf-8")),
            text=rendered,
        )


def load_prompt_bundle(root: str | Path, *, strict: bool = True) -> PromptBundle:
    prompt_root = Path(root).resolve(strict=True)
    manifest_path = (prompt_root / "manifest.toml").resolve(strict=True)
    if not manifest_path.is_relative_to(prompt_root):
        raise PromptBundleError("prompt manifest escapes bundle root")
    with manifest_path.open("rb") as stream:
        manifest = PromptManifest.model_validate(tomllib.load(stream))

    templates: list[LoadedPrompt] = []
    for spec in manifest.template:
        path = (prompt_root / spec.filename).resolve(strict=True)
        if not path.is_relative_to(prompt_root) or not path.is_file():
            raise PromptBundleError(f"prompt path escapes bundle root: {spec.filename}")
        data = path.read_bytes()
        if sha256_bytes(data) != spec.sha256:
            raise PromptBundleError(f"prompt hash mismatch: {spec.logical_name}")
        try:
            text = data.decode("utf-8")
        except UnicodeDecodeError as error:
            raise PromptBundleError(f"prompt is not UTF-8: {spec.logical_name}") from error
        placeholders = _placeholders(text)
        if not placeholders.issubset(spec.allowed_variables):
            unknown = placeholders - spec.allowed_variables
            raise PromptBundleError(
                f"undeclared variables in {spec.logical_name}: {sorted(unknown)}"
            )
        if strict and any(marker in text for marker in ("TODO", "MUST_BE_SET", "{{FIXME}}")):
            raise PromptBundleError(f"unresolved marker in prompt: {spec.logical_name}")
        templates.append(LoadedPrompt(spec=spec, text=text))

    bundle_payload = [
        {
            "logical_name": item.spec.logical_name,
            "role": item.spec.role,
            "version": item.spec.version,
            "sha256": item.spec.sha256,
            "allowed_variables": item.spec.allowed_variables,
        }
        for item in sorted(templates, key=lambda item: item.spec.logical_name)
    ]
    return PromptBundle(
        bundle_version=manifest.bundle_version,
        templates=templates,
        bundle_sha256=sha256_digest(bundle_payload),
    )


def _placeholders(template: str) -> set[str]:
    names: set[str] = set()
    try:
        parsed = string.Formatter().parse(template)
        for _literal, field_name, format_spec, conversion in parsed:
            if field_name is None:
                continue
            if not field_name or "." in field_name or "[" in field_name:
                raise PromptBundleError("prompt variables must be simple identifiers")
            if format_spec or conversion:
                raise PromptBundleError("prompt variables cannot use conversions or format specs")
            names.add(field_name)
    except ValueError as error:
        raise PromptBundleError("prompt contains malformed braces") from error
    return names
