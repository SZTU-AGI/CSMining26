"""P2: assemble the 101x42 submission workbook and gate its completeness.

Two facts about the official template drive every decision in this file, both
verified against ``数据集/Task2/submission_template.xlsx``:

* The header is exactly ``RE Number, CP1 ... CP41`` and the shipped file is
  **header-only** (1 row, 42 columns). Rows are ours to append.
* The graded artefact has no room for an empty cell. 100 rows x 41 verdicts = 4 100
  cells, and a blank is not a third answer — it is an unanswered question, which
  scores as wrong.

That second point collides with a deliberate choice made upstream:
``AdjudicationResult.label`` returns ``""`` when a decision was blocked, precisely so
that a pipeline failure is never silently laundered into a ``0``. Both behaviours are
right in their own layer, so this file resolves the collision explicitly rather than
letting a default decide: a blocked cell is filled with :data:`BLOCKED_FILL`, every
such cell is listed in the report, and the count is printed. The frozen decision
"missing evidence maps to 0 but keeps the ``insufficient`` flag" is about *evidence*
that is absent from a farm's documents; a blocked *pipeline step* is a different
failure and is accounted for separately, because conflating them would hide our own
bugs inside a legitimate-looking compliance finding.

Why ``0`` is nonetheless the fill value: the grader accepts only ``1``, ``0`` and
``N/A``; of the three, ``0`` is the one that does not assert facts we never
established (``1`` claims verified compliance; ``N/A`` claims verified
non-applicability, which ``FinalDecision`` will not even let us state without
supporting evidence). It is the least-unfounded placeholder, not a verdict — and the
report says so, per cell.
"""

from __future__ import annotations

import shutil
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from freca.domain.enums import FinalLabel

#: Column order of the official template.
CP_IDS: tuple[str, ...] = tuple(f"CP{index}" for index in range(1, 42))
EXPECTED_HEADER: tuple[str, ...] = ("RE Number", *CP_IDS)
ALLOWED_VALUES: frozenset[str] = frozenset(label.value for label in FinalLabel)

#: What a blocked cell becomes. See the module docstring — this is a placeholder
#: forced by the grading format, and it is always reported and counted.
BLOCKED_FILL = FinalLabel.NON_COMPLIANT.value

N_CASES = 100
N_CPS = 41


class SubmissionError(RuntimeError):
    """Raised when the workbook would be malformed or silently incomplete."""


@dataclass(slots=True)
class SubmissionReport:
    output_path: str
    rows: int
    columns: int
    n_cells: int
    label_counts: dict[str, int] = field(default_factory=dict)
    #: ``"<case_id>/<cp_id>"`` for every cell filled because adjudication blocked.
    blocked_cells: list[str] = field(default_factory=list)
    #: Cells whose decision asked for human review (missing-evidence 0s land here).
    review_cells: list[str] = field(default_factory=list)
    duplicate_re_numbers: list[str] = field(default_factory=list)
    #: True when the row identifiers could not be trusted unambiguously, so the file
    #: is a candidate for review rather than something to submit.
    candidate_only: bool = False
    notes: list[str] = field(default_factory=list)

    @property
    def n_blocked(self) -> int:
        return len(self.blocked_cells)

    def to_dict(self) -> dict[str, Any]:
        return {
            "output_path": self.output_path,
            "rows": self.rows,
            "columns": self.columns,
            "n_cells": self.n_cells,
            "label_counts": self.label_counts,
            "n_blocked_cells": self.n_blocked,
            "blocked_cells": self.blocked_cells,
            "n_review_cells": len(self.review_cells),
            "review_cells": self.review_cells,
            "duplicate_re_numbers": self.duplicate_re_numbers,
            "candidate_only": self.candidate_only,
            "notes": self.notes,
        }


def _verdict_grid(verdicts: list[Any]) -> dict[tuple[str, str], Any]:
    """Index verdicts by ``(case_id, cp_id)``, rejecting duplicates.

    A duplicate is refused rather than resolved by last-write-wins: two verdicts for
    one cell means the run was assembled from mixed sources, and choosing between
    them silently is how a stale verdict reaches the graded file.
    """

    grid: dict[tuple[str, str], Any] = {}
    for verdict in verdicts:
        key = (verdict.case_id, verdict.cp_id)
        if key in grid:
            raise SubmissionError(f"duplicate verdict for {key[0]} {key[1]}")
        grid[key] = verdict
    return grid


def assemble_submission(
    verdicts: list[Any],
    cases: list[Any],
    *,
    template_path: str | Path,
    output_path: str | Path,
    expected_cases: int | None = N_CASES,
    allow_missing_verdicts: bool = False,
) -> SubmissionReport:
    """Write the submission workbook from a case list and its verdicts.

    ``verdicts`` are :class:`~freca.consistency.case_consistency.CaseVerdict` records
    (anything exposing ``case_id``, ``cp_id``, ``label``, ``review_required``).
    ``cases`` are manifest ``LogicalCase`` records, which supply the ``RE Number``
    and — crucially — the row *order*. Row order comes from the manifest rather than
    from the verdict list because the verdicts are grouped for convenience during
    adjudication, and a submission whose rows are permuted scores near zero while
    looking perfectly well-formed.

    The two relaxations are kept separate because they describe different failures.
    ``expected_cases=None`` waives only the "there are 100 farms" gate, which is what
    a smoke run over a handful of cases needs. ``allow_missing_verdicts`` waives
    something far more serious — a cell for which adjudication produced *no record at
    all*, as opposed to a record that was blocked. A single flag covering both would
    mean every partial run silently tolerated absent verdicts.
    """

    from openpyxl import load_workbook

    template = Path(template_path)
    output = Path(output_path)
    if output.resolve() == template.resolve():
        # The official template is a read-only input; overwriting it would destroy
        # the only reference for the expected header.
        raise SubmissionError("refusing to overwrite the official template")

    workbook = load_workbook(template)
    sheet = workbook.active
    header = tuple(sheet.cell(1, column).value for column in range(1, 43))
    if header != EXPECTED_HEADER:
        raise SubmissionError(f"template header is not RE Number, CP1..CP41: got {header}")
    if sheet.max_row != 1:
        raise SubmissionError(
            f"expected the header-only template, found {sheet.max_row} rows; a pre-populated "
            "template needs its row identifiers reviewed before this assembler is used"
        )

    report = SubmissionReport(output_path=str(output), rows=0, columns=42, n_cells=0)

    if expected_cases is not None and len(cases) != expected_cases:
        raise SubmissionError(f"expected {expected_cases} cases, got {len(cases)}")

    re_counts = Counter(case.re_number for case in cases)
    report.duplicate_re_numbers = sorted(
        re_number for re_number, count in re_counts.items() if count > 1
    )
    if report.duplicate_re_numbers:
        # Not fatal: two farms can legitimately share an RE number in the source
        # data. But it means we cannot prove which row is which, so the artefact is
        # marked as a candidate and the caller has to decide.
        report.candidate_only = True
        report.notes.append(
            "duplicate RE Number(s) "
            + ", ".join(report.duplicate_re_numbers)
            + " — row identity is unproven, treat this file as a candidate"
        )

    grid = _verdict_grid(verdicts)
    labels = Counter()

    for case in cases:
        row: list[str] = [case.re_number]
        for cp_id in CP_IDS:
            verdict = grid.get((case.case_id, cp_id))
            if verdict is None:
                if not allow_missing_verdicts:
                    raise SubmissionError(f"no verdict for {case.case_id} {cp_id}")
                value = BLOCKED_FILL
                report.blocked_cells.append(f"{case.case_id}/{cp_id}")
                report.notes.append(f"{case.case_id}/{cp_id}: no verdict produced")
            elif verdict.label in ALLOWED_VALUES:
                value = verdict.label
                if getattr(verdict, "review_required", False):
                    report.review_cells.append(f"{case.case_id}/{cp_id}")
            elif not verdict.label:
                # Blocked upstream. Filled, counted, and named — never quietly a 0.
                value = BLOCKED_FILL
                report.blocked_cells.append(f"{case.case_id}/{cp_id}")
            else:
                raise SubmissionError(
                    f"{case.case_id} {cp_id}: {verdict.label!r} is not one of "
                    f"{sorted(ALLOWED_VALUES)}"
                )
            row.append(value)
            labels[value] += 1
        sheet.append(row)

    report.rows = len(cases)
    report.n_cells = sum(labels.values())
    report.label_counts = dict(labels)
    if report.blocked_cells:
        report.candidate_only = True
        report.notes.append(
            f"{report.n_blocked} cell(s) filled with {BLOCKED_FILL!r} because adjudication "
            "was blocked, not because non-compliance was established"
        )

    output.parent.mkdir(parents=True, exist_ok=True)
    workbook.save(output)

    # Re-read what was actually written. Verifying the object in memory only proves
    # the assembler agrees with itself; the graded artefact is the file on disk.
    verify_submission(output, expect_rows=len(cases) + 1)
    return report


def verify_submission(path: str | Path, *, expect_rows: int = N_CASES + 1) -> dict[str, Any]:
    """Re-open a written workbook and assert it is gradeable.

    Separate from :func:`assemble_submission` so it can be run against any candidate
    file — including one edited by hand, which is exactly when this check matters.
    """

    from openpyxl import load_workbook

    sheet = load_workbook(Path(path), data_only=True).active
    if sheet.max_row != expect_rows or sheet.max_column != 42:
        raise SubmissionError(
            f"shape is {sheet.max_row}x{sheet.max_column}, expected {expect_rows}x42"
        )
    header = tuple(sheet.cell(1, column).value for column in range(1, 43))
    if header != EXPECTED_HEADER:
        raise SubmissionError("header changed during assembly")

    counts: Counter[str] = Counter()
    for row in range(2, sheet.max_row + 1):
        if not str(sheet.cell(row, 1).value or "").strip():
            raise SubmissionError(f"row {row} has an empty RE Number")
        for column in range(2, 43):
            value = sheet.cell(row, column).value
            text = "" if value is None else str(value).strip()
            if text not in ALLOWED_VALUES:
                raise SubmissionError(
                    f"row {row} column {column} ({EXPECTED_HEADER[column - 1]}) is {text!r}; "
                    f"only {sorted(ALLOWED_VALUES)} are gradeable"
                )
            counts[text] += 1

    return {
        "rows": sheet.max_row,
        "columns": sheet.max_column,
        "n_cells": sum(counts.values()),
        "label_counts": dict(counts),
    }
