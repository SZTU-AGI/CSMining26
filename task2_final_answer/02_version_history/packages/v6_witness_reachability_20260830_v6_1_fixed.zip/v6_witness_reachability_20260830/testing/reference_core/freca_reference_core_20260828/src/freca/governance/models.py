"""Immutable Layer 0 run, event, failure, and reproducibility contracts."""

from __future__ import annotations

from datetime import UTC, datetime
from enum import StrEnum
from typing import Any, Literal

from pydantic import Field, model_validator

from freca.domain.models import SafeId, Sha256, StrictModel
from freca.governance.config import ModelSpec, RunMode
from freca.governance.hashing import sha256_digest


class EventType(StrEnum):
    RUN_STARTED = "RUN_STARTED"
    SOURCE_GUARD_PASSED = "SOURCE_GUARD_PASSED"
    NODE_STARTED = "NODE_STARTED"
    ARTIFACT_WRITTEN = "ARTIFACT_WRITTEN"
    MODEL_CALL_STARTED = "MODEL_CALL_STARTED"
    MODEL_CALL_COMPLETED = "MODEL_CALL_COMPLETED"
    MODEL_CALL_FAILED = "MODEL_CALL_FAILED"
    GATE_DECIDED = "GATE_DECIDED"
    NODE_COMPLETED = "NODE_COMPLETED"
    NODE_FAILED = "NODE_FAILED"
    RUN_COMPLETING = "RUN_COMPLETING"
    RUN_COMPLETED = "RUN_COMPLETED"
    RUN_ABORTED = "RUN_ABORTED"


class FailureScope(StrEnum):
    RUN = "RUN"
    CASE = "CASE"
    CP = "CP"
    NODE = "NODE"
    MODEL_CALL = "MODEL_CALL"
    ARTIFACT = "ARTIFACT"


class Recoverability(StrEnum):
    FATAL = "FATAL"
    RETRYABLE = "RETRYABLE"
    DEFERABLE = "DEFERABLE"
    FORCE_FOLDABLE = "FORCE_FOLDABLE"


class CodeState(StrictModel):
    git_commit: str = Field(min_length=1)
    git_dirty: bool
    tracked_diff_sha256: Sha256 | None = None
    untracked_source_manifest_sha256: Sha256 | None = None

    @model_validator(mode="after")
    def dirty_state_requires_a_snapshot(self) -> CodeState:
        if self.git_dirty and not (
            self.tracked_diff_sha256 or self.untracked_source_manifest_sha256
        ):
            raise ValueError("dirty code state requires a tracked or untracked snapshot hash")
        return self

    def semantic_sha256(self) -> str:
        return sha256_digest(self)


class EnvironmentSnapshot(StrictModel):
    os: str = Field(min_length=1)
    python_version: str = Field(min_length=1)
    dependency_lock_sha256: Sha256
    installed_packages_sha256: Sha256
    package_version: str = Field(min_length=1)
    external_tools: dict[str, str] = Field(default_factory=dict)

    def semantic_sha256(self) -> str:
        return sha256_digest(self)


class RunManifest(StrictModel):
    schema_version: Literal["freca.run-manifest.v1"] = "freca.run-manifest.v1"
    run_id: SafeId
    resumed_from_run_id: SafeId | None = None
    mode: RunMode
    replay_key: Sha256
    source_catalog_id: SafeId
    source_catalog_sha256: Sha256
    config_sha256: Sha256
    prompt_bundle_sha256: Sha256
    code_state: CodeState
    environment: EnvironmentSnapshot
    requested_models: list[ModelSpec]
    human_availability_profile: Literal["NO_HUMAN", "LIMITED_HUMAN", "HUMAN_AVAILABLE"]
    fold_assumption_register_sha256: Sha256
    started_at: datetime

    @model_validator(mode="after")
    def timestamp_is_aware(self) -> RunManifest:
        if self.started_at.tzinfo is None:
            raise ValueError("started_at must be timezone-aware")
        return self


class RunCompletion(StrictModel):
    schema_version: Literal["freca.run-completion.v1"] = "freca.run-completion.v1"
    run_id: SafeId
    status: Literal["RUN_VALID", "RUN_DEGRADED", "RUN_INVALID", "RUN_FAILED"]
    finished_at: datetime
    source_integrity_end_check: str
    resolved_model_versions: list[str]
    event_log_sha256: Sha256
    output_artifact_ids: list[SafeId]
    blocking_findings: list[str]
    warnings: list[str]

    @model_validator(mode="after")
    def timestamp_is_aware(self) -> RunCompletion:
        if self.finished_at.tzinfo is None:
            raise ValueError("finished_at must be timezone-aware")
        return self


class FailureRecord(StrictModel):
    failure_id: SafeId
    code: str = Field(min_length=1)
    scope: FailureScope
    recoverability: Recoverability
    node: str = Field(min_length=1)
    case_id: str | None = None
    cp_id: str | None = None
    message: str = Field(min_length=1)
    cause_artifact_ids: list[SafeId] = Field(default_factory=list)
    attempt: int = Field(ge=0)
    created_at: datetime


class RunEventV2(StrictModel):
    schema_version: Literal["freca.run-event.v2"] = "freca.run-event.v2"
    event_id: SafeId
    run_id: SafeId
    sequence: int = Field(ge=0)
    event_type: EventType
    severity: Literal["INFO", "WARNING", "ERROR", "FATAL"]
    node: str | None = None
    case_id: str | None = None
    cp_id: str | None = None
    artifact_ids: list[SafeId] = Field(default_factory=list)
    detail: dict[str, Any] = Field(default_factory=dict)
    previous_event_sha256: Sha256 | None = None
    event_sha256: Sha256
    created_at: datetime

    @classmethod
    def create(
        cls,
        *,
        event_id: str,
        run_id: str,
        sequence: int,
        event_type: EventType,
        severity: Literal["INFO", "WARNING", "ERROR", "FATAL"] = "INFO",
        previous_event_sha256: str | None = None,
        node: str | None = None,
        case_id: str | None = None,
        cp_id: str | None = None,
        artifact_ids: list[str] | None = None,
        detail: dict[str, Any] | None = None,
        created_at: datetime | None = None,
    ) -> RunEventV2:
        data: dict[str, Any] = {
            "schema_version": "freca.run-event.v2",
            "event_id": event_id,
            "run_id": run_id,
            "sequence": sequence,
            "event_type": event_type,
            "severity": severity,
            "node": node,
            "case_id": case_id,
            "cp_id": cp_id,
            "artifact_ids": artifact_ids or [],
            "detail": detail or {},
            "previous_event_sha256": previous_event_sha256,
            "created_at": created_at or datetime.now(UTC),
        }
        data["event_sha256"] = sha256_digest(data)
        return cls.model_validate(data)

    @model_validator(mode="after")
    def verify_own_hash_and_time(self) -> RunEventV2:
        if self.created_at.tzinfo is None:
            raise ValueError("event created_at must be timezone-aware")
        payload = self.model_dump(mode="python", exclude={"event_sha256"})
        if self.event_sha256 != sha256_digest(payload):
            raise ValueError("event_sha256 does not match event content")
        return self


def build_replay_key(
    *,
    mode: RunMode,
    source_catalog_sha256: str,
    semantic_config_sha256: str,
    prompt_bundle_sha256: str,
    method_policy_bundle_sha256: str,
    model_fingerprints: list[dict[str, Any]],
    code_state: CodeState,
    environment: EnvironmentSnapshot,
) -> str:
    return sha256_digest(
        {
            "schema": "freca.replay-key.v1",
            "mode": mode.value,
            "source_catalog_sha256": source_catalog_sha256,
            "semantic_config_sha256": semantic_config_sha256,
            "prompt_bundle_sha256": prompt_bundle_sha256,
            "method_policy_bundle_sha256": method_policy_bundle_sha256,
            "model_fingerprints": sorted(
                model_fingerprints,
                key=lambda item: (item["role"], item["provider_id"], item["requested_model"]),
            ),
            "code_state_sha256": code_state.semantic_sha256(),
            "environment_sha256": environment.semantic_sha256(),
        }
    )
