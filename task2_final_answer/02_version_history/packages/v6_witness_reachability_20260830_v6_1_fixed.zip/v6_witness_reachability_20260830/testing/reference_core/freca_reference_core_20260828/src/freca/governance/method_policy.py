"""CP-agnostic method policy isolated from normative and factual sources."""

from __future__ import annotations

import re
from typing import Literal

from pydantic import Field, model_validator

from freca.domain.models import SafeId, Sha256, StrictModel
from freca.governance.hashing import sha256_digest

ProhibitedEffect = Literal[
    "CREATE_NORM_PROPOSITION",
    "CREATE_CP_EXCEPTION",
    "CREATE_CP_NA_TRIGGER",
    "CREATE_CONDITION_SCOPE_CLASS",
    "SET_FALSE_TRIGGER_SEMANTICS",
    "CREATE_INTERPRETATION_BRANCH",
    "CREATE_CASE_FACT",
    "CHOOSE_FINAL_LABEL",
]

ALL_PROHIBITED_EFFECTS: frozenset[str] = frozenset(
    {
        "CREATE_NORM_PROPOSITION",
        "CREATE_CP_EXCEPTION",
        "CREATE_CP_NA_TRIGGER",
        "CREATE_CONDITION_SCOPE_CLASS",
        "SET_FALSE_TRIGGER_SEMANTICS",
        "CREATE_INTERPRETATION_BRANCH",
        "CREATE_CASE_FACT",
        "CHOOSE_FINAL_LABEL",
    }
)


class MethodReferenceManifest(StrictModel):
    reference_id: SafeId
    title: str = Field(min_length=1)
    source_sha256: Sha256
    reference_kind: Literal["AUDIT_METHOD", "REASONING_METHOD", "EXPERIMENT_REPORT"]
    normative_authority_for_freca: Literal[False] = False
    production_source_catalog_access: Literal[False] = False
    extracted_policy_ids: list[SafeId] = Field(default_factory=list)


class MethodPolicyClause(StrictModel):
    policy_id: SafeId
    method_family: Literal[
        "RELEVANCE",
        "RELIABILITY",
        "SUFFICIENCY",
        "INFORMATION_INTEGRITY",
        "CONFLICT_REPAIR",
        "ENGAGEMENT_SCOPE",
        "PROCEDURE_PURPOSE",
        "POPULATION_AND_SAMPLING",
        "REPRESENTATION_CORROBORATION",
        "TECHNOLOGY_PROCEDURE_VALIDATION",
        "SIGNIFICANT_JUDGMENT",
        "SEARCH_CONTROL",
        "AUDIT_TRACE",
        "QUALITY_MANAGEMENT",
    ]
    cp_agnostic_instruction: str = Field(min_length=1)
    permitted_consumers: list[SafeId] = Field(min_length=1)
    prohibited_effects: list[ProhibitedEffect]
    method_reference_ids: list[SafeId] = Field(min_length=1)
    contains_cp_id: Literal[False] = False
    contains_case_id: Literal[False] = False
    contains_label_prior: Literal[False] = False

    @model_validator(mode="after")
    def enforce_non_decision_boundary(self) -> MethodPolicyClause:
        if set(self.prohibited_effects) != ALL_PROHIBITED_EFFECTS:
            raise ValueError("every method clause must prohibit all decision-source effects")
        text = self.cp_agnostic_instruction
        if re.search(r"\bCP\s*\d+\b", text, flags=re.IGNORECASE):
            raise ValueError("method clause contains a CP-specific identifier")
        if re.search(r"\bRE-[A-Z]{2,4}-\d{4}-\d+\b", text):
            raise ValueError("method clause contains a case-specific identifier")
        return self


class MethodPolicyBundle(StrictModel):
    schema_version: Literal["freca.method-policy-bundle.v1"] = "freca.method-policy-bundle.v1"
    bundle_id: SafeId
    references: list[MethodReferenceManifest]
    clauses: list[MethodPolicyClause]
    logical_prompt_fragment_ids: list[SafeId] = Field(default_factory=list)
    source_manifests_sha256: Sha256
    bundle_sha256: Sha256

    @model_validator(mode="after")
    def verify_references_and_hashes(self) -> MethodPolicyBundle:
        reference_ids = {item.reference_id for item in self.references}
        if len(reference_ids) != len(self.references):
            raise ValueError("method reference IDs must be unique")
        if len({item.policy_id for item in self.clauses}) != len(self.clauses):
            raise ValueError("method policy IDs must be unique")
        unknown = {
            reference_id
            for clause in self.clauses
            for reference_id in clause.method_reference_ids
            if reference_id not in reference_ids
        }
        if unknown:
            raise ValueError(f"method clauses contain unknown references: {sorted(unknown)}")
        expected_source_hash = sha256_digest(
            [
                item.model_dump(mode="python")
                for item in sorted(self.references, key=lambda item: item.reference_id)
            ]
        )
        if self.source_manifests_sha256 != expected_source_hash:
            raise ValueError("source_manifests_sha256 mismatch")
        expected_bundle_hash = _bundle_hash(
            self.bundle_id,
            self.references,
            self.clauses,
            self.logical_prompt_fragment_ids,
            self.source_manifests_sha256,
        )
        if self.bundle_sha256 != expected_bundle_hash:
            raise ValueError("bundle_sha256 mismatch")
        return self


def create_method_policy_bundle(
    *,
    bundle_id: str,
    references: list[MethodReferenceManifest],
    clauses: list[MethodPolicyClause],
    logical_prompt_fragment_ids: list[str] | None = None,
) -> MethodPolicyBundle:
    prompt_ids = logical_prompt_fragment_ids or []
    source_hash = sha256_digest(
        [
            item.model_dump(mode="python")
            for item in sorted(references, key=lambda item: item.reference_id)
        ]
    )
    bundle_hash = _bundle_hash(
        bundle_id,
        references,
        clauses,
        prompt_ids,
        source_hash,
    )
    return MethodPolicyBundle(
        bundle_id=bundle_id,
        references=references,
        clauses=clauses,
        logical_prompt_fragment_ids=prompt_ids,
        source_manifests_sha256=source_hash,
        bundle_sha256=bundle_hash,
    )


def default_method_policy_bundle() -> MethodPolicyBundle:
    """Return the frozen v1 policy; no external document is read at runtime."""
    references = [
        _reference(
            "asa500-2022",
            "ASA 500 Audit Evidence (December 2022)",
            "954144cfae1ff9ad0f8b8fe730fa2fdb2a237c4fa916519956b31fc97e747830",
            "AUDIT_METHOD",
        ),
        _reference(
            "carneades-4-code",
            "Carneades argument graph reference implementation",
            "dbac157bb9505e3c48a376f7bc06418cced949144ff2dd6ed91f90fcff611d0b",
            "REASONING_METHOD",
        ),
        _reference(
            "sara-ie-code",
            "SARA legal information extraction reference implementation",
            "5a950e9f5fc09c43193f64cd0e6f95e8cb23d7b962acc6ce4a7175cf5c08810c",
            "REASONING_METHOD",
        ),
        _reference(
            "tot-code",
            "Tree of Thoughts reference implementation",
            "b8ce580e1ce439923b9e81b5c2a07d1e6e276c3e0439d16d113d96e60ea3038f",
            "REASONING_METHOD",
        ),
        _reference(
            "rap-code",
            "RAP and llm-reasoners reference implementation",
            "5afd74248c6df3291be5def1357eb1b241a0aa8304b92c445740abeee81dee61",
            "REASONING_METHOD",
        ),
        _reference(
            "lats-code",
            "Language Agent Tree Search reference implementation",
            "333c97a4f98ee049904e0a2498b9209d264da80d4b9606d1ad4f65ae13d9c925",
            "REASONING_METHOD",
        ),
        _reference(
            "planning-eval-code",
            "LLM planning evaluation and search-gating reference implementation",
            "34ef4286b562b7d079d960b79a506e0ed972303bfc2457c9761a8736f7720a2b",
            "EXPERIMENT_REPORT",
        ),
        _reference(
            "self-correction-code",
            "LLM self-correction paper and implementation collection",
            "c5ea19cd671a167d5842de2b8f27fa1fccfc1ac345b0a14a9abd6cbad5178828",
            "EXPERIMENT_REPORT",
        ),
        _reference(
            "learn-to-defer-code",
            "Learning to defer reference implementation",
            "a5682924019367187f51b0e7f584326e43e814dc518021e903863c8e6c43d9ba",
            "REASONING_METHOD",
        ),
        _reference(
            "human-ai-deferral-code",
            "Human-AI deferral reference implementation",
            "e9df4bc5a11e3f5ba55cd150da94cb65d07e4ee7d198c656930687106a7bfae6",
            "REASONING_METHOD",
        ),
    ]
    clauses = [
        _clause(
            "method-relevance",
            "RELEVANCE",
            "Assess relevance against the exact proposition and direction of testing; "
            "do not assign a document one global relevance label.",
            ["LAYER4", "LAYER5", "LAYER7", "TEAM_B"],
            ["asa500-2022"],
        ),
        _clause(
            "method-reliability",
            "RELIABILITY",
            "Record source independence, acquisition path, original-versus-transformed status, "
            "and control context as rebuttable reliability signals rather than absolute weights.",
            ["LAYER4", "LAYER5", "LAYER7", "TEAM_B"],
            ["asa500-2022"],
        ),
        _clause(
            "method-sufficiency",
            "SUFFICIENCY",
            "Evaluate sufficiency at the decisive proposition and evidence-set level; repeated "
            "dependent material cannot compensate for missing independent support.",
            ["LAYER7", "LAYER10", "LAYER11"],
            ["asa500-2022"],
        ),
        _clause(
            "method-information-integrity",
            "INFORMATION_INTEGRITY",
            "Verify accuracy, completeness, precision, source anchors, and transformation lineage "
            "before information can affect a decisive claim.",
            ["LAYER3", "LAYER4", "LAYER5", "LAYER10"],
            ["asa500-2022", "sara-ie-code"],
        ),
        _clause(
            "method-conflict-repair",
            "CONFLICT_REPAIR",
            "Preserve contradictory material, identify the proposition it attacks, and trigger a "
            "targeted additional procedure instead of averaging or voting away the conflict.",
            ["LAYER7", "LAYER8", "LAYER10"],
            ["asa500-2022", "self-correction-code"],
        ),
        _clause(
            "method-argument-roles",
            "AUDIT_TRACE",
            "Represent ordinary premises, assumptions, exceptions, support, attack, "
            "proof standards, and burdens as typed roles while retaining an independent "
            "indexed source view.",
            ["LAYER2", "LAYER7", "LAYER10"],
            ["carneades-4-code"],
        ),
        _clause(
            "method-search-control",
            "SEARCH_CONTROL",
            "Use tree search only after an in-domain gate validates a need for multi-step repair; "
            "search state may cite verified sources but reflections and rollout scores are never "
            "evidence.",
            ["LAYER8", "LAYER9"],
            ["tot-code", "rap-code", "lats-code", "planning-eval-code"],
        ),
        _clause(
            "method-independent-verification",
            "QUALITY_MANAGEMENT",
            "Independent verification must re-check original allowed sources, citations, rules, "
            "exceptions, time, identity, and counterevidence; same-model self-criticism alone is "
            "not independent evidence.",
            ["LAYER10"],
            ["self-correction-code", "carneades-4-code"],
        ),
        _clause(
            "method-selective-routing",
            "SIGNIFICANT_JUDGMENT",
            "Route unresolved legal, factual, identity, citation, or conflict states to explicit "
            "repair or deferral without training a supervised deferral classifier when no "
            "trustworthy target labels exist.",
            ["LAYER0", "LAYER8", "LAYER11"],
            ["learn-to-defer-code", "human-ai-deferral-code"],
        ),
    ]
    return create_method_policy_bundle(
        bundle_id="method-policy-v1",
        references=references,
        clauses=clauses,
        logical_prompt_fragment_ids=[
            "policy_extract_system",
            "evidence_read_system",
            "team_b_system",
        ],
    )


def _reference(
    reference_id: str,
    title: str,
    digest: str,
    kind: Literal["AUDIT_METHOD", "REASONING_METHOD", "EXPERIMENT_REPORT"],
) -> MethodReferenceManifest:
    return MethodReferenceManifest(
        reference_id=reference_id,
        title=title,
        source_sha256=f"sha256:{digest}",
        reference_kind=kind,
    )


def _clause(
    policy_id: str,
    method_family: str,
    instruction: str,
    consumers: list[str],
    references: list[str],
) -> MethodPolicyClause:
    return MethodPolicyClause(
        policy_id=policy_id,
        method_family=method_family,
        cp_agnostic_instruction=instruction,
        permitted_consumers=consumers,
        prohibited_effects=sorted(ALL_PROHIBITED_EFFECTS),
        method_reference_ids=references,
    )


def _bundle_hash(
    bundle_id: str,
    references: list[MethodReferenceManifest],
    clauses: list[MethodPolicyClause],
    prompt_ids: list[str],
    source_hash: str,
) -> str:
    return sha256_digest(
        {
            "schema_version": "freca.method-policy-bundle.v1",
            "bundle_id": bundle_id,
            "references": [
                item.model_dump(mode="python")
                for item in sorted(references, key=lambda item: item.reference_id)
            ],
            "clauses": [
                item.model_dump(mode="python")
                for item in sorted(clauses, key=lambda item: item.policy_id)
            ],
            "logical_prompt_fragment_ids": sorted(prompt_ids),
            "source_manifests_sha256": source_hash,
        }
    )
