"""Dependency-light equal-budget executors for the frozen search registry.

The implementations borrow the control decomposition visible in the reference
repositories: ToT separates propose/evaluate/select, RAP separates world model
from reward configuration, and LATS adds environment observations/reflection.
Only verified external observations contribute reward or artifacts.
"""

from __future__ import annotations

import heapq
import math
import random
from dataclasses import dataclass, field
from typing import Protocol

from freca.search.models import (
    SearchBudget,
    SearchMove,
    SearchObservation,
    SearchResult,
    SearchState,
    SearchTraceStep,
)
from freca.search.registry import SearchStrategy


class SearchEnvironment(Protocol):
    def initial_state(self) -> SearchState: ...

    def propose(
        self,
        state: SearchState,
        *,
        limit: int,
        strategy: SearchStrategy,
    ) -> list[SearchMove]: ...

    def apply(
        self, state: SearchState, move: SearchMove
    ) -> tuple[SearchState, SearchObservation]: ...


@dataclass
class _Node:
    state: SearchState
    reward: float = 0.0
    signals: set[str] = field(default_factory=set)
    parent: _Node | None = None
    visits: int = 0
    value_sum: float = 0.0
    children: list[_Node] = field(default_factory=list)
    unexpanded_moves: list[SearchMove] | None = None

    @property
    def mean_value(self) -> float:
        return self.value_sum / self.visits if self.visits else 0.0


def _validated_moves(
    environment: SearchEnvironment,
    state: SearchState,
    budget: SearchBudget,
    strategy: SearchStrategy,
) -> list[SearchMove]:
    moves = environment.propose(state, limit=budget.branch_factor, strategy=strategy)
    seen: set[str] = set()
    valid: list[SearchMove] = []
    for move in moves:
        if move.action_signature in seen or move.action_signature in state.action_history:
            continue
        seen.add(move.action_signature)
        valid.append(move)
    return valid


def _expand(
    *,
    environment: SearchEnvironment,
    node: _Node,
    move: SearchMove,
    trace: list[SearchTraceStep],
    reflection: bool,
) -> _Node:
    child_state, observation = environment.apply(node.state, move)
    if observation.move_id != move.move_id:
        raise ValueError("observation does not correspond to the applied move")
    if observation.new_artifact_ids and not observation.validator_passed:
        raise ValueError("unvalidated observation cannot publish artifacts")
    signals = node.signals | set(observation.verified_external_signal_ids)
    child = _Node(
        state=child_state,
        reward=node.reward + observation.external_reward,
        signals=signals,
        parent=node,
    )
    reflection_text = None
    if reflection:
        reflector = getattr(environment, "reflect", None)
        if reflector is not None:
            reflection_text = reflector(node.state, move, observation)
    trace.append(
        SearchTraceStep(
            sequence=len(trace),
            parent_state_id=node.state.state_id,
            move=move,
            child_state=child_state,
            observation=observation,
            cumulative_external_reward=child.reward,
            reflection_text=reflection_text,
        )
    )
    node.children.append(child)
    return child


def _select_best(nodes: list[_Node]) -> _Node:
    return max(
        nodes,
        key=lambda node: (len(node.signals), node.reward, -node.state.depth, node.state.state_id),
    )


def _run_frontier(
    environment: SearchEnvironment,
    strategy: SearchStrategy,
    budget: SearchBudget,
) -> SearchResult:
    root = _Node(environment.initial_state())
    all_nodes = [root]
    trace: list[SearchTraceStep] = []
    expansions = 0
    is_depth = strategy is SearchStrategy.B09_TOT_DFS
    is_best = strategy in {
        SearchStrategy.B03_RERANK,
        SearchStrategy.B06_BOUNDED_BEST_FIRST_AND_OR,
    }
    single_path = strategy in {
        SearchStrategy.B00_DIRECT_DETERMINISTIC,
        SearchStrategy.B01_DIRECT_MODEL,
        SearchStrategy.B04_ITERATIVE_CORRECTION,
        SearchStrategy.B05_TARGETED_REPAIR,
    }
    frontier: list[_Node] = [root]
    while frontier and expansions < budget.max_expansions:
        node = frontier.pop() if is_depth else frontier.pop(0)
        if node.state.terminal or node.state.depth >= budget.max_depth:
            continue
        moves = _validated_moves(environment, node.state, budget, strategy)
        children = []
        for move in moves:
            if expansions >= budget.max_expansions:
                break
            child = _expand(
                environment=environment,
                node=node,
                move=move,
                trace=trace,
                reflection=False,
            )
            children.append(child)
            all_nodes.append(child)
            expansions += 1
        if single_path and children:
            children = [_select_best(children)]
        if is_best:
            frontier.extend(children)
            frontier.sort(key=lambda item: (len(item.signals), item.reward), reverse=True)
        elif strategy in {
            SearchStrategy.B07_TOT_BFS_VALUE,
            SearchStrategy.B08_TOT_BFS_VOTE,
            SearchStrategy.B10_TOT_BEAM,
        }:
            frontier.extend(children)
            frontier = sorted(
                frontier,
                key=lambda item: (len(item.signals), item.reward),
                reverse=True,
            )[: budget.beam_width]
        else:
            frontier.extend(children)
        if strategy in {
            SearchStrategy.B00_DIRECT_DETERMINISTIC,
            SearchStrategy.B01_DIRECT_MODEL,
            SearchStrategy.B02_SELF_CONSISTENCY,
            SearchStrategy.B03_RERANK,
        }:
            break
    best = _select_best(all_nodes)
    return SearchResult(
        strategy_id=strategy.value,
        initial_state_id=root.state.state_id,
        selected_state=best.state,
        trace_steps=trace,
        expansions=expansions,
        verified_signal_gain=len(best.signals),
        exhausted_budget=expansions >= budget.max_expansions,
    )


def _rollout(
    environment: SearchEnvironment,
    start: _Node,
    strategy: SearchStrategy,
    budget: SearchBudget,
    rng: random.Random,
) -> float:
    node = start
    rewards: list[float] = []
    while not node.state.terminal and node.state.depth < budget.max_depth:
        moves = _validated_moves(environment, node.state, budget, strategy)
        if not moves:
            break
        move = rng.choice(moves)
        state, observation = environment.apply(node.state, move)
        rewards.append(observation.external_reward)
        node = _Node(state=state)
    if not rewards:
        return 0.0
    return (
        max(rewards)
        if strategy is SearchStrategy.B11_CHEN_HEAP_MC_MAX
        else sum(rewards) / len(rewards)
    )


def _run_chen_mc(
    environment: SearchEnvironment,
    strategy: SearchStrategy,
    budget: SearchBudget,
) -> SearchResult:
    root = _Node(environment.initial_state())
    trace: list[SearchTraceStep] = []
    all_nodes = [root]
    frontier: list[tuple[float, int, _Node]] = [(0.0, 0, root)]
    counter = 1
    expansions = 0
    rng = random.Random(budget.seed)
    while frontier and expansions < budget.max_expansions:
        _, _, node = heapq.heappop(frontier)
        if node.state.terminal or node.state.depth >= budget.max_depth:
            continue
        for move in _validated_moves(environment, node.state, budget, strategy):
            if expansions >= budget.max_expansions:
                break
            child = _expand(
                environment=environment,
                node=node,
                move=move,
                trace=trace,
                reflection=False,
            )
            scores = [
                _rollout(environment, child, strategy, budget, rng)
                for _ in range(budget.monte_carlo_completions)
            ]
            backed_up = (
                max(scores)
                if strategy is SearchStrategy.B11_CHEN_HEAP_MC_MAX
                else sum(scores) / len(scores)
            )
            priority = -(child.reward + backed_up)
            heapq.heappush(frontier, (priority, counter, child))
            counter += 1
            all_nodes.append(child)
            expansions += 1
    best = _select_best(all_nodes)
    return SearchResult(
        strategy_id=strategy.value,
        initial_state_id=root.state.state_id,
        selected_state=best.state,
        trace_steps=trace,
        expansions=expansions,
        verified_signal_gain=len(best.signals),
        exhausted_budget=expansions >= budget.max_expansions,
    )


def _run_mcts(
    environment: SearchEnvironment,
    strategy: SearchStrategy,
    budget: SearchBudget,
) -> SearchResult:
    root = _Node(environment.initial_state())
    trace: list[SearchTraceStep] = []
    all_nodes = [root]
    expansions = 0
    iterations = 0
    reflection = strategy is SearchStrategy.B16_LATS_MCTS_EXTERNAL_VALUE
    while expansions < budget.max_expansions and iterations < budget.max_expansions * 4:
        iterations += 1
        node = root
        path = [node]
        while node.children and node.unexpanded_moves == []:
            log_parent = math.log(max(node.visits, 1))
            node = max(
                node.children,
                key=lambda child: (
                    child.mean_value + math.sqrt(2.0 * log_parent / max(child.visits, 1))
                ),
            )
            path.append(node)
        if node.state.terminal or node.state.depth >= budget.max_depth:
            reward = node.reward
        else:
            if node.unexpanded_moves is None:
                node.unexpanded_moves = _validated_moves(environment, node.state, budget, strategy)
            if not node.unexpanded_moves:
                reward = node.reward
            else:
                move = node.unexpanded_moves.pop(0)
                child = _expand(
                    environment=environment,
                    node=node,
                    move=move,
                    trace=trace,
                    reflection=reflection,
                )
                all_nodes.append(child)
                path.append(child)
                reward = child.reward
                expansions += 1
        for visited in path:
            visited.visits += 1
            visited.value_sum += reward
        if not root.children and root.unexpanded_moves == []:
            break
    best = _select_best(all_nodes)
    return SearchResult(
        strategy_id=strategy.value,
        initial_state_id=root.state.state_id,
        selected_state=best.state,
        trace_steps=trace,
        expansions=expansions,
        verified_signal_gain=len(best.signals),
        exhausted_budget=expansions >= budget.max_expansions,
    )


def run_search_arm(
    environment: SearchEnvironment,
    strategy: SearchStrategy,
    budget: SearchBudget,
) -> SearchResult:
    if strategy in {
        SearchStrategy.B11_CHEN_HEAP_MC_MAX,
        SearchStrategy.B12_CHEN_HEAP_MC_MEAN,
    }:
        return _run_chen_mc(environment, strategy, budget)
    if strategy in {
        SearchStrategy.B13_UCT_MCTS,
        SearchStrategy.B14_RAP_MCTS_EXTERNAL_REWARD,
        SearchStrategy.B15_RAP_SELF_EVAL_ABLATION,
        SearchStrategy.B16_LATS_MCTS_EXTERNAL_VALUE,
        SearchStrategy.B17_LATS_REFLECTION_ABLATION,
    }:
        return _run_mcts(environment, strategy, budget)
    return _run_frontier(environment, strategy, budget)
