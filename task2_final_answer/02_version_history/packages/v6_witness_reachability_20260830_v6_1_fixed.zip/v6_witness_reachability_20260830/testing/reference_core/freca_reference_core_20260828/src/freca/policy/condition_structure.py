"""Keep legal condition scope separate from case-level trigger evidence."""

from __future__ import annotations

from enum import StrEnum

from pydantic import Field

from freca.domain.models import SafeId, StrictModel


class ConditionScopeClass(StrEnum):
    REGISTERED_OPERATION_SCOPE_GATE = "REGISTERED_OPERATION_SCOPE_GATE"
    WHOLE_CP_TRIGGER = "WHOLE_CP_TRIGGER"
    SUBREQUIREMENT_TRIGGER = "SUBREQUIREMENT_TRIGGER"
    AMBIGUOUS_WHOLE_VS_SUBREQUIREMENT = "AMBIGUOUS_WHOLE_VS_SUBREQUIREMENT"


class FalseTriggerSemantics(StrEnum):
    NOT_APPLICABLE = "NOT_APPLICABLE"
    VACUOUSLY_SATISFIED = "VACUOUSLY_SATISFIED"
    INTERPRETATION_OPEN = "INTERPRETATION_OPEN"
    NOT_REACHED_SUBREQUIREMENT_ONLY = "NOT_REACHED_SUBREQUIREMENT_ONLY"


class ConditionTriggerEvidenceState(StrEnum):
    PROVEN_OCCURRED = "PROVEN_OCCURRED"
    PROVEN_NOT_OCCURRED = "PROVEN_NOT_OCCURRED"
    CONFLICTING = "CONFLICTING"
    UNKNOWN = "UNKNOWN"


class ConditionStructureDecision(StrictModel):
    decision_id: SafeId
    condition_proposition_id: SafeId
    condition_scope_class: ConditionScopeClass
    controlled_requirement_ids: list[SafeId] = Field(default_factory=list)
    residual_requirement_ids: list[SafeId] = Field(default_factory=list)
    false_trigger_semantics: FalseTriggerSemantics
    official_source_span_ids: list[SafeId] = Field(min_length=1)
    connector_source_span_ids: list[SafeId] = Field(default_factory=list)
    quantifier_source_span_ids: list[SafeId] = Field(default_factory=list)


class FalseTriggerEligibility(StrictModel):
    eligible_for_whole_cp_branch: bool
    reason_codes: list[str]


def evaluate_false_trigger_eligibility(
    decision: ConditionStructureDecision,
    trigger_state: ConditionTriggerEvidenceState,
) -> FalseTriggerEligibility:
    reasons: list[str] = []
    if decision.condition_scope_class not in {
        ConditionScopeClass.REGISTERED_OPERATION_SCOPE_GATE,
        ConditionScopeClass.WHOLE_CP_TRIGGER,
    }:
        reasons.append("CONDITION_DOES_NOT_CONTROL_WHOLE_CP")
    if trigger_state is not ConditionTriggerEvidenceState.PROVEN_NOT_OCCURRED:
        reasons.append("FALSE_TRIGGER_NOT_POSITIVELY_PROVEN")
    if decision.residual_requirement_ids:
        reasons.append("RESIDUAL_DECISIVE_REQUIREMENTS_REMAIN")
    if decision.false_trigger_semantics not in {
        FalseTriggerSemantics.NOT_APPLICABLE,
        FalseTriggerSemantics.VACUOUSLY_SATISFIED,
        FalseTriggerSemantics.INTERPRETATION_OPEN,
    }:
        reasons.append("FALSE_TRIGGER_IS_SUBREQUIREMENT_ONLY")
    return FalseTriggerEligibility(
        eligible_for_whole_cp_branch=not reasons,
        reason_codes=reasons,
    )
