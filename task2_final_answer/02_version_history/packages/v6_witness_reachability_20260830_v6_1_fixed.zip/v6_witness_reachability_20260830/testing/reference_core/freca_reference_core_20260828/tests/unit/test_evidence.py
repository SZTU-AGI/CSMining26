"""Tests for the evidence chain: readers, segmentation, identity, admissibility.

Fixtures are synthesised in-process rather than read from ``数据集/``. The corpus
is read-only input, and a test suite that needs it cannot run on a machine that
only has the code. The fixtures deliberately reproduce the structures that were
*measured* in the real corpus — ``w:br`` line breaks, heading-less numbered
sections, a row-3 spreadsheet header, a ``Dest RE No.`` column — so the tests
fail for the same reasons production would.
"""

from __future__ import annotations

import zipfile
from pathlib import Path

import pytest
from openpyxl import Workbook

from freca.evidence.admissibility import (
    AdmissibilityReason,
    IdentityPolicy,
    decide_admissibility,
)
from freca.evidence.docx_reader import DocxParseError, read_docx
from freca.evidence.identity import (
    IdentityReference,
    extract_anchors_docx,
    extract_anchors_xlsx,
    find_re_numbers,
    normalise_entity,
    resolve_identity,
)
from freca.domain.enums import EvidenceIdentityState
from freca.evidence.segment import classify_heading, segment_document
from freca.evidence.docx_reader import DocxParagraph
from freca.evidence.xlsx_reader import read_xlsx

DOCUMENT_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>
    <w:p><w:r><w:t>REGISTERED ESTABLISHMENT</w:t><w:br/><w:t>EXPORT RECORD</w:t></w:r></w:p>
    <w:tbl>
      <w:tr><w:tc><w:p><w:r><w:t>Establishment Name</w:t></w:r></w:p></w:tc>
             <w:tc><w:p><w:r><w:t>Darling Downs Grain Pty Ltd</w:t></w:r></w:p></w:tc></w:tr>
      <w:tr><w:tc><w:p><w:r><w:t>RE Number</w:t></w:r></w:p></w:tc>
             <w:tc><w:p><w:r><w:t>RE-QLD-2021-0112</w:t></w:r></w:p></w:tc></w:tr>
    </w:tbl>
    <w:p><w:pPr><w:pStyle w:val="Heading1"/></w:pPr><w:r><w:t>1. Establishment Details</w:t></w:r></w:p>
    <w:p><w:r><w:t>The premises comprise Lot 8 on Plan DP 932273.</w:t></w:r></w:p>
    <w:p><w:r><w:t>2. Pest Control System Overview</w:t></w:r></w:p>
    <w:p><w:r><w:t>Stations are serviced monthly.</w:t></w:r></w:p>
  </w:body>
</w:document>
"""


@pytest.fixture()
def docx_path(tmp_path: Path) -> Path:
    path = tmp_path / "1_Farm_05_Darling_Downs_Grain_Pty_Ltd.docx"
    with zipfile.ZipFile(path, "w") as archive:
        archive.writestr("word/document.xml", DOCUMENT_XML)
    return path


@pytest.fixture()
def xlsx_path(tmp_path: Path) -> Path:
    path = tmp_path / "9_Traceability_Records_Hinterland_Packing_005.xlsx"
    workbook = Workbook()
    cover = workbook.active
    cover.title = "Cover"
    for row, (key, value) in enumerate(
        [("PEST CONTROL RECORD", None), ("Export Control", None),
         ("Establishment Name", "Kimberley Cotton Ginning"), ("RE Number", "RE-WA-2022-0198")],
        start=1,
    ):
        cover.cell(row=row, column=1, value=key)
        if value is not None:
            cover.cell(row=row, column=2, value=value)

    sheet = workbook.create_sheet("4. Dispatch-Transfer Dockets")
    sheet.append(["DISPATCH / TRANSFER DOCKETS"])
    sheet.append(["Establishment: Hinterland Packing 005  |  no registration"])
    sheet.append(["Docket Ref", "Date", "Destination Premises", "Dest RE No."])
    sheet.append(["DD-1", "15/03/2026", "Port Terminal", "RE-TAS-P100"])
    workbook.save(path)
    return path


# ---------------------------------------------------------------- docx reader


def test_line_breaks_survive_text_extraction(docx_path: Path) -> None:
    """``w:br`` must not silently weld two lines together."""

    document = read_docx(docx_path)
    assert document.paragraphs[0].text == "REGISTERED ESTABLISHMENT\nEXPORT RECORD"


def test_paragraph_and_table_indexes_are_independent(docx_path: Path) -> None:
    document = read_docx(docx_path)
    assert [p.paragraph_index for p in document.paragraphs] == list(range(5))
    assert [t.table_index for t in document.tables] == [0]
    assert document.tables[0].rows[0] == ["Establishment Name", "Darling Downs Grain Pty Ltd"]


def test_non_docx_raises(tmp_path: Path) -> None:
    broken = tmp_path / "broken.docx"
    broken.write_bytes(b"not a zip")
    with pytest.raises(DocxParseError):
        read_docx(broken)


# ----------------------------------------------------------------- segmenting


def test_unstyled_numbered_paragraph_opens_a_section(docx_path: Path) -> None:
    """T2/T7/T8 carry no heading style; numbering alone must be enough."""

    sections = segment_document(read_docx(docx_path))
    keys = {section.section_key: section for section in sections}
    assert keys["1"].detected_by == "number+style"
    assert keys["2"].detected_by == "number"
    assert keys["2"].title == "Pest Control System Overview"


def test_preamble_is_kept_not_dropped(docx_path: Path) -> None:
    sections = segment_document(read_docx(docx_path))
    preamble = sections[0]
    assert preamble.section_key == "__preamble__"
    # The cover table holds the establishment name that E3 needs.
    assert preamble.tables and preamble.tables[0].rows[1][1] == "RE-QLD-2021-0112"


def test_long_numbered_prose_is_not_a_heading() -> None:
    prose = DocxParagraph(
        paragraph_index=0,
        block_order=0,
        style=None,
        text=(
            "2. The occupier must ensure that every consignment presented for export is "
            "accompanied by documentation sufficient to establish traceability to the paddock."
        ),
    )
    assert classify_heading(prose) is None


# ---------------------------------------------------------------- xlsx reader


def test_header_row_is_detected_not_assumed(xlsx_path: Path) -> None:
    document = read_xlsx(xlsx_path)
    dockets = document.sheet("4. Dispatch-Transfer Dockets")
    assert dockets is not None
    assert dockets.header_row == 3
    assert dockets.kind == "records"
    assert dockets.headers == ["Docket Ref", "Date", "Destination Premises", "Dest RE No."]


def test_record_rows_carry_spreadsheet_native_locators(xlsx_path: Path) -> None:
    dockets = read_xlsx(xlsx_path).sheet("4. Dispatch-Transfer Dockets")
    assert dockets is not None
    row = dockets.rows[0]
    assert row.cell_range == "A4:D4"
    assert row.as_mapping()["Dest RE No."] == "RE-TAS-P100"


def test_cover_sheet_is_key_value(xlsx_path: Path) -> None:
    cover = read_xlsx(xlsx_path).sheet("Cover")
    assert cover is not None
    assert cover.kind == "key_value"
    assert cover.key_values["Establishment Name"] == "Kimberley Cotton Ginning"


# ------------------------------------------------------------------- identity


def test_legal_suffixes_are_stripped_but_distinguishing_words_are_not() -> None:
    assert normalise_entity("Gwydir Valley Grain Trust") == normalise_entity("Gwydir Valley Grain")
    # 'Holdings' distinguishes an entity and must survive.
    assert normalise_entity("Midwest Grain Holdings Pty Ltd") != normalise_entity("Midwest Grain")


def test_malformed_registration_numbers_are_separated() -> None:
    canonical, malformed = find_re_numbers("valid RE-QLD-2021-0112 and bogus RE-QLD-3318")
    assert canonical == ["RE-QLD-2021-0112"]
    assert malformed == ["RE-QLD-3318"]


def test_matching_registration_number_outranks_a_differing_name(docx_path: Path) -> None:
    anchors = extract_anchors_docx(read_docx(docx_path))
    reference = IdentityReference("Darling Downs Grain", "RE-QLD-2021-0112", 5)
    assert resolve_identity(anchors, reference).state is EvidenceIdentityState.SELF


def test_third_party_registration_numbers_are_mentions_not_claims(xlsx_path: Path) -> None:
    """A ``Dest RE No.`` names the next premises, not the document's owner."""

    anchors = extract_anchors_xlsx(read_xlsx(xlsx_path))
    assert "RE-TAS-P100" in anchors.mentioned_re_numbers
    assert "RE-TAS-P100" not in anchors.malformed_re_numbers
    assert "RE-TAS-P100" not in anchors.re_numbers


# -------------------------------------------------------------- admissibility


def _assess(xlsx_path: Path, reference: IdentityReference):
    anchors = extract_anchors_xlsx(read_xlsx(xlsx_path))
    return anchors, resolve_identity(anchors, reference)


def test_conflicting_registration_is_rejected_when_differentiated(xlsx_path: Path) -> None:
    reference = IdentityReference("Darling Downs Grain Pty Ltd", "RE-QLD-2021-0112", 5)
    anchors, assessment = _assess(xlsx_path, reference)
    decision = decide_admissibility(
        assessment, anchors, reference, IdentityPolicy.DIFFERENTIATED
    )
    assert decision.reason is AdmissibilityReason.CONFLICTING_REGISTRATION
    assert not decision.admissible


def test_alias_bound_to_case_serial_is_admitted_when_differentiated(tmp_path: Path) -> None:
    """The T9 shape: another trading name, no registration number, case serial."""

    path = tmp_path / "9_Traceability_Records_Alias_005.xlsx"
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "1. Receival Register"
    sheet.append(["RECEIVAL REGISTER"])
    sheet.append(["Establishment: Hinterland Packing 005"])
    sheet.append(["Receival Date", "Variety", "Qty (t)"])
    sheet.append(["03/02/2026", "Rosalind", "196.4"])
    workbook.save(path)

    reference = IdentityReference("Darling Downs Grain Pty Ltd", "RE-QLD-2021-0112", 5)
    anchors = extract_anchors_xlsx(read_xlsx(path))
    assessment = resolve_identity(anchors, reference)
    decision = decide_admissibility(
        assessment, anchors, reference, IdentityPolicy.DIFFERENTIATED
    )
    assert decision.reason is AdmissibilityReason.ALIAS_UNVERIFIED
    assert decision.admissible
    # Admitted, but never silently: the verdict must still be reviewed.
    assert decision.review_required


def test_policies_disagree_which_is_the_point_of_the_ablation(xlsx_path: Path) -> None:
    reference = IdentityReference("Darling Downs Grain Pty Ltd", "RE-QLD-2021-0112", 5)
    anchors, assessment = _assess(xlsx_path, reference)
    verdicts = {
        policy: decide_admissibility(assessment, anchors, reference, policy).admissible
        for policy in IdentityPolicy
    }
    assert verdicts[IdentityPolicy.LENIENT] is True
    assert verdicts[IdentityPolicy.STRICT] is False
