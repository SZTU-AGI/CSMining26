"""Single-writer, append-only hash-chained RunEventV2 log."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Literal

from pydantic import ValidationError

from freca.governance.hashing import canonical_json_bytes, sha256_bytes
from freca.governance.models import EventType, RunEventV2


class EventLogIntegrityError(ValueError):
    pass


class EventWriter:
    def __init__(self, run_root: str | Path, run_id: str) -> None:
        self.run_id = run_id
        self.path = Path(run_root).resolve() / run_id / "events.v2.jsonl"
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def append(
        self,
        event_type: EventType,
        *,
        severity: Literal["INFO", "WARNING", "ERROR", "FATAL"] = "INFO",
        node: str | None = None,
        case_id: str | None = None,
        cp_id: str | None = None,
        artifact_ids: list[str] | None = None,
        detail: dict[str, Any] | None = None,
    ) -> RunEventV2:
        events = self.read_verified()
        sequence = len(events)
        event = RunEventV2.create(
            event_id=f"event-{sequence:08d}",
            run_id=self.run_id,
            sequence=sequence,
            event_type=event_type,
            severity=severity,
            previous_event_sha256=events[-1].event_sha256 if events else None,
            node=node,
            case_id=case_id,
            cp_id=cp_id,
            artifact_ids=artifact_ids,
            detail=detail,
        )
        with self.path.open("ab") as stream:
            stream.write(canonical_json_bytes(event) + b"\n")
            stream.flush()
            os.fsync(stream.fileno())
        return event

    def read_verified(self) -> list[RunEventV2]:
        if not self.path.exists():
            return []
        events: list[RunEventV2] = []
        try:
            lines = self.path.read_text(encoding="utf-8").splitlines()
            for sequence, line in enumerate(lines):
                if not line.strip():
                    raise EventLogIntegrityError("blank line in event log")
                event = RunEventV2.model_validate_json(line)
                expected_previous = events[-1].event_sha256 if events else None
                if event.run_id != self.run_id:
                    raise EventLogIntegrityError("event run_id does not match log")
                if event.sequence != sequence:
                    raise EventLogIntegrityError("event sequence is not contiguous")
                if event.previous_event_sha256 != expected_previous:
                    raise EventLogIntegrityError("event previous hash link is broken")
                events.append(event)
        except (OSError, ValidationError, json.JSONDecodeError) as error:
            raise EventLogIntegrityError(f"cannot verify event log: {self.path}") from error
        return events

    def log_sha256(self) -> str:
        self.read_verified()
        return sha256_bytes(self.path.read_bytes() if self.path.exists() else b"")
