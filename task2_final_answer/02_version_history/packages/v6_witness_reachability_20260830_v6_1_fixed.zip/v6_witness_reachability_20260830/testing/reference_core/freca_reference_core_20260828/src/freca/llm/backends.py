"""Pluggable LLM backends with reproducibility built in.

Competition constraints shape this module
------------------------------------------
* Submissions must state the exact prompts and the model name/version, and a
  non-reproducible submission is disqualified. Every call therefore returns a
  :class:`LLMResponse` carrying the prompt hash, the model identifier and the
  config hash, and those are what get persisted — not a free-text log line.
* API keys must never appear in the shipped ZIP. :class:`OpenAICompatibleLLM`
  reads its key from an environment variable and refuses to accept one as a
  literal argument.
* The package has to run on a server with no outbound network. ``FakeJSONLLM``
  is a deterministic offline backend so that the whole pipeline, its gates and
  its reports can be exercised end to end before a real key is ever configured.

The fake backend is *not* a mock in the testing sense: it is a real backend that
answers from a seeded hash. It makes runs bit-reproducible and makes it obvious
when a result is an artefact of plumbing rather than of reasoning — a fake run
that scores well is a bug, not a success.
"""

from __future__ import annotations

import json
import os
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

from freca.governance.hashing import sha256_bytes, sha256_digest

DEFAULT_TIMEOUT_S = 120


def sha256_text(text: str) -> str:
    return sha256_bytes(text.encode("utf-8"))


def canonical_hash(value: Any) -> str:
    return sha256_digest(value)


class LLMError(RuntimeError):
    """Backend failure that the caller must handle explicitly, never swallow."""


@dataclass(slots=True)
class LLMResponse:
    text: str
    model_name: str
    prompt_hash: str
    config_hash: str
    input_tokens: int
    output_tokens: int
    latency_ms: int
    #: True when the payload came from a deterministic offline backend.
    synthetic: bool = False
    raw: dict[str, Any] = field(default_factory=dict)

    def json(self) -> Any:
        """Parse the response as JSON, tolerating fenced code blocks."""

        return parse_json_payload(self.text)


def parse_json_payload(text: str) -> Any:
    """Extract a JSON object from a model response.

    Models wrap JSON in ```json fences or prose often enough that failing on it
    would attribute a formatting slip to the reasoning. Repair is limited to
    locating the outermost object — the content is never edited.
    """

    stripped = text.strip()
    if stripped.startswith("```"):
        lines = [line for line in stripped.splitlines() if not line.strip().startswith("```")]
        stripped = "\n".join(lines).strip()
    try:
        return json.loads(stripped)
    except json.JSONDecodeError:
        pass
    start = stripped.find("{")
    end = stripped.rfind("}")
    if start != -1 and end > start:
        try:
            return json.loads(stripped[start : end + 1])
        except json.JSONDecodeError as error:
            raise LLMError(f"response is not valid JSON: {stripped[:200]}") from error
    raise LLMError(f"response contains no JSON object: {stripped[:200]}")


@dataclass(slots=True)
class LLMConfig:
    model_name: str
    temperature: float = 0.0
    max_tokens: int = 2048
    top_p: float = 1.0
    seed: int | None = 20260731
    #: Name of the environment variable holding the key. Never the key itself.
    api_key_env: str = "FRECA_LLM_API_KEY"
    base_url: str | None = None
    timeout_s: int = DEFAULT_TIMEOUT_S

    def fingerprint(self) -> str:
        """Config identity for the audit trail; excludes anything secret."""

        return canonical_hash(
            {
                "model_name": self.model_name,
                "temperature": self.temperature,
                "max_tokens": self.max_tokens,
                "top_p": self.top_p,
                "seed": self.seed,
                "base_url": self.base_url,
            }
        )


class LLMBackend(ABC):
    """Minimal surface every backend must provide."""

    def __init__(self, config: LLMConfig) -> None:
        self.config = config
        #: Exact prompt/response records for reproducibility audits.  The API
        #: key is never part of either prompt field or the response metadata.
        self.call_records: list[dict[str, Any]] = []

    @property
    def model_name(self) -> str:
        return self.config.model_name

    @abstractmethod
    def complete(self, system: str, user: str) -> LLMResponse: ...

    def complete_json(self, system: str, user: str, *, retries: int = 1) -> Any:
        """Complete and parse as JSON, retrying once on a formatting failure.

        The retry re-sends the *same* prompt with an explicit format reminder. It
        never rewrites the task, because a second attempt that changes the
        question would silently answer a different one.
        """

        payload, _response = self.complete_json_with_response(system, user, retries=retries)
        return payload

    def complete_json_with_response(
        self, system: str, user: str, *, retries: int = 1
    ) -> tuple[Any, LLMResponse]:
        """Return parsed JSON and the response metadata used to produce it."""

        last_error: LLMError | None = None
        for attempt in range(retries + 1):
            reminder = (
                ""
                if attempt == 0
                else (
                    "\n\nYour previous reply was not valid JSON. "
                    "Reply with a single JSON object and nothing else."
                )
            )
            request_user = user + reminder
            response = self.complete(system, request_user)
            self.call_records.append(
                {
                    "attempt": attempt,
                    "system": system,
                    "user": request_user,
                    "response": response.text,
                    "model_name": response.model_name,
                    "prompt_hash": response.prompt_hash,
                    "config_hash": response.config_hash,
                    "input_tokens": response.input_tokens,
                    "output_tokens": response.output_tokens,
                    "latency_ms": response.latency_ms,
                    "synthetic": response.synthetic,
                }
            )
            try:
                return response.json(), response
            except LLMError as error:
                last_error = error
        raise last_error or LLMError("json completion failed")


class FakeJSONLLM(LLMBackend):
    """Deterministic offline backend.

    Answers are derived from a hash of the prompt, so the same prompt always
    yields the same reply and different prompts yield different replies. A caller
    may register exact-match responses for the prompts a test cares about; the
    hash fallback keeps the pipeline running for everything else.
    """

    def __init__(self, config: LLMConfig | None = None) -> None:
        super().__init__(config or LLMConfig(model_name="fake-offline-v1"))
        self.responses: dict[str, str] = {}
        self.calls: list[tuple[str, str]] = []
        self.default_payload: dict[str, Any] = {}

    def register(self, prompt_substring: str, payload: Any) -> None:
        self.responses[prompt_substring] = json.dumps(payload, ensure_ascii=False)

    def complete(self, system: str, user: str) -> LLMResponse:
        started = time.perf_counter()
        self.calls.append((system, user))
        prompt = f"{system}\n\n{user}"

        text: str | None = None
        for needle, payload in self.responses.items():
            if needle in user or needle in system:
                text = payload
                break
        if text is None:
            digest = sha256_text(prompt).removeprefix("sha256:")
            payload = dict(self.default_payload)
            payload.setdefault("synthetic", True)
            payload.setdefault("fingerprint", digest[:16])
            text = json.dumps(payload, ensure_ascii=False)

        return LLMResponse(
            text=text,
            model_name=self.model_name,
            prompt_hash=sha256_text(prompt),
            config_hash=self.config.fingerprint(),
            input_tokens=len(prompt) // 4,
            output_tokens=len(text) // 4,
            latency_ms=int((time.perf_counter() - started) * 1000),
            synthetic=True,
        )


class OpenAICompatibleLLM(LLMBackend):
    """Any OpenAI-compatible ``/chat/completions`` endpoint.

    Uses ``urllib`` rather than the ``openai`` SDK to avoid adding a dependency
    that the target JupyterLab may not have; the wire format is stable and small.
    """

    def __init__(self, config: LLMConfig) -> None:
        super().__init__(config)
        if not config.base_url:
            raise ValueError("OpenAICompatibleLLM requires base_url")

    def _api_key(self) -> str:
        key = os.environ.get(self.config.api_key_env, "").strip()
        if not key:
            raise LLMError(
                f"environment variable {self.config.api_key_env} is not set; "
                "keys are never read from config files or the package"
            )
        return key

    def complete(self, system: str, user: str) -> LLMResponse:
        import urllib.error
        import urllib.request

        started = time.perf_counter()
        prompt = f"{system}\n\n{user}"
        body = {
            "model": self.config.model_name,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "temperature": self.config.temperature,
            "max_tokens": self.config.max_tokens,
            "top_p": self.config.top_p,
        }
        if self.config.seed is not None:
            body["seed"] = self.config.seed

        request = urllib.request.Request(
            url=self.config.base_url.rstrip("/") + "/chat/completions",
            data=json.dumps(body).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self._api_key()}",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=self.config.timeout_s) as handle:
                payload = json.loads(handle.read().decode("utf-8"))
        except urllib.error.HTTPError as error:
            raise LLMError(
                f"HTTP {error.code} from {self.config.base_url}: {error.read()[:300]!r}"
            ) from error
        except urllib.error.URLError as error:
            raise LLMError(f"cannot reach {self.config.base_url}: {error.reason}") from error

        try:
            text = payload["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as error:
            raise LLMError(f"unexpected response shape: {str(payload)[:300]}") from error

        usage = payload.get("usage", {}) or {}
        return LLMResponse(
            text=text,
            model_name=payload.get("model", self.model_name),
            prompt_hash=sha256_text(prompt),
            config_hash=self.config.fingerprint(),
            input_tokens=int(usage.get("prompt_tokens", 0)),
            output_tokens=int(usage.get("completion_tokens", 0)),
            latency_ms=int((time.perf_counter() - started) * 1000),
            synthetic=False,
            raw=payload if isinstance(payload, dict) else {},
        )


def build_backend(spec: dict[str, Any]) -> LLMBackend:
    """Construct a backend from a config mapping (see ``configs/models.yaml``)."""

    kind = str(spec.get("backend", "fake")).lower()
    config = LLMConfig(
        model_name=str(spec.get("model_name", "fake-offline-v1")),
        temperature=float(spec.get("temperature", 0.0)),
        max_tokens=int(spec.get("max_tokens", 2048)),
        top_p=float(spec.get("top_p", 1.0)),
        seed=spec.get("seed", 20260731),
        api_key_env=str(spec.get("api_key_env", "FRECA_LLM_API_KEY")),
        base_url=spec.get("base_url"),
        timeout_s=int(spec.get("timeout_s", DEFAULT_TIMEOUT_S)),
    )
    if kind == "fake":
        return FakeJSONLLM(config)
    if kind in {"openai", "openai_compatible", "vllm", "ollama"}:
        return OpenAICompatibleLLM(config)
    raise ValueError(f"unknown llm backend: {kind!r}")
