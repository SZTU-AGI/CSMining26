"""Fail-closed Layer 2 vertical slice from candidates to dual representations."""

from __future__ import annotations

from enum import StrEnum
from typing import Literal

from pydantic import Field, model_validator

from freca.argument.models import ArgumentGraphTemplate
from freca.argument.projection import project_argument_graph
from freca.domain.models import SafeId, Sha256, StrictModel
from freca.governance.hashing import sha256_digest
from freca.logic.ast import ContractRoots, LogicDAG, LogicNode, LogicOperator
from freca.policy.graph_projection_conformance import (
    GraphProjectionConformanceReport,
    audit_graph_projection,
)
from freca.policy.indexed_requirement_view import (
    IndexedRequirementView,
    build_indexed_requirement_view,
)
from freca.policy.norm_events import NormEventBundle, NormEventGroup, build_norm_event_bundle
from freca.policy.propositions import (
    PropositionCatalog,
    PropositionRole,
    build_grouped_proposition_catalog,
    build_proposition_catalog,
)
from freca.policy.retrieval_v2 import CandidateLedger
from freca.policy.schemas_v2 import PolicyIndex


class ContractSliceStatus(StrEnum):
    VALID = "VALID"
    REVIEW_REQUIRED = "REVIEW_REQUIRED"


class ClosureConfig(StrictModel):
    max_reference_depth: int = Field(default=1, ge=0, le=8)
    max_added_units: int = Field(default=80, ge=0, le=500)
    include_structural_context: bool = True
    include_direct_references: bool = True


class ClosureStep(StrictModel):
    step_id: SafeId
    source_unit_id: SafeId | None = None
    target_unit_id: SafeId
    reason: Literal["SELECTED_CANDIDATE", "STRUCTURAL_CONTEXT", "DIRECT_REFERENCE"]
    depth: int = Field(ge=0)


class BoundedPolicyClosure(StrictModel):
    closure_id: SafeId
    cp_id: str = Field(min_length=1)
    seed_policy_unit_ids: list[SafeId]
    included_policy_unit_ids: list[SafeId]
    steps: list[ClosureStep]
    budget_exceeded: bool
    unresolved_policy_unit_ids: list[SafeId] = Field(default_factory=list)
    closure_sha256: Sha256


class ContractSliceBundle(StrictModel):
    slice_id: SafeId
    cp_id: str = Field(min_length=1)
    status: ContractSliceStatus
    review_required_reason_codes: list[str] = Field(default_factory=list)
    candidate_ledger_id: SafeId
    closure: BoundedPolicyClosure
    norm_event_bundle: NormEventBundle
    proposition_catalog: PropositionCatalog | None = None
    logic_dag: LogicDAG | None = None
    indexed_requirement_view: IndexedRequirementView | None = None
    argument_graph_template: ArgumentGraphTemplate | None = None
    projection_conformance: GraphProjectionConformanceReport | None = None
    slice_sha256: Sha256

    @model_validator(mode="after")
    def downstream_artifacts_are_atomic(self) -> ContractSliceBundle:
        downstream = (
            self.proposition_catalog,
            self.logic_dag,
            self.indexed_requirement_view,
            self.argument_graph_template,
            self.projection_conformance,
        )
        present = sum(item is not None for item in downstream)
        if present not in {0, len(downstream)}:
            raise ValueError("contract slice downstream artifacts must be absent or complete")
        if self.status is ContractSliceStatus.VALID:
            if present != len(downstream):
                raise ValueError("VALID contract slice requires complete downstream artifacts")
            if self.review_required_reason_codes:
                raise ValueError("VALID contract slice cannot carry review-required reasons")
            if not self.projection_conformance.exact_projection_passed:
                raise ValueError("VALID contract slice requires exact graph-index projection")
        elif not self.review_required_reason_codes:
            raise ValueError("REVIEW_REQUIRED contract slice requires at least one reason")
        return self


def _step(*, source_id: str | None, target_id: str, reason: str, depth: int) -> ClosureStep:
    payload = {
        "source_unit_id": source_id,
        "target_unit_id": target_id,
        "reason": reason,
        "depth": depth,
    }
    digest = sha256_digest(payload)
    return ClosureStep(step_id=f"closurestep-{digest.split(':', 1)[1][:20]}", **payload)


def build_bounded_policy_closure(
    *,
    ledger: CandidateLedger,
    policy: PolicyIndex,
    config: ClosureConfig | None = None,
) -> BoundedPolicyClosure:
    config = config or ClosureConfig()
    by_id = {unit.unit_id: unit for unit in policy.units}
    seeds = sorted(
        {
            candidate.policy_unit_id
            for candidate in ledger.candidates
            if candidate.decision is not None and candidate.decision.selected
        }
    )
    included = {unit_id for unit_id in seeds if unit_id in by_id}
    unresolved = {unit_id for unit_id in seeds if unit_id not in by_id}
    steps = [
        _step(source_id=None, target_id=unit_id, reason="SELECTED_CANDIDATE", depth=0)
        for unit_id in seeds
    ]
    additions = 0
    budget_exceeded = False

    def add(source_id: str, target_id: str, reason: str, depth: int) -> bool:
        nonlocal additions, budget_exceeded
        if target_id not in by_id:
            unresolved.add(target_id)
            return False
        if target_id in included:
            return False
        if additions >= config.max_added_units:
            budget_exceeded = True
            return False
        included.add(target_id)
        additions += 1
        steps.append(_step(source_id=source_id, target_id=target_id, reason=reason, depth=depth))
        return True

    if config.include_structural_context:
        structural_frontier = list(sorted(included))
        while structural_frontier:
            source_id = structural_frontier.pop(0)
            unit = by_id[source_id]
            targets = set(unit.context_unit_ids)
            if unit.parent_id is not None:
                targets.add(unit.parent_id)
            for target_id in sorted(targets):
                if add(source_id, target_id, "STRUCTURAL_CONTEXT", 0):
                    structural_frontier.append(target_id)

    if config.include_direct_references and config.max_reference_depth:
        references_by_source: dict[str, set[str]] = {}
        for edge in policy.graph_edges:
            if edge.edge_type == "REFERS_TO":
                references_by_source.setdefault(edge.source_id, set()).add(edge.target_id)
        for mention in policy.reference_mentions:
            for target in mention.targets:
                if target.resolution_status == "RESOLVED" and target.target_unit_id:
                    references_by_source.setdefault(mention.source_unit_id, set()).add(
                        target.target_unit_id
                    )
        frontier = [(unit_id, 0) for unit_id in sorted(included)]
        expanded: set[tuple[str, int]] = set()
        while frontier:
            source_id, depth = frontier.pop(0)
            if (source_id, depth) in expanded or depth >= config.max_reference_depth:
                continue
            expanded.add((source_id, depth))
            for target_id in sorted(references_by_source.get(source_id, set())):
                added = add(source_id, target_id, "DIRECT_REFERENCE", depth + 1)
                if added or target_id in included:
                    frontier.append((target_id, depth + 1))

    steps = sorted(
        steps,
        key=lambda item: (item.depth, item.reason, item.source_unit_id or "", item.target_unit_id),
    )
    payload = {
        "cp_id": ledger.cp_id,
        "seed_policy_unit_ids": seeds,
        "included_policy_unit_ids": sorted(included),
        "steps": steps,
        "budget_exceeded": budget_exceeded,
        "unresolved_policy_unit_ids": sorted(unresolved),
    }
    digest = sha256_digest(payload)
    return BoundedPolicyClosure(
        closure_id=f"closure-{digest.split(':', 1)[1][:20]}",
        closure_sha256=digest,
        **payload,
    )


def _build_logic_dag(catalog: PropositionCatalog, primary_span_ids: list[str]) -> LogicDAG:
    root_nodes: dict[str, str] = {}
    nodes: list[LogicNode] = []
    propositions_by_id = {item.proposition_id: item for item in catalog.propositions}
    for root_name, proposition_id in sorted(catalog.root_proposition_ids.items()):
        if proposition_id is None:
            raise ValueError("single-norm catalog cannot have a structural proposition root")
        node_id = f"logic-{root_name.replace('_', '-')}-{proposition_id.removeprefix('prop-')}"
        root_nodes[root_name] = node_id
        nodes.append(
            LogicNode(
                node_id=node_id,
                operator=LogicOperator.ATOM,
                proposition_id=proposition_id,
                compile_rule_id="SINGLE_ANCHORED_PRIMARY_NORM_V1",
                semantic_role=propositions_by_id[proposition_id].semantic_role.value,
                source_span_ids=primary_span_ids,
            )
        )
    digest = sha256_digest(
        {"catalog_sha256": catalog.catalog_sha256, "nodes": nodes, "roots": root_nodes}
    )
    return LogicDAG(
        interpretation_id=f"interpretation-{digest.split(':', 1)[1][:20]}",
        nodes=nodes,
        roots=ContractRoots(
            applicability_root_id=root_nodes["applicability"],
            satisfaction_root_id=root_nodes["satisfaction"],
            violation_root_id=root_nodes["violation"],
            non_applicability_root_id=root_nodes["non_applicability"],
        ),
    )


def _build_grouped_logic_dag(
    catalog: PropositionCatalog,
    norm_bundle: NormEventBundle,
    group: NormEventGroup,
) -> LogicDAG:
    event_by_id = {item.event_id: item for item in norm_bundle.events}
    propositions_by_event = {
        item.source_norm_event_ids[0]: item
        for item in catalog.propositions
        if item.semantic_role is PropositionRole.LEGAL_SATISFACTION
    }
    nodes: list[LogicNode] = []
    root_nodes: dict[str, str] = {}

    for root_name in ("applicability", "violation", "non_applicability"):
        proposition_id = catalog.root_proposition_ids[root_name]
        if proposition_id is None:
            raise ValueError(f"grouped catalog is missing {root_name} proposition")
        proposition = next(
            item for item in catalog.propositions if item.proposition_id == proposition_id
        )
        node_id = f"logic-{root_name.replace('_', '-')}-{proposition_id.removeprefix('prop-')}"
        root_nodes[root_name] = node_id
        nodes.append(
            LogicNode(
                node_id=node_id,
                operator=LogicOperator.ATOM,
                proposition_id=proposition_id,
                compile_rule_id="ANCHORED_EVENT_GROUP_ROOT_V1",
                semantic_role=proposition.semantic_role.value,
                source_span_ids=proposition.source_span_binding_ids,
            )
        )

    satisfaction_child_node_ids: list[str] = []
    satisfaction_source_span_ids: list[str] = list(group.connector_binding_ids)
    for event_id in group.child_event_ids:
        event = event_by_id[event_id]
        proposition = propositions_by_event[event_id]
        node_id = f"logic-satisfaction-item-{proposition.proposition_id.removeprefix('prop-')}"
        satisfaction_child_node_ids.append(node_id)
        satisfaction_source_span_ids.extend(event.span_binding_ids)
        nodes.append(
            LogicNode(
                node_id=node_id,
                operator=LogicOperator.ATOM,
                proposition_id=proposition.proposition_id,
                compile_rule_id="ANCHORED_ENUM_CHILD_V1",
                semantic_role=proposition.semantic_role.value,
                source_span_ids=event.span_binding_ids,
            )
        )

    satisfaction_payload = {
        "catalog_sha256": catalog.catalog_sha256,
        "group_id": group.group_id,
        "operator": group.aggregation_operator,
        "children": satisfaction_child_node_ids,
        "connectors": group.connector_binding_ids,
    }
    satisfaction_root_id = (
        f"logic-satisfaction-group-{sha256_digest(satisfaction_payload).split(':', 1)[1][:20]}"
    )
    nodes.append(
        LogicNode(
            node_id=satisfaction_root_id,
            operator=LogicOperator(group.aggregation_operator),
            child_ids=satisfaction_child_node_ids,
            connector_span_ids=group.connector_binding_ids,
            compile_rule_id=group.compile_rule_id,
            semantic_role=PropositionRole.LEGAL_SATISFACTION.value,
            source_span_ids=sorted(set(satisfaction_source_span_ids)),
        )
    )
    root_nodes["satisfaction"] = satisfaction_root_id
    digest = sha256_digest(
        {"catalog_sha256": catalog.catalog_sha256, "nodes": nodes, "roots": root_nodes}
    )
    return LogicDAG(
        interpretation_id=f"interpretation-{digest.split(':', 1)[1][:20]}",
        nodes=nodes,
        roots=ContractRoots(
            applicability_root_id=root_nodes["applicability"],
            satisfaction_root_id=root_nodes["satisfaction"],
            violation_root_id=root_nodes["violation"],
            non_applicability_root_id=root_nodes["non_applicability"],
        ),
    )


def compile_contract_slice(
    ledger: CandidateLedger,
    policy: PolicyIndex,
    *,
    closure_config: ClosureConfig | None = None,
) -> ContractSliceBundle:
    """Compile the first narrow contract slice and stop before case adjudication."""

    closure = build_bounded_policy_closure(
        ledger=ledger,
        policy=policy,
        config=closure_config,
    )
    selected = [
        candidate
        for candidate in ledger.candidates
        if candidate.decision is not None and candidate.decision.selected
    ]
    relation_by_unit = {
        candidate.policy_unit_id: candidate.decision.relation
        for candidate in selected
        if candidate.decision is not None
    }
    event_unit_ids = sorted(
        unit_id
        for unit_id, relation in relation_by_unit.items()
        if relation in {"PRIMARY_NORM", "APPLICABILITY", "EXCEPTION_OR_DEEMING"}
    )
    norm_bundle = build_norm_event_bundle(
        cp_id=ledger.cp_id,
        policy=policy,
        policy_unit_ids=event_unit_ids,
        relation_by_unit_id=relation_by_unit,
    )

    reasons = set(norm_bundle.review_required_reason_codes)
    if closure.budget_exceeded:
        reasons.add("BOUNDED_CLOSURE_BUDGET_EXCEEDED")
    if closure.unresolved_policy_unit_ids:
        reasons.add("BOUNDED_CLOSURE_HAS_UNRESOLVED_UNITS")
    primary_unit_ids = sorted(
        unit_id for unit_id, relation in relation_by_unit.items() if relation == "PRIMARY_NORM"
    )
    supported_group = None
    if len(norm_bundle.event_groups) == 1:
        candidate_group = norm_bundle.event_groups[0]
        event_by_id = {event.event_id: event for event in norm_bundle.events}
        grouped_unit_ids = {
            event_by_id[event_id].source_policy_unit_id
            for event_id in candidate_group.child_event_ids
        }
        if grouped_unit_ids == set(primary_unit_ids):
            supported_group = candidate_group

    if not primary_unit_ids:
        reasons.add("NO_SELECTED_PRIMARY_NORM")
    elif len(primary_unit_ids) > 1 and supported_group is None:
        reasons.add("MULTIPLE_PRIMARY_NORMS_REQUIRE_CONNECTOR_BASIS")
    unsupported_relations = {
        relation
        for relation in relation_by_unit.values()
        if relation in {"APPLICABILITY", "EXCEPTION_OR_DEEMING"}
    }
    if unsupported_relations:
        reasons.add("RELATION_SCOPE_COMPILATION_NOT_IMPLEMENTED")

    catalog = None
    dag = None
    view = None
    graph = None
    conformance = None
    if not reasons:
        event_by_unit = {event.source_policy_unit_id: event for event in norm_bundle.events}
        if supported_group is not None:
            event_by_id = {event.event_id: event for event in norm_bundle.events}
            parent_event = event_by_id[supported_group.parent_event_id]
            child_events = [event_by_id[event_id] for event_id in supported_group.child_event_ids]
            catalog = build_grouped_proposition_catalog(
                cp_id=ledger.cp_id,
                parent_event=parent_event,
                child_events=child_events,
            )
            dag = _build_grouped_logic_dag(catalog, norm_bundle, supported_group)
        else:
            primary_event = event_by_unit.get(primary_unit_ids[0])
            if primary_event is None:
                reasons.add("PRIMARY_NORM_EVENT_MISSING")
            else:
                catalog = build_proposition_catalog(
                    cp_id=ledger.cp_id,
                    primary_event=primary_event,
                )
                dag = _build_logic_dag(catalog, primary_event.span_binding_ids)

        if dag is not None and catalog is not None:
            view = build_indexed_requirement_view(
                dag,
                proposition_catalog_sha256=catalog.catalog_sha256,
            )
            graph = project_argument_graph(view, logic_roots=dag.roots)
            conformance = audit_graph_projection(view, graph)
            if not conformance.exact_projection_passed:
                reasons.add("GRAPH_INDEX_PROJECTION_MISMATCH")

    payload = {
        "cp_id": ledger.cp_id,
        "status": (ContractSliceStatus.REVIEW_REQUIRED if reasons else ContractSliceStatus.VALID),
        "review_required_reason_codes": sorted(reasons),
        "candidate_ledger_id": ledger.ledger_id,
        "closure": closure,
        "norm_event_bundle": norm_bundle,
        "proposition_catalog": catalog,
        "logic_dag": dag,
        "indexed_requirement_view": view,
        "argument_graph_template": graph,
        "projection_conformance": conformance,
    }
    digest = sha256_digest(payload)
    return ContractSliceBundle(
        slice_id=f"contractslice-{digest.split(':', 1)[1][:20]}",
        slice_sha256=digest,
        **payload,
    )
