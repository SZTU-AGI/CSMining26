"""Tests for the C0-C7 adjudication loop.

The invariants under test are the ones that protect the score from the pipeline
itself: no silent 0, no compliance-from-absence, no cross-case citation, and a
retry that actually changes the query.
"""

from __future__ import annotations

import pytest

from freca.audit.nodes.adjudicate import (
    adjudicate,
    c0_bind_anchor,
    c1_applicability,
    c2_needs,
    c7_decide,
)
from freca.domain.enums import (
    Applicability,
    ClaimRelation,
    ClaimType,
    DecisionBasis,
    EvidenceIdentityState,
    FinalLabel,
    GateDecision,
    PremiseSourceType,
    Sufficiency,
)
from freca.domain.models import (
    AuditArgument,
    AuditClaim,
    ClaimPremise,
    EvidenceAtom,
    EvidenceLocator,
    IdentityAssessment,
    PolicyPack,
    PolicySpan,
    RuleSlots,
)
from freca.domain.policy_enums import ActorRole, NormScope
from freca.llm.backends import FakeJSONLLM
from freca.policy.norm_graph import NormGraph
from freca.policy.sectionize import NormSection
from freca.retrieval.evidence_index import CaseEvidenceIndex

HASH = "sha256:" + "cd" * 32


def _atom(
    evidence_id: str,
    content: str,
    *,
    track: str = "T1",
    state: EvidenceIdentityState = EvidenceIdentityState.SELF,
    case_id: str = "CASE-1",
) -> EvidenceAtom:
    return EvidenceAtom(
        evidence_id=evidence_id,
        case_id=case_id,
        doc_id=f"{case_id}.{track}",
        track=track,
        source_type="docx.section",
        locator=EvidenceLocator(document_path=f"/{track}.docx", paragraph_index=0),
        content=content,
        identity=IdentityAssessment(state=state),
        source_hash=HASH,
        parse_confidence=1.0,
    )


def _pack(**overrides: object) -> PolicyPack:
    payload: dict[str, object] = {
        "cp_id": "CP22",
        "policy_version": "2021",
        "authoritative_spans": [
            PolicySpan(
                source_id="s11-5",
                locator="11-5",
                text="The occupier of a registered establishment must keep records.",
                source_hash=HASH,
            )
        ],
        "rule_slots": RuleSlots(
            subject="occupier of a registered establishment",
            deontic="must",
            action="keep records of pest control treatment",
            object="pest control records",
            conditions=[],
        ),
        "required_facts": ["pest control treatment records are kept"],
        "violation_facts": [],
        "explicit_na_conditions": [],
    }
    payload.update(overrides)
    return PolicyPack(**payload)  # type: ignore[arg-type]


def _section(
    section_id: str,
    title: str,
    text: str,
    *,
    chapter_no: str,
    chapter_title: str,
    part_no: str,
    part_title: str,
) -> NormSection:
    return NormSection(
        section_id=section_id,
        title=title,
        chapter_no=chapter_no,
        chapter_title=chapter_title,
        part_no=part_no,
        part_title=part_title,
        division_no=None,
        division_title=None,
        lines=text.split("\n"),
    )


@pytest.fixture
def graph() -> NormGraph:
    return NormGraph(
        {
            "11-5": _section(
                "11-5",
                "Records to be kept",
                "(1) The occupier of a registered establishment must keep records.",
                chapter_no="4",
                chapter_title="Registered establishments",
                part_no="3",
                part_title="Records",
            ),
            "6-2": _section(
                "6-2",
                "Manager duties",
                "(1) The manager of an accredited property must keep records.",
                chapter_no="3",
                chapter_title="Accredited properties",
                part_no="1",
                part_title="Duties",
            ),
        }
    )


@pytest.fixture
def index() -> CaseEvidenceIndex:
    return CaseEvidenceIndex(
        [
            _atom("e1", "Pest control treatment records: monthly fumigation of stored chickpeas"),
            _atom("e2", "Inspection completed by the occupier on 2024-03-02", track="T7"),
            _atom(
                "e3",
                "Pest control treatment record signed by Midwest Grain Holdings",
                track="T3",
                state=EvidenceIdentityState.FOREIGN,
            ),
        ]
    )


# -- C0 ---------------------------------------------------------------------


def test_c0_rejects_the_parallel_obligation_chapter(graph: NormGraph) -> None:
    """Chapter 3's manager duty is worded like Chapter 4's but is the wrong regime."""

    admitted, gate = c0_bind_anchor(cp_id="CP22", anchor_section_ids=["6-2"], graph=graph)
    assert admitted == []
    assert gate.decision is GateDecision.ESCALATE


def test_c0_admits_the_occupier_section(graph: NormGraph) -> None:
    admitted, gate = c0_bind_anchor(cp_id="CP22", anchor_section_ids=["11-5", "6-2"], graph=graph)
    assert admitted == ["11-5"]
    assert gate.decision is GateDecision.PASS


# -- C1 ---------------------------------------------------------------------


def test_c1_unknown_condition_does_not_become_not_applicable() -> None:
    """"We could not tell" must never be scored as N/A — N/A is a scored class."""

    pack = _pack(explicit_na_conditions=["handles_fumigated_goods"], required_facts=[])
    applicability, gate, matched = c1_applicability(cp_id="CP22", pack=pack, profile={})
    assert applicability is Applicability.UNKNOWN
    assert matched == []
    assert gate.decision is GateDecision.ESCALATE


def test_c1_explicit_condition_yields_not_applicable() -> None:
    pack = _pack(explicit_na_conditions=["handles_fumigated_goods"])
    applicability, gate, matched = c1_applicability(
        cp_id="CP22", pack=pack, profile={"handles_fumigated_goods": True}
    )
    assert applicability is Applicability.NOT_APPLICABLE
    assert matched == ["handles_fumigated_goods"]
    assert gate.decision is GateDecision.PASS


# -- C2 ---------------------------------------------------------------------


def test_c2_flags_a_pack_with_nothing_to_retrieve() -> None:
    pack = _pack(required_facts=[], violation_facts=[], explicit_na_conditions=["x"])
    needs, gate = c2_needs(cp_id="CP22", pack=pack)
    assert needs == []
    assert gate.decision is GateDecision.ESCALATE


# -- C7 ---------------------------------------------------------------------


def _argument(label: FinalLabel, sufficiency: Sufficiency, evidence: list[str]) -> AuditArgument:
    claims: list[AuditClaim] = [
        AuditClaim(
            claim_id="c-policy",
            claim_type=ClaimType.POLICY,
            proposition={"requirement": "keep records"},
            premises=[
                ClaimPremise(
                    source_type=PremiseSourceType.POLICY_SOURCE,
                    source_id="s11-5",
                    relation=ClaimRelation.REQUIRES,
                )
            ],
        )
    ]
    if evidence:
        claims.append(
            AuditClaim(
                claim_id="c-evidence",
                claim_type=ClaimType.EVIDENCE,
                proposition={"fact": "records exist"},
                premises=[
                    ClaimPremise(
                        source_type=PremiseSourceType.CASE_EVIDENCE,
                        source_id=eid,
                        relation=ClaimRelation.SUPPORTS,
                    )
                    for eid in evidence
                ],
            )
        )
    claims.append(
        AuditClaim(
            claim_id="c-verdict",
            claim_type=ClaimType.VERDICT,
            proposition={"label": label.value},
        )
    )
    return AuditArgument(
        argument_id="CASE-1.CP22",
        case_id="CASE-1",
        cp_id="CP22",
        claims=claims,
        candidate_label=label,
        sufficiency=sufficiency,
    )


def test_c7_maps_missing_evidence_to_zero_but_keeps_the_marker() -> None:
    """Frozen decision: label 0, basis missing_required_evidence, review_required."""

    decision = c7_decide(
        argument=_argument(FinalLabel.NON_COMPLIANT, Sufficiency.INSUFFICIENT, []),
        applicability=Applicability.APPLICABLE,
        gate_report_ids=["g1"],
        review_required=False,
        reasoning="no evidence retrieved",
    )
    assert decision.label is FinalLabel.NON_COMPLIANT
    assert decision.basis is DecisionBasis.MISSING_REQUIRED_EVIDENCE
    assert decision.sufficiency is Sufficiency.INSUFFICIENT
    assert decision.review_required is True


def test_c7_downgrades_compliance_asserted_without_sufficient_evidence() -> None:
    """A model claiming 1 on insufficient evidence must not produce a 1."""

    decision = c7_decide(
        argument=_argument(FinalLabel.COMPLIANT, Sufficiency.INSUFFICIENT, []),
        applicability=Applicability.APPLICABLE,
        gate_report_ids=["g1"],
        review_required=False,
        reasoning="claimed compliant with nothing cited",
    )
    assert decision.label is FinalLabel.NON_COMPLIANT
    assert decision.basis is DecisionBasis.MISSING_REQUIRED_EVIDENCE


def test_c7_emits_compliant_when_evidence_supports_it() -> None:
    decision = c7_decide(
        argument=_argument(FinalLabel.COMPLIANT, Sufficiency.SUFFICIENT, ["e1"]),
        applicability=Applicability.APPLICABLE,
        gate_report_ids=["g1"],
        review_required=False,
        reasoning="records found",
    )
    assert decision.label is FinalLabel.COMPLIANT
    assert decision.basis is DecisionBasis.COMPLIANT_EVIDENCE
    assert decision.supporting_evidence_ids == ["e1"]


# -- loop -------------------------------------------------------------------


def _reading_backend(payload: dict[str, object] | None = None) -> FakeJSONLLM:
    """A backend that returns an actual reading of the evidence.

    Most loop tests are about the *shape* of the chain, not about what the model
    concludes, but the chain no longer produces a decision without a reading — by
    design, since inferring a verdict from document authorship alone is what made
    an earlier run label 98% of cells compliant. So these tests supply a reading
    rather than assert on a fabricated one.
    """

    backend = FakeJSONLLM()
    backend.register(
        "POLICY REQUIREMENT",
        payload
        or {
            "label": "1",
            "supporting_evidence_ids": ["e1"],
            "contrary_evidence_ids": [],
            "reasoning": "monthly fumigation records were produced",
            "synthetic": False,
        },
    )
    return backend


def test_loop_runs_offline_and_records_a_gate_per_node(
    graph: NormGraph, index: CaseEvidenceIndex
) -> None:
    result = adjudicate(
        case_id="CASE-1",
        cp_id="CP22",
        pack=_pack(),
        anchor_section_ids=["11-5"],
        graph=graph,
        profile={},
        index=index,
        backend=_reading_backend(),
    )
    assert result.decision is not None
    nodes = [trace.node for trace in result.traces]
    assert nodes[:6] == ["C0", "C1", "C2", "C3", "C4", "C5"]
    assert nodes[-1] == "C7"
    assert result.retrieval, "retrieval must be traced, not just performed"


def test_loop_without_a_backend_blocks_instead_of_labelling(
    graph: NormGraph, index: CaseEvidenceIndex
) -> None:
    """No model reading must mean no verdict — not a verdict inferred from filing.

    This pins the fix for a measured failure: with no backend the loop used to
    apply "the farm produced its own paperwork, therefore it complied", which
    returned 1 for 98% of cells while every gate reported PASS. The cell is now
    recorded as blocked at C4, which is visible, instead of as a compliant
    finding, which is not.
    """

    result = adjudicate(
        case_id="CASE-1",
        cp_id="CP22",
        pack=_pack(),
        anchor_section_ids=["11-5"],
        graph=graph,
        profile={},
        index=index,
    )
    assert result.decision is None
    assert result.blocked_at == "C4"
    # The retrieved atoms are still on the record; what is withheld is the verdict.
    assert result.retrieval


def test_a_reply_without_a_label_is_not_treated_as_non_compliance(
    graph: NormGraph, index: CaseEvidenceIndex
) -> None:
    """An unlabelled reply has not answered the question; it is not a 0.

    This is the second disguise of the same defect. After the no-backend path was
    fixed, running with the offline backend still produced a constant classifier —
    its default reply carries no ``label`` key, that fell through to "0", and all
    120 cells came back non-compliant with every gate green. Whichever constant it
    lands on, a constant is not an audit.
    """

    backend = FakeJSONLLM()  # default reply: {"synthetic": true, "fingerprint": ...}
    result = adjudicate(
        case_id="CASE-1",
        cp_id="CP22",
        pack=_pack(),
        anchor_section_ids=["11-5"],
        graph=graph,
        profile={},
        index=index,
        backend=backend,
    )
    assert backend.calls, "the backend must actually have been consulted"
    assert result.decision is None
    assert result.blocked_at == "C4"


def test_loop_blocks_rather_than_guessing_when_no_anchor_survives(
    graph: NormGraph, index: CaseEvidenceIndex
) -> None:
    """A CP anchored only to the wrong obligation regime must not yield a label.

    Escalation still produces a decision, but the gate is recorded as failed and
    review_required is set — the failure is visible in the artefacts.
    """

    result = adjudicate(
        case_id="CASE-1",
        cp_id="CP22",
        pack=_pack(),
        anchor_section_ids=["6-2"],
        graph=graph,
        profile={},
        index=index,
        backend=_reading_backend(),
    )
    assert result.traces[0].gate.decision is GateDecision.ESCALATE
    assert result.decision is not None
    assert result.decision.review_required is True


def test_loop_marks_synthetic_when_using_the_offline_backend(
    graph: NormGraph, index: CaseEvidenceIndex
) -> None:
    """A fake-backend run must be stamped so its score is never read as a result."""

    result = adjudicate(
        case_id="CASE-1",
        cp_id="CP22",
        pack=_pack(),
        anchor_section_ids=["11-5"],
        graph=graph,
        profile={},
        index=index,
        backend=FakeJSONLLM(),
    )
    assert result.synthetic is True


def test_loop_uses_a_model_reading_when_the_backend_provides_one(
    graph: NormGraph, index: CaseEvidenceIndex
) -> None:
    """The registered reply must actually drive the label, not be ignored."""

    backend = FakeJSONLLM()
    backend.register(
        "POLICY REQUIREMENT",
        {
            "label": "0",
            "supporting_evidence_ids": [],
            "contrary_evidence_ids": ["e3"],
            "reasoning": "the only record is signed by another establishment",
            "synthetic": False,
        },
    )
    result = adjudicate(
        case_id="CASE-1",
        cp_id="CP22",
        pack=_pack(violation_facts=["records signed by another establishment"]),
        anchor_section_ids=["11-5"],
        graph=graph,
        profile={},
        index=index,
        backend=backend,
    )
    assert result.decision is not None
    assert result.decision.label is FinalLabel.NON_COMPLIANT
    assert "e3" in (
        result.decision.supporting_evidence_ids + result.decision.contrary_evidence_ids
    )


def test_loop_never_cites_another_case(graph: NormGraph) -> None:
    """Cross-case citation must be impossible even when the model asks for it.

    The backend here deliberately cites ``z9``, an atom belonging to CASE-2. A
    test that merely ran the loop and found no foreign citation would pass
    vacuously — nothing ever proposed one. So the attempt is made explicitly and
    the pipeline must refuse it.
    """

    index = CaseEvidenceIndex(
        [
            _atom("e1", "Pest control treatment records kept monthly"),
            _atom("z9", "Pest control treatment records kept monthly", case_id="CASE-2"),
        ]
    )
    backend = _reading_backend(
        {
            "label": "1",
            "supporting_evidence_ids": ["z9"],
            "contrary_evidence_ids": [],
            "reasoning": "cites an atom from a different case",
            "synthetic": False,
        }
    )
    result = adjudicate(
        case_id="CASE-1",
        cp_id="CP22",
        pack=_pack(),
        anchor_section_ids=["11-5"],
        graph=graph,
        profile={},
        index=index,
        backend=backend,
    )
    if result.decision is not None:
        cited = set(
            result.decision.supporting_evidence_ids + result.decision.contrary_evidence_ids
        )
        assert "z9" not in cited
    else:
        assert result.blocked_at in {"C4", "C5"}


def test_c1_applicable_when_no_na_condition_matches() -> None:
    applicability, gate, matched = c1_applicability(
        cp_id="CP22", pack=_pack(), profile={"anything": False}
    )
    assert applicability is Applicability.APPLICABLE
    assert gate.decision is GateDecision.PASS
    assert matched == []


def test_norm_graph_fixture_classifies_scope_as_expected(graph: NormGraph) -> None:
    """Guard the fixture itself: if scope classification changes, C0's tests lie."""

    assert graph.nodes["11-5"].scope is NormScope.REGISTERED_ESTABLISHMENT
    assert ActorRole.OCCUPIER in graph.nodes["11-5"].subjects
    assert graph.nodes["6-2"].scope is NormScope.ACCREDITED_PROPERTY
