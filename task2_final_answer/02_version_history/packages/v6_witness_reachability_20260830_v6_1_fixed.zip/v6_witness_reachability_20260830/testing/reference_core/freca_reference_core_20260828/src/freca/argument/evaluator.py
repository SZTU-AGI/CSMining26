"""Independent evaluator for the bounded FRECA argument-graph profile."""

from __future__ import annotations

from pydantic import Field

from freca.argument.models import ArgumentGraphTemplate, PremiseRole, RequiredPolarity
from freca.domain.models import SafeId, StrictModel
from freca.logic.ast import LogicOperator
from freca.logic.four_valued import FourValuedState


class ArgumentGraphEvaluation(StrictModel):
    interpretation_id: SafeId
    statement_states: dict[SafeId, FourValuedState]
    root_states: dict[SafeId, FourValuedState]
    unresolved_exception_statement_ids: list[SafeId] = Field(default_factory=list)


def _state_from_pair(support: bool, attack: bool) -> FourValuedState:
    return FourValuedState.from_pair(support, attack)


def evaluate_argument_graph(
    graph: ArgumentGraphTemplate,
    atom_states: dict[str, FourValuedState],
) -> ArgumentGraphEvaluation:
    """Evaluate the DAG from its projected statements and typed premises.

    Exception premises are undercutters.  A main rule is positively established
    only when every exception is itself attacked (disproved under its allocated
    burden); an unknown exception therefore keeps the conclusion unresolved.
    This rule is intentionally confined to the graph evaluator and is never
    exposed as a Boolean ``NOT`` rewrite in the shadow evaluator.
    """

    statement_by_id = {item.statement_id: item for item in graph.statement_nodes}
    arguments_by_conclusion: dict[str, list] = {}
    for argument in graph.argument_nodes:
        arguments_by_conclusion.setdefault(argument.conclusion_statement_id, []).append(argument)
    cache: dict[str, FourValuedState] = {}
    visiting: set[str] = set()
    unresolved_exceptions: set[str] = set()

    def evaluate(statement_id: str) -> FourValuedState:
        if statement_id in cache:
            return cache[statement_id]
        if statement_id in visiting:
            raise ValueError("FRECA-CAES-DAG-v1 does not allow cyclic statement dependencies")
        visiting.add(statement_id)
        statement = statement_by_id[statement_id]
        if statement.logic_operator is LogicOperator.ATOM:
            assert statement.proposition_id is not None
            result = atom_states.get(statement.proposition_id, FourValuedState.UNKNOWN)
        else:
            arguments = sorted(
                arguments_by_conclusion.get(statement_id, []),
                key=lambda item: item.argument_id,
            )
            if not arguments:
                raise ValueError(f"non-atomic statement {statement_id} has no projected arguments")

            argument_pairs: list[tuple[bool, bool]] = []
            for argument in arguments:
                ordinary_pairs: list[tuple[bool, bool]] = []
                exception_pairs: list[tuple[bool, bool]] = []
                for premise in argument.premises:
                    support, attack = evaluate(premise.statement_id).pair
                    if premise.required_polarity is RequiredPolarity.NEGATIVE:
                        support, attack = attack, support
                    if premise.premise_role is PremiseRole.EXCEPTION:
                        exception_pairs.append((support, attack))
                    else:
                        ordinary_pairs.append((support, attack))

                ordinary_support = all(item[0] for item in ordinary_pairs)
                ordinary_attack = any(item[1] for item in ordinary_pairs)
                if exception_pairs:
                    exception_absence_proven = all(item[1] for item in exception_pairs)
                    exception_present = any(item[0] for item in exception_pairs)
                    if any(not support and not attack for support, attack in exception_pairs):
                        unresolved_exceptions.add(statement_id)
                    support = ordinary_support and exception_absence_proven
                    attack = ordinary_attack or exception_present
                else:
                    support = ordinary_support
                    attack = ordinary_attack
                argument_pairs.append((support, attack))

            # Alternative arguments: one may support, while every alternative
            # must be defeated before the conclusion is attacked.
            result = _state_from_pair(
                support=any(item[0] for item in argument_pairs),
                attack=all(item[1] for item in argument_pairs),
            )
        visiting.remove(statement_id)
        cache[statement_id] = result
        return result

    root_states = {
        statement_id: evaluate(statement_id) for statement_id in graph.root_statement_ids.values()
    }
    return ArgumentGraphEvaluation(
        interpretation_id=graph.interpretation_id,
        statement_states=cache,
        root_states=root_states,
        unresolved_exception_statement_ids=sorted(unresolved_exceptions),
    )
