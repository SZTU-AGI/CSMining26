"""Deterministic validation of a typed audit argument (the per-step 复核 gate).

Why deterministic, and why here
-------------------------------
The teacher's second point was that an error in any one step propagates through
every later step. The usual answer — "add an LLM reviewer" — has a defect: a
reviewer that shares the auditor's failure mode agrees with it. VeriCoT's
contribution is the alternative: force the chain of thought into *explicit
premises* and check each premise mechanically for grounding and contradiction,
so the check cannot inherit the generator's blind spot.

This module is the mechanical half. It never calls a model. Every rule below is
an entailment or a citation check that either holds or does not:

``UNGROUNDED``
    A claim rests on a premise whose ``source_id`` is not in the run's actual
    evidence/policy set, or an EVIDENCE claim cites nothing. This is the
    hallucinated-citation case, and it is checkable without judgement.
``CITATION_INVALID``
    The cited atom exists but belongs to a different case. Cross-case citation is
    the leakage failure V0 exists to catch; catching it here makes it a blocked
    decision instead of a silently inflated score.
``IDENTITY_MISMATCH``
    A COMPLIANT verdict is supported by an atom not signed by the audited
    occupier. Whether this should block or merely warn is a *policy* switch, not
    a truth: ``identity_is_hard`` exposes it.
``CONTRADICTION``
    The argument asserts a verdict its own claims do not support — e.g. label 1
    while a COUNTER_EVIDENCE claim stands verified, or label 1 with
    ``INSUFFICIENT`` sufficiency.
``UNTRANSLATABLE``
    A claim whose proposition lacks the fields its type requires, so no check can
    be performed on it at all. Reported rather than skipped: an unparseable claim
    silently ignored is indistinguishable from a claim that passed.

What this module deliberately does *not* do
-------------------------------------------
It does not judge whether the retrieved evidence semantically satisfies the
policy requirement. That is a substantive legal question, and a rule-based
checker pretending to answer it would manufacture false confidence. It is left to
the adjudication node, whose output this module then constrains.

``GateDecision`` mapping follows the competition's reproducibility requirement:
a ``RETRY`` must carry a ``RetrievalNeed`` so the retry is a *different, recorded*
retrieval rather than an unlogged second guess at the same prompt.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from freca.domain.enums import (
    ClaimRelation,
    ClaimStatus,
    ClaimType,
    FinalLabel,
    GateDecision,
    GateSeverity,
    PremiseSourceType,
    Sufficiency,
    VerificationIssueCode,
)
from freca.domain.models import (
    AuditArgument,
    AuditClaim,
    EvidenceAtom,
    GateReport,
    RetrievalNeed,
    VerificationIssue,
)

#: Proposition fields each claim type must carry to be checkable at all.
REQUIRED_PROPOSITION_FIELDS: dict[ClaimType, tuple[str, ...]] = {
    ClaimType.POLICY: ("requirement",),
    ClaimType.APPLICABILITY: ("applicable",),
    ClaimType.EVIDENCE: ("fact",),
    ClaimType.COUNTER_EVIDENCE: ("fact",),
    ClaimType.DERIVED_FACT: ("fact",),
    ClaimType.SUFFICIENCY: ("sufficient",),
    ClaimType.VERDICT: ("label",),
}

#: Claim types whose factual content must trace to a real source, not to the
#: model's own prior. COMMONSENSE is not an accepted premise source anywhere.
GROUNDED_CLAIM_TYPES = frozenset(
    {ClaimType.POLICY, ClaimType.EVIDENCE, ClaimType.COUNTER_EVIDENCE}
)


@dataclass(slots=True)
class ValidationContext:
    """The set of things a premise is allowed to point at.

    Supplying this explicitly — rather than letting the validator go and look —
    is what makes the check a *closed-world* test: an id absent from these sets is
    ungrounded by definition, so a hallucinated citation cannot pass by being
    plausible.
    """

    case_id: str
    evidence: dict[str, EvidenceAtom] = field(default_factory=dict)
    policy_source_ids: set[str] = field(default_factory=set)
    deterministic_result_ids: set[str] = field(default_factory=set)

    def known(self, source_type: PremiseSourceType, source_id: str) -> bool:
        if source_type is PremiseSourceType.CASE_EVIDENCE:
            return source_id in self.evidence
        if source_type is PremiseSourceType.POLICY_SOURCE:
            return source_id in self.policy_source_ids
        if source_type is PremiseSourceType.DETERMINISTIC_RESULT:
            return source_id in self.deterministic_result_ids
        return False  # PRIOR_CLAIM is resolved against the argument, not the context.


@dataclass(slots=True)
class ArgumentValidator:
    """Rule-based premise checker.

    ``identity_is_hard`` and ``require_policy_citation`` are constructor switches
    because both are contestable design choices; freezing them into the code
    would make the corresponding ablation impossible to run.
    """

    name: str = "argument_validator_v1"
    identity_is_hard: bool = False
    require_policy_citation: bool = True

    def validate(self, argument: AuditArgument, context: ValidationContext) -> GateReport:
        issues: list[VerificationIssue] = []
        claim_by_id = {claim.claim_id: claim for claim in argument.claims}

        for claim in argument.claims:
            issues.extend(self._check_shape(argument, claim))
            issues.extend(self._check_premises(argument, claim, claim_by_id, context))

        issues.extend(self._check_verdict_coherence(argument, context))

        return GateReport(
            gate_id=f"{argument.argument_id}.argument",
            gate_name=self.name,
            decision=self._decide(issues),
            severity=GateSeverity.HARD if issues else GateSeverity.SOFT,
            issues=issues,
        )

    # -- individual checks ---------------------------------------------------

    def _check_shape(self, argument: AuditArgument, claim: AuditClaim) -> list[VerificationIssue]:
        missing = [
            key
            for key in REQUIRED_PROPOSITION_FIELDS.get(claim.claim_type, ())
            if key not in claim.proposition
        ]
        if not missing:
            return []
        return [
            VerificationIssue(
                issue_id=f"{argument.argument_id}.{claim.claim_id}.shape",
                code=VerificationIssueCode.UNTRANSLATABLE,
                message=(
                    f"{claim.claim_type.value} claim is missing required proposition "
                    f"field(s) {missing}; no check can be applied to it"
                ),
                retryable=False,
                claim_id=claim.claim_id,
            )
        ]

    def _check_premises(
        self,
        argument: AuditArgument,
        claim: AuditClaim,
        claim_by_id: dict[str, AuditClaim],
        context: ValidationContext,
    ) -> list[VerificationIssue]:
        issues: list[VerificationIssue] = []

        if claim.claim_type in GROUNDED_CLAIM_TYPES and not claim.premises:
            issues.append(
                VerificationIssue(
                    issue_id=f"{argument.argument_id}.{claim.claim_id}.nopremise",
                    code=VerificationIssueCode.UNGROUNDED,
                    message=(
                        f"{claim.claim_type.value} claim asserts a fact with no premise; "
                        "factual claims must cite a source"
                    ),
                    retryable=True,
                    claim_id=claim.claim_id,
                    retrieval_need=self._need_for(claim),
                )
            )

        if (
            self.require_policy_citation
            and claim.claim_type is ClaimType.POLICY
            and not any(
                premise.source_type is PremiseSourceType.POLICY_SOURCE
                for premise in claim.premises
            )
        ):
            issues.append(
                VerificationIssue(
                    issue_id=f"{argument.argument_id}.{claim.claim_id}.nopolicy",
                    code=VerificationIssueCode.UNGROUNDED,
                    message="POLICY claim must cite at least one policy span",
                    retryable=False,
                    claim_id=claim.claim_id,
                )
            )

        for index, premise in enumerate(claim.premises):
            if premise.source_type is PremiseSourceType.PRIOR_CLAIM:
                if premise.source_id not in claim_by_id:
                    issues.append(
                        VerificationIssue(
                            issue_id=f"{argument.argument_id}.{claim.claim_id}.p{index}.unknown",
                            code=VerificationIssueCode.UNGROUNDED,
                            message=f"premise cites unknown prior claim {premise.source_id!r}",
                            retryable=False,
                            claim_id=claim.claim_id,
                        )
                    )
                elif claim_by_id[premise.source_id].status is ClaimStatus.REJECTED:
                    issues.append(
                        VerificationIssue(
                            issue_id=f"{argument.argument_id}.{claim.claim_id}.p{index}.rejected",
                            code=VerificationIssueCode.CONTRADICTION,
                            message=(
                                f"claim rests on rejected prior claim {premise.source_id!r}; "
                                "a rejected premise cannot support a conclusion"
                            ),
                            retryable=False,
                            claim_id=claim.claim_id,
                        )
                    )
                continue

            if not context.known(premise.source_type, premise.source_id):
                issues.append(
                    VerificationIssue(
                        issue_id=f"{argument.argument_id}.{claim.claim_id}.p{index}.ungrounded",
                        code=VerificationIssueCode.UNGROUNDED,
                        message=(
                            f"premise cites {premise.source_type.value} {premise.source_id!r}, "
                            "which is not present in this run's sources"
                        ),
                        retryable=True,
                        claim_id=claim.claim_id,
                        artifact_ids=[premise.source_id],
                        retrieval_need=self._need_for(claim),
                    )
                )
                continue

            if premise.source_type is PremiseSourceType.CASE_EVIDENCE:
                atom = context.evidence[premise.source_id]
                if atom.case_id != context.case_id:
                    issues.append(
                        VerificationIssue(
                            issue_id=f"{argument.argument_id}.{claim.claim_id}.p{index}.crosscase",
                            code=VerificationIssueCode.CITATION_INVALID,
                            message=(
                                f"evidence {premise.source_id!r} belongs to case "
                                f"{atom.case_id!r}, not {context.case_id!r}"
                            ),
                            retryable=False,
                            claim_id=claim.claim_id,
                            artifact_ids=[premise.source_id],
                        )
                    )

        return issues

    def _check_verdict_coherence(
        self, argument: AuditArgument, context: ValidationContext
    ) -> list[VerificationIssue]:
        """Check the label against the argument's own claims, not against a gold answer."""

        issues: list[VerificationIssue] = []
        label = argument.candidate_label

        standing_counters = [
            claim
            for claim in argument.claims
            if claim.claim_type is ClaimType.COUNTER_EVIDENCE
            and claim.status is not ClaimStatus.REJECTED
        ]
        supporting = [
            premise
            for claim in argument.claims
            if claim.claim_type is ClaimType.EVIDENCE
            for premise in claim.premises
            if premise.source_type is PremiseSourceType.CASE_EVIDENCE
            and premise.relation is ClaimRelation.SUPPORTS
        ]

        if label is FinalLabel.COMPLIANT:
            if standing_counters:
                issues.append(
                    VerificationIssue(
                        issue_id=f"{argument.argument_id}.verdict.counter",
                        code=VerificationIssueCode.CONTRADICTION,
                        message=(
                            "label 1 asserted while "
                            f"{len(standing_counters)} counter-evidence claim(s) still stand"
                        ),
                        retryable=False,
                    )
                )
            if argument.sufficiency is not Sufficiency.SUFFICIENT:
                issues.append(
                    VerificationIssue(
                        issue_id=f"{argument.argument_id}.verdict.sufficiency",
                        code=VerificationIssueCode.INSUFFICIENT,
                        message=(
                            f"label 1 asserted with sufficiency {argument.sufficiency.value}; "
                            "compliance may not be inferred from absent evidence"
                        ),
                        retryable=True,
                        retrieval_need=RetrievalNeed(
                            fact_type="compliance_evidence",
                            query_facets=[argument.cp_id, "required record"],
                        ),
                    )
                )
            if not supporting:
                issues.append(
                    VerificationIssue(
                        issue_id=f"{argument.argument_id}.verdict.nosupport",
                        code=VerificationIssueCode.UNGROUNDED,
                        message="label 1 asserted with no supporting case evidence",
                        retryable=True,
                        retrieval_need=RetrievalNeed(
                            fact_type="compliance_evidence",
                            query_facets=[argument.cp_id],
                        ),
                    )
                )

            foreign = [
                premise.source_id
                for premise in supporting
                if premise.source_id in context.evidence
                and context.evidence[premise.source_id].identity.state.value != "SELF"
            ]
            if foreign:
                issues.append(
                    VerificationIssue(
                        issue_id=f"{argument.argument_id}.verdict.identity",
                        code=VerificationIssueCode.IDENTITY_MISMATCH,
                        message=(
                            "label 1 supported by evidence not signed by the audited "
                            f"establishment: {sorted(foreign)}"
                        ),
                        retryable=bool(self.identity_is_hard),
                        artifact_ids=sorted(foreign),
                        retrieval_need=(
                            RetrievalNeed(
                                fact_type="self_signed_evidence",
                                query_facets=[argument.cp_id, "occupier record"],
                            )
                            if self.identity_is_hard
                            else None
                        ),
                    )
                )

        elif label is FinalLabel.NOT_APPLICABLE:
            explicit = [
                claim
                for claim in argument.claims
                if claim.claim_type is ClaimType.APPLICABILITY
                and claim.proposition.get("applicable") is False
                and claim.premises
            ]
            if not explicit:
                issues.append(
                    VerificationIssue(
                        issue_id=f"{argument.argument_id}.verdict.na",
                        code=VerificationIssueCode.UNGROUNDED,
                        message=(
                            "N/A requires a cited applicability claim; "
                            "absence of evidence is not non-applicability"
                        ),
                        retryable=True,
                        retrieval_need=RetrievalNeed(
                            fact_type="non_applicability",
                            query_facets=[argument.cp_id, "does not apply exemption"],
                        ),
                    )
                )

        return issues

    # -- helpers -------------------------------------------------------------

    @staticmethod
    def _need_for(claim: AuditClaim) -> RetrievalNeed:
        fact = str(
            claim.proposition.get("fact")
            or claim.proposition.get("requirement")
            or claim.claim_type.value
        )
        return RetrievalNeed(fact_type=claim.claim_type.value.lower(), query_facets=[fact[:200]])

    @staticmethod
    def _decide(issues: list[VerificationIssue]) -> GateDecision:
        """Retry only when a retry could actually change the answer.

        A non-retryable issue means the argument is malformed rather than
        under-evidenced, so re-retrieving would produce the same defect with a
        different citation. Those escalate instead — spending a second model call
        on a structural error is how token budget gets burned without moving the
        accuracy number.
        """

        if not issues:
            return GateDecision.PASS
        if any(issue.code is VerificationIssueCode.CITATION_INVALID for issue in issues):
            return GateDecision.BLOCK
        if all(issue.retryable for issue in issues):
            return GateDecision.RETRY
        return GateDecision.ESCALATE
