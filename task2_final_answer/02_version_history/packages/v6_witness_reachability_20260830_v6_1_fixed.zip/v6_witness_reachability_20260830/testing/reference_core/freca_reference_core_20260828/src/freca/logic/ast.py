"""Typed, validated Logic DAG for automatically compiled CP contracts."""

from __future__ import annotations

from enum import StrEnum

from pydantic import Field, model_validator

from freca.domain.models import SafeId, StrictModel


class LogicOperator(StrEnum):
    ATOM = "ATOM"
    ALL_OF = "ALL_OF"
    ANY_OF = "ANY_OF"
    NOT = "NOT"
    IF_THEN = "IF_THEN"
    UNLESS = "UNLESS"
    EXCEPTION_GATE = "EXCEPTION_GATE"


class LogicNode(StrictModel):
    node_id: SafeId
    operator: LogicOperator
    proposition_id: SafeId | None = None
    child_ids: list[SafeId] = Field(default_factory=list)
    connector_span_ids: list[SafeId] = Field(default_factory=list)
    compile_rule_id: str = Field(min_length=1)
    semantic_role: str = Field(default="STRUCTURAL_INTERMEDIATE", min_length=1)
    source_span_ids: list[SafeId] = Field(default_factory=list)
    evidence_requirement_ids: list[SafeId] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_shape(self) -> LogicNode:
        size = len(self.child_ids)
        if self.operator is LogicOperator.ATOM:
            if self.proposition_id is None or size:
                raise ValueError("ATOM requires proposition_id and no children")
        else:
            if self.proposition_id is not None:
                raise ValueError(f"{self.operator.value} cannot carry proposition_id")
            if self.operator is LogicOperator.NOT and size != 1:
                raise ValueError("NOT requires exactly one child")
            if self.operator in {LogicOperator.ALL_OF, LogicOperator.ANY_OF} and size < 2:
                raise ValueError(f"{self.operator.value} requires at least two children")
            if self.operator in {LogicOperator.IF_THEN, LogicOperator.UNLESS} and size != 2:
                raise ValueError(f"{self.operator.value} requires exactly two ordered children")
            if self.operator is LogicOperator.EXCEPTION_GATE and size < 2:
                raise ValueError("EXCEPTION_GATE requires a main child and at least one exception")
        if len(set(self.child_ids)) != size:
            raise ValueError("child_ids must be unique within a node")
        return self


class ContractRoots(StrictModel):
    applicability_root_id: SafeId
    satisfaction_root_id: SafeId
    violation_root_id: SafeId
    non_applicability_root_id: SafeId

    def as_dict(self) -> dict[str, str]:
        return {
            "applicability": self.applicability_root_id,
            "satisfaction": self.satisfaction_root_id,
            "violation": self.violation_root_id,
            "non_applicability": self.non_applicability_root_id,
        }


class LogicDAG(StrictModel):
    interpretation_id: SafeId
    nodes: list[LogicNode] = Field(min_length=1)
    roots: ContractRoots

    @model_validator(mode="after")
    def validate_dag(self) -> LogicDAG:
        node_by_id = {node.node_id: node for node in self.nodes}
        if len(node_by_id) != len(self.nodes):
            raise ValueError("logic node IDs must be unique")

        unknown_roots = set(self.roots.as_dict().values()) - node_by_id.keys()
        if unknown_roots:
            raise ValueError(f"contract roots reference unknown nodes: {sorted(unknown_roots)}")
        for node in self.nodes:
            unknown = set(node.child_ids) - node_by_id.keys()
            if unknown:
                raise ValueError(
                    f"logic node {node.node_id} has unknown children: {sorted(unknown)}"
                )
            if node.node_id in node.child_ids:
                raise ValueError(f"logic node {node.node_id} cannot contain itself")

        visiting: set[str] = set()
        visited: set[str] = set()

        def visit(node_id: str) -> None:
            if node_id in visiting:
                raise ValueError("logic graph must be acyclic")
            if node_id in visited:
                return
            visiting.add(node_id)
            for child_id in node_by_id[node_id].child_ids:
                visit(child_id)
            visiting.remove(node_id)
            visited.add(node_id)

        for node_id in node_by_id:
            visit(node_id)
        return self

    def node_map(self) -> dict[str, LogicNode]:
        return {node.node_id: node for node in self.nodes}

    def reachable_ids(self, root_id: str) -> set[str]:
        node_by_id = self.node_map()
        reached: set[str] = set()

        def walk(node_id: str) -> None:
            if node_id in reached:
                return
            reached.add(node_id)
            for child_id in node_by_id[node_id].child_ids:
                walk(child_id)

        walk(root_id)
        return reached
