"""E3: extract identity anchors from a document and resolve them against the case.

The measurement that shaped this module
---------------------------------------
Comparing the filename-declared establishment with the name written inside each
document by **exact string equality** flags 650 of 898 files (72 %) as
mismatched. Inspecting those 650 shows most are not mismatches at all::

    file: "Gwydir Valley Grain Trust"   doc: "Gwydir Valley Grain"
    doc RE-NSW-2020-0033 == directory RE-NSW-2020-0033      -> same entity

versus a genuine foreign signature::

    file: "Gwydir Valley Grain Trust"   doc: "Burnett Grain Terminal"
    doc RE-QLD-2020-8011 != directory RE-NSW-2020-0033      -> foreign

Two consequences are designed in here:

1. **The RE number outranks the name.** It is a registration key, so a matching
   RE number settles identity even when the name string differs; a *conflicting*
   RE number settles it the other way even when names look similar. Name
   comparison alone is the wrong primitive and would inflate the mismatch rate
   by roughly a factor of two.
2. **Legal suffixes are stripped conservatively.** ``Pty``/``Ltd``/``Trust``/
   ``Co-operative`` and friends are dropped, but distinguishing words such as
   ``Holdings`` in *Midwest Grain Holdings* are kept — over-aggressive stripping
   silently merges distinct entities, which is the more damaging error.

The reference identity is the *filename*-declared name plus the directory RE
number (both from M0), never the document body — otherwise the thing being
audited would be used to define the answer.

Per frozen decision, this extractor's output is **not** ground truth. It is one
extractor; agreement against an independent one is reportable, accuracy is not,
until a human-checked sample exists.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from freca.domain.enums import EvidenceIdentityState
from freca.domain.models import IdentityAssessment
from freca.evidence.docx_reader import DocxDocument
from freca.evidence.xlsx_reader import XlsxDocument

#: Canonical registration key: ``RE-<state>-<year>-<serial>``.
RE_NUMBER_CANONICAL = re.compile(r"\bRE-(?P<state>[A-Z]{2,3})-(?P<year>(?:19|20)\d{2})-(?P<serial>\d{4})\b")
#: Anything that *looks* like a registration key. Everything matching this but
#: not the canonical pattern is malformed — itself an auditable finding, e.g.
#: ``RE-QLD-3318`` (no year) and ``RE-TAS-P100`` (non-numeric serial).
RE_NUMBER_LOOSE = re.compile(r"\bRE-[A-Z]{2,4}-[A-Z0-9-]{3,12}\b")

#: Dropped when canonicalising an entity name. Deliberately excludes words that
#: distinguish entities (``Holdings``, ``Terminal``, ``Storage``, ``Exports``).
LEGAL_SUFFIXES = frozenset(
    {
        "pty",
        "ptyltd",
        "ltd",
        "limited",
        "proprietary",
        "trust",
        "cooperative",
        "coop",
        "co",
        "company",
        "incorporated",
        "inc",
        "nl",
    }
)

_NAME_KEY = re.compile(
    r"^(establishment|business|company|trading|entity|occupier|operator)\s*(name)?\s*:?$", re.I
)
_RE_KEY = re.compile(r"^(re|registration)\s*(number|no\.?|#)?\s*:?$", re.I)
_PRODUCT_KEY = re.compile(r"^(registered\s+)?(commodity|commodities|product|produce|crop)\s*:?$", re.I)
_ADDRESS_KEY = re.compile(r"^(address|site address|premises|location)\s*:?$", re.I)
_PERSON_KEY = re.compile(r"^(responsible person|nominated person|manager|contact|prepared by|approved by)\s*:?$", re.I)

#: Row-2 subtitles that are section descriptions rather than establishment names.
_SUBTITLE_NOISE = re.compile(
    r"^(export control|internal|fumigation|failed|inspection|transfer|traceability record|"
    r"records? from|pest|bait|chemical|establishment condition)",
    re.I,
)


def normalise_entity(name: str | None) -> str:
    """Canonical comparison key: lowercase alphanumerics minus legal suffixes."""

    if not name:
        return ""
    tokens = re.findall(r"[a-z0-9]+", name.lower())
    kept = [token for token in tokens if token not in LEGAL_SUFFIXES]
    return "".join(kept or tokens)


def entity_tokens(name: str | None) -> set[str]:
    if not name:
        return set()
    return {
        token
        for token in re.findall(r"[a-z0-9]+", name.lower())
        if token not in LEGAL_SUFFIXES and len(token) > 1
    }


def find_re_numbers(text: str) -> tuple[list[str], list[str]]:
    """Return ``(canonical, malformed)`` registration numbers found in ``text``."""

    canonical = [match.group(0) for match in RE_NUMBER_CANONICAL.finditer(text)]
    canonical_set = set(canonical)
    malformed = [
        match.group(0) for match in RE_NUMBER_LOOSE.finditer(text) if match.group(0) not in canonical_set
    ]
    return _dedupe(canonical), _dedupe(malformed)


def _dedupe(values: list[str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for value in values:
        if value not in seen:
            seen.add(value)
            out.append(value)
    return out


@dataclass(slots=True)
class IdentityAnchors:
    """Every identity-bearing string a document declares about itself.

    ``re_numbers`` holds only **self-asserted** registration numbers — those in an
    identity-bearing position such as a cover key-value or a sheet's
    establishment line. Registration numbers appearing anywhere else in the body
    go to ``mentioned_re_numbers`` and must never drive identity resolution: the
    T9 dispatch dockets carry a ``Dest RE No.`` column naming the *next* premises
    in the supply chain, and reading those as claims about the document's owner
    would mark every traceability record as belonging to a different
    establishment. Whose document it is, and whom the document talks about, are
    different questions.
    """

    names: list[str] = field(default_factory=list)
    re_numbers: list[str] = field(default_factory=list)
    malformed_re_numbers: list[str] = field(default_factory=list)
    mentioned_re_numbers: list[str] = field(default_factory=list)
    products: list[str] = field(default_factory=list)
    addresses: list[str] = field(default_factory=list)
    persons: list[str] = field(default_factory=list)
    #: ``anchor value -> where it was seen``, kept so a verdict can cite a coordinate.
    provenance: dict[str, str] = field(default_factory=dict)

    def record(self, bucket: list[str], value: str, where: str) -> None:
        value = value.strip()
        if not value or value in bucket:
            return
        bucket.append(value)
        self.provenance.setdefault(value, where)

    def note_mentions(self, text: str, where: str) -> None:
        """Record third-party registration numbers seen in free body text."""

        canonical, malformed = find_re_numbers(text)
        for item in canonical + malformed:
            if item in self.re_numbers or item in self.malformed_re_numbers:
                continue
            self.record(self.mentioned_re_numbers, item, where)

    def to_dict(self) -> dict[str, object]:
        return {
            "names": self.names,
            "re_numbers": self.re_numbers,
            "malformed_re_numbers": self.malformed_re_numbers,
            "mentioned_re_numbers": self.mentioned_re_numbers,
            "products": self.products,
            "addresses": self.addresses,
            "persons": self.persons,
            "provenance": self.provenance,
        }


def _absorb_key_value(anchors: IdentityAnchors, key: str, value: str, where: str) -> None:
    key = key.strip()
    if not value.strip():
        return
    if _NAME_KEY.match(key):
        anchors.record(anchors.names, value, where)
    elif _RE_KEY.match(key):
        canonical, malformed = find_re_numbers(value)
        for item in canonical:
            anchors.record(anchors.re_numbers, item, where)
        for item in malformed:
            anchors.record(anchors.malformed_re_numbers, item, where)
    elif _PRODUCT_KEY.match(key):
        anchors.record(anchors.products, value, where)
    elif _ADDRESS_KEY.match(key):
        anchors.record(anchors.addresses, value, where)
    elif _PERSON_KEY.match(key):
        anchors.record(anchors.persons, value, where)


def extract_anchors_docx(document: DocxDocument) -> IdentityAnchors:
    """Identity claims come from key-value table rows; body text only mentions."""

    anchors = IdentityAnchors()
    for table in document.tables:
        for row_index, row in enumerate(table.rows):
            if len(row) >= 2:
                _absorb_key_value(
                    anchors, row[0], row[1], f"table[{table.table_index}].row[{row_index}]"
                )
    anchors.note_mentions(document.text(), "document text")
    return anchors


def extract_anchors_xlsx(document: XlsxDocument) -> IdentityAnchors:
    anchors = IdentityAnchors()
    for sheet in document.sheets:
        for key, value in sheet.key_values.items():
            _absorb_key_value(anchors, key, value, f"{sheet.sheet_name}!key_values")
        # Row 2 carries the establishment for record sheets: "Name  |  RE-...".
        subtitle = sheet.subtitle or ""
        if subtitle:
            head = subtitle.split("|")[0].replace("Establishment:", "").strip()
            if head and not _SUBTITLE_NOISE.match(head):
                anchors.record(anchors.names, head, f"{sheet.sheet_name}!A2")
            canonical, malformed = find_re_numbers(subtitle)
            for item in canonical:
                anchors.record(anchors.re_numbers, item, f"{sheet.sheet_name}!A2")
            for item in malformed:
                anchors.record(anchors.malformed_re_numbers, item, f"{sheet.sheet_name}!A2")
    anchors.note_mentions(document.text(), "workbook text")
    return anchors


@dataclass(slots=True)
class IdentityReference:
    """What M0 says the case is, from filesystem facts only."""

    establishment: str
    re_number: str
    #: The case serial the filenames declare (1..100). Used as corroboration when
    #: a document trades under a second name; see ``admissibility.py``.
    serial: int | None = None

    @property
    def key(self) -> str:
        return normalise_entity(self.establishment)

    @property
    def tokens(self) -> set[str]:
        return entity_tokens(self.establishment)


#: Token overlap above which two names are treated as variants of one entity.
NAME_VARIANT_THRESHOLD = 0.6


def _name_relation(candidate: str, reference: IdentityReference) -> str:
    """``"same"`` | ``"variant"`` | ``"foreign"`` for one candidate name."""

    if not candidate:
        return "foreign"
    if normalise_entity(candidate) == reference.key:
        return "same"
    candidate_tokens = entity_tokens(candidate)
    if not candidate_tokens or not reference.tokens:
        return "foreign"
    if candidate_tokens <= reference.tokens or reference.tokens <= candidate_tokens:
        return "variant"
    overlap = len(candidate_tokens & reference.tokens) / len(candidate_tokens | reference.tokens)
    return "variant" if overlap >= NAME_VARIANT_THRESHOLD else "foreign"


def resolve_identity(anchors: IdentityAnchors, reference: IdentityReference) -> IdentityAssessment:
    """Decide whether a document speaks about the case's own establishment.

    Precedence: a canonical RE number is a registration key and therefore
    outranks the free-text name in both directions.
    """

    matched: list[str] = []
    conflicting: list[str] = []

    re_match = any(number == reference.re_number for number in anchors.re_numbers)
    re_conflict = [number for number in anchors.re_numbers if number != reference.re_number]
    if re_match:
        matched.append(reference.re_number)
    conflicting.extend(re_conflict)
    conflicting.extend(anchors.malformed_re_numbers)

    relations = [_name_relation(name, reference) for name in anchors.names]
    for name, relation in zip(anchors.names, relations, strict=True):
        (matched if relation in {"same", "variant"} else conflicting).append(name)

    has_same = "same" in relations or "variant" in relations
    has_foreign = "foreign" in relations

    if re_match and not re_conflict and not has_foreign:
        state = EvidenceIdentityState.SELF
    elif re_conflict and not re_match:
        state = EvidenceIdentityState.FOREIGN if has_foreign or not has_same else EvidenceIdentityState.MIXED
    elif has_foreign and has_same:
        state = EvidenceIdentityState.MIXED
    elif has_foreign:
        state = EvidenceIdentityState.FOREIGN
    elif has_same:
        state = EvidenceIdentityState.SELF
    else:
        state = EvidenceIdentityState.UNKNOWN

    return IdentityAssessment(
        state=state,
        farm=anchors.names[0] if anchors.names else None,
        re_number=anchors.re_numbers[0] if anchors.re_numbers else None,
        product=anchors.products[0] if anchors.products else None,
        address=anchors.addresses[0] if anchors.addresses else None,
        matched_anchors=_dedupe(matched),
        conflicting_anchors=_dedupe(conflicting),
    )
