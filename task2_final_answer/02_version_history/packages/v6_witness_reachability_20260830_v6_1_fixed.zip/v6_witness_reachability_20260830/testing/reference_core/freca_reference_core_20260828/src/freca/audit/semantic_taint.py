"""Path-level uncertainty propagation and bounded decisive-path certificates."""

from __future__ import annotations

from enum import StrEnum

from pydantic import Field

from freca.domain.models import SafeId, Sha256, StrictModel
from freca.harness.artifact_store import sha256_digest


class TaintKind(StrEnum):
    PARSE_UNCERTAINTY = "PARSE_UNCERTAINTY"
    OMITTED_DECISIVE_SOURCE = "OMITTED_DECISIVE_SOURCE"
    AMBIGUOUS_ALIGNMENT = "AMBIGUOUS_ALIGNMENT"
    IDENTITY_UNRESOLVED = "IDENTITY_UNRESOLVED"
    TEMPORAL_UNRESOLVED = "TEMPORAL_UNRESOLVED"
    SCOPE_UNRESOLVED = "SCOPE_UNRESOLVED"
    GRAPH_PROJECTION_MISMATCH = "GRAPH_PROJECTION_MISMATCH"
    EVALUATOR_MISMATCH = "EVALUATOR_MISMATCH"
    CORRELATED_VERIFICATION = "CORRELATED_VERIFICATION"
    BENCHMARK_FALLBACK = "BENCHMARK_FALLBACK"


class TaintDisposition(StrEnum):
    UNRESOLVED_DECISIVE = "UNRESOLVED_DECISIVE"
    RESOLVED = "RESOLVED"
    PROVEN_NONDECISIVE = "PROVEN_NONDECISIVE"
    DISCLOSED_FALLBACK = "DISCLOSED_FALLBACK"


class SemanticTaint(StrictModel):
    taint_id: SafeId
    origin_artifact_id: SafeId
    origin_layer: int = Field(ge=0, le=11)
    kind: TaintKind
    affected_proposition_ids: list[SafeId] = Field(default_factory=list)
    affected_root_ids: list[SafeId] = Field(default_factory=list)
    disposition: TaintDisposition = TaintDisposition.UNRESOLVED_DECISIVE
    resolution_basis_ids: list[SafeId] = Field(default_factory=list)


class TaintPropagationRecord(StrictModel):
    taint_id: SafeId
    reached_artifact_ids: list[SafeId]
    reached_decisive_root_ids: list[SafeId]
    bounded: bool
    truncation_reason: str | None = None
    record_sha256: Sha256


class DecisivePathCertificate(StrictModel):
    certificate_id: SafeId
    source_artifact_id: SafeId
    target_root_id: SafeId
    minimal_source_to_fold_paths: list[list[SafeId]]
    max_paths: int = Field(ge=1)
    complete_within_bound: bool
    certificate_sha256: Sha256


def propagate_taint(
    taint: SemanticTaint,
    dependency_edges: dict[str, list[str]],
    artifact_root_ids: dict[str, list[str]],
    *,
    max_nodes: int = 10000,
) -> TaintPropagationRecord:
    queue = [taint.origin_artifact_id]
    reached: set[str] = set()
    roots: set[str] = set(taint.affected_root_ids)
    while queue and len(reached) < max_nodes:
        current = queue.pop(0)
        if current in reached:
            continue
        reached.add(current)
        roots.update(artifact_root_ids.get(current, []))
        queue.extend(sorted(dependency_edges.get(current, [])))
    bounded = not queue
    payload = {
        "taint_id": taint.taint_id,
        "reached_artifact_ids": sorted(reached),
        "reached_decisive_root_ids": sorted(roots),
        "bounded": bounded,
        "truncation_reason": None if bounded else "MAX_NODES_EXCEEDED",
    }
    digest = sha256_digest(payload)
    return TaintPropagationRecord(record_sha256=digest, **payload)


def build_decisive_path_certificate(
    *,
    source_artifact_id: str,
    target_root_id: str,
    dependency_edges: dict[str, list[str]],
    artifact_root_ids: dict[str, list[str]],
    max_paths: int = 32,
) -> DecisivePathCertificate:
    """Enumerate shortest source-to-root paths with an explicit bound."""

    queue: list[list[str]] = [[source_artifact_id]]
    found: list[list[str]] = []
    shortest: int | None = None
    seen_depth: dict[str, int] = {source_artifact_id: 0}
    truncated = False
    while queue:
        path = queue.pop(0)
        current = path[-1]
        depth = len(path) - 1
        if shortest is not None and depth > shortest:
            break
        if target_root_id in artifact_root_ids.get(current, []):
            shortest = depth
            found.append(path)
            if len(found) >= max_paths:
                truncated = bool(queue)
                break
            continue
        for child in sorted(dependency_edges.get(current, [])):
            if child in path:
                continue
            next_depth = depth + 1
            prior = seen_depth.get(child)
            if prior is None or next_depth <= prior:
                seen_depth[child] = next_depth
                queue.append([*path, child])
    payload = {
        "source_artifact_id": source_artifact_id,
        "target_root_id": target_root_id,
        "minimal_source_to_fold_paths": found,
        "max_paths": max_paths,
        "complete_within_bound": not truncated,
    }
    digest = sha256_digest(payload)
    return DecisivePathCertificate(
        certificate_id=f"path-{digest.split(':', 1)[1][:20]}",
        certificate_sha256=digest,
        **payload,
    )
