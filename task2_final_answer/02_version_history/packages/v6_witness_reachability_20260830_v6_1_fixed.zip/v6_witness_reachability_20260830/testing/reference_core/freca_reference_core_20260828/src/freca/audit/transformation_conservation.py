"""Conservation checks for every high-risk transformation boundary."""

from __future__ import annotations

from enum import StrEnum

from freca.domain.models import SafeId, Sha256, StrictModel
from freca.harness.artifact_store import sha256_digest


class TransitionKind(StrEnum):
    PDF_TO_POLICY_UNIT = "PDF_TO_POLICY_UNIT"
    POLICY_UNIT_TO_NORM_EVENT = "POLICY_UNIT_TO_NORM_EVENT"
    CP_TO_PROPOSITION_AST = "CP_TO_PROPOSITION_AST"
    AST_TO_ARGUMENT_GRAPH = "AST_TO_ARGUMENT_GRAPH"
    SOURCE_TO_EVIDENCE_ATOM = "SOURCE_TO_EVIDENCE_ATOM"
    ATOM_TO_FACT_CANDIDATE = "ATOM_TO_FACT_CANDIDATE"
    FACT_TO_ALIGNMENT = "FACT_TO_ALIGNMENT"
    ALIGNMENT_TO_PREMISE = "ALIGNMENT_TO_PREMISE"
    GRAPH_TO_INTERNAL_OUTCOME = "GRAPH_TO_INTERNAL_OUTCOME"
    OUTCOME_TO_FOLD = "OUTCOME_TO_FOLD"


class TransformationConservationReport(StrictModel):
    report_id: SafeId
    transition_kind: TransitionKind
    input_catalog_sha256: Sha256
    output_catalog_sha256: Sha256
    total_input_ids: list[SafeId]
    mapped_input_ids: list[SafeId]
    excluded_input_ids_with_reason: dict[SafeId, list[str]]
    orphan_output_ids: list[SafeId]
    duplicated_semantic_ids: list[SafeId]
    decisive_unmapped_ids: list[SafeId]
    status: str
    report_sha256: Sha256


def audit_transformation_conservation(
    *,
    transition_kind: TransitionKind,
    input_ids: list[str],
    output_ids: list[str],
    mapping: dict[str, list[str]],
    exclusions: dict[str, list[str]] | None = None,
    decisive_input_ids: set[str] | None = None,
) -> TransformationConservationReport:
    exclusions = exclusions or {}
    decisive_input_ids = decisive_input_ids or set()
    input_set = set(input_ids)
    output_set = set(output_ids)
    if len(input_set) != len(input_ids) or len(output_set) != len(output_ids):
        raise ValueError("input and output catalogs must not contain duplicate IDs")
    unknown_mapping_inputs = set(mapping) - input_set
    unknown_exclusions = set(exclusions) - input_set
    if unknown_mapping_inputs or unknown_exclusions:
        raise ValueError("mapping/exclusion contains IDs outside the input catalog")
    if set(mapping) & set(exclusions):
        raise ValueError("an input cannot be both mapped and excluded")
    if any(not reasons for reasons in exclusions.values()):
        raise ValueError("every exclusion requires a reason")

    mapped_outputs = [output for values in mapping.values() for output in values]
    unknown_outputs = set(mapped_outputs) - output_set
    if unknown_outputs:
        raise ValueError(f"mapping references unknown outputs: {sorted(unknown_outputs)}")
    mapped_inputs = set(mapping)
    unmapped = input_set - mapped_inputs - set(exclusions)
    decisive_unmapped = sorted(unmapped & decisive_input_ids)
    orphan_outputs = sorted(output_set - set(mapped_outputs))

    output_frequency: dict[str, int] = {}
    for output_id in mapped_outputs:
        output_frequency[output_id] = output_frequency.get(output_id, 0) + 1
    duplicated = sorted(output_id for output_id, count in output_frequency.items() if count > 1)
    status = "BLOCK" if decisive_unmapped or orphan_outputs or duplicated else "PASS"
    payload = {
        "transition_kind": transition_kind.value,
        "input_catalog_sha256": sha256_digest(sorted(input_ids)),
        "output_catalog_sha256": sha256_digest(sorted(output_ids)),
        "total_input_ids": sorted(input_ids),
        "mapped_input_ids": sorted(mapped_inputs),
        "excluded_input_ids_with_reason": {key: exclusions[key] for key in sorted(exclusions)},
        "orphan_output_ids": orphan_outputs,
        "duplicated_semantic_ids": duplicated,
        "decisive_unmapped_ids": decisive_unmapped,
        "status": status,
    }
    digest = sha256_digest(payload)
    return TransformationConservationReport(
        report_id=f"conservation-{digest.split(':', 1)[1][:16]}",
        report_sha256=digest,
        **payload,
    )
