"""R1: build a PolicyPack for a checking point from the statute text alone.

The constraint this module lives under
-------------------------------------
The competition forbids encoding compliance rules into prompts: the system must
derive its reasoning "solely from the policy document and farm evidence". So this
module may not contain a table of "CP22 requires a fumigation log". What it may
contain is *structural* extraction — how a legislative sentence is shaped —
because that is a property of legal drafting, not of this regulation's content.

What the statute actually looks like
------------------------------------
An earlier draft of this module assumed one obligation per section, shaped
``<subject> must <action> <object>``, and extracted the subject from the sentence.
Run against the real 2021 compilation that produced 38/41 packs whose subject slot
was wrong: phrases like "An establishment", "A record that" and "the operations"
rather than a duty-holder. Inspecting the anchored sections showed four distinct
drafting shapes, only the first of which the assumption fits:

1. *Named duty-holder* — s 11-7(1): "The occupier of an establishment that is
   registered ... **must retain** each document".
2. *Obligation-object as grammatical subject* — s 11-2(1): "**A record** that is
   required to be retained under this Part ... **must be**: (a) in English; ...".
   The duty-holder is never named in the sentence.
3. *Passive* — s 4-7A(1): "**A registered establishment must be kept** in a
   condition ...". Again no duty-holder in the sentence.
4. *Existential* — s 4-3(3): "**There must be** a system of controls in place ...".

Two design consequences follow, and they are the substance of this module.

**The duty-holder comes from the norm graph, not from the sentence.** Shapes 2-4
have no sentence-level subject to find, and guessing one produces exactly the
garbage the first draft produced. But the graph already resolves this: subject
closure over ``PART_SCOPE`` / ``APPLIES_VIA`` edges tells us that s 11-2 binds the
occupier because the other operative sections of Part 11-1 do. So ``subject`` is
taken from ``NormNode``, with its ``SubjectResolution`` recorded, and the sentence
is only consulted when the graph is ``UNRESOLVED``.

**One section carries many obligations, and different checking points target
different ones.** Section 4-7A(2) alone contains four: (a) clean and hygienic
condition, (b) pests and contaminants controlled, (c) toxic substances managed,
(d) waste treated and disposed of. CP24 and CP25 discriminate between them, so
collapsing 4-7A to a single rule slot destroys precisely the distinction being
tested. This module therefore segments each section into *obligation units* keyed
by their own subsection/paragraph path — ``4-7A(2)(b)`` — and runs a second,
finer BM25 pass to choose the unit a checking point is actually about.

That second pass makes retrieval hierarchical: section-level anchoring narrows
184 sections to a handful, then unit-level scoring picks the paragraph. This is
the standard coarse-to-fine arrangement (LegalBench-RAG reports legal retrieval
quality is dominated by chunk-boundary quality, and here the useful boundary is
finer than a section), and it costs one extra BM25 index over a few dozen short
strings.

Why an LLM is offered but not required
--------------------------------------
The deterministic extractor is the baseline and always runs. When a backend is
supplied it is asked to fill *only* slots the patterns left empty, and its answer
is accepted only if every returned string appears verbatim in the section text. A
model that paraphrases the statute has invented a requirement; substring-checking
catches that mechanically rather than by review. This is VeriCoT's grounding
discipline applied one stage earlier than the reasoning chain.

Ablation handles
----------------
``PACK_CONFIGS`` exposes ``section_level`` (the first draft's behaviour: one
quadruple per anchored section, sentence-level subject), ``unit_level`` (the
design above) and ``unit_level_model_assisted``. Keeping the discarded design
runnable is what lets the improvement be reported as a measurement rather than as
an assertion.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum

from freca.domain.models import PolicyPack, PolicySpan, RuleSlots
from freca.domain.policy_enums import ActorRole, SubjectResolution
from freca.llm.backends import LLMBackend, LLMError
from freca.policy.anchor import CheckingPoint
from freca.policy.norm_graph import NormGraph, NormNode, subjects_named_in
from freca.retrieval.bm25 import BM25Index

PACK_CONFIGS = ("section_level", "unit_level", "unit_level_model_assisted")


class Voice(str, Enum):
    """Which grammatical shape the obligation takes.

    This is not linguistic decoration: it decides where the *object of the duty*
    is found. In "the occupier must retain each document" the object follows the
    verb; in "a registered establishment must be kept in a condition" the object
    has been promoted to subject position by the passive, so reading the object
    from after the verb yields "in a condition" — a prepositional phrase, not a
    thing that can be checked against evidence.
    """

    ACTIVE = "ACTIVE"
    PASSIVE = "PASSIVE"
    EXISTENTIAL = "EXISTENTIAL"


#: Alternation order is load-bearing: ``must not`` before ``must`` and ``may
#: only`` before ``may``. Python's alternation is first-match, and reading a
#: prohibition as an obligation inverts the verdict — the worst error available.
_DEONTIC = re.compile(
    r"\b(?P<deontic>must not|must never|must|is required to|are required to|may only)\b",
    re.IGNORECASE,
)

_PASSIVE = re.compile(
    # An adverb may sit between the auxiliary and the participle ("must be
    # appropriately treated"), so one is allowed for; without it that provision
    # was misread as active and its object taken from the wrong side of the verb.
    r"\bmust\s+(?:not\s+)?be\s+(?:able\s+to\s+be\s+)?(?:\w+ly\s+)?"
    r"(?:\w+(?:ed|t|n)\b|\w+ing\b)",
    re.IGNORECASE,
)
_EXISTENTIAL = re.compile(r"\bthere\s+must\s+(?:not\s+)?be\b", re.IGNORECASE)

#: Examples in Commonwealth legislation are explanatory, not operative
#: (Acts Interpretation Act 1901 s 15AD / Legislation Act 2003). Section 4-7A(1)
#: carries "Example: Materials at the establishment must be monitored ...", whose
#: "must" was being extracted as a free-standing obligation and attached to the
#: wrong paragraph. Stripping examples removes an obligation the statute does not
#: impose — an error that would show up as a confident wrong verdict.
_EXAMPLE_CUE = re.compile(r"\bExample[s]?\s*:", re.IGNORECASE)

#: Inline italic signposts such as "System of controls must be in place" or
#: "Design and construction—general". They are drafting aids that sit between
#: subsections; the first kind contains "must" and would otherwise be mined as an
#: obligation in its own right.
_INLINE_HEADING = re.compile(
    r"^(?:[A-Z][A-Za-z ,\-]{2,60}—[A-Za-z ,\-]{2,40}"
    r"|[A-Z][A-Za-z ]{2,60}must (?:be|not be|have|comply|include|ensure)[A-Za-z ]{0,40})$"
)

_CONDITION = re.compile(
    r"\b(?:if|unless|where|when|provided that)\b\s+(?P<condition>[^.;:]{5,200})",
    re.IGNORECASE,
)

_NON_APPLICABILITY = re.compile(
    r"(?P<phrase>(?:this (?:section|Division|Part)\s+)?does not apply[^.;]{0,200}"
    r"|is not required to[^.;]{0,200}"
    r"|is taken to have complied[^.;]{0,200})",
    re.IGNORECASE,
)

_TEMPORAL = re.compile(
    r"\b(?:within|for at least|for a period of|no later than|before the end of|"
    r"at least)\s+[^.;,:]{2,60}",
    re.IGNORECASE,
)

#: Generic legal/administrative nouns only. A crop or treatment list here would be
#: a domain compliance rule smuggled in as a pattern, which the rules forbid.
_OBJECT_HEAD = re.compile(
    r"\b(record|records|document|documents|notice|report|declaration|register|"
    r"sample|samples|treatment|treatments|inspection|inspections|approval|permit|"
    r"certificate|label|labels|seal|seals|premises|establishment|equipment|area|"
    r"areas|goods|system of controls|controls|condition|waste|pest|pests|"
    r"contaminant|contaminants|substance|substances|requirement|requirements)\b",
    re.IGNORECASE,
)

#: Subsection/paragraph label at the start of a line: (1) (2A) (a) (ii).
_LABEL = re.compile(r"^(?P<indent>\s*)\((?P<label>\d{1,2}[A-Z]?|[a-z]{1,4})\)\s+(?P<rest>.*)$")

_ROMAN = re.compile(r"^[ivxl]+$")

#: Phrases the statute uses to name its own duty-holders, used to render the
#: graph-resolved role in the regulation's own words rather than as an enum name.
_ROLE_PHRASE = re.compile(
    r"(?:the |a |an )?(?:occupier of (?:an?|the) (?:establishment that is registered|"
    r"registered establishment)|occupier|manager of (?:an?|the) accredited property|"
    r"manager|exporter|authorised officer|assessor)",
    re.IGNORECASE,
)

#: The grammatical subject of an impersonal provision: the noun phrase sitting
#: immediately before the modal. "A registered establishment must be kept ..."
_PREMODAL_NP = re.compile(
    r"(?P<np>(?:The|A|An|All)\s+[A-Za-z][^.;:]{2,90}?)\s+"
    r"(?:must|is required to|are required to|may only)\b",
    re.IGNORECASE,
)

_ROLE_FALLBACK: dict[ActorRole, str] = {
    ActorRole.OCCUPIER: "the occupier of the registered establishment",
    ActorRole.MANAGER: "the manager of the accredited property",
    ActorRole.EXPORTER: "the exporter",
    ActorRole.AUTHORISED_OFFICER: "the authorised officer",
    ActorRole.REGULATOR: "the Secretary",
    ActorRole.SUPPLIER: "the supplier",
}

#: Fallback for existential provisions ("There must be a system of controls ..."),
#: which have no grammatical subject at all. The phrase is taken from the chapter
#: heading that ``derive_scope`` already reads, so it is the document's own
#: wording rather than an assumption about who is liable.
_SCOPE_PHRASE: dict[str, str] = {
    "REGISTERED_ESTABLISHMENT": "the registered establishment",
    "ACCREDITED_PROPERTY": "the accredited property",
    "EXPORT_PERMIT": "the export permit",
    "GOODS": "the prescribed plants or plant products",
}


@dataclass(slots=True, frozen=True)
class ObligationUnit:
    """One deontic statement, addressed by its own path inside the section."""

    section_id: str
    path: str
    own_text: str
    context_text: str
    deontic: str
    voice: Voice
    action: str
    obligation_object: str

    @property
    def unit_id(self) -> str:
        return f"{self.section_id}{self.path}"

    @property
    def searchable(self) -> str:
        return f"{self.context_text} {self.own_text}".strip()

    def to_dict(self) -> dict[str, object]:
        return {
            "unit_id": self.unit_id,
            "section_id": self.section_id,
            "path": self.path,
            "deontic": self.deontic,
            "voice": self.voice.value,
            "action": self.action,
            "object": self.obligation_object,
            "own_text": self.own_text,
            "context_text": self.context_text,
        }


@dataclass(slots=True)
class SlotEvidence:
    """One filled slot plus the verbatim statute span it came from."""

    slot: str
    value: str
    section_id: str
    span: str
    filled_by: str

    def to_dict(self) -> dict[str, object]:
        return {
            "slot": self.slot,
            "value": self.value,
            "section_id": self.section_id,
            "span": self.span,
            "filled_by": self.filled_by,
        }


@dataclass(slots=True)
class PackExtraction:
    """A PolicyPack plus the provenance of every slot and the gaps that remain."""

    pack: PolicyPack | None = None
    config: str = "unit_level"
    slot_evidence: list[SlotEvidence] = field(default_factory=list)
    unfilled_slots: list[str] = field(default_factory=list)
    model_rejected: list[str] = field(default_factory=list)
    #: Slots the backend was asked for and left empty. Kept separate from
    #: ``model_rejected`` because "would not answer" and "answered with a
    #: paraphrase" call for different responses: the first is a coverage gap, the
    #: second is a grounding failure.
    model_abstained: list[str] = field(default_factory=list)
    #: True when the model was actually asked for a slot. Distinguishes "the model
    #: answered well" from "the model was never consulted" — on the real instrument
    #: the deterministic patterns fill every slot, so the model-assisted config is
    #: asked nothing, and a summary that omitted this would read as a clean run.
    model_consulted: bool = False
    units: list[ObligationUnit] = field(default_factory=list)
    chosen_unit_id: str | None = None
    chosen_unit_ids: list[str] = field(default_factory=list)
    unit_scores: list[tuple[str, float]] = field(default_factory=list)
    #: Units that scored high enough to join the pack but were excluded because a
    #: different duty-holder governs them. Recorded rather than dropped so the
    #: filter's rate is measurable and a wrong exclusion is visible in the audit
    #: trail instead of only in the absence of a fact.
    rejected_companions: list[tuple[str, str]] = field(default_factory=list)
    subject: SubjectFinding | None = None
    subject_resolution: str | None = None
    subject_path: list[str] = field(default_factory=list)

    @property
    def adjudicable(self) -> bool:
        return self.pack is not None

    @property
    def review_required(self) -> bool:
        """Whether the pack rests on an inferred duty-holder.

        Read by C1/C7 so that "we worked out who this binds" is visible on the
        decision rather than implicit in the pack.
        """

        return self.subject is None or self.subject.review_required

    def to_dict(self) -> dict[str, object]:
        return {
            "config": self.config,
            "adjudicable": self.adjudicable,
            "cp_id": self.pack.cp_id if self.pack else None,
            "chosen_unit_id": self.chosen_unit_id,
            "chosen_unit_ids": self.chosen_unit_ids,
            "unit_scores": self.unit_scores[:10],
            "rejected_companions": self.rejected_companions,
            "n_units": len(self.units),
            "subject_resolution": self.subject_resolution,
            "subject_basis": self.subject.basis if self.subject else None,
            "subject_path": self.subject_path,
            "review_required": self.review_required,
            "unfilled_slots": self.unfilled_slots,
            "model_rejected": self.model_rejected,
            "model_abstained": self.model_abstained,
            "model_consulted": self.model_consulted,
            "slot_evidence": [item.to_dict() for item in self.slot_evidence],
            "pack": self.pack.model_dump(mode="json") if self.pack else None,
        }


# -- segmentation ------------------------------------------------------------


@dataclass(slots=True)
class _Block:
    indent: int
    label: str
    lines: list[str]
    parents: tuple[str, ...]

    @property
    def path(self) -> str:
        return "".join(f"({label})" for label in (*self.parents, self.label))

    @property
    def text(self) -> str:
        return " ".join(" ".join(line.split()) for line in self.lines).strip()


def _find_deontic(text: str) -> re.Match[str] | None:
    """Find the *operative* modal, skipping ones inside a relative clause.

    Legislative drafting routinely qualifies the duty-bearing noun with a
    relative clause that contains its own modal. Section 11-2(1) opens "A record
    that **is required to** be retained under this Part ... **must be**: ..." —
    the first modal describes which records the section is about, the second
    imposes the duty. Taking the first produced the action "is required to be
    retained under this Part ...", i.e. the scope test misread as the obligation.

    Measured on the 2021 compilation: 6 of 204 deontic units open with a
    relative-clause modal followed by a later operative one. The rule only skips
    a match when a later modal exists, so a genuine duty phrased with "is
    required to" as its main verb is untouched.
    """

    for match in _DEONTIC.finditer(text):
        preceding = text[: match.start()]
        if _RELATIVE_CLAUSE.search(preceding) and _DEONTIC.search(text, match.end()):
            continue
        return match
    return None


#: A relative pronoun immediately before a modal marks the modal as part of a
#: qualifying clause rather than the operative duty.
_RELATIVE_CLAUSE = re.compile(r"\b(?:that|which|who)\s+$", re.IGNORECASE)

#: A chapeau ends in a colon and defers its content to child paragraphs.
_CHAPEAU_TAIL = re.compile(r":\s*$")


def _blocks(lines: list[str]) -> list[_Block]:
    """Split a section's lines into labelled blocks, nested by indentation.

    Indentation rather than label *type* decides nesting because ``(i)`` is both a
    valid roman numeral and a valid letter label, so the label alone is ambiguous
    while the compilation's layout is not.

    Indentation alone is not enough either. The compilation re-indents after a page
    break, so a paragraph list can restart several columns to the right and its
    later members then look like children of their own earlier sibling — the
    observed symptom was the path ``4-7A(2)(a)(d)``, which asserts a paragraph (d)
    nested inside paragraph (a). Label *continuity* disambiguates: if a new label
    is the successor of the innermost open block's label, the two are siblings
    regardless of what the indentation says.
    """

    blocks: list[_Block] = []
    stack: list[_Block] = []
    preamble = _Block(indent=-1, label="", lines=[], parents=())

    for line in lines:
        match = _LABEL.match(line)
        if match is None:
            (blocks[-1] if blocks else preamble).lines.append(line)
            continue
        indent = len(match.group("indent"))
        label = match.group("label")

        while stack and stack[-1].indent >= indent:
            stack.pop()
        # Sibling rescue: an out-dented successor of the open block is its peer.
        if stack and _is_successor(stack[-1].label, label):
            stack.pop()

        block = _Block(
            indent=indent,
            label=label,
            lines=[match.group("rest")],
            parents=tuple(item.label for item in stack),
        )
        blocks.append(block)
        stack.append(block)

    if preamble.lines:
        blocks.insert(0, preamble)
    return blocks


def _is_successor(previous: str, candidate: str) -> bool:
    """True when ``candidate`` is the next label in ``previous``'s own series.

    Only adjacent successors count. Treating any same-series label as a sibling
    would flatten genuine nesting such as ``(2)(a)`` under ``(1)``.
    """

    if not previous or not candidate:
        return False
    if previous.isdigit() and candidate.isdigit():
        return int(candidate) == int(previous) + 1
    prev_alpha = previous.isalpha() and previous.islower()
    cand_alpha = candidate.isalpha() and candidate.islower()
    if not (prev_alpha and cand_alpha):
        return False
    prev_roman, cand_roman = bool(_ROMAN.match(previous)), bool(_ROMAN.match(candidate))
    if prev_roman != cand_roman:
        return False
    if len(previous) == 1 and len(candidate) == 1:
        return ord(candidate) == ord(previous) + 1
    return _roman_value(candidate) == _roman_value(previous) + 1


def _roman_value(text: str) -> int:
    values = {"i": 1, "v": 5, "x": 10, "l": 50}
    total = 0
    previous = 0
    for char in reversed(text.lower()):
        current = values.get(char, 0)
        total += -current if current < previous else current
        previous = max(previous, current)
    return total


def _voice_of(text: str) -> Voice:
    if _EXISTENTIAL.search(text):
        return Voice.EXISTENTIAL
    if _PASSIVE.search(text):
        return Voice.PASSIVE
    return Voice.ACTIVE


def _object_from(text: str, *, before: int, after: int, voice: Voice) -> str:
    """Locate the thing the duty is about.

    For an active or existential obligation that is the noun following the verb;
    for a passive one it is the noun phrase *preceding* the modal, which the
    construction has promoted into subject position.

    Two details were wrong in the first version and both produced garbage slots.
    The active branch sliced from the start of the deontic match, so the modal
    itself led the object ("must be a system of controls"). And the passive branch
    started a fixed 40 characters back, which lands mid-word: the observed output
    was "stablishment, the establishment and its equipment". Both are fixed by
    slicing on token boundaries — ``after`` is the end of the deontic match, and
    the backward window is snapped to a word start.
    """

    if voice is not Voice.PASSIVE:
        # Existential provisions ("There must be a system of controls in place")
        # have nothing before the modal but the dummy "there", so like actives
        # their object follows the verb.
        region = text[after:]
        match = _OBJECT_HEAD.search(region)
        if match is None:
            return ""
        return _trim(region[match.start() : match.start() + 120])

    region = text[:before]
    matches = list(_OBJECT_HEAD.finditer(region))
    if not matches:
        return ""
    match = matches[-1]
    start = max(0, match.start() - 60)
    if start > 0:
        space = region.find(" ", start)
        start = space + 1 if space != -1 and space < match.start() else match.start()
    return _trim(region[start : match.end()])


def _trim(span: str) -> str:
    """Normalise whitespace and shed leading/trailing punctuation and stopwords."""

    text = " ".join(span.split()).strip(" ,;:.—-")
    words = text.split()
    while words and words[0].lower() in {"and", "or", "the", "a", "an", "of", "at", "in", "that"}:
        words.pop(0)
    return " ".join(words)


def segment_obligations(section_id: str, lines: list[str]) -> list[ObligationUnit]:
    """Return every deontic statement in a section, addressed by its own path."""

    blocks = _blocks(lines)
    by_path = {block.path: block for block in blocks}
    units: list[ObligationUnit] = []

    for block in blocks:
        text = _operative_text(block.text)
        if not text:
            continue
        match = _find_deontic(text)
        if match is None:
            continue
        deontic = match.group("deontic").lower()
        voice = _voice_of(text)
        action = " ".join(text[match.start() :].split())[:300]
        obligation_object = _object_from(
            text, before=match.start(), after=match.end(), voice=voice
        )

        context: list[str] = []
        for depth in range(len(block.parents)):
            parent_path = "".join(f"({label})" for label in block.parents[: depth + 1])
            parent = by_path.get(parent_path)
            if parent is not None:
                context.append(_operative_text(parent.text)[:200])

        # A chapeau defers its content to its children: s 11-2(1) says a record
        # "must be:" and the requirement itself is in (a)-(d). Those children carry
        # no modal, so they produce no unit of their own and the duty would reduce
        # to "must be: is present and complete" — a fact with no content. The
        # children are appended to the action so the requirement survives, with
        # their own labels kept so a reviewer can still see which limb is which.
        if _CHAPEAU_TAIL.search(action):
            limbs = [
                f"({child.label}) {_operative_text(child.text)}"
                for child in blocks
                if child.parents == (*block.parents, block.label)
            ]
            if limbs:
                action = " ".join(f"{action} {' '.join(limbs)}".split())[:600]
                if not obligation_object:
                    obligation_object = _trim(" ".join(limbs))[:200]

        units.append(
            ObligationUnit(
                section_id=section_id,
                path=block.path,
                own_text=text,
                context_text=" ".join(item for item in context if item),
                deontic=deontic,
                voice=voice,
                action=action,
                obligation_object=obligation_object,
            )
        )
    return units


def _operative_text(text: str) -> str:
    """Drop the non-operative matter a block may carry.

    Examples and inline signpost headings are removed because neither imposes a
    duty, yet both contain "must" and were being mined as obligations. Keeping
    them meant s 4-7A(1) acquired a spurious requirement to monitor materials,
    sourced from its own explanatory Example.
    """

    cut = _EXAMPLE_CUE.search(text)
    if cut is not None:
        text = text[: cut.start()]
    kept = [
        part
        for part in re.split(r"(?<=[.;:])\s+", text)
        if part.strip() and not _INLINE_HEADING.match(part.strip())
    ]
    return " ".join(kept).strip()


# -- subject -----------------------------------------------------------------


@dataclass(slots=True, frozen=True)
class SubjectFinding:
    """Who the obligation binds, and on what authority we say so."""

    phrase: str
    resolution: SubjectResolution
    basis: str
    path: list[str] = field(default_factory=list)

    @property
    def review_required(self) -> bool:
        """True when the duty-holder was not stated by the provision itself.

        Surfaced so C1/C7 can set ``review_required`` on the decision instead of
        this uncertainty vanishing into a confident-looking label.
        """

        return self.resolution is not SubjectResolution.DIRECT


def resolve_subject(
    node: NormNode,
    target_role: ActorRole,
    *,
    unit: ObligationUnit | None = None,
) -> SubjectFinding:
    """Name the duty-holder, preferring the strongest available authority.

    The ladder, strongest first:

    1. ``DIRECT`` — the section names a role and the graph resolved it. Use the
       statute's own phrase.
    2. ``INHERITED`` — the graph closed the subject over ``APPLIES_VIA`` (this is
       what rescues s 11-2, whose duty-holder is only discoverable from the rest
       of Part 11-1).
    3. *Impersonal provision* — no role anywhere in the section. This is not a
       parse failure; it is the dominant drafting style of the conditions of
       registration, which is where most checking points live. Measured on the
       2021 compilation: of the 41 checking points, 29 anchor to sections such as
       4-2, 4-3, 4-7A, 4-7B and 11-8, none of which contains the word "occupier"
       and none of which says "under this Part", so neither (1) nor (2) can fire.
       For these the grammatical subject of the sentence is used ("A registered
       establishment must be kept ..."), falling back to the chapter's regulated
       object for existentials ("There must be a system of controls ...").

    Rejecting case 3 as unfilled — the previous behaviour — is the same
    over-pruning mistake that config PB makes in the policy chain: it treats
    "unstated" as "incompatible" and discards 29 of 41 checking points. It is safe
    to proceed here precisely because ``NormGraph.gate`` has already run: a
    section addressed to a *different* role is rejected before reaching this
    function, so an impersonal section that survives the gate is one no competing
    regime claims. The residual uncertainty is recorded in ``resolution`` and
    ``basis`` and propagated as ``review_required`` rather than hidden.
    """

    roles = node.subjects
    if roles:
        role = target_role if target_role in roles else sorted(roles, key=lambda r: r.value)[0]
        if node.resolution is SubjectResolution.DIRECT:
            match = _ROLE_PHRASE.search(node.section.text)
            if match is not None:
                return SubjectFinding(
                    phrase=" ".join(match.group(0).split()),
                    resolution=node.resolution,
                    basis=f"named in {node.section_id}",
                    path=node.subject_path,
                )
        return SubjectFinding(
            phrase=_ROLE_FALLBACK.get(role, role.value),
            resolution=node.resolution,
            basis=(
                f"subject closure over {node.subject_path[1:]}"
                if node.resolution is SubjectResolution.INHERITED
                else f"role {role.value} detected in {node.section_id}"
            ),
            path=node.subject_path,
        )

    if unit is not None:
        if unit.voice is not Voice.EXISTENTIAL:
            match = _PREMODAL_NP.search(unit.own_text)
            if match is not None:
                return SubjectFinding(
                    phrase=" ".join(match.group("np").split()),
                    resolution=SubjectResolution.UNRESOLVED,
                    basis=f"grammatical subject of {unit.unit_id}; provision is impersonal",
                )
        phrase = _SCOPE_PHRASE.get(node.scope.value)
        if phrase is not None:
            return SubjectFinding(
                phrase=phrase,
                resolution=SubjectResolution.UNRESOLVED,
                basis=f"regulated object of scope {node.scope.value}; no duty-holder stated",
            )

    return SubjectFinding(phrase="", resolution=SubjectResolution.UNRESOLVED, basis="no subject found")


# -- extraction --------------------------------------------------------------


def extract_pack(
    *,
    checking_point: CheckingPoint,
    anchor_section_ids: list[str],
    graph: NormGraph,
    policy_version: str,
    target_role: ActorRole = ActorRole.OCCUPIER,
    backend: LLMBackend | None = None,
    config: str = "unit_level",
) -> PackExtraction:
    """Derive a PolicyPack from the anchored sections' own text.

    ``anchor_section_ids`` must already have passed the scope/subject gate; this
    function reads text and does not re-litigate scope.
    """

    if config not in PACK_CONFIGS:
        raise ValueError(f"unknown pack config: {config!r}")

    extraction = PackExtraction(config=config)

    nodes: dict[str, NormNode] = {}
    spans: list[PolicySpan] = []
    for section_id in anchor_section_ids:
        node = graph.nodes.get(section_id)
        if node is None or not node.section.text.strip():
            continue
        nodes[section_id] = node
        spans.append(
            PolicySpan(
                source_id=section_id,
                locator=f"{section_id} {node.section.title}".strip(),
                # Not truncated on purpose: ``NormSection.source_hash`` is the
                # sha256 of the *full* section text, so a clipped copy here would
                # fail an independent hash check.
                text=node.section.text,
                source_hash=node.section.source_hash,
            )
        )

    if not spans:
        extraction.unfilled_slots = ["authoritative_spans"]
        return extraction

    for section_id, node in nodes.items():
        extraction.units.extend(segment_obligations(section_id, node.section.lines))

    units = _choose_units(checking_point, extraction, config=config, target_role=target_role)
    if not units:
        extraction.unfilled_slots = ["obligation_unit"]
        return extraction

    unit = units[0]
    home = nodes[unit.section_id]
    finding = resolve_subject(home, target_role, unit=unit)
    extraction.subject = finding
    extraction.subject_resolution = finding.resolution.value
    extraction.subject_path = finding.path

    subject = finding.phrase
    deontic = unit.deontic
    action = unit.action
    obligation_object = unit.obligation_object

    for slot, value, basis in (
        ("subject", subject, finding.basis),
        ("deontic", deontic, "pattern"),
        ("action", action, "pattern"),
        ("object", obligation_object, "pattern"),
    ):
        if value:
            extraction.slot_evidence.append(
                SlotEvidence(
                    slot=slot,
                    value=value,
                    section_id=unit.section_id,
                    span=unit.own_text[:400],
                    filled_by=basis,
                )
            )

    conditions, na_conditions, temporal = _modifiers(units, nodes, extraction)

    if backend is not None and config == "unit_level_model_assisted":
        subject, deontic, action, obligation_object = _model_fill(
            backend=backend,
            checking_point=checking_point,
            unit=unit,
            current=(subject, deontic, action, obligation_object),
            extraction=extraction,
        )

    unfilled = [
        name
        for name, value in (
            ("subject", subject),
            ("deontic", deontic),
            ("action", action),
            ("object", obligation_object),
        )
        if not value
    ]
    extraction.unfilled_slots = list(unfilled)

    # An obligation with no duty-holder, no force, or no act is not an obligation.
    # Emitting a pack anyway would let the loop adjudicate against a half-read
    # rule, and the resulting label would look identical to a well-founded one.
    if {"subject", "deontic", "action"} & set(unfilled):
        return extraction

    required_facts: list[str] = []
    violation_facts: list[str] = []
    for member in units:
        member_required, member_violations = _decision_paths(
            deontic=member.deontic,
            action=member.action,
            obligation_object=member.obligation_object,
            # Only the primary unit's temporal requirement is applied to itself;
            # a retention period in one paragraph does not govern a sibling.
            temporal=temporal if member is unit else None,
            voice=member.voice,
            unit_id=member.unit_id,
        )
        for fact in member_required:
            if fact not in required_facts:
                required_facts.append(fact)
        for fact in member_violations:
            if fact not in violation_facts:
                violation_facts.append(fact)

    if not (required_facts or violation_facts or na_conditions):
        extraction.unfilled_slots = [*unfilled, "decision_path"]
        return extraction

    extraction.pack = PolicyPack(
        cp_id=checking_point.cp_id,
        policy_version=policy_version,
        authoritative_spans=spans,
        rule_slots=RuleSlots(
            subject=subject,
            deontic=deontic,
            action=action,
            object=obligation_object or action[:80],
            conditions=conditions,
            temporal=temporal,
        ),
        scope_predicates=conditions,
        explicit_legal_exemptions=na_conditions,
        # Keep the old names populated while existing run artefacts and fixtures
        # are migrated.  C1 reads the new fields first.
        applicability_predicates=conditions,
        explicit_na_conditions=na_conditions,
        required_facts=required_facts,
        violation_facts=violation_facts,
        counter_facts=[],
        related_cp_ids=[],
    )
    return extraction


#: A companion unit is kept when it scores at least this fraction of the best
#: unit's score. Calibrated against the observed distributions on the 2021
#: compilation, where the gap between "the checking point also tests this" and
#: "different subject matter" falls in a wide, sparsely-populated band: for CP24
#: the ratios run 1.00, 0.56, 0.38, 0.34 with 4-7A(2)(a) and (2)(b) — both
#: genuinely in scope — above 0.5, and unrelated sections below 0.4. For CP11 the
#: 4-2 design paragraphs sit at 1.00/0.79/0.74/0.69 and the first out-of-topic
#: unit at 0.33. Exposed as a parameter rather than hard-coded so it can be swept.
UNIT_COMPANION_RATIO = 0.55

#: Cap on units per pack. Without it a section drafted as a long list (s 4-2 has
#: 11 obligation units) would put its entire contents into one pack and the
#: required-facts list would stop discriminating between checking points.
UNIT_MAX_PER_PACK = 4


def _choose_units(
    checking_point: CheckingPoint,
    extraction: PackExtraction,
    *,
    config: str,
    target_role: ActorRole,
    companion_ratio: float = UNIT_COMPANION_RATIO,
    max_units: int = UNIT_MAX_PER_PACK,
) -> list[ObligationUnit]:
    """Pick the obligation(s) the checking point is about.

    Returning a list rather than a single unit is deliberate. Checking points are
    written as conjunctions — CP24 reads "All areas of the establishment are
    operating and/or maintained in a clean and hygienic condition" and is tested
    against s 4-7A(2)(a) *and* (2)(b) — so a pack built from one paragraph asks a
    narrower question than the checking point does, and would score a farm
    compliant on the strength of half the requirement.

    A ratio-to-best rule is used rather than a fixed count because the number of
    paragraphs a checking point spans varies from one to four in this instrument,
    and because scores are not comparable across checking points (BM25 is not
    normalised) while ratios within one query are.

    ``section_level`` keeps the discarded design runnable for ablation: one unit,
    taken from the best-ranked section, which is what "one rule per section"
    amounts to in practice.
    """

    if not extraction.units:
        return []

    index = BM25Index({unit.unit_id: unit.searchable for unit in extraction.units})
    hits = index.score(checking_point.query)
    extraction.unit_scores = [(hit.doc_id, round(hit.score, 4)) for hit in hits[:10]]

    by_id = {unit.unit_id: unit for unit in extraction.units}
    if not hits or hits[0].score <= 0.0:
        # No lexical signal at all. Falling back to document order is honest —
        # the alternative is to pretend a zero-score match was a choice.
        chosen = [extraction.units[0]]
        extraction.chosen_unit_id = chosen[0].unit_id
        extraction.chosen_unit_ids = [chosen[0].unit_id]
        return chosen

    if config == "section_level":
        chosen = [by_id[hits[0].doc_id]]
    else:
        cutoff = hits[0].score * companion_ratio
        candidates = [by_id[hit.doc_id] for hit in hits[:max_units] if hit.score >= cutoff]
        compatible: list[ObligationUnit] = []
        for candidate in candidates:
            reason = _role_conflict(candidate, target_role=target_role)
            if reason is None:
                compatible.append(candidate)
            else:
                extraction.rejected_companions.append((candidate.unit_id, reason))
        # Demote rather than delete. If every candidate names a competing role the
        # pack is built from the best of them anyway, because an empty pack is an
        # abstention the checking point did not ask for; the rejection stays in
        # ``rejected_companions`` so a reviewer can see the pack rests on a
        # provision whose duty-holder looks wrong.
        chosen = compatible or [candidates[0]]

    extraction.chosen_unit_id = chosen[0].unit_id
    extraction.chosen_unit_ids = [unit.unit_id for unit in chosen]
    return chosen


def _role_conflict(unit: ObligationUnit, *, target_role: ActorRole) -> str | None:
    """Say why ``unit`` may not enter a pack addressed to ``target_role``.

    A pack carries a single ``subject`` slot, so every fact inside it is asserted
    against one duty-holder. Admitting a paragraph governed by a *different* role
    does not merely add noise: it reassigns the obligation, and the pack would
    then find a farm non-compliant on the strength of a duty owed by somebody
    else.

    ``NormGraph.gate`` cannot catch this, because it reasons per section while
    packs reason per obligation unit, and a section may host several duty-holders
    in different paragraphs. Measured instance: CP23 and CP40 paired s 11-2(1)
    (occupier, INHERITED) with s 8-8(4)(b). Section 8-8 legitimately survives the
    gate — its subsection (3)(b) does address the occupier of a registered
    establishment — but (4)(b) states the *translator's* independence
    requirement, so the gate's section-level admission is no licence to import
    that paragraph.

    The test is applied to every candidate including the best-scoring one, because
    nothing else checks the primary: BM25 ranks on wording, and a foreign-governed
    paragraph can outscore the right one.

    Only a *named competing role* conflicts. A unit that names no role is
    admitted, deliberately: the conditions of registration are drafted
    impersonally, and treating silence as conflict would repeat the over-pruning
    error of anchor config PB and dissolve the conjunctive packs (CP16, CP24) that
    multi-unit selection exists to build.
    """

    roles = subjects_named_in(unit.searchable)
    if target_role in roles:
        # "The occupier must notify the Secretary" names two roles and is owed by
        # the occupier; the target's presence settles it.
        return None
    competing = roles - {target_role}
    if not competing:
        return None
    named = ", ".join(sorted(role.value for role in competing))
    # Worded as "names ... but not" rather than "addressed to", because that is
    # what the cue table licenses. Measured example: s 8-8(4)(b) trips this rule on
    # a mention of the Secretary, yet its true duty-holder is the translator. The
    # exclusion is right for a weaker reason than "addressed to" would claim, and
    # overstating it here would put an unsupported assertion in the audit trail.
    return f"names {named} but not {target_role.value}"


def _modifiers(
    units: list[ObligationUnit],
    nodes: dict[str, NormNode],
    extraction: PackExtraction,
) -> tuple[list[str], list[str], str | None]:
    """Collect conditions, explicit N/A phrases and the temporal requirement.

    Conditions and the temporal requirement are read from the selected units and
    their context only — a condition attached to a sibling paragraph that was *not*
    selected governs that sibling, not this obligation. Explicit non-applicability
    is read from the whole section, because "this section does not apply if ..." is
    normally drafted as a separate closing subsection rather than inside the
    paragraph it exempts.
    """

    conditions: list[str] = []
    na_conditions: list[str] = []
    temporal: str | None = None

    for unit in units:
        scope_text = unit.searchable
        for match in _CONDITION.finditer(scope_text):
            value = " ".join(match.group("condition").split())
            if value not in conditions:
                conditions.append(value)
                extraction.slot_evidence.append(
                    SlotEvidence("condition", value, unit.section_id, scope_text[:400], "pattern")
                )
        if temporal is None:
            match = _TEMPORAL.search(scope_text)
            if match is not None:
                temporal = " ".join(match.group(0).split())
                extraction.slot_evidence.append(
                    SlotEvidence("temporal", temporal, unit.section_id, scope_text[:400], "pattern")
                )

    for section_id in dict.fromkeys(unit.section_id for unit in units):
        section_text = nodes[section_id].section.text
        for match in _NON_APPLICABILITY.finditer(section_text):
            value = " ".join(match.group("phrase").split())
            if value not in na_conditions:
                na_conditions.append(value)
                extraction.slot_evidence.append(
                    SlotEvidence(
                        "explicit_na_condition", value, section_id, value[:400], "pattern"
                    )
                )

    return conditions, na_conditions, temporal


def _decision_paths(
    *,
    deontic: str,
    action: str,
    obligation_object: str,
    temporal: str | None,
    voice: Voice,
    unit_id: str,
) -> tuple[list[str], list[str]]:
    """Turn deontic force into required facts and violation facts.

    The direction is the only inference made here and it follows from the deontic
    operator, not from the subject matter: an obligation is discharged by the act
    occurring, a prohibition is breached by it occurring. Getting this backwards
    would invert every verdict on a prohibitory checking point, which is why
    ``must not`` is matched ahead of ``must``.

    Each fact carries its ``unit_id`` so that a per-fact retrieval failure can be
    traced back to the paragraph that demanded it — without that, a pack spanning
    four paragraphs yields four indistinguishable "not found" results.
    """

    target = obligation_object or action
    required: list[str] = []
    violations: list[str] = []
    tag = f" [{unit_id}]"

    if deontic in {"must not", "must never"}:
        violations.append(f"{target} occurred{tag}")
        return required, violations

    if deontic in {"must", "is required to", "are required to", "may only"}:
        if voice is Voice.EXISTENTIAL:
            required.append(f"{target} exists at the establishment{tag}")
        elif voice is Voice.PASSIVE:
            # The participle carries the requirement. Phrasing the fact as
            # "<object> is in the state the provision requires" was measurably
            # empty: s 4-7A(1)(a) "all areas ... must be kept in a clean
            # condition" became "all areas of the establishment is in the state
            # the provision requires", which no retriever can look for and no
            # reviewer can check. The predicate is recovered from the action.
            predicate = _passive_predicate(action)
            if predicate:
                required.append(f"{target} is {predicate}{tag}")
            else:
                required.append(f"{target} is in the state the provision requires{tag}")
        else:
            required.append(f"{target} is present and complete{tag}")
        if temporal:
            required.append(f"{target} satisfies the time requirement: {temporal}{tag}")
        if deontic == "may only":
            violations.append(f"{target} occurred outside the permitted circumstances{tag}")
    return required, violations


def _passive_predicate(action: str) -> str:
    """Return the participle phrase of a passive obligation, or ``""``.

    ``action`` begins at the modal, so "must be kept in a clean condition" yields
    "kept in a clean condition". Only text taken verbatim from the provision is
    returned — nothing is paraphrased — so the resulting fact stays checkable
    against the instrument.
    """

    match = _PASSIVE.search(action)
    if match is None:
        return ""
    # Start at the participle: skip the modal and the auxiliary the pattern
    # matched, keeping any adverb that qualifies the act.
    head = re.search(r"\bbe\s+(?:able\s+to\s+be\s+)?", match.group(0))
    if head is None:
        return ""
    start = match.start() + head.end()
    return " ".join(action[start:].split())[:200].strip(" ,;:.")


def _model_fill(
    *,
    backend: LLMBackend,
    checking_point: CheckingPoint,
    unit: ObligationUnit,
    current: tuple[str, str, str, str],
    extraction: PackExtraction,
) -> tuple[str, str, str, str]:
    """Ask the model for missing slots; accept only verbatim statute substrings.

    Rejected values are recorded rather than dropped, so "the model paraphrased
    the statute" becomes a measurable rate instead of an invisible one.

    ``extraction.model_consulted`` records whether the model was asked at all.
    Without it, a config in which every slot was already filled deterministically
    is indistinguishable from one in which the model answered perfectly — measured
    on the real instrument, the model-assisted config is asked **nothing** on all
    40 adjudicable checking points, and reporting that as a clean run would be a
    false positive.
    """

    subject, deontic, action, obligation_object = current
    missing = [
        name
        for name, value in (
            ("subject", subject),
            ("deontic", deontic),
            ("action", action),
            ("object", obligation_object),
        )
        if not value
    ]
    if not missing:
        return current

    extraction.model_consulted = True
    system = (
        "You extract the grammatical parts of a legislative obligation. "
        "Every value you return must be copied verbatim from the provided text. "
        "Do not paraphrase, summarise or infer. If a part is absent from the text, "
        "return an empty string. Reply with one JSON object and nothing else."
    )
    user = (
        f"CHECKING POINT: {checking_point.query[:500]}\n\n"
        f"PROVISION {unit.unit_id}:\n{unit.context_text}\n{unit.own_text}\n\n"
        f"Return verbatim spans for these keys only: {missing}\n"
        'Format: {"subject": "...", "deontic": "...", "action": "...", "object": "..."}'
    )

    try:
        payload = backend.complete_json(system, user)
    except LLMError:
        return current
    if not isinstance(payload, dict):
        return current

    haystack = " ".join(unit.searchable.split()).lower()
    filled = {
        "subject": subject,
        "deontic": deontic,
        "action": action,
        "object": obligation_object,
    }
    for slot in missing:
        candidate = str(payload.get(slot, "") or "").strip()
        if not candidate:
            # A third outcome, distinct from accept and reject: the backend
            # declined to answer. The offline fake always lands here because it
            # answers from a hash rather than inventing statutory text — which is
            # the right behaviour for it, but it means an unreported abstention
            # would make a fake run look like a clean one.
            extraction.model_abstained.append(slot)
            continue
        if " ".join(candidate.split()).lower() not in haystack:
            extraction.model_rejected.append(f"{slot}={candidate[:120]}")
            continue
        filled[slot] = candidate
        extraction.slot_evidence.append(
            SlotEvidence(
                slot=slot,
                value=candidate,
                section_id=unit.section_id,
                span=candidate[:400],
                filled_by="model_verbatim_verified",
            )
        )

    return filled["subject"], filled["deontic"], filled["action"], filled["object"]
