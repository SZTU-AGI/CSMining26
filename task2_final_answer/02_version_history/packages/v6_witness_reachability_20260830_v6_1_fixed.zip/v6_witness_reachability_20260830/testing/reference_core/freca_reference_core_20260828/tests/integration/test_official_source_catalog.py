from __future__ import annotations

import unittest
from pathlib import Path

from freca.governance.config import load_run_config
from freca.governance.source_guard import FileSystemSourceGuard


class OfficialSourceCatalogTests(unittest.TestCase):
    def test_frozen_official_catalog(self) -> None:
        package_root = Path(__file__).resolve().parents[2]
        config = load_run_config(package_root / "configs" / "run.example.toml")
        if not Path(config.inputs.task_root).is_dir():
            self.skipTest("official Task2 bundle is not installed on this host")
        guard = FileSystemSourceGuard()
        catalog = guard.validate(config)
        self.assertEqual(len(catalog.evidence), 898)
        self.assertEqual(sum(item.extension == ".docx" for item in catalog.evidence), 698)
        self.assertEqual(sum(item.extension == ".xlsx" for item in catalog.evidence), 200)
        self.assertEqual(guard.verify_unchanged(catalog).status, "UNCHANGED")


if __name__ == "__main__":
    unittest.main()
