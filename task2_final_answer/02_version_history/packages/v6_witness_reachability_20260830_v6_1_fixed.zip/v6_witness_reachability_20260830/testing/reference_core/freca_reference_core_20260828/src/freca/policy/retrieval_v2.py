"""CP-independent multi-channel legal candidate retrieval and auditable RRF."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import Literal

from pydantic import Field

from freca.domain.models import SafeId, Sha256, StrictModel
from freca.governance.hashing import sha256_digest
from freca.policy.cp_loader import OfficialCP
from freca.policy.schemas_v2 import PolicyIndex, PolicyUnit, PolicyUnitType
from freca.retrieval.bm25 import STOPWORDS, BM25Index, tokenize


class ScopeCompatibility(StrEnum):
    COMPATIBLE = "COMPATIBLE"
    POSSIBLY_COMPATIBLE = "POSSIBLY_COMPATIBLE"
    CONFLICTING = "CONFLICTING"
    NOT_APPLICABLE_TO_RELATION_TYPE = "NOT_APPLICABLE_TO_RELATION_TYPE"


class RetrievalConfig(StrictModel):
    schema_version: Literal["freca.legal-retrieval-config.v1"] = "freca.legal-retrieval-config.v1"
    unit_top_k: int = Field(default=30, ge=1)
    heading_top_k: int = Field(default=30, ge=1)
    definition_top_k: int = Field(default=30, ge=1)
    fused_candidate_cap: int = Field(default=60, ge=1)
    rrf_k: int = Field(default=60, ge=1)
    exact_min_tokens: int = Field(default=4, ge=2)
    exact_min_non_stopwords: int = Field(default=2, ge=1)
    channel_weights: dict[str, float] = Field(
        default_factory=lambda: {
            "EXACT": 3.0,
            "UNIT_BM25": 1.0,
            "HEADING_BM25": 1.0,
            "DEFINITION_EXPANSION": 0.8,
            "REFERENCE_EXPANSION": 1.0,
        }
    )
    embedding_enabled: bool = False


class QueryRecord(StrictModel):
    query_id: SafeId
    cp_id: str
    channel: str
    query_text: str
    source_ids: list[SafeId]
    query_sha256: Sha256


class QueryBundle(StrictModel):
    bundle_id: SafeId
    cp_id: str
    queries: list[QueryRecord]
    bundle_sha256: Sha256


class RetrievalSignal(StrictModel):
    channel: str
    query_id: SafeId
    rank: int | None = None
    raw_score: float | None = None
    normalized_score: float | None = None


class CandidateDecision(StrictModel):
    relation: Literal[
        "PRIMARY_NORM",
        "APPLICABILITY",
        "EXCEPTION_OR_DEEMING",
        "DEFINITION",
        "CROSS_REFERENCE_DEPENDENCY",
        "STRUCTURAL_CONTEXT",
        "CP_OPERATIONALIZATION_SUPPORT",
        "IRRELEVANT",
        "UNRESOLVED",
    ]
    selected: bool
    reason_code: str
    criterion_span_ids: list[SafeId] = Field(default_factory=list)
    policy_span_ids: list[SafeId] = Field(default_factory=list)
    decided_by: Literal["RULE", "MODEL", "VALIDATOR"]


class PolicyCandidate(StrictModel):
    candidate_id: SafeId
    cp_id: str
    policy_unit_id: SafeId
    retrieval_signals: list[RetrievalSignal]
    rrf_score: float = Field(ge=0.0)
    scope_compatibility: ScopeCompatibility
    inherited_context_unit_ids: list[SafeId] = Field(default_factory=list)
    layer1_issue_ids: list[SafeId] = Field(default_factory=list)
    decision: CandidateDecision | None = None


class CandidateLedger(StrictModel):
    ledger_id: SafeId
    cp_id: str
    query_bundle: QueryBundle
    candidates: list[PolicyCandidate]
    config_sha256: Sha256
    ledger_sha256: Sha256


@dataclass(slots=True)
class PreparedPolicyRetrieval:
    policy: PolicyIndex
    config: RetrievalConfig
    units: list[PolicyUnit]
    by_id: dict[str, PolicyUnit]
    unit_index: BM25Index
    heading_index: BM25Index
    unit_tokens: dict[str, list[str]]
    exact_ngram_index: dict[tuple[str, ...], set[str]]


def prepare_policy_retrieval(
    policy: PolicyIndex,
    *,
    config: RetrievalConfig | None = None,
) -> PreparedPolicyRetrieval:
    config = config or RetrievalConfig()
    if config.embedding_enabled:
        raise ValueError(
            "embedding channel is enabled but no pinned embedding adapter was supplied"
        )
    units = [unit for unit in policy.units if _retrievable(unit)]
    by_id = {unit.unit_id: unit for unit in policy.units}
    retrieval_text = {unit.unit_id: _retrieval_text(unit, by_id) for unit in units}
    heading_text = {unit.unit_id: unit.title or "" for unit in units if unit.title}
    unit_tokens = {
        unit.unit_id: tokenize(
            unit.normalized_text,
            drop_stopwords=False,
            min_length=1,
        )
        for unit in units
    }
    exact_ngram_index: dict[tuple[str, ...], set[str]] = {}
    for unit_id, tokens in unit_tokens.items():
        for index in range(len(tokens) - config.exact_min_tokens + 1):
            ngram = tuple(tokens[index : index + config.exact_min_tokens])
            exact_ngram_index.setdefault(ngram, set()).add(unit_id)
    return PreparedPolicyRetrieval(
        policy=policy,
        config=config,
        units=units,
        by_id=by_id,
        unit_index=BM25Index(retrieval_text),
        heading_index=BM25Index(heading_text),
        unit_tokens=unit_tokens,
        exact_ngram_index=exact_ngram_index,
    )


def retrieve_policy_candidates(
    cp: OfficialCP,
    policy: PolicyIndex,
    *,
    config: RetrievalConfig | None = None,
    prepared: PreparedPolicyRetrieval | None = None,
) -> CandidateLedger:
    prepared = prepared or prepare_policy_retrieval(policy, config=config)
    if prepared.policy.index_sha256 != policy.index_sha256:
        raise ValueError("prepared retrieval belongs to a different PolicyIndex")
    config = prepared.config
    units = prepared.units
    by_id = prepared.by_id
    queries = [_query(cp, "Q0_DIRECT", cp.retrieval_context_text, cp.source_cells)]

    definition_terms = [
        definition
        for definition in policy.definitions
        if definition.defined_term_normalized in cp.retrieval_context_text.casefold()
    ]
    if definition_terms:
        expansion = "\n".join(
            f"{item.defined_term_raw}: {item.definition_text}" for item in definition_terms
        )
        queries.append(
            _query(
                cp,
                "Q1_DEFINITION",
                f"{cp.retrieval_context_text}\n{expansion}",
                [item.unit_id for item in definition_terms],
            )
        )
    query_bundle = _query_bundle(cp.cp_id, queries)

    channels: dict[str, list[tuple[str, float, str]]] = {}
    exact_hits = _exact_hits(
        cp.criterion_text_normalized,
        units,
        config,
        unit_tokens=prepared.unit_tokens,
        ngram_index=prepared.exact_ngram_index,
    )
    channels["EXACT"] = [
        (unit_id, float(token_count), queries[0].query_id) for unit_id, token_count in exact_hits
    ]
    channels["UNIT_BM25"] = [
        (hit.doc_id, hit.score, queries[0].query_id)
        for hit in prepared.unit_index.score(queries[0].query_text)
        if hit.score > 0
    ][: config.unit_top_k]
    channels["HEADING_BM25"] = [
        (hit.doc_id, hit.score, queries[0].query_id)
        for hit in prepared.heading_index.score(queries[0].query_text)
        if hit.score > 0
    ][: config.heading_top_k]
    if len(queries) > 1:
        channels["DEFINITION_EXPANSION"] = [
            (hit.doc_id, hit.score, queries[1].query_id)
            for hit in prepared.unit_index.score(queries[1].query_text)
            if hit.score > 0
        ][: config.definition_top_k]

    reference_targets = _reference_expansion_targets(channels, policy)
    if reference_targets:
        reference_query = _query(
            cp,
            "Q2_REFERENCE",
            cp.retrieval_context_text,
            reference_targets,
        )
        queries.append(reference_query)
        query_bundle = _query_bundle(cp.cp_id, queries)
        channels["REFERENCE_EXPANSION"] = [
            (unit_id, 1.0, reference_query.query_id) for unit_id in reference_targets
        ]

    signals_by_unit: dict[str, list[RetrievalSignal]] = {}
    totals: dict[str, float] = {}
    for channel, hits in channels.items():
        weight = config.channel_weights[channel]
        for rank, (unit_id, raw_score, query_id) in enumerate(hits, start=1):
            normalized = weight / (config.rrf_k + rank)
            totals[unit_id] = totals.get(unit_id, 0.0) + normalized
            signals_by_unit.setdefault(unit_id, []).append(
                RetrievalSignal(
                    channel=channel,
                    query_id=query_id,
                    rank=rank,
                    raw_score=raw_score,
                    normalized_score=normalized,
                )
            )
    exact_ids = {unit_id for unit_id, _score in exact_hits}
    regular = sorted(totals, key=lambda unit_id: (-totals[unit_id], unit_id))
    retained = set(regular[: config.fused_candidate_cap]) | exact_ids
    candidates = [
        _candidate(cp, by_id[unit_id], signals_by_unit[unit_id], totals[unit_id])
        for unit_id in regular
        if unit_id in retained
    ]
    config_hash = sha256_digest(config)
    payload = {
        "cp_id": cp.cp_id,
        "query_bundle": query_bundle,
        "candidates": candidates,
        "config_sha256": config_hash,
    }
    ledger_hash = sha256_digest(payload)
    return CandidateLedger(
        ledger_id=f"ledger-{cp.cp_id.lower()}-{ledger_hash.split(':', 1)[1][:12]}",
        ledger_sha256=ledger_hash,
        **payload,
    )


def retrieve_all_policy_candidates(
    cps: list[OfficialCP],
    policy: PolicyIndex,
    *,
    config: RetrievalConfig | None = None,
) -> list[CandidateLedger]:
    prepared = prepare_policy_retrieval(policy, config=config)
    return [retrieve_policy_candidates(cp, policy, prepared=prepared) for cp in cps]


def _query(cp: OfficialCP, channel: str, text: str, sources) -> QueryRecord:
    source_ids = [item.cell_id if hasattr(item, "cell_id") else item for item in sources]
    payload = {
        "cp_id": cp.cp_id,
        "channel": channel,
        "query_text": text,
        "source_ids": source_ids,
    }
    digest = sha256_digest(payload)
    return QueryRecord(
        query_id=f"query-{digest.split(':', 1)[1][:24]}",
        query_sha256=digest,
        **payload,
    )


def _query_bundle(cp_id: str, queries: list[QueryRecord]) -> QueryBundle:
    payload = {"cp_id": cp_id, "queries": queries}
    digest = sha256_digest(payload)
    return QueryBundle(
        bundle_id=f"queries-{cp_id.lower()}-{digest.split(':', 1)[1][:12]}",
        bundle_sha256=digest,
        **payload,
    )


def _retrievable(unit: PolicyUnit) -> bool:
    return unit.unit_type not in {
        PolicyUnitType.CHAPTER,
        PolicyUnitType.PART,
        PolicyUnitType.DIVISION,
        PolicyUnitType.SUBDIVISION,
    }


def _retrieval_text(unit: PolicyUnit, by_id: dict[str, PolicyUnit]) -> str:
    context = [
        by_id[item].own_raw_text
        for item in unit.context_unit_ids
        if item in by_id and by_id[item].unit_type is PolicyUnitType.SECTION
    ]
    return "\n".join([*(item for item in context if item), unit.own_raw_text])


def _exact_hits(
    criterion: str,
    units: list[PolicyUnit],
    config: RetrievalConfig,
    *,
    unit_tokens: dict[str, list[str]] | None = None,
    ngram_index: dict[tuple[str, ...], set[str]] | None = None,
) -> list[tuple[str, int]]:
    query_tokens = tokenize(criterion, drop_stopwords=False, min_length=1)
    hits: list[tuple[str, int]] = []
    if ngram_index is None:
        candidate_ids = {unit.unit_id for unit in units}
    else:
        candidate_ids: set[str] = set()
        for index in range(len(query_tokens) - config.exact_min_tokens + 1):
            ngram = tuple(query_tokens[index : index + config.exact_min_tokens])
            if sum(token not in STOPWORDS for token in ngram) >= config.exact_min_non_stopwords:
                candidate_ids.update(ngram_index.get(ngram, set()))
    for unit in units:
        if unit.unit_id not in candidate_ids:
            continue
        tokens = (
            unit_tokens[unit.unit_id]
            if unit_tokens is not None
            else tokenize(unit.normalized_text, drop_stopwords=False, min_length=1)
        )
        best = _longest_eligible_contiguous_match(query_tokens, tokens, config)
        if best:
            hits.append((unit.unit_id, best))
    return sorted(hits, key=lambda item: (-item[1], item[0]))


def _longest_eligible_contiguous_match(
    query: list[str],
    unit: list[str],
    config: RetrievalConfig,
) -> int:
    previous = [0] * (len(unit) + 1)
    best = 0
    non_stop_prefix = [0]
    for token in query:
        non_stop_prefix.append(non_stop_prefix[-1] + int(token not in STOPWORDS))
    for query_index, query_token in enumerate(query, start=1):
        current = [0] * (len(unit) + 1)
        for unit_index, unit_token in enumerate(unit, start=1):
            if query_token != unit_token:
                continue
            length = previous[unit_index - 1] + 1
            current[unit_index] = length
            if length < config.exact_min_tokens or length <= best:
                continue
            start = query_index - length
            non_stop_count = non_stop_prefix[query_index] - non_stop_prefix[start]
            if non_stop_count >= config.exact_min_non_stopwords:
                best = length
        previous = current
    return best


def _reference_expansion_targets(
    channels: dict[str, list[tuple[str, float, str]]],
    policy: PolicyIndex,
) -> list[str]:
    seeds = {
        unit_id
        for channel in ("EXACT", "UNIT_BM25", "HEADING_BM25")
        for unit_id, _score, _query in channels.get(channel, [])[:10]
    }
    targets = {
        target.target_unit_id
        for mention in policy.reference_mentions
        if mention.source_unit_id in seeds
        for target in mention.targets
        if target.resolution_status == "RESOLVED" and target.target_unit_id
    }
    return sorted(targets)


def _candidate(
    cp: OfficialCP,
    unit: PolicyUnit,
    signals: list[RetrievalSignal],
    score: float,
) -> PolicyCandidate:
    channels = {signal.channel for signal in signals}
    if "EXACT" in channels and unit.normative:
        decision = CandidateDecision(
            relation="PRIMARY_NORM",
            selected=True,
            reason_code="DYNAMIC_EXACT_CRITERION_OCCURRENCE",
            criterion_span_ids=[cp.source_cells[2].cell_id],
            policy_span_ids=[unit.unit_id],
            decided_by="RULE",
        )
    elif unit.unit_type is PolicyUnitType.DEFINITION_ITEM:
        decision = CandidateDecision(
            relation="DEFINITION",
            selected=True,
            reason_code="OFFICIAL_DEFINED_TERM_EXPANSION",
            criterion_span_ids=[cp.source_cells[2].cell_id],
            policy_span_ids=[unit.unit_id],
            decided_by="RULE",
        )
    elif "REFERENCE_EXPANSION" in channels:
        decision = CandidateDecision(
            relation="CROSS_REFERENCE_DEPENDENCY",
            selected=True,
            reason_code="RESOLVED_INTERNAL_REFERENCE",
            criterion_span_ids=[cp.source_cells[2].cell_id],
            policy_span_ids=[unit.unit_id],
            decided_by="RULE",
        )
    else:
        decision = CandidateDecision(
            relation="UNRESOLVED",
            selected=False,
            reason_code="RELATION_CLASSIFIER_REQUIRED",
            criterion_span_ids=[cp.source_cells[2].cell_id],
            policy_span_ids=[unit.unit_id],
            decided_by="RULE",
        )
    digest = sha256_digest({"cp_id": cp.cp_id, "unit_id": unit.unit_id})
    return PolicyCandidate(
        candidate_id=f"candidate-{digest.split(':', 1)[1][:24]}",
        cp_id=cp.cp_id,
        policy_unit_id=unit.unit_id,
        retrieval_signals=signals,
        rrf_score=score,
        scope_compatibility=ScopeCompatibility.POSSIBLY_COMPATIBLE,
        inherited_context_unit_ids=unit.context_unit_ids,
        decision=decision,
    )
