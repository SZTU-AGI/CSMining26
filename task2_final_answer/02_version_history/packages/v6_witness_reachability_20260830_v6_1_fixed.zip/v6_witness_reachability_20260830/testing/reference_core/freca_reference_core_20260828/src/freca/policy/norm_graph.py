"""Norm graph, subject closure, and the scope/subject gate.

Why this module exists
---------------------
Measured on 2026-07-31: with BM25 over all 184 sections, 8 of the 41 checking
points anchor to a *structurally incompatible* obligation — CP1/CP2 land on
``2-4`` (prohibited export), CP6/CP29 on Chapter 3 (accredited properties),
and CP20/CP22/CP26/CP33 on ``9-16`` (approval of pest tolerance levels).

The reason is that the instrument contains three parallel obligation regimes
worded almost identically:

===========================  =====================================
Chapter 3                    ``MANAGER`` of an accredited property
Chapter 4                    ``OCCUPIER`` of a registered establishment
Chapters 9 / 11              ``AUTHORISED_OFFICER`` / ``EXPORTER``
===========================  =====================================

Only Chapter 4 (plus general provisions reaching it) is in scope for this task.
The distinguishing token is a single subject phrase inside subsection ``(1)``.
Concretely, ``11-5`` / ``11-7`` / ``11-8`` all say "retain each record ... for at
least 2 years", and for CP22 BM25 scores all three **identically** (11/11/11);
for CP38 the ranking is ``11-8`` / ``11-9`` / ``11-7`` at 15/15/14. No embedding
or reranker can separate them, because the difference is not similarity — it is
the addressed subject. It has to be a deterministic gate.

The trap on the other side
--------------------------
A naive subject filter over isolated section text *over-prunes*. The correct
anchor for CP23 and CP40 is ``11-2 General requirements for records`` (verbatim
"in English; dated; accurate, legible and able to be audited"), yet ``11-2``
never mentions "registered establishment" — it says "required to be retained
under this Part". Filtering on isolated text deletes the right answer.

So the gate must run over a graph, not over sections:

* ``PART_SCOPE``  — sections sharing a Part, which is what "under this Part"
  denotes;
* ``APPLIES_VIA`` — a subject-less general provision inherits the union of the
  subjects of the operative provisions it serves (``11-2 --APPLIES_VIA--> 11-7``);
* ``UNRESOLVED``  — never pruned. Unknown is not the same as incompatible.

This mirrors the observation in *法律信息抽取与符号推理* (SARA) that downstream
symbolic reasoning quality is bounded by information-extraction quality, and the
EU Acquis obligation-extraction work, which likewise models the addressed
obligor as a first-class slot rather than as free text.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from freca.domain.policy_enums import (
    ActorRole,
    NormEdge,
    NormScope,
    PolicyIssueCode,
    SubjectResolution,
)
from freca.policy.sectionize import NormSection

# --------------------------------------------------------------------------
# Scope is derived from the instrument's own chapter titles, never hardcoded
# as a list of section numbers. Changing the regulation changes the mapping
# automatically, and a reviewer can check the derivation against the contents
# page.
# --------------------------------------------------------------------------
_CHAPTER_TITLE_TO_SCOPE: tuple[tuple[str, NormScope], ...] = (
    ("registered establishment", NormScope.REGISTERED_ESTABLISHMENT),
    ("accredited propert", NormScope.ACCREDITED_PROPERTY),
    ("export permit", NormScope.EXPORT_PERMIT),
    ("exporting goods", NormScope.GOODS),
    ("powers and officials", NormScope.OFFICIALS),
    ("compliance and enforcement", NormScope.OFFICIALS),
    ("preliminary", NormScope.GENERAL),
    ("miscellaneous", NormScope.GENERAL),
    ("other matters relating to export", NormScope.GENERAL),
    ("application, saving and transitional", NormScope.GENERAL),
)

# Subject cues. Order matters: the more specific phrase is tested first so that
# "occupier of an establishment that is registered" is not captured by a bare
# "establishment" pattern.
_SUBJECT_CUES: tuple[tuple[ActorRole, re.Pattern[str]], ...] = (
    (
        ActorRole.OCCUPIER,
        re.compile(
            r"occupier of (?:an?|the) (?:establishment that is registered|registered establishment)",
        ),
    ),
    (ActorRole.OCCUPIER, re.compile(r"\boccupier\b")),
    (
        ActorRole.MANAGER,
        re.compile(r"manager of (?:an?|the) accredited propert"),
    ),
    (ActorRole.AUTHORISED_OFFICER, re.compile(r"\bauthorised officer\b|\bassessor\b")),
    (ActorRole.EXPORTER, re.compile(r"\bexporter\b")),
    (ActorRole.REGULATOR, re.compile(r"\bthe Secretary\b")),
)

_GENERAL_REFERENCE = re.compile(
    r"under this Part|required to be (?:retained|made|kept) under this Part|"
    r"referred to in this Part",
    re.IGNORECASE,
)
_SECTION_REFERENCE = re.compile(r"\bsections?\s+(\d{1,2}-\d{1,3}[A-Z]?)")
_EXCEPTION_CUE = re.compile(r"does not apply|unless|except|is taken to have complied")


@dataclass(slots=True)
class NormNode:
    """A norm section enriched with derived scope and subject information."""

    section: NormSection
    scope: NormScope
    direct_subjects: set[ActorRole] = field(default_factory=set)
    inherited_subjects: set[ActorRole] = field(default_factory=set)
    resolution: SubjectResolution = SubjectResolution.UNRESOLVED
    subject_path: list[str] = field(default_factory=list)

    @property
    def section_id(self) -> str:
        return self.section.section_id

    @property
    def subjects(self) -> set[ActorRole]:
        return self.direct_subjects or self.inherited_subjects


@dataclass(slots=True)
class NormEdgeRecord:
    source: str
    target: str
    edge: NormEdge
    evidence: str


@dataclass(slots=True)
class GateVerdict:
    """Result of applying the scope/subject gate to a single norm section."""

    section_id: str
    admitted: bool
    issue: PolicyIssueCode | None
    reason: str
    resolution: SubjectResolution
    subjects: list[str]
    scope: str

    def to_dict(self) -> dict[str, object]:
        return {
            "section_id": self.section_id,
            "admitted": self.admitted,
            "issue": self.issue.value if self.issue else None,
            "reason": self.reason,
            "resolution": self.resolution.value,
            "subjects": self.subjects,
            "scope": self.scope,
        }


def derive_scope(section: NormSection) -> NormScope:
    """Map a section to a regulated object using its own chapter title."""

    title = (section.chapter_title or "").lower()
    for needle, scope in _CHAPTER_TITLE_TO_SCOPE:
        if needle in title:
            return scope
    return NormScope.UNKNOWN


def subjects_named_in(text: str) -> set[ActorRole]:
    """Return the actor roles named anywhere in ``text``.

    Shared with the pack builder so that section-level and unit-level subject
    detection cannot drift apart: both read the same cue table. The caller decides
    what a hit *means* — :func:`detect_direct_subjects` treats it as the section's
    duty-holder, while the pack builder uses it to test whether one paragraph of a
    multi-actor section is governed by a different role than another.

    The ``REGULATOR`` demotion is applied here for the same reason as in
    :func:`detect_direct_subjects`: a mention of the Secretary inside a duty owed
    *to* the Secretary is not the duty-holder.
    """

    found: set[ActorRole] = set()
    for role, pattern in _SUBJECT_CUES:
        if pattern.search(text):
            found.add(role)
    if found - {ActorRole.REGULATOR}:
        found.discard(ActorRole.REGULATOR)
    return found


def detect_direct_subjects(section: NormSection) -> set[ActorRole]:
    """Find actor roles named in the section's own text.

    Only the operative opening of the section is inspected. Later subsections
    frequently mention other actors incidentally ("must give the document to
    another person"), and letting those vote produces ``MIXED`` everywhere.
    """

    head = (section.title + "\n" + section.text)[:1800]
    return subjects_named_in(head)


class NormGraph:
    """Norm sections plus the derived edges needed for subject closure."""

    def __init__(self, sections: dict[str, NormSection]):
        self.nodes: dict[str, NormNode] = {}
        self.edges: list[NormEdgeRecord] = []
        for section_id, section in sections.items():
            self.nodes[section_id] = NormNode(
                section=section,
                scope=derive_scope(section),
                direct_subjects=detect_direct_subjects(section),
            )
        self._build_edges()
        self._close_subjects()

    # -- construction ------------------------------------------------------
    def _build_edges(self) -> None:
        by_part: dict[str, list[str]] = {}
        for section_id, node in self.nodes.items():
            key = node.section.part_key
            if key is not None:
                by_part.setdefault(key, []).append(section_id)

        for key, members in by_part.items():
            for source in members:
                for target in members:
                    if source != target:
                        self.edges.append(
                            NormEdgeRecord(source, target, NormEdge.PART_SCOPE, key)
                        )

        for section_id, node in self.nodes.items():
            text = node.section.text
            for match in _SECTION_REFERENCE.finditer(text):
                target = match.group(1)
                if target in self.nodes and target != section_id:
                    self.edges.append(
                        NormEdgeRecord(
                            section_id, target, NormEdge.REFERS_TO, match.group(0)
                        )
                    )
            if _EXCEPTION_CUE.search(text):
                self.edges.append(
                    NormEdgeRecord(section_id, section_id, NormEdge.EXCEPTS, "exception cue")
                )

    def _close_subjects(self) -> None:
        """Propagate subjects into subject-less general provisions.

        A section with no detected subject that explicitly scopes itself to "this
        Part" inherits the union of the directly-resolved subjects of the other
        sections in the same Part. The path is recorded so a reviewer can see
        *why* the section was admitted.
        """

        part_direct: dict[str, set[ActorRole]] = {}
        part_sources: dict[str, list[str]] = {}
        for node in self.nodes.values():
            key = node.section.part_key
            if key is None or not node.direct_subjects:
                continue
            part_direct.setdefault(key, set()).update(node.direct_subjects)
            part_sources.setdefault(key, []).append(node.section_id)

        for node in self.nodes.values():
            if node.direct_subjects:
                node.resolution = SubjectResolution.DIRECT
                node.subject_path = [node.section_id]
                continue
            key = node.section.part_key
            if key is None or not _GENERAL_REFERENCE.search(node.section.text):
                node.resolution = SubjectResolution.UNRESOLVED
                continue
            inherited = part_direct.get(key, set())
            if not inherited:
                node.resolution = SubjectResolution.UNRESOLVED
                continue
            node.inherited_subjects = set(inherited)
            node.resolution = SubjectResolution.INHERITED
            node.subject_path = [node.section_id, *sorted(part_sources.get(key, []))]
            for target in part_sources.get(key, []):
                self.edges.append(
                    NormEdgeRecord(
                        node.section_id, target, NormEdge.APPLIES_VIA, "under this Part"
                    )
                )

    # -- gate --------------------------------------------------------------
    def gate(
        self,
        target_scope: NormScope = NormScope.REGISTERED_ESTABLISHMENT,
        target_role: ActorRole = ActorRole.OCCUPIER,
    ) -> dict[str, GateVerdict]:
        """Admit only norms compatible with the audited subject.

        Rules, in order:

        1. Scope incompatible with the audit target and not ``GENERAL`` →
           reject with ``POLICY_SCOPE_MISMATCH``.
        2. Subjects resolved and the target role absent → reject with
           ``POLICY_SUBJECT_MISMATCH`` (hard gate).
        3. Subjects unresolved → **admit** and flag
           ``POLICY_SUBJECT_UNRESOLVED``. Unknown is not incompatible; pruning
           here is what deleted ``11-2`` in the first draft.
        """

        verdicts: dict[str, GateVerdict] = {}
        for section_id, node in self.nodes.items():
            subjects = sorted(role.value for role in node.subjects)
            if node.scope not in (target_scope, NormScope.GENERAL):
                verdicts[section_id] = GateVerdict(
                    section_id,
                    False,
                    PolicyIssueCode.POLICY_SCOPE_MISMATCH,
                    f"scope {node.scope.value} governs a different regulated object",
                    node.resolution,
                    subjects,
                    node.scope.value,
                )
                continue
            if node.subjects and target_role not in node.subjects:
                verdicts[section_id] = GateVerdict(
                    section_id,
                    False,
                    PolicyIssueCode.POLICY_SUBJECT_MISMATCH,
                    f"addressed to {subjects}, not {target_role.value}",
                    node.resolution,
                    subjects,
                    node.scope.value,
                )
                continue
            issue = (
                PolicyIssueCode.POLICY_SUBJECT_UNRESOLVED
                if node.resolution is SubjectResolution.UNRESOLVED
                else None
            )
            reason = (
                "subject unresolved; admitted for review rather than pruned"
                if issue
                else f"{node.resolution.value.lower()} subject includes {target_role.value}"
            )
            verdicts[section_id] = GateVerdict(
                section_id, True, issue, reason, node.resolution, subjects, node.scope.value
            )
        return verdicts

    def admitted_ids(self, **kwargs: object) -> list[str]:
        verdicts = self.gate(**kwargs)  # type: ignore[arg-type]
        return sorted(sid for sid, verdict in verdicts.items() if verdict.admitted)

    def to_dict(self) -> dict[str, object]:
        return {
            "nodes": [
                {
                    **node.section.to_dict(),
                    "scope": node.scope.value,
                    "direct_subjects": sorted(r.value for r in node.direct_subjects),
                    "inherited_subjects": sorted(r.value for r in node.inherited_subjects),
                    "resolution": node.resolution.value,
                    "subject_path": node.subject_path,
                }
                for node in self.nodes.values()
            ],
            "edges": [
                {
                    "source": edge.source,
                    "target": edge.target,
                    "edge": edge.edge.value,
                    "evidence": edge.evidence,
                }
                for edge in self.edges
                if edge.edge is not NormEdge.PART_SCOPE
            ],
            "part_scope_edge_count": sum(
                1 for edge in self.edges if edge.edge is NormEdge.PART_SCOPE
            ),
        }
