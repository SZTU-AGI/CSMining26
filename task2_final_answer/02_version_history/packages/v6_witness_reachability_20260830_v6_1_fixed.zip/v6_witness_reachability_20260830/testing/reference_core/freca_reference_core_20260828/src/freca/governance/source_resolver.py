"""Read-only access to sources already admitted by SourceGuard."""

from pathlib import Path

from freca.governance.source_guard import SourceCatalog, SourceGuardError, SourceRef, _file_sha256


class CatalogSourceResolver:
    def __init__(self, catalog: SourceCatalog) -> None:
        sources = [catalog.rules_pdf, catalog.cp_definitions, *catalog.evidence]
        sources.extend(item for item in (catalog.task_governance, catalog.output_schema) if item)
        self._by_id = {item.source_id: item for item in sources}

    def source(self, source_id: str, *, consumer: str) -> SourceRef:
        try:
            source = self._by_id[source_id]
        except KeyError as error:
            raise SourceGuardError(f"unregistered source ID: {source_id}") from error
        if consumer not in source.allowed_consumers:
            raise SourceGuardError(f"consumer {consumer} cannot access source role {source.role}")
        return source

    def read_bytes(self, source_id: str, *, consumer: str) -> bytes:
        source = self.source(source_id, consumer=consumer)
        path = Path(source.canonical_path)
        if not path.is_file() or _file_sha256(path) != source.sha256:
            raise SourceGuardError(f"source changed after catalog admission: {source_id}")
        return path.read_bytes()

    def readonly_path(self, source_id: str, *, consumer: str) -> Path:
        source = self.source(source_id, consumer=consumer)
        path = Path(source.canonical_path)
        if not path.is_file() or _file_sha256(path) != source.sha256:
            raise SourceGuardError(f"source changed after catalog admission: {source_id}")
        return path
