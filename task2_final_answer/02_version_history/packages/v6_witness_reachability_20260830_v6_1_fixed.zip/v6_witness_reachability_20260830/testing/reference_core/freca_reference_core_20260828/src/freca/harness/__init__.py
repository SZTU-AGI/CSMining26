"""Workflow-runtime infrastructure for FRECA."""

from freca.harness.artifact_store import FileArtifactStore

__all__ = ["FileArtifactStore"]

