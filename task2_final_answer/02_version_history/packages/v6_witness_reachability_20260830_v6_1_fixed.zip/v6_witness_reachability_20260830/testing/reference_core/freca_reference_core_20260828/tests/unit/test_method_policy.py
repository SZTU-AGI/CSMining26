from __future__ import annotations

import unittest

from pydantic import ValidationError

from freca.governance.method_policy import (
    ALL_PROHIBITED_EFFECTS,
    MethodPolicyClause,
    default_method_policy_bundle,
)


class MethodPolicyTests(unittest.TestCase):
    def test_default_bundle_is_deterministic_and_non_normative(self) -> None:
        first = default_method_policy_bundle()
        second = default_method_policy_bundle()
        self.assertEqual(first.bundle_sha256, second.bundle_sha256)
        self.assertEqual(len(first.clauses), 9)
        self.assertTrue(
            all(not reference.normative_authority_for_freca for reference in first.references)
        )
        self.assertTrue(
            all(
                set(clause.prohibited_effects) == ALL_PROHIBITED_EFFECTS for clause in first.clauses
            )
        )

    def test_cp_specific_clause_and_incomplete_boundary_are_rejected(self) -> None:
        common = {
            "policy_id": "bad-policy",
            "method_family": "RELEVANCE",
            "permitted_consumers": ["LAYER4"],
            "method_reference_ids": ["asa500-2022"],
        }
        with self.assertRaises(ValidationError):
            MethodPolicyClause(
                cp_agnostic_instruction="For CP6 choose N/A.",
                prohibited_effects=sorted(ALL_PROHIBITED_EFFECTS),
                **common,
            )
        with self.assertRaises(ValidationError):
            MethodPolicyClause(
                cp_agnostic_instruction="Check proposition-relative relevance.",
                prohibited_effects=["CHOOSE_FINAL_LABEL"],
                **common,
            )


if __name__ == "__main__":
    unittest.main()
