"""Run-mode gate: decide whether a run's numbers are allowed to be believed.

Why this module exists
----------------------
A measured failure, not a hypothetical one. A three-case smoke run produced 120
decisions of which **120 were synthetic and 98% were labelled "1"**, every gate
reported PASS, and the submission workbook was perfectly well-formed: 101x42, no
blank cell, header exact, every value in ``{1, 0, N/A}``. Every validator in the
codebase passed, because every validator in the codebase was checking *structure*.

The lesson is that structural validity and substantive validity are independent,
and only the first one was being enforced. A pipeline that answers "1" to
everything satisfies the format perfectly. So this module adds the second kind of
check and gives it teeth: in production or evaluation mode a run that did not
actually reason is marked ``RUN_INVALID`` and its export is blocked, rather than
merely warned about. Warnings were the previous design and they are not enough —
a warning printed above a valid-looking workbook gets scrolled past.

What is *not* being banned
--------------------------
The offline fake backend stays, and dev mode stays permissive. Being able to
exercise the whole chain with no network and no API key is what makes the package
runnable on a server before a key is configured, and it is how the two structural
defects above were found in the first place. The rule is narrower: a synthetic run
may not be *exported or scored*, because that is where a plumbing artefact starts
being read as a result.

Denominators
------------
Three counts are reported together and none of them is optional:

``decision_coverage``
    Cells where the pipeline actually reached a verdict, over all cells it was
    asked about. This is the honest denominator for accuracy. A run that answers
    40% of cells and gets them all right is not a 100% system.

``scored_cells``
    Cells eligible to count toward model accuracy — the cells that carry a real
    verdict. Blocked cells appear in the workbook as the placeholder ``0`` that
    the submission format demands, and they are counted and reported, but they
    are **not** part of this number: that ``0`` is a formatting obligation, not a
    prediction, and letting it score would credit the model with the majority
    class every time the pipeline fell over.

``synthetic_rate``
    Share of *decided* cells reached with no real model reading. Blocked cells are
    excluded from both sides of this ratio — whether a cell that produced no
    verdict was going to be synthetic is not a meaningful question.

Reporting accuracy without coverage is the specific way this project could fool
itself, so :class:`RunHealth` refuses to hand out one without the other.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Iterable, Mapping

__all__ = [
    "RunMode",
    "RunStatus",
    "RunHealth",
    "assess_run",
    "MAJORITY_CLASS_THRESHOLD",
]

#: Above this share of a single predicted label, the run is treated as a
#: near-constant predictor. 0.95 is not a tuned value: it is well above the most
#: skewed plausible true distribution and well below the 0.98 that the degenerate
#: fallback actually produced.
MAJORITY_CLASS_THRESHOLD = 0.95

#: The three labels the grader accepts. A run that never predicts one of them
#: loses every cell whose true label it is.
REQUIRED_LABELS = ("1", "0", "N/A")


class RunMode(str, Enum):
    """How much the run's output is allowed to be trusted.

    ``DEV`` exists so the chain can be exercised offline; it permits synthetic
    decisions and still reports every defect, it simply does not block. The other
    two modes are for runs whose numbers will be read by a human as a measurement
    of the system, and there a synthetic decision is disqualifying.
    """

    DEV = "dev"
    EVALUATION = "evaluation"
    PRODUCTION = "production"

    @property
    def is_strict(self) -> bool:
        return self in {RunMode.EVALUATION, RunMode.PRODUCTION}


class RunStatus(str, Enum):
    RUN_VALID = "RUN_VALID"
    RUN_DEGRADED = "RUN_DEGRADED"
    RUN_INVALID = "RUN_INVALID"


@dataclass(slots=True)
class RunHealth:
    """The verdict on the run itself, as distinct from verdicts on the farms."""

    mode: RunMode
    status: RunStatus
    export_blocked: bool

    n_cells_attempted: int
    n_decided: int
    n_synthetic: int
    n_blocked_filled: int
    label_counts: dict[str, int] = field(default_factory=dict)

    #: Conditions that force RUN_INVALID in a strict mode.
    blocking_findings: list[str] = field(default_factory=list)
    #: Conditions that are wrong but do not by themselves invalidate the run.
    warnings: list[str] = field(default_factory=list)

    @property
    def decision_coverage(self) -> float:
        if not self.n_cells_attempted:
            return 0.0
        return self.n_decided / self.n_cells_attempted

    @property
    def synthetic_rate(self) -> float:
        if not self.n_decided:
            return 0.0
        return self.n_synthetic / self.n_decided

    @property
    def scored_cells(self) -> int:
        """Cells that may count toward model accuracy.

        Equal to the number of cells that reached a verdict. Blocked cells never
        produced one; the placeholder ``0`` written into the workbook for them
        exists to satisfy "no blank cell" and asserting nothing is the most it was
        ever meant to do, so it is excluded here.
        """

        return self.n_decided

    @property
    def unreachable_labels(self) -> list[str]:
        return [label for label in REQUIRED_LABELS if not self.label_counts.get(label)]

    def accuracy_denominator(self) -> int:
        """The only denominator this project should divide by.

        Named as a method rather than exposed as a bare number so that a caller
        computing accuracy has to go through something whose docstring says what
        it excludes.
        """

        return self.scored_cells

    def to_dict(self) -> dict[str, Any]:
        return {
            "mode": self.mode.value,
            "status": self.status.value,
            "export_blocked": self.export_blocked,
            "n_cells_attempted": self.n_cells_attempted,
            "n_decided": self.n_decided,
            "n_synthetic": self.n_synthetic,
            "n_blocked_filled": self.n_blocked_filled,
            "scored_cells": self.scored_cells,
            "decision_coverage": round(self.decision_coverage, 4),
            "synthetic_rate": round(self.synthetic_rate, 4),
            "label_counts": dict(self.label_counts),
            "unreachable_labels": self.unreachable_labels,
            "blocking_findings": list(self.blocking_findings),
            "warnings": list(self.warnings),
        }

    def summary_lines(self) -> list[str]:
        """Human-readable report. Coverage is printed next to every count."""

        lines = [
            f"run mode       : {self.mode.value}",
            f"run status     : {self.status.value}"
            + ("  [EXPORT BLOCKED]" if self.export_blocked else ""),
            f"decided        : {self.n_decided}/{self.n_cells_attempted} cells "
            f"(coverage {self.decision_coverage:.1%})",
            f"scored cells   : {self.scored_cells} "
            f"({self.n_blocked_filled} blocked cell(s) filled with a placeholder and "
            "excluded from accuracy)",
            f"synthetic      : {self.n_synthetic} ({self.synthetic_rate:.1%} of decisions)",
        ]
        for finding in self.blocking_findings:
            lines.append(f"  ✗ BLOCKING: {finding}")
        for warning in self.warnings:
            lines.append(f"  → WARNING: {warning}")
        return lines


def assess_run(
    *,
    mode: RunMode | str,
    n_cells_attempted: int,
    decisions: Iterable[Mapping[str, Any]],
    n_blocked_filled: int = 0,
) -> RunHealth:
    """Judge a completed run.

    ``decisions`` is any iterable of mappings with a ``label`` and a ``synthetic``
    key — the shape ``AdjudicationResult.to_dict()`` already produces. Only cells
    that reached a verdict should appear; cells the pipeline blocked are counted
    through ``n_cells_attempted`` and ``n_blocked_filled`` instead, because the
    difference between "asked and answered" and "asked and failed" is the whole
    point of the coverage number.
    """

    mode = RunMode(mode)
    rows = list(decisions)

    # A row without a label never reached a verdict. It is counted through
    # coverage, not through the label distribution — and not through the synthetic
    # rate either, because "would this blocked cell have been synthetic" is not a
    # question with an answer. Counting them made a run with zero decisions report
    # "120 synthetic (0.0% of decisions)".
    decided_rows = [row for row in rows if str(row.get("label", ""))]
    label_counts = Counter(str(row["label"]) for row in decided_rows)
    n_decided = len(decided_rows)
    n_synthetic = sum(1 for row in decided_rows if row.get("synthetic"))

    health = RunHealth(
        mode=mode,
        status=RunStatus.RUN_VALID,
        export_blocked=False,
        n_cells_attempted=max(n_cells_attempted, n_decided),
        n_decided=n_decided,
        n_synthetic=n_synthetic,
        n_blocked_filled=n_blocked_filled,
        label_counts=dict(label_counts),
    )

    blocking: list[str] = []
    warnings: list[str] = []

    if n_decided == 0:
        blocking.append(
            "the run produced no decisions at all; there is nothing here to score"
        )

    if health.synthetic_rate > 0:
        message = (
            f"{n_synthetic}/{n_decided} decision(s) are synthetic — reached without a "
            "real model reading of the evidence. These measure the plumbing, not the "
            "reasoning, and a synthetic run has scored 98% on one label before."
        )
        (blocking if mode.is_strict else warnings).append(message)

    unreachable = health.unreachable_labels
    if unreachable and n_decided:
        message = (
            f"label(s) {unreachable} were never predicted. The graded set contains all "
            "three, so an unreachable class loses every cell whose true label it is — "
            "a pipeline defect, not a property of the farms."
        )
        # Not blocking: an unreachable class is a real defect but the run's other
        # numbers are still measurements of something. It is loud, not fatal.
        warnings.append(message)

    if label_counts:
        top_label, top_count = max(label_counts.items(), key=lambda item: item[1])
        share = top_count / n_decided
        if share >= MAJORITY_CLASS_THRESHOLD:
            warnings.append(
                f"{share:.0%} of decided cells are {top_label!r}. A near-constant "
                "predictor scores the majority class and tells you nothing about the "
                "reasoning; check this before reading the accuracy."
            )

    if health.decision_coverage < 1.0 and n_decided:
        warnings.append(
            f"decision coverage is {health.decision_coverage:.1%}; "
            f"{health.n_cells_attempted - n_decided} cell(s) never reached a verdict. "
            "Any accuracy figure must be reported alongside this number."
        )

    health.blocking_findings = blocking
    health.warnings = warnings

    if blocking:
        health.status = RunStatus.RUN_INVALID
        health.export_blocked = True
    elif warnings:
        health.status = RunStatus.RUN_DEGRADED

    return health
