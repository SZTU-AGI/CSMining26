"""E1/E2: turn parsed documents into addressable, citable evidence atoms.

Granularity
-----------
Two granularities coexist because the corpus mixes two kinds of content:

* **Prose** is emitted at *section* level. A single paragraph loses the heading
  that gives it meaning ("monthly" means nothing without "3. Monitoring and
  Servicing Schedule"), while a whole document is too coarse to cite.
* **Tabular content** is emitted at *row* level, because a row is the record. Row
  atoms are rendered as ``header: value`` pairs so that a retrieved atom is
  readable without its table, and so lexical retrieval can match on the column
  name as well as the value.

``source_type`` records which granularity produced the atom, so a retrieval
ablation can weight or filter them without re-parsing.

Every atom carries a locator a human can act on — ``paragraph_index`` /
``table_index`` + ``row_index`` for DOCX, ``sheet`` + ``cell_range`` for XLSX.
This is the precondition for the audit argument: a claim whose premise is an
evidence atom can always be traced back to a coordinate in a source file.

Identity travels with the atom, not with the track, because admissibility is
decided per document and a case can mix admissible and inadmissible sources.
"""

from __future__ import annotations

import re

from freca.domain.models import EvidenceAtom, EvidenceLocator, IdentityAssessment
from freca.evidence.docx_reader import DocxDocument, DocxTable
from freca.evidence.segment import DocSection
from freca.evidence.xlsx_reader import XlsxDocument

#: Atoms shorter than this carry no retrievable signal (stray punctuation, "N/A").
MIN_ATOM_CHARS = 3
#: Section atoms longer than this are split so one atom cannot dominate BM25.
MAX_ATOM_CHARS = 2000


def _safe(fragment: str) -> str:
    """Coerce a fragment into the ``SafeId`` character class."""

    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "-", fragment).strip("-")
    return cleaned or "x"


def _key_value_table(table: DocxTable) -> bool:
    """A two-column table whose left column is a short label."""

    if table.n_cols != 2 or table.n_rows == 0:
        return False
    labels = [row[0] for row in table.rows if row and row[0]]
    if not labels:
        return False
    return sum(len(label) <= 40 for label in labels) / len(labels) >= 0.8


def _chunk(text: str, limit: int = MAX_ATOM_CHARS) -> list[str]:
    if len(text) <= limit:
        return [text]
    chunks: list[str] = []
    current: list[str] = []
    size = 0
    for line in text.split("\n"):
        if size + len(line) > limit and current:
            chunks.append("\n".join(current))
            current, size = [], 0
        current.append(line)
        size += len(line) + 1
    if current:
        chunks.append("\n".join(current))
    return chunks


def build_docx_atoms(
    *,
    case_id: str,
    track: str,
    document: DocxDocument,
    sections: list[DocSection],
    identity: IdentityAssessment,
) -> list[EvidenceAtom]:
    """Section atoms for prose, row atoms for tables."""

    doc_id = _safe(f"{case_id}.{track}")
    atoms: list[EvidenceAtom] = []

    for section in sections:
        heading = section.heading
        prose = "\n".join(p.text for p in section.paragraphs if p.text.strip())
        if len(prose) >= MIN_ATOM_CHARS:
            anchor = section.paragraphs[0].paragraph_index
            for part_index, part in enumerate(_chunk(prose)):
                atoms.append(
                    EvidenceAtom(
                        evidence_id=_safe(f"{doc_id}.s{section.section_key}.p{part_index}"),
                        case_id=case_id,
                        doc_id=doc_id,
                        track=track,
                        source_type="docx.section",
                        locator=EvidenceLocator(
                            document_path=document.path,
                            paragraph_index=anchor,
                        ),
                        content=f"{heading}\n{part}" if heading else part,
                        identity=identity,
                        source_hash=document.source_hash,
                        parse_confidence=1.0,
                    )
                )

        for table in section.tables:
            key_value = _key_value_table(table)
            header = table.header if not key_value else []
            rows = table.rows if key_value else table.body_rows
            offset = 0 if key_value else 1
            for row_index, row in enumerate(rows):
                if key_value:
                    rendered = f"{row[0]}: {row[1]}" if len(row) >= 2 else row[0]
                else:
                    rendered = "; ".join(
                        f"{name}: {value}"
                        for name, value in zip(header, row, strict=False)
                        if name and value
                    )
                if len(rendered.strip()) < MIN_ATOM_CHARS:
                    continue
                atoms.append(
                    EvidenceAtom(
                        evidence_id=_safe(f"{doc_id}.t{table.table_index}.r{row_index}"),
                        case_id=case_id,
                        doc_id=doc_id,
                        track=track,
                        source_type="docx.key_value" if key_value else "docx.table_row",
                        locator=EvidenceLocator(
                            document_path=document.path,
                            table_index=table.table_index,
                            row_index=row_index + offset,
                            headers=list(header),
                        ),
                        content=f"{heading} — {rendered}" if heading else rendered,
                        identity=identity,
                        source_hash=document.source_hash,
                        parse_confidence=1.0,
                    )
                )
    return atoms


def build_xlsx_atoms(
    *,
    case_id: str,
    track: str,
    document: XlsxDocument,
    identity: IdentityAssessment,
) -> list[EvidenceAtom]:
    """One atom per record row, plus one per cover key-value pair."""

    doc_id = _safe(f"{case_id}.{track}")
    atoms: list[EvidenceAtom] = []

    for sheet in document.sheets:
        label = sheet.sheet_name
        for key_index, (key, value) in enumerate(sheet.key_values.items()):
            rendered = f"{key}: {value}"
            if len(rendered.strip()) < MIN_ATOM_CHARS:
                continue
            atoms.append(
                EvidenceAtom(
                    evidence_id=_safe(f"{doc_id}.{label}.kv{key_index}"),
                    case_id=case_id,
                    doc_id=doc_id,
                    track=track,
                    source_type="xlsx.key_value",
                    locator=EvidenceLocator(
                        document_path=document.path,
                        sheet=sheet.sheet_name,
                        cell_range=f"A{key_index + 1}:B{key_index + 1}",
                    ),
                    content=f"{label} — {rendered}",
                    identity=identity,
                    source_hash=document.source_hash,
                    parse_confidence=1.0,
                )
            )

        for row in sheet.rows:
            rendered = row.as_text()
            if len(rendered.strip()) < MIN_ATOM_CHARS:
                continue
            atoms.append(
                EvidenceAtom(
                    evidence_id=_safe(f"{doc_id}.{label}.r{row.row_index}"),
                    case_id=case_id,
                    doc_id=doc_id,
                    track=track,
                    source_type="xlsx.record_row",
                    locator=EvidenceLocator(
                        document_path=document.path,
                        sheet=sheet.sheet_name,
                        cell_range=row.cell_range,
                        headers=list(row.headers),
                    ),
                    content=f"{label} — {rendered}",
                    identity=identity,
                    source_hash=document.source_hash,
                    parse_confidence=1.0,
                )
            )
    return atoms
