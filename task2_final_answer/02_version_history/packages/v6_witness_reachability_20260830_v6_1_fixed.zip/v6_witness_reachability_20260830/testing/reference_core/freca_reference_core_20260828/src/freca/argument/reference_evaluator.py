"""Second graph evaluator with an iterative implementation and agreement gate."""

from __future__ import annotations

from pydantic import Field

from freca.argument.evaluator import ArgumentGraphEvaluation
from freca.argument.models import ArgumentGraphTemplate, PremiseRole, RequiredPolarity
from freca.domain.models import SafeId, StrictModel
from freca.logic.ast import LogicOperator
from freca.logic.four_valued import FourValuedState


class EvaluatorAgreementReport(StrictModel):
    interpretation_id: SafeId
    primary_root_states: dict[SafeId, FourValuedState]
    reference_root_states: dict[SafeId, FourValuedState]
    mismatch_root_statement_ids: list[SafeId] = Field(default_factory=list)
    status: str


def reference_evaluate_argument_graph(
    graph: ArgumentGraphTemplate,
    atom_states: dict[str, FourValuedState],
) -> ArgumentGraphEvaluation:
    """Iteratively evaluate statements without calling the primary evaluator."""

    arguments_by_conclusion: dict[str, list] = {}
    for argument in graph.argument_nodes:
        arguments_by_conclusion.setdefault(argument.conclusion_statement_id, []).append(argument)
    states: dict[str, FourValuedState] = {}
    unresolved_exceptions: set[str] = set()
    for statement in graph.statement_nodes:
        if statement.logic_operator is LogicOperator.ATOM:
            assert statement.proposition_id is not None
            states[statement.statement_id] = atom_states.get(
                statement.proposition_id,
                FourValuedState.UNKNOWN,
            )

    pending = {
        item.statement_id
        for item in graph.statement_nodes
        if item.logic_operator is not LogicOperator.ATOM
    }
    while pending:
        progress = False
        for statement_id in sorted(pending):
            arguments = arguments_by_conclusion.get(statement_id, [])
            premise_ids = {
                premise.statement_id for argument in arguments for premise in argument.premises
            }
            if not arguments or not premise_ids.issubset(states):
                continue
            alternatives: list[tuple[bool, bool]] = []
            for argument in sorted(arguments, key=lambda item: item.argument_id):
                required: list[tuple[bool, bool]] = []
                exceptions: list[tuple[bool, bool]] = []
                for premise in argument.premises:
                    pair = states[premise.statement_id].pair
                    if premise.required_polarity is RequiredPolarity.NEGATIVE:
                        pair = (pair[1], pair[0])
                    if premise.premise_role is PremiseRole.EXCEPTION:
                        exceptions.append(pair)
                    else:
                        required.append(pair)
                supports_rule = all(pair[0] for pair in required)
                defeats_rule = any(pair[1] for pair in required)
                if exceptions:
                    if any(pair == (False, False) for pair in exceptions):
                        unresolved_exceptions.add(statement_id)
                    supports_rule = supports_rule and all(pair[1] for pair in exceptions)
                    defeats_rule = defeats_rule or any(pair[0] for pair in exceptions)
                alternatives.append((supports_rule, defeats_rule))
            states[statement_id] = FourValuedState.from_pair(
                any(pair[0] for pair in alternatives),
                all(pair[1] for pair in alternatives),
            )
            pending.remove(statement_id)
            progress = True
            break
        if not progress:
            raise ValueError(
                "reference evaluator cannot resolve graph; cycle or missing projected argument"
            )
    return ArgumentGraphEvaluation(
        interpretation_id=graph.interpretation_id,
        statement_states=states,
        root_states={
            statement_id: states[statement_id] for statement_id in graph.root_statement_ids.values()
        },
        unresolved_exception_statement_ids=sorted(unresolved_exceptions),
    )


def compare_evaluators(
    primary: ArgumentGraphEvaluation,
    reference: ArgumentGraphEvaluation,
) -> EvaluatorAgreementReport:
    if primary.interpretation_id != reference.interpretation_id:
        raise ValueError("evaluators used different interpretations")
    root_ids = set(primary.root_states) | set(reference.root_states)
    mismatch = sorted(
        root_id
        for root_id in root_ids
        if primary.root_states.get(root_id) != reference.root_states.get(root_id)
    )
    return EvaluatorAgreementReport(
        interpretation_id=primary.interpretation_id,
        primary_root_states=primary.root_states,
        reference_root_states=reference.root_states,
        mismatch_root_statement_ids=mismatch,
        status="PASS" if not mismatch else "EVALUATOR_DISAGREEMENT_BLOCK",
    )
