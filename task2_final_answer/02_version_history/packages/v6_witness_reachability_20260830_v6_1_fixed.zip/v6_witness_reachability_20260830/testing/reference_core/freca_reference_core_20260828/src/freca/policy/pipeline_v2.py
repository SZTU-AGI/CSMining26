"""Fixed deterministic Layer 1 pipeline over an admitted Rules SourceRef."""

from __future__ import annotations

from freca.governance.hashing import sha256_digest
from freca.governance.source_guard import SourceRef
from freca.governance.source_resolver import CatalogSourceResolver
from freca.policy.cues import build_cue_index
from freca.policy.definitions import build_definition_index
from freca.policy.extract import extract_policy_text
from freca.policy.furniture import classify_policy_lines
from freca.policy.graph_v2 import build_policy_graph
from freca.policy.hierarchy import build_policy_units, build_section_occurrences
from freca.policy.references import extract_reference_mentions
from freca.policy.schemas_v2 import PolicyIndex
from freca.policy.validate_v2 import validate_policy_structure

POLICY_PARSER_VERSION = "freca-policy-parser-v2.0.0"


def build_policy_index(
    source: SourceRef,
    resolver: CatalogSourceResolver,
) -> PolicyIndex:
    extracted = extract_policy_text(source, resolver)
    lines = classify_policy_lines(extracted)
    occurrences, occurrence_issues, _toc = build_section_occurrences(lines)
    units, hierarchy_issues = build_policy_units(
        lines=lines,
        pages=extracted.pages,
        occurrences=occurrences,
        source_pdf_sha256=source.sha256,
    )
    definitions = build_definition_index(units)
    references = extract_reference_mentions(units)
    cues = build_cue_index(units)
    edges = build_policy_graph(units, definitions, references)
    issues = [
        *occurrence_issues,
        *hierarchy_issues,
        *validate_policy_structure(units, edges),
    ]
    payload = {
        "schema_version": "freca.policy-index.v1",
        "source_id": source.source_id,
        "source_pdf_sha256": source.sha256,
        "parser_version": POLICY_PARSER_VERSION,
        "pages": extracted.pages,
        "lines": lines,
        "section_occurrences": occurrences,
        "units": units,
        "definitions": definitions,
        "reference_mentions": references,
        "graph_edges": edges,
        "cues": cues,
        "issues": issues,
    }
    return PolicyIndex(**payload, index_sha256=sha256_digest(payload))
