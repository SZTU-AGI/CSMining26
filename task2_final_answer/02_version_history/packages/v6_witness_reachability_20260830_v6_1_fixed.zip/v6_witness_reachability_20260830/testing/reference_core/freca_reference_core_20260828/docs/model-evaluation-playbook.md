# FRECA 模型效果评测手册 v1

## 1. 先回答最重要的问题

不能只用“最终 4100 格答对多少”判断系统好坏。

FRECA 是一条多阶段取证与裁决链。最终答错可能来自：

1. 数据或案例映射错误；
2. 没有检索到关键证据；
3. 检索到了，但采用了外来主体或错误时间的材料；
4. 引用存在，但并不支持模型声称的事实；
5. 事实正确，但适用性或三值映射错误；
6. 候选本来正确，却被复核门错误拦截；
7. 单个 CP 正确，但与同案其他 CP 矛盾。

所以必须分层评测。

## 2. 五层质量仪表盘

| 层 | 回答的问题 | 首要指标 |
|---|---|---|
| L0 数据完整性 | 模型看到的是不是正确案例和完整文件？ | manifest pass、locator validity、跨 case 泄漏率 |
| L1 检索 | 需要的正证/反证找到了吗？ | supporting Recall@k、contrary Recall@k、MRR |
| L2 证据采用 | 找到后有没有正确引用和归属？ | citation precision/completeness、foreign adoption rate |
| L3 推理与复核 | 结论是否由前提支持，复核是否真的纠错？ | ungrounded rate、Error Recovery、False Block、Propagation |
| L4 最终任务 | 1/0/N/A 是否正确？ | macro-F1、MCC、N/A F1、每 CP F1 |

另设成本层：

- 每 CP 模型调用数；
- token；
- 平均检索轮数；
- 延迟；
- 人工复核率。

## 3. 需要什么人工金标

每个 `case × CP` 不只标最终标签，还要标：

```json
{
  "case_id": "FRECA-T2-S096",
  "cp_id": "CP22",
  "gold_label": "1",
  "applicability": "APPLICABLE",
  "supporting_spans": ["doc_id + locator"],
  "contrary_spans": [],
  "required_facts": ["..."],
  "basis": "compliant_evidence",
  "notes": "..."
}
```

推荐：

- 10 个案例作为 micro-gold；
- 两名标注者独立判断；
- 不一致由第三人或讨论仲裁；
- 至少覆盖正常、缺失、外来主体、冲突和表格推理案例；
- 开发集和最终测试集按 case 隔离，不能把同案不同 CP 分到两边。

## 4. 如何读一次实验结果

### 情况 A：最终 F1 低，Recall@k 也低

主要是检索问题。先修 chunk、查询、metadata、identity 或 rerank，不应先改裁决 prompt。

### 情况 B：Recall@k 高，但 citation precision 低

模型看到了正确证据，却选错或曲解。应改 Evidence Reviewer、引用门和上下文组织。

### 情况 C：引用正确，但最终标签错

是适用性、充分性或 `1/0/N/A` 映射问题。检查 PolicyPack、Argument Validator 和三值协议。

### 情况 D：候选正确，最终反而错误

复核门发生 False Block。需要降低语义 Reviewer 权限，或提高确定性 comparator 优先级。

### 情况 E：平均分高，但异常子集骤降

模型可能只学会普通案例。必须单独报告 Missing、Foreign、Conflict、Table 子集。

## 5. 复核门是否有用

对每个 gate 记录四种数量：

```text
DetectedError:
  候选确实错误，gate 也拦截

RecoveredError:
  被拦截后通过 C6/重判修正

MissedError:
  候选错误但 gate 放行

FalseBlock:
  候选正确但 gate 拦截并导致失败/错误
```

核心指标：

```text
Error Detection Rate = DetectedError / 所有进入 gate 的真实错误
Recovery Rate        = RecoveredError / DetectedError
False Block Rate     = FalseBlock / 所有进入 gate 的正确候选
Net Correction Gain  = RecoveredError - FalseBlock
Propagation Rate     = 上游错误最终仍造成错误 / 上游错误总数
```

只有 `Net Correction Gain > 0` 且传播率下降，才能说“逐步复核有效”。

## 6. 最小可行评测

正式全量标注前，先完成：

```text
3 个案例 × 7 个代表 CP
```

其中至少：

- S096：当前已有人工作为参照；
- 1 个缺失/证据不足案例；
- 1 个外来主体或冲突案例。

先比较：

```text
A Full Context
D Pure Hybrid RAG
E Agentic Hybrid，无验证门
F 完整方法
```

第一轮不用追求论文显著性，只回答：

1. 正确证据能否稳定回到 locator？
2. 缺证是否会被误判成 N/A？
3. 外来证据是否会被误采纳？
4. 验证门至少修正过真实错误吗？
5. F 的提升是不是只来自更多 token？

## 7. 建议的阶段性通过线

这些是工程门，不是论文结论：

| 阶段 | 建议通过条件 |
|---|---|
| M0/E0–E3 | manifest 硬约束 100% 通过；locator 可回开率 100%；跨案泄漏 0 |
| 检索试运行 | 7 CP 的 supporting Recall@10 达到可人工检查的稳定水平 |
| 引用试运行 | 不允许无 locator 引用；foreign supporting adoption 为 0 |
| 三值协议 | 所有 N/A 都能同时指出法规条件和案例事实 |
| 验证门 | Net Correction Gain > 0；所有 False Block 有完整缺陷记录 |
| 扩展 41 CP | 纵切面可复现、可恢复，且主要错误来源已经可以分类 |

不要提前给最终 F1 设置拍脑袋阈值。先完成双标 micro-gold，再依据标注一致率、类别分布和强基线确定合理目标。

## 8. 以后每次实验必须产生的四份结果

```text
summary.json
  最终指标、成本和配置 hash

predictions.jsonl
  每个 case × CP 的预测与 gold

stage_metrics.json
  检索、引用、论证和 gate 指标

error_cases.jsonl
  可回到原始 evidence、argument 和 gate report 的错误清单
```

当前 `python -m freca.cli evaluate --run-dir <run_dir>` 已生成上述四类文件，另有
`v0_report.json` 作为合并视图。没有 gold 时 `summary.json.gold.status` 必须为
`NO_GOLD`，不能把 run-health 或 synthetic 结果解释成准确率。

这样看到一个分数下降时，可以立即定位下降发生在哪一层。
