"""Pre-registered FOLD-POLICY-v3 with branch-support invariants."""

from __future__ import annotations

from enum import StrEnum
from typing import Literal

from pydantic import Field, model_validator

from freca.domain.enums import FinalLabel
from freca.domain.models import SafeId, StrictModel


class InternalOutcome(StrEnum):
    PROVEN_COMPLIANT = "PROVEN_COMPLIANT"
    PROVEN_NON_COMPLIANT = "PROVEN_NON_COMPLIANT"
    PROVEN_NOT_APPLICABLE = "PROVEN_NOT_APPLICABLE"
    NOT_DEMONSTRATED = "NOT_DEMONSTRATED"
    CONFLICTING = "CONFLICTING"
    UNKNOWN = "UNKNOWN"


class Finality(StrEnum):
    RULE_FIXED_NA = "RULE_FIXED_NA"
    EVIDENCE_DEMONSTRATED = "EVIDENCE_DEMONSTRATED"
    VACUOUSLY_SATISFIED = "VACUOUSLY_SATISFIED"
    EVIDENCE_REBUTTED = "EVIDENCE_REBUTTED"
    INSUFFICIENT_EVIDENCE_BENCHMARK_FALLBACK = "INSUFFICIENT_EVIDENCE_BENCHMARK_FALLBACK"
    ONE_NA_TIE_PREFER_ONE = "ONE_NA_TIE_PREFER_ONE"
    ONE_NA_TIE_PREFER_NA = "ONE_NA_TIE_PREFER_NA"
    INTERPRETATION_CONFLICT_FALLBACK = "INTERPRETATION_CONFLICT_FALLBACK"
    UNKNOWN_BENCHMARK_FALLBACK = "UNKNOWN_BENCHMARK_FALLBACK"
    SYSTEM_FORCED_FALLBACK = "SYSTEM_FORCED_FALLBACK"


class AssuranceDisposition(StrEnum):
    SUBSTANTIVE_CONCLUSION_SUPPORTED = "SUBSTANTIVE_CONCLUSION_SUPPORTED"
    EVIDENCE_LIMITATION = "EVIDENCE_LIMITATION"
    INTERPRETATION_LIMITATION = "INTERPRETATION_LIMITATION"
    SYSTEM_LIMITATION = "SYSTEM_LIMITATION"


class OneNaTiePolicy(StrEnum):
    PREFER_ONE_NONVIOLATION = "PREFER_ONE_NONVIOLATION"
    PREFER_NA_APPLICABILITY = "PREFER_NA_APPLICABILITY"


class RunMode(StrEnum):
    DIAGNOSTIC = "DIAGNOSTIC"
    SUBMISSION = "SUBMISSION"


class FoldGateReport(StrictModel):
    positive_non_applicability_proven: bool = False
    na_countercheck_passed: bool = False
    activity_counterevidence_standing: bool = False
    applicability_standing: bool = False
    false_trigger_proven: bool = False
    vacuous_satisfaction_proven: bool = False
    vacuous_satisfaction_basis_id: SafeId | None = None
    residual_decisive_requirement_ids: list[SafeId] = Field(default_factory=list)
    all_decisive_requirements_meet_standard: bool = False
    decisive_rebuttal_standing: bool = False
    decisive_attack_or_violation_standing: bool = False
    insufficient_evidence_benchmark_fallback_permitted: bool = False
    burden_application_id: SafeId | None = None


class BranchEvaluation(StrictModel):
    internal_outcome: InternalOutcome
    fold_gate_report: FoldGateReport


class InterpretationBranchResult(StrictModel):
    branch_id: SafeId
    valid: bool = True
    invalid_reason_codes: list[str] = Field(default_factory=list)
    evaluation: BranchEvaluation

    @model_validator(mode="after")
    def invalid_branch_has_reason(self) -> InterpretationBranchResult:
        if not self.valid and not self.invalid_reason_codes:
            raise ValueError("invalid interpretation branch requires a reason code")
        return self


class InterpretationEnvelope(StrictModel):
    envelope_id: SafeId
    case_id: str = Field(min_length=1)
    cp_id: str = Field(min_length=1)
    accepted_branches: list[InterpretationBranchResult] = Field(min_length=1)


class FoldedBranch(StrictModel):
    branch_id: SafeId
    label: FinalLabel
    finality: Finality
    benchmark_fallback: bool = False


class FoldDecision(StrictModel):
    case_id: str
    cp_id: str
    envelope_id: SafeId
    fold_policy_version: Literal["FOLD-POLICY-v3"] = "FOLD-POLICY-v3"
    branch_fold_results: list[FoldedBranch]
    label: FinalLabel
    finality: Finality
    assurance_disposition: AssuranceDisposition
    forced: bool = False
    system_forced: bool = False
    benchmark_fallback: bool = False
    preserved_branch_ids: list[SafeId]
    fold_reason_code: str


class FoldInvariantError(ValueError):
    pass


def assurance_disposition(outcome: InternalOutcome) -> AssuranceDisposition:
    if outcome in {
        InternalOutcome.PROVEN_COMPLIANT,
        InternalOutcome.PROVEN_NON_COMPLIANT,
        InternalOutcome.PROVEN_NOT_APPLICABLE,
    }:
        return AssuranceDisposition.SUBSTANTIVE_CONCLUSION_SUPPORTED
    if outcome is InternalOutcome.CONFLICTING:
        return AssuranceDisposition.INTERPRETATION_LIMITATION
    return AssuranceDisposition.EVIDENCE_LIMITATION


def fold_branch(branch: InterpretationBranchResult) -> FoldedBranch:
    if not branch.valid:
        raise FoldInvariantError(f"cannot fold invalid branch {branch.branch_id}")
    state = branch.evaluation
    gates = state.fold_gate_report
    if (
        state.internal_outcome is InternalOutcome.PROVEN_NOT_APPLICABLE
        and gates.positive_non_applicability_proven
        and gates.na_countercheck_passed
        and not gates.activity_counterevidence_standing
    ):
        return FoldedBranch(
            branch_id=branch.branch_id,
            label=FinalLabel.NOT_APPLICABLE,
            finality=Finality.RULE_FIXED_NA,
        )
    if (
        state.internal_outcome is InternalOutcome.PROVEN_COMPLIANT
        and (
            (gates.applicability_standing and gates.all_decisive_requirements_meet_standard)
            or (
                gates.false_trigger_proven
                and gates.vacuous_satisfaction_proven
                and gates.vacuous_satisfaction_basis_id is not None
                and not gates.residual_decisive_requirement_ids
            )
        )
        and not gates.decisive_rebuttal_standing
        and not gates.decisive_attack_or_violation_standing
    ):
        finality = (
            Finality.VACUOUSLY_SATISFIED
            if gates.vacuous_satisfaction_proven and not gates.applicability_standing
            else Finality.EVIDENCE_DEMONSTRATED
        )
        return FoldedBranch(
            branch_id=branch.branch_id,
            label=FinalLabel.COMPLIANT,
            finality=finality,
        )
    if (
        state.internal_outcome is InternalOutcome.PROVEN_NON_COMPLIANT
        and gates.decisive_attack_or_violation_standing
    ):
        return FoldedBranch(
            branch_id=branch.branch_id,
            label=FinalLabel.NON_COMPLIANT,
            finality=Finality.EVIDENCE_REBUTTED,
        )
    if (
        state.internal_outcome is InternalOutcome.NOT_DEMONSTRATED
        and gates.insufficient_evidence_benchmark_fallback_permitted
        and gates.burden_application_id is not None
    ):
        return FoldedBranch(
            branch_id=branch.branch_id,
            label=FinalLabel.NON_COMPLIANT,
            finality=Finality.INSUFFICIENT_EVIDENCE_BENCHMARK_FALLBACK,
            benchmark_fallback=True,
        )
    if state.internal_outcome is InternalOutcome.CONFLICTING:
        return FoldedBranch(
            branch_id=branch.branch_id,
            label=FinalLabel.NON_COMPLIANT,
            finality=Finality.INTERPRETATION_CONFLICT_FALLBACK,
            benchmark_fallback=True,
        )
    if state.internal_outcome is InternalOutcome.UNKNOWN:
        return FoldedBranch(
            branch_id=branch.branch_id,
            label=FinalLabel.NON_COMPLIANT,
            finality=Finality.UNKNOWN_BENCHMARK_FALLBACK,
            benchmark_fallback=True,
        )
    raise FoldInvariantError("InternalOutcome and FoldGateReport are inconsistent or unhandled")


def _same_label_finality(folded: list[FoldedBranch]) -> Finality:
    finalities = {item.finality for item in folded}
    if len(finalities) == 1:
        return next(iter(finalities))
    if any(item.benchmark_fallback for item in folded):
        if any(item.finality is Finality.INTERPRETATION_CONFLICT_FALLBACK for item in folded):
            return Finality.INTERPRETATION_CONFLICT_FALLBACK
        return Finality.UNKNOWN_BENCHMARK_FALLBACK
    return sorted(finalities, key=lambda item: item.value)[0]


def fold_envelope(
    envelope: InterpretationEnvelope,
    *,
    mode: RunMode,
    one_na_policy: OneNaTiePolicy,
) -> FoldDecision:
    valid = [branch for branch in envelope.accepted_branches if branch.valid]
    if not valid:
        if mode is RunMode.DIAGNOSTIC:
            raise FoldInvariantError("NO_VALID_INTERPRETATION")
        return FoldDecision(
            case_id=envelope.case_id,
            cp_id=envelope.cp_id,
            envelope_id=envelope.envelope_id,
            branch_fold_results=[],
            label=FinalLabel.NON_COMPLIANT,
            finality=Finality.SYSTEM_FORCED_FALLBACK,
            assurance_disposition=AssuranceDisposition.SYSTEM_LIMITATION,
            forced=True,
            system_forced=True,
            benchmark_fallback=True,
            preserved_branch_ids=[],
            fold_reason_code="NO_VALID_INTERPRETATION",
        )

    folded = [fold_branch(branch) for branch in valid]
    labels = {item.label for item in folded}
    common = {
        "case_id": envelope.case_id,
        "cp_id": envelope.cp_id,
        "envelope_id": envelope.envelope_id,
        "branch_fold_results": folded,
        "preserved_branch_ids": [branch.branch_id for branch in valid],
    }
    if len(labels) == 1:
        label = next(iter(labels))
        finality = _same_label_finality(folded)
        fallback = any(item.benchmark_fallback for item in folded)
        disposition = (
            AssuranceDisposition.EVIDENCE_LIMITATION
            if fallback
            else AssuranceDisposition.SUBSTANTIVE_CONCLUSION_SUPPORTED
        )
        return FoldDecision(
            **common,
            label=label,
            finality=finality,
            assurance_disposition=disposition,
            benchmark_fallback=fallback,
            fold_reason_code="ROBUST_SAME_LABEL_ACROSS_INTERPRETATIONS",
        )

    one_na = {FinalLabel.COMPLIANT, FinalLabel.NOT_APPLICABLE}
    if labels == one_na:
        prefer_one = one_na_policy is OneNaTiePolicy.PREFER_ONE_NONVIOLATION
        return FoldDecision(
            **common,
            label=FinalLabel.COMPLIANT if prefer_one else FinalLabel.NOT_APPLICABLE,
            finality=(
                Finality.ONE_NA_TIE_PREFER_ONE if prefer_one else Finality.ONE_NA_TIE_PREFER_NA
            ),
            assurance_disposition=AssuranceDisposition.INTERPRETATION_LIMITATION,
            benchmark_fallback=True,
            fold_reason_code=(
                "ONE_NA_TIE_PRECOMMITTED_PREFER_ONE"
                if prefer_one
                else "ONE_NA_TIE_PRECOMMITTED_PREFER_NA"
            ),
        )

    if FinalLabel.NON_COMPLIANT not in labels:
        raise FoldInvariantError("mixed envelope label is unsupported by any branch")
    return FoldDecision(
        **common,
        label=FinalLabel.NON_COMPLIANT,
        finality=Finality.INTERPRETATION_CONFLICT_FALLBACK,
        assurance_disposition=AssuranceDisposition.INTERPRETATION_LIMITATION,
        benchmark_fallback=True,
        fold_reason_code="ZERO_SUPPORTED_INTERPRETATION_CONFLICT",
    )
