"""Strict loader for the official horizontal 4x41 checking-point workbook."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Literal

from pydantic import Field, model_validator

from freca.domain.models import SafeId, Sha256, StrictModel
from freca.governance.hashing import sha256_digest
from freca.governance.source_guard import SourceRef
from freca.governance.source_resolver import CatalogSourceResolver

_SUBELEMENT_CODE = re.compile(r"^\s*(\d+(?:\.\d+)+)\b")


class CPWorkbookError(ValueError):
    pass


class WorkbookCellRef(StrictModel):
    cell_id: SafeId
    sheet: str
    coordinate: str
    raw_value: str
    inherited_from_merge: bool
    merge_range: str | None = None


class OfficialCP(StrictModel):
    official_cp_id: SafeId
    cp_id: str = Field(pattern=r"^CP(?:[1-9]|[1-3]\d|4[01])$")
    ordinal: int = Field(ge=1, le=41)
    element_group_raw: str = Field(min_length=1)
    subelement_title_raw: str = Field(min_length=1)
    subelement_code: str | None = None
    criterion_text_raw: str = Field(min_length=1)
    criterion_text_normalized: str = Field(min_length=1)
    retrieval_context_text: str = Field(min_length=1)
    group_id: SafeId
    source_cells: list[WorkbookCellRef] = Field(min_length=4, max_length=4)
    workbook_sha256: Sha256


class OfficialCPBundle(StrictModel):
    schema_version: Literal["freca.official-cp-bundle.v1"] = "freca.official-cp-bundle.v1"
    source_id: SafeId
    workbook_sha256: Sha256
    cps: list[OfficialCP]
    group_index: dict[SafeId, list[str]]
    bundle_sha256: Sha256

    @model_validator(mode="after")
    def exact_official_order(self) -> OfficialCPBundle:
        expected = [f"CP{index}" for index in range(1, 42)]
        if [cp.cp_id for cp in self.cps] != expected:
            raise ValueError("official CPs must be exactly CP1..CP41 in order")
        if len({cp.official_cp_id for cp in self.cps}) != 41:
            raise ValueError("official CP IDs must be unique")
        return self


def load_official_cps(
    source: SourceRef,
    resolver: CatalogSourceResolver,
) -> OfficialCPBundle:
    from openpyxl import load_workbook

    if source.role != "CP_DEFINITIONS":
        raise CPWorkbookError("Layer 2 accepts only the admitted CP_DEFINITIONS source")
    path = resolver.readonly_path(source.source_id, consumer="LAYER2")
    workbook = load_workbook(path, data_only=False, read_only=False)
    _validate_workbook_shape(workbook, path)
    sheet = workbook["All Elements"]
    cps: list[OfficialCP] = []
    for column in range(1, 42):
        refs = [_resolved_cell(sheet, row, column) for row in range(1, 5)]
        cp_id = refs[3].raw_value.strip()
        ordinal = column
        if cp_id != f"CP{ordinal}":
            raise CPWorkbookError(
                f"L2_CP_WORKBOOK_SHAPE_INVALID: expected CP{ordinal} at row 4, got {cp_id!r}"
            )
        criterion = refs[2].raw_value.strip()
        if not criterion:
            raise CPWorkbookError(f"L2_CP_TEXT_EMPTY: {cp_id}")
        element = refs[0].raw_value.strip()
        subelement = refs[1].raw_value.strip()
        code_match = _SUBELEMENT_CODE.match(subelement)
        group_hash = sha256_digest(
            {"element_group_raw": element, "subelement_title_raw": subelement}
        )
        group_id = f"cp-group-{group_hash.split(':', 1)[1][:20]}"
        cps.append(
            OfficialCP(
                official_cp_id=f"official-{cp_id.lower()}",
                cp_id=cp_id,
                ordinal=ordinal,
                element_group_raw=element,
                subelement_title_raw=subelement,
                subelement_code=code_match.group(1) if code_match else None,
                criterion_text_raw=criterion,
                criterion_text_normalized=" ".join(criterion.split()),
                retrieval_context_text=f"{subelement}\n{criterion}",
                group_id=group_id,
                source_cells=refs,
                workbook_sha256=source.sha256,
            )
        )
    if len({cp.element_group_raw for cp in cps}) != 4:
        raise CPWorkbookError("L2_CP_WORKBOOK_SHAPE_INVALID: expected 4 Element groups")
    if len({cp.subelement_title_raw for cp in cps}) != 17:
        raise CPWorkbookError("L2_CP_WORKBOOK_SHAPE_INVALID: expected 17 Subelement groups")
    group_index: dict[str, list[str]] = {}
    for cp in cps:
        group_index.setdefault(cp.group_id, []).append(cp.cp_id)
    payload = {
        "source_id": source.source_id,
        "workbook_sha256": source.sha256,
        "cps": cps,
        "group_index": group_index,
    }
    return OfficialCPBundle(**payload, bundle_sha256=sha256_digest(payload))


def _resolved_cell(sheet, row: int, column: int) -> WorkbookCellRef:
    cell = sheet.cell(row, column)
    anchor = cell
    merge_range: str | None = None
    inherited = False
    if cell.value is None:
        for merged in sheet.merged_cells.ranges:
            if cell.coordinate in merged:
                anchor = sheet.cell(merged.min_row, merged.min_col)
                merge_range = str(merged)
                inherited = anchor.coordinate != cell.coordinate
                break
    value = anchor.value
    if value is None or not isinstance(value, str):
        raise CPWorkbookError(
            f"L2_CP_WORKBOOK_SHAPE_INVALID: missing string at {sheet.title}!{cell.coordinate}"
        )
    return WorkbookCellRef(
        cell_id=f"cell-{sheet.title.lower().replace(' ', '-')}-{cell.coordinate.lower()}",
        sheet=sheet.title,
        coordinate=cell.coordinate,
        raw_value=value,
        inherited_from_merge=inherited,
        merge_range=merge_range,
    )


def _validate_workbook_shape(workbook, path: Path) -> None:
    if workbook.sheetnames != ["All Elements"]:
        raise CPWorkbookError("L2_CP_WORKBOOK_SHAPE_INVALID: unexpected sheets")
    sheet = workbook["All Elements"]
    if sheet.sheet_state != "visible" or sheet.max_row != 4 or sheet.max_column != 41:
        raise CPWorkbookError("L2_CP_WORKBOOK_SHAPE_INVALID: expected visible A1:AO4")
    if sheet.calculate_dimension() != "A1:AO4":
        raise CPWorkbookError("L2_CP_WORKBOOK_SHAPE_INVALID: used range must be A1:AO4")
    if any(sheet.row_dimensions[row].hidden for row in range(1, 5)):
        raise CPWorkbookError("L2_CP_WORKBOOK_SHAPE_INVALID: hidden row")
    if any(sheet.column_dimensions[column].hidden for column in sheet.column_dimensions):
        raise CPWorkbookError("L2_CP_WORKBOOK_SHAPE_INVALID: hidden column")
    for merged in sheet.merged_cells.ranges:
        if merged.min_row not in {1, 2} or merged.max_row not in {1, 2}:
            raise CPWorkbookError("L2_CP_WORKBOOK_SHAPE_INVALID: invalid merged range")
    for row in sheet.iter_rows():
        for cell in row:
            if cell.data_type == "f" or cell.comment is not None or cell.hyperlink is not None:
                raise CPWorkbookError(
                    f"L2_CP_WORKBOOK_SHAPE_INVALID: active content at {cell.coordinate}"
                )
    if getattr(workbook, "_external_links", []):
        raise CPWorkbookError(f"L2_CP_WORKBOOK_SHAPE_INVALID: external link in {path.name}")
