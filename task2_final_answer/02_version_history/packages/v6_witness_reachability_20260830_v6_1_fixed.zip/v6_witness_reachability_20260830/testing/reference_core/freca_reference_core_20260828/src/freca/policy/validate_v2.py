"""Structural and replay validation for the neutral policy index."""

from __future__ import annotations

from freca.policy.schemas_v2 import PolicyGraphEdge, PolicyParseIssue, PolicyUnit


def validate_policy_structure(
    units: list[PolicyUnit],
    graph_edges: list[PolicyGraphEdge],
) -> list[PolicyParseIssue]:
    issues: list[PolicyParseIssue] = []
    by_id = {unit.unit_id: unit for unit in units}
    if len(by_id) != len(units):
        issues.append(PolicyParseIssue(issue_code="L1_DUPLICATE_UNIT_ID", severity="FATAL"))
    for unit in units:
        if unit.parent_id and unit.parent_id not in by_id:
            issues.append(
                PolicyParseIssue(
                    issue_code="L1_UNKNOWN_PARENT",
                    severity="FATAL",
                    unit_id=unit.unit_id,
                    details={"parent_id": unit.parent_id},
                )
            )
        if not unit.full_raw_text:
            issues.append(
                PolicyParseIssue(
                    issue_code="L1_EMPTY_POLICY_UNIT",
                    severity="FATAL",
                    unit_id=unit.unit_id,
                )
            )
    contains = [edge for edge in graph_edges if edge.edge_type == "CONTAINS"]
    adjacency: dict[str, list[str]] = {}
    for edge in contains:
        adjacency.setdefault(edge.source_id, []).append(edge.target_id)
    visiting: set[str] = set()
    visited: set[str] = set()

    def visit(node: str) -> None:
        if node in visiting:
            issues.append(
                PolicyParseIssue(
                    issue_code="L1_POLICY_GRAPH_CYCLE",
                    severity="FATAL",
                    unit_id=node,
                )
            )
            return
        if node in visited:
            return
        visiting.add(node)
        for child in adjacency.get(node, []):
            visit(child)
        visiting.remove(node)
        visited.add(node)

    for unit_id in by_id:
        visit(unit_id)
    forbidden = [
        edge for edge in graph_edges if edge.edge_type not in {"CONTAINS", "REFERS_TO", "DEFINES"}
    ]
    if forbidden:
        issues.append(
            PolicyParseIssue(
                issue_code="L1_SEMANTIC_EDGE_FORBIDDEN",
                severity="FATAL",
                details={"edge_ids": [edge.edge_id for edge in forbidden]},
            )
        )
    return issues
