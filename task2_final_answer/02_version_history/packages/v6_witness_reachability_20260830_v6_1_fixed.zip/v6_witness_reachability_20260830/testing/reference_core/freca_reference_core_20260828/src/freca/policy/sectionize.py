"""Split the regulation into addressable norm sections.

Design note
-----------
The regulation is a legislative instrument, not prose. It already carries a
machine-readable hierarchy: ``Chapter N—Title`` / ``Part N—Title`` /
``Division N—Title`` headings, and numbered sections such as ``4-7A`` or
``11-2``. We therefore do **not** use a fixed-size sliding-window chunker. Fixed
windows destroy exactly the information that turned out to matter most: the
subsection ``(1)`` that names the addressed subject.

Two details make this parser non-trivial:

1. The em-dash form ``Chapter 4—Registered establishments`` marks a *real*
   heading, while the space form ``Chapter 4 Registered establishments`` is the
   running page header repeated on every page. Only the former updates context.
2. The table of contents at the front of the document repeats every heading and
   every section number. It is skipped by requiring that a section heading be
   followed by body text rather than by a dotted page-number leader.

References
----------
* Chain-of-Table (Wang et al., 2024) and SpreadsheetLLM motivate preserving
  native document structure instead of flattening it into text windows; the same
  argument applies to legislative structure.
* LegalBench-RAG reports that legal retrieval quality is dominated by chunk
  boundary quality rather than by the retriever, which is why boundaries here are
  taken from the statute's own numbering.
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field

_HEADING = re.compile(r"^(Chapter|Part|Division|Subdivision)\s+(\d+[A-Z]?)—(.+?)\s*$")
_SECTION = re.compile(r"^\s{0,12}(\d{1,2}-\d{1,3}[A-Z]?)\s+([A-Z][^\n]{2,90})\s*$")
_TOC_LEADER = re.compile(r"\.{4,}\s*\d+\s*$")

#: Page furniture. Each alternative below was confirmed present in the 2021
#: compilation and together they account for 303 of 3575 extracted lines,
#: affecting 98 of 184 sections — i.e. every section that spans a page break.
#:
#: Filtering matters beyond tidiness. These lines carry the words "Chapter",
#: "Part", "Registered establishments" and "Export Control ... Rules 2021", so
#: leaving them in (a) inflates BM25 scores for long sections purely because they
#: crossed more page boundaries, and (b) injects chapter/part vocabulary into the
#: text that ``derive_scope`` and ``detect_direct_subjects`` read, which can move
#: a section's scope or subject on the strength of a printer's header.
_PAGE_NOISE = re.compile(
    r"^(?:"
    r"Compilation No\.|Compilation date|Authorised Version|Registered:"
    # Running title. The page number sits left on verso pages and right on recto
    # pages, so both must be allowed — but the line must consist of *only* the
    # title and a number. Section 1-1's body text is "This instrument is the
    # Export Control (Plants and Plant Products) Rules 2021.", which this must
    # not touch: it is not anchored at the title and it ends in a full stop.
    r"|\d{0,4}\s*Export Control \(Plants and Plant Products\) Rules 2021\s*\d{0,4}"
    r"|\d{0,4}\s*Export Control \(Plants"
    # Running headers. The compilation right-aligns them, so the structural label
    # trails on recto pages and leads on verso pages; both orders occur.
    r"|(?:Chapter|Part|Division|Subdivision)\s+\d{1,2}[A-Z]?\s+\S.*"
    r"|.{0,80}?\s(?:Chapter|Part|Division|Subdivision)\s+\d{1,2}[A-Z]?"
    # Running footer naming the last section printed on the page.
    r"|Section\s+\d{1,2}-\d{1,3}[A-Z]?"
    # A bare page number.
    r"|\d{1,4}"
    r")\s*$"
)

#: Guard for the header patterns above: a genuine em-dash heading must never be
#: swallowed by them, and a body line that merely mentions a Part must survive.
_REAL_HEADING_HINT = re.compile(r"—|\bunder this (?:Part|Division|Chapter)\b")


@dataclass(slots=True)
class NormSection:
    """One numbered section of the regulation, with its structural context."""

    section_id: str
    title: str
    chapter_no: str | None
    chapter_title: str | None
    part_no: str | None
    part_title: str | None
    division_no: str | None
    division_title: str | None
    lines: list[str] = field(default_factory=list)

    @property
    def text(self) -> str:
        return "\n".join(self.lines).strip()

    @property
    def part_key(self) -> str | None:
        """Stable key for the Part this section lives in.

        ``PART_SCOPE`` edges are drawn between sections sharing a ``part_key``,
        which is what makes phrases like "required to be retained under this
        Part" resolvable.
        """

        if self.chapter_no is None or self.part_no is None:
            return None
        return f"Ch{self.chapter_no}/Part{self.part_no}"

    @property
    def source_hash(self) -> str:
        digest = hashlib.sha256(self.text.encode("utf-8")).hexdigest()
        return f"sha256:{digest}"

    def to_dict(self) -> dict[str, object]:
        return {
            "section_id": self.section_id,
            "title": self.title,
            "chapter_no": self.chapter_no,
            "chapter_title": self.chapter_title,
            "part_no": self.part_no,
            "part_title": self.part_title,
            "division_no": self.division_no,
            "division_title": self.division_title,
            "part_key": self.part_key,
            "text": self.text,
            "source_hash": self.source_hash,
        }


def _is_body_line(line: str) -> bool:
    stripped = line.strip()
    if not stripped:
        return False
    if _TOC_LEADER.search(stripped):
        return False
    if _REAL_HEADING_HINT.search(stripped):
        # An em-dash heading or a genuine cross-reference such as "required to be
        # retained under this Part" must reach the caller; the latter is the exact
        # phrase the norm graph's PART_SCOPE edges are built from, so discarding
        # it here would silently break subject closure for section 11-2.
        return True
    return not _PAGE_NOISE.match(stripped)


def sectionize(raw_text: str) -> dict[str, NormSection]:
    """Return ``section_id -> NormSection`` for the regulation body.

    When a section number appears more than once (once in the table of contents
    and once in the body) the longest body occurrence wins, because the table of
    contents entry carries no substantive text.
    """

    chapter: tuple[str, str] | None = None
    part: tuple[str, str] | None = None
    division: tuple[str, str] | None = None

    sections: dict[str, NormSection] = {}
    current: NormSection | None = None

    def close(section: NormSection | None) -> None:
        if section is None:
            return
        if not section.text:
            return
        previous = sections.get(section.section_id)
        if previous is None or len(section.text) > len(previous.text):
            sections[section.section_id] = section

    for line in raw_text.splitlines():
        heading = _HEADING.match(line.strip())
        if heading is not None:
            kind, number, title = heading.group(1), heading.group(2), heading.group(3)
            title = _TOC_LEADER.sub("", title).strip()
            title = re.sub(r"\s{2,}\d+$", "", title).strip()
            if kind == "Chapter":
                chapter, part, division = (number, title), None, None
            elif kind == "Part":
                part, division = (number, title), None
            else:
                division = (number, title)
            continue

        section = _SECTION.match(line)
        if section is not None and not _TOC_LEADER.search(line):
            close(current)
            current = NormSection(
                section_id=section.group(1),
                title=section.group(2).strip(),
                chapter_no=chapter[0] if chapter else None,
                chapter_title=chapter[1] if chapter else None,
                part_no=part[0] if part else None,
                part_title=part[1] if part else None,
                division_no=division[0] if division else None,
                division_title=division[1] if division else None,
            )
            continue

        if current is not None and _is_body_line(line):
            current.lines.append(line.rstrip())

    close(current)
    return sections


def load_regulation_text(pdf_path: str) -> str:
    """Extract layout-preserving text from the regulation PDF.

    ``pdftotext -layout`` is used rather than a Python PDF library because the
    numbered-paragraph indentation is load-bearing for the section parser, and
    layout mode is the only extraction mode that preserves it reliably here.
    """

    import shutil
    import subprocess

    if shutil.which("pdftotext") is None:  # pragma: no cover - environment guard
        raise RuntimeError(
            "pdftotext not found; install poppler-utils or pass pre-extracted text"
        )
    completed = subprocess.run(
        ["pdftotext", "-layout", pdf_path, "-"],
        capture_output=True,
        text=True,
        check=True,
    )
    return completed.stdout
