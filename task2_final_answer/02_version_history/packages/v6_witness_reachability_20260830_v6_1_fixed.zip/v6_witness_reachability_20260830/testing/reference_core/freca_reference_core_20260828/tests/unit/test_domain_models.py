from __future__ import annotations

import unittest

from pydantic import ValidationError

from freca.domain.enums import (
    Applicability,
    ClaimStatus,
    ClaimType,
    DecisionBasis,
    FinalLabel,
    GateDecision,
    GateSeverity,
    Sufficiency,
    VerificationIssueCode,
)
from freca.domain.models import (
    AuditArgument,
    AuditClaim,
    FinalDecision,
    GateReport,
    RetrievalNeed,
    VerificationIssue,
)


class FinalDecisionTests(unittest.TestCase):
    def test_compliant_decision_requires_supported_applicable_evidence(self) -> None:
        decision = FinalDecision(
            case_id="FRECA-T2-S096",
            cp_id="CP22",
            label=FinalLabel.COMPLIANT,
            applicability=Applicability.APPLICABLE,
            sufficiency=Sufficiency.SUFFICIENT,
            basis=DecisionBasis.COMPLIANT_EVIDENCE,
            supporting_evidence_ids=["ev-1"],
            argument_id="arg-1",
            gate_report_ids=["gate-1"],
            reasoning_summary="已验证证据覆盖全部必要事实。",
        )
        self.assertEqual(decision.label, FinalLabel.COMPLIANT)

    def test_missing_evidence_cannot_be_na(self) -> None:
        with self.assertRaises(ValidationError):
            FinalDecision(
                case_id="FRECA-T2-S096",
                cp_id="CP22",
                label=FinalLabel.NOT_APPLICABLE,
                applicability=Applicability.APPLICABLE,
                sufficiency=Sufficiency.INSUFFICIENT,
                basis=DecisionBasis.MISSING_REQUIRED_EVIDENCE,
                argument_id="arg-1",
                gate_report_ids=["gate-1"],
                review_required=True,
                reasoning_summary="没有找到材料。",
            )

    def test_missing_evidence_zero_requires_review(self) -> None:
        with self.assertRaises(ValidationError):
            FinalDecision(
                case_id="FRECA-T2-S096",
                cp_id="CP22",
                label=FinalLabel.NON_COMPLIANT,
                applicability=Applicability.APPLICABLE,
                sufficiency=Sufficiency.INSUFFICIENT,
                basis=DecisionBasis.MISSING_REQUIRED_EVIDENCE,
                argument_id="arg-1",
                gate_report_ids=["gate-1"],
                review_required=False,
                reasoning_summary="适用但缺少必要证据。",
            )

    def test_explicit_na_requires_supporting_evidence(self) -> None:
        with self.assertRaises(ValidationError):
            FinalDecision(
                case_id="FRECA-T2-S096",
                cp_id="CP22",
                label=FinalLabel.NOT_APPLICABLE,
                applicability=Applicability.NOT_APPLICABLE,
                sufficiency=Sufficiency.SUFFICIENT,
                basis=DecisionBasis.EXPLICIT_NON_APPLICABILITY,
                argument_id="arg-1",
                gate_report_ids=["gate-1"],
                reasoning_summary="法规明确不适用。",
            )


class GateReportTests(unittest.TestCase):
    def test_retry_requires_actionable_issue(self) -> None:
        issue = VerificationIssue(
            issue_id="issue-1",
            code=VerificationIssueCode.UNGROUNDED,
            message="保存期限缺少出处。",
            retryable=True,
            retrieval_need=RetrievalNeed(
                fact_type="retention_period",
                query_facets=["保存期限", "两年"],
            ),
        )
        report = GateReport(
            gate_id="gate-1",
            gate_name="argument_grounding",
            decision=GateDecision.RETRY,
            severity=GateSeverity.HARD,
            issues=[issue],
        )
        self.assertEqual(report.decision, GateDecision.RETRY)

    def test_pass_cannot_hide_issues(self) -> None:
        issue = VerificationIssue(
            issue_id="issue-1",
            code=VerificationIssueCode.CONTRADICTION,
            message="两条证据相互冲突。",
            retryable=False,
        )
        with self.assertRaises(ValidationError):
            GateReport(
                gate_id="gate-1",
                gate_name="argument_consistency",
                decision=GateDecision.PASS,
                severity=GateSeverity.HARD,
                issues=[issue],
            )


class AuditArgumentTests(unittest.TestCase):
    def test_claim_dependencies_must_be_acyclic(self) -> None:
        claim_a = AuditClaim(
            claim_id="claim-a",
            claim_type=ClaimType.EVIDENCE,
            proposition={"predicate": "has_record"},
            depends_on=["claim-b"],
            status=ClaimStatus.UNVERIFIED,
        )
        claim_b = AuditClaim(
            claim_id="claim-b",
            claim_type=ClaimType.VERDICT,
            proposition={"predicate": "is_compliant"},
            depends_on=["claim-a"],
            status=ClaimStatus.UNVERIFIED,
        )
        with self.assertRaises(ValidationError):
            AuditArgument(
                argument_id="arg-1",
                case_id="FRECA-T2-S096",
                cp_id="CP22",
                claims=[claim_a, claim_b],
                candidate_label=FinalLabel.COMPLIANT,
                sufficiency=Sufficiency.SUFFICIENT,
            )


if __name__ == "__main__":
    unittest.main()

