"""Complete frozen B00-B31 experiment registry.

Registration preserves methods for reproducible A/B work; it is not itself a
claim that an arm is accurate or production-admissible.
"""

from __future__ import annotations

from pydantic import Field

from freca.domain.models import StrictModel
from freca.search.registry import default_search_arm_registry


class ExperimentArm(StrictModel):
    arm_id: str = Field(pattern=r"^B(?:0[0-9]|[12][0-9]|3[01])$")
    name: str
    category: str
    production_candidate: bool = False
    research_only: bool = True
    changes_production_policy: bool = False


def full_ab_registry() -> list[ExperimentArm]:
    search_specs = default_search_arm_registry()
    arms = [
        ExperimentArm(
            arm_id=spec.strategy.value[:3],
            name=spec.strategy.value[4:],
            category="SEARCH" if spec.tree_based else "NON_TREE_BASELINE",
            production_candidate=spec.production_eligible_by_default,
            research_only=not spec.production_eligible_by_default,
        )
        for spec in search_specs
    ]
    arms.extend(
        [
            ExperimentArm(
                arm_id="B18",
                name="TEAM_B_SAME_CONTEXT_SELF_CRITIQUE",
                category="TEAM_B_NEGATIVE_BASELINE",
            ),
            ExperimentArm(arm_id="B19", name="TEAM_B_BLIND_SAME_MODEL", category="TEAM_B"),
            ExperimentArm(
                arm_id="B20",
                name="TEAM_B_TOOL_INDEPENDENT",
                category="TEAM_B",
                production_candidate=True,
                research_only=False,
            ),
            ExperimentArm(
                arm_id="B21",
                name="TEAM_B_DIFFERENT_MODEL_AND_TOOL",
                category="TEAM_B",
                production_candidate=True,
                research_only=False,
            ),
            ExperimentArm(
                arm_id="B22",
                name="TEAM_B_REFERENCE_EVALUATOR",
                category="TEAM_B",
                production_candidate=True,
                research_only=False,
            ),
            ExperimentArm(
                arm_id="B23", name="BRANCH_INTERSECTION_GROUNDED", category="BRANCH_GENERATION"
            ),
            ExperimentArm(
                arm_id="B24",
                name="BRANCH_CONFORMANCE_PRODUCTION",
                category="BRANCH_GENERATION",
                production_candidate=True,
                research_only=False,
            ),
            ExperimentArm(arm_id="B25", name="BRANCH_UNION_GROUNDED", category="BRANCH_GENERATION"),
            ExperimentArm(
                arm_id="B26",
                name="BRANCH_PRIMARY_ONLY_NEGATIVE_BASELINE",
                category="BRANCH_GENERATION",
            ),
            ExperimentArm(
                arm_id="B27",
                name="FOLD_PREFER_NA_APPLICABILITY",
                category="FOLD",
                production_candidate=True,
                research_only=False,
            ),
            ExperimentArm(arm_id="B28", name="FOLD_PREFER_ONE_NONVIOLATION", category="FOLD"),
            ExperimentArm(arm_id="B29", name="INDEXED_AST_ONLY", category="EVIDENCE_CHAIN"),
            ExperimentArm(
                arm_id="B30", name="CARNEADES_ONLY_NEGATIVE_BASELINE", category="EVIDENCE_CHAIN"
            ),
            ExperimentArm(
                arm_id="B31",
                name="HYBRID_DUAL_CONFORMANCE",
                category="EVIDENCE_CHAIN",
                production_candidate=True,
                research_only=False,
            ),
        ]
    )
    expected = {f"B{index:02d}" for index in range(32)}
    actual = {arm.arm_id for arm in arms}
    if actual != expected or len(actual) != len(arms):
        raise RuntimeError(
            f"A/B registry incomplete or duplicated: missing={sorted(expected - actual)}"
        )
    return sorted(arms, key=lambda arm: arm.arm_id)
