from __future__ import annotations

from freca.evaluation.v0 import (
    compare_perturbations,
    detect_prompt_leakage,
    evaluate_gold,
    load_labels,
)


def _row(case: str, cp: str, label: str, *, synthetic: bool = False) -> dict[str, object]:
    return {"case_id": case, "cp_id": cp, "label": label, "synthetic": synthetic}


def test_no_gold_is_explicitly_not_scored() -> None:
    result = evaluate_gold([_row("c1", "CP1", "1")], None)
    assert result.status == "NO_GOLD"
    assert result.accuracy is None


def test_gold_loader_accepts_the_playbook_gold_label_column(tmp_path) -> None:
    path = tmp_path / "gold.jsonl"
    path.write_text('{"case_id":"c1","cp_id":"CP1","gold_label":"N/A"}\n', encoding="utf-8")
    assert load_labels(path) == {("c1", "CP1"): "N/A"}


def test_gold_excludes_blocked_cells_and_reports_partial_coverage() -> None:
    result = evaluate_gold(
        [_row("c1", "CP1", "1"), _row("c1", "CP2", "")],
        {("c1", "CP1"): "1", ("c1", "CP2"): "0"},
    )
    assert result.status == "PARTIAL"
    assert result.n_compared == 1
    assert result.accuracy == 1.0
    assert result.missing_predictions == ["c1/CP2"]


def test_perturbation_stability_is_measured_only_on_paired_decisions() -> None:
    result = compare_perturbations(
        [_row("c1", "CP1", "1"), _row("c1", "CP2", "0")],
        [_row("c1", "CP1", "0"), _row("c1", "CP2", "0")],
    )
    assert result.n_pairs == 2
    assert result.n_changed == 1
    assert result.stability == 0.5


def test_leakage_detector_flags_oracle_language_but_not_output_schema() -> None:
    findings = detect_prompt_leakage(
        [
            {"prompt": 'Reply with {"label": "1"|"0"|"N/A"}'},
            {"prompt": "The gold label is 1"},
        ]
    )
    assert [(item.location, item.marker) for item in findings] == [("row[1]", "gold label")]
