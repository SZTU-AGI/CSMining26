"""Cluster copied/derived evidence so duplicates cannot masquerade as corroboration."""

from __future__ import annotations

from pydantic import Field

from freca.domain.models import SafeId, Sha256, StrictModel
from freca.harness.artifact_store import sha256_digest


class EvidenceLineageItem(StrictModel):
    evidence_id: SafeId
    source_sha256: Sha256
    represented_from_evidence_ids: list[SafeId] = Field(default_factory=list)
    template_family_id: SafeId | None = None


class EvidenceLineageCluster(StrictModel):
    cluster_id: SafeId
    evidence_ids: list[SafeId]
    source_sha256_values: list[Sha256]
    template_family_ids: list[SafeId]
    independent_source_count: int
    cluster_sha256: Sha256


def cluster_evidence_lineage(items: list[EvidenceLineageItem]) -> list[EvidenceLineageCluster]:
    by_id = {item.evidence_id: item for item in items}
    if len(by_id) != len(items):
        raise ValueError("evidence IDs must be unique")
    parent = {item.evidence_id: item.evidence_id for item in items}

    def find(item_id: str) -> str:
        while parent[item_id] != item_id:
            parent[item_id] = parent[parent[item_id]]
            item_id = parent[item_id]
        return item_id

    def union(left: str, right: str) -> None:
        left_root, right_root = find(left), find(right)
        if left_root != right_root:
            parent[max(left_root, right_root)] = min(left_root, right_root)

    hash_owner: dict[str, str] = {}
    template_owner: dict[str, str] = {}
    for item in items:
        if item.source_sha256 in hash_owner:
            union(item.evidence_id, hash_owner[item.source_sha256])
        else:
            hash_owner[item.source_sha256] = item.evidence_id
        if item.template_family_id:
            if item.template_family_id in template_owner:
                union(item.evidence_id, template_owner[item.template_family_id])
            else:
                template_owner[item.template_family_id] = item.evidence_id
        for source_id in item.represented_from_evidence_ids:
            if source_id not in by_id:
                raise ValueError(f"lineage references unknown evidence: {source_id}")
            union(item.evidence_id, source_id)

    groups: dict[str, list[EvidenceLineageItem]] = {}
    for item in items:
        groups.setdefault(find(item.evidence_id), []).append(item)
    clusters = []
    for members in sorted(
        groups.values(), key=lambda group: min(item.evidence_id for item in group)
    ):
        evidence_ids = sorted(item.evidence_id for item in members)
        hashes = sorted({item.source_sha256 for item in members})
        templates = sorted({item.template_family_id for item in members if item.template_family_id})
        # Derivatives and same-template copies count as one corroborating lineage.
        payload = {
            "evidence_ids": evidence_ids,
            "source_sha256_values": hashes,
            "template_family_ids": templates,
            "independent_source_count": 1,
        }
        digest = sha256_digest(payload)
        clusters.append(
            EvidenceLineageCluster(
                cluster_id=f"lineage-{digest.split(':', 1)[1][:20]}",
                cluster_sha256=digest,
                **payload,
            )
        )
    return clusters
