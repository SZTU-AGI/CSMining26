"""Original-text-anchored normative events for the Layer 2 contract slice."""

from __future__ import annotations

import re
from enum import StrEnum
from typing import Literal

from pydantic import Field, model_validator

from freca.domain.models import SafeId, Sha256, StrictModel
from freca.governance.hashing import sha256_digest
from freca.policy.schemas_v2 import PolicyIndex, PolicyLocator, PolicyUnit, PolicyUnitType


class NormSpanRole(StrEnum):
    MODALITY = "MODALITY"
    ACTOR = "ACTOR"
    PREDICATE = "PREDICATE"
    OBJECT = "OBJECT"
    CONDITION = "CONDITION"
    EXCEPTION = "EXCEPTION"
    TEMPORAL = "TEMPORAL"
    SCOPE = "SCOPE"
    CONNECTOR = "CONNECTOR"
    DEEMING_RESULT = "DEEMING_RESULT"


class NormEventKind(StrEnum):
    OBLIGATION = "OBLIGATION"
    PROHIBITION = "PROHIBITION"
    PERMISSION = "PERMISSION"
    APPLICABILITY = "APPLICABILITY"
    EXCEPTION = "EXCEPTION"
    DEEMING = "DEEMING"
    RECORDKEEPING = "RECORDKEEPING"
    OTHER_NORMATIVE = "OTHER_NORMATIVE"


class NormModality(StrEnum):
    MUST = "MUST"
    MUST_NOT = "MUST_NOT"
    IS_REQUIRED_TO = "IS_REQUIRED_TO"
    MAY_ONLY = "MAY_ONLY"
    MAY = "MAY"
    PROHIBITED = "PROHIBITED"
    TAKEN_TO = "TAKEN_TO"
    NONE = "NONE"


class NormVoice(StrEnum):
    ACTIVE = "ACTIVE"
    PASSIVE = "PASSIVE"
    EXISTENTIAL = "EXISTENTIAL"
    NOMINAL = "NOMINAL"
    OTHER = "OTHER"


class RuleSetRelation(StrEnum):
    CUMULATIVE = "CUMULATIVE"
    ALTERNATIVE = "ALTERNATIVE"
    SPECIALIZES = "SPECIALIZES"
    SUPPORTS_SAME_CRITERION = "SUPPORTS_SAME_CRITERION"
    CONTEXT_ONLY = "CONTEXT_ONLY"
    CONTESTED = "CONTESTED"


class NormSpanBinding(StrictModel):
    binding_id: SafeId
    role: NormSpanRole
    policy_unit_id: SafeId
    locator: PolicyLocator
    exact_raw_text: str = Field(min_length=1)
    normalized_text: str = Field(min_length=1)
    match_mode: Literal["EXACT_RAW", "WHITESPACE_NORMALIZED"] = "EXACT_RAW"
    binding_sha256: Sha256


class NormEvent(StrictModel):
    event_id: SafeId
    event_kind: NormEventKind
    modality: NormModality
    voice: NormVoice
    actor_entity_ids: list[SafeId] = Field(default_factory=list)
    source_policy_unit_id: SafeId
    span_binding_ids: list[SafeId] = Field(min_length=1)
    parent_event_id: SafeId | None = None
    child_event_ids: list[SafeId] = Field(default_factory=list)
    reference_ids: list[SafeId] = Field(default_factory=list)
    extraction_method: Literal["RULE", "MODEL_ASSISTED"] = "RULE"
    extraction_status: Literal["COMPLETE", "PARTIAL", "AMBIGUOUS"]
    issue_ids: list[SafeId] = Field(default_factory=list)
    event_sha256: Sha256


class NormEventGroup(StrictModel):
    group_id: SafeId
    parent_event_id: SafeId
    child_event_ids: list[SafeId] = Field(min_length=2)
    connector_binding_ids: list[SafeId] = Field(min_length=1)
    aggregation_operator: Literal["ALL_OF", "ANY_OF"]
    rule_set_relation: RuleSetRelation
    compile_rule_id: Literal["EXPLICIT_CHAPEAU_ENUM_CONNECTOR_V1"]
    group_sha256: Sha256


class NormEventBundle(StrictModel):
    bundle_id: SafeId
    cp_id: str = Field(min_length=1)
    source_policy_unit_ids: list[SafeId]
    span_bindings: list[NormSpanBinding]
    events: list[NormEvent]
    event_groups: list[NormEventGroup] = Field(default_factory=list)
    unresolved_policy_unit_ids: list[SafeId] = Field(default_factory=list)
    review_required_reason_codes: list[str] = Field(default_factory=list)
    bundle_sha256: Sha256

    @model_validator(mode="after")
    def references_are_internal(self) -> NormEventBundle:
        binding_by_id = {item.binding_id: item for item in self.span_bindings}
        if len(binding_by_id) != len(self.span_bindings):
            raise ValueError("norm span binding IDs must be unique")
        event_by_id = {item.event_id: item for item in self.events}
        if len(event_by_id) != len(self.events):
            raise ValueError("norm event IDs must be unique")
        for event in self.events:
            unknown_bindings = set(event.span_binding_ids) - binding_by_id.keys()
            linked_ids = set(event.child_event_ids)
            if event.parent_event_id:
                linked_ids.add(event.parent_event_id)
            unknown_events = linked_ids - event_by_id.keys()
            if unknown_bindings:
                raise ValueError(
                    f"norm event {event.event_id} has unknown bindings: {sorted(unknown_bindings)}"
                )
            if unknown_events:
                raise ValueError(
                    f"norm event {event.event_id} has unknown event links: {sorted(unknown_events)}"
                )
        for group in self.event_groups:
            if group.parent_event_id not in event_by_id:
                raise ValueError(f"norm event group {group.group_id} has unknown parent")
            if set(group.child_event_ids) - event_by_id.keys():
                raise ValueError(f"norm event group {group.group_id} has unknown children")
            for binding_id in group.connector_binding_ids:
                binding = binding_by_id.get(binding_id)
                if binding is None or binding.role is not NormSpanRole.CONNECTOR:
                    raise ValueError(f"norm event group {group.group_id} has ungrounded connector")
        return self


class _EventGroupSpec(StrictModel):
    parent_unit_id: SafeId
    child_unit_ids: list[SafeId] = Field(min_length=2)
    connector_unit_id: SafeId
    connector_exact_text: str = Field(min_length=1)
    aggregation_operator: Literal["ALL_OF", "ANY_OF"]
    rule_set_relation: RuleSetRelation


_ALL_PHRASES = ("all of the following", "all of")
_ANY_PHRASES = ("one or more of the following", "any of the following", "any of")
_NON_EXHAUSTIVE_PHRASES = ("including but not limited to", "for example")
_TRAILING_CONNECTOR = re.compile(r"(?:;|,)\s*(and|or)\s*$", re.IGNORECASE)
_INELIGIBLE_ENUM_TYPES = {PolicyUnitType.NOTE, PolicyUnitType.EXAMPLE}


def _stable_id(prefix: str, payload: object) -> str:
    return f"{prefix}-{sha256_digest(payload).split(':', 1)[1][:20]}"


def _issue_id(cp_id: str, unit_id: str, code: str) -> str:
    return _stable_id("normissue", {"cp_id": cp_id, "unit_id": unit_id, "code": code})


def _exact_phrase(raw_text: str, phrases: tuple[str, ...]) -> str | None:
    folded = raw_text.casefold()
    for phrase in phrases:
        start = folded.find(phrase)
        if start >= 0:
            return raw_text[start : start + len(phrase)]
    return None


def _connector_from_group(
    parent: PolicyUnit,
    children: list[PolicyUnit],
) -> tuple[str, str, Literal["ALL_OF", "ANY_OF"], RuleSetRelation] | None:
    if _exact_phrase(parent.own_raw_text, _NON_EXHAUSTIVE_PHRASES):
        return None
    phrase = _exact_phrase(parent.own_raw_text, _ALL_PHRASES)
    if phrase:
        return parent.unit_id, phrase, "ALL_OF", RuleSetRelation.CUMULATIVE
    phrase = _exact_phrase(parent.own_raw_text, _ANY_PHRASES)
    if phrase:
        return parent.unit_id, phrase, "ANY_OF", RuleSetRelation.ALTERNATIVE

    trailing: list[tuple[PolicyUnit, str]] = []
    for child in children:
        match = _TRAILING_CONNECTOR.search(child.own_raw_text)
        if match:
            trailing.append((child, match.group(1)))
    kinds = {text.casefold() for _unit, text in trailing}
    if len(kinds) != 1 or not trailing:
        return None
    connector_unit, connector = trailing[-1]
    if connector.casefold() == "and":
        return connector_unit.unit_id, connector, "ALL_OF", RuleSetRelation.CUMULATIVE
    return connector_unit.unit_id, connector, "ANY_OF", RuleSetRelation.ALTERNATIVE


def _detect_event_groups(
    policy: PolicyIndex,
    selected_unit_ids: set[str],
) -> tuple[list[_EventGroupSpec], set[str]]:
    by_id = {unit.unit_id: unit for unit in policy.units}
    order = {unit.unit_id: index for index, unit in enumerate(policy.units)}
    children_by_parent: dict[str, list[PolicyUnit]] = {}
    for unit_id in selected_unit_ids:
        unit = by_id.get(unit_id)
        if unit is None or unit.parent_id is None or unit.unit_type in _INELIGIBLE_ENUM_TYPES:
            continue
        children_by_parent.setdefault(unit.parent_id, []).append(unit)

    specs: list[_EventGroupSpec] = []
    ambiguous_parents: set[str] = set()
    for parent_id, children in sorted(children_by_parent.items()):
        if len(children) < 2:
            continue
        parent = by_id.get(parent_id)
        if parent is None or not parent.normative or parent.unit_type in _INELIGIBLE_ENUM_TYPES:
            ambiguous_parents.add(parent_id)
            continue
        children.sort(key=lambda item: (order.get(item.unit_id, len(order)), item.unit_id))
        connector = _connector_from_group(parent, children)
        if connector is None:
            ambiguous_parents.add(parent_id)
            continue
        connector_unit_id, connector_text, operator, relation = connector
        specs.append(
            _EventGroupSpec(
                parent_unit_id=parent_id,
                child_unit_ids=[item.unit_id for item in children],
                connector_unit_id=connector_unit_id,
                connector_exact_text=connector_text,
                aggregation_operator=operator,
                rule_set_relation=relation,
            )
        )
    return specs, ambiguous_parents


def _classify(unit: PolicyUnit, relation: str) -> tuple[NormEventKind, NormModality, list[str]]:
    text = unit.normalized_text.casefold()
    if "must not" in text:
        return NormEventKind.PROHIBITION, NormModality.MUST_NOT, []
    if "is required to" in text:
        return NormEventKind.OBLIGATION, NormModality.IS_REQUIRED_TO, []
    if "may only" in text:
        return NormEventKind.PERMISSION, NormModality.MAY_ONLY, []
    if "is prohibited" in text:
        return NormEventKind.PROHIBITION, NormModality.PROHIBITED, []
    if "is taken to" in text or "taken to have" in text:
        return NormEventKind.DEEMING, NormModality.TAKEN_TO, []
    if relation == "APPLICABILITY":
        return NormEventKind.APPLICABILITY, NormModality.NONE, []
    if relation == "EXCEPTION_OR_DEEMING":
        return NormEventKind.EXCEPTION, NormModality.NONE, []
    if "must" in text:
        return NormEventKind.OBLIGATION, NormModality.MUST, []
    if "may" in text:
        return NormEventKind.PERMISSION, NormModality.MAY, []
    return (
        NormEventKind.OTHER_NORMATIVE,
        NormModality.NONE,
        ["NORMATIVE_MODALITY_UNRESOLVED"],
    )


def _binding(
    unit: PolicyUnit,
    *,
    role: NormSpanRole,
    exact_raw_text: str | None = None,
) -> NormSpanBinding | None:
    raw_text = unit.own_raw_text if exact_raw_text is None else exact_raw_text
    if not raw_text.strip() or raw_text not in unit.full_raw_text:
        return None
    payload = {
        "role": role,
        "policy_unit_id": unit.unit_id,
        "locator": unit.locator,
        "exact_raw_text": raw_text,
        "normalized_text": " ".join(raw_text.split()),
        "match_mode": "EXACT_RAW",
    }
    return NormSpanBinding(
        binding_id=_stable_id("normspan", payload),
        binding_sha256=sha256_digest(payload),
        **payload,
    )


def _event_id(cp_id: str, unit_id: str, role: str) -> str:
    return _stable_id(
        "normevent",
        {"cp_id": cp_id, "source_policy_unit_id": unit_id, "event_role": role},
    )


def build_norm_event_bundle(
    *,
    cp_id: str,
    policy: PolicyIndex,
    policy_unit_ids: list[str],
    relation_by_unit_id: dict[str, str],
) -> NormEventBundle:
    """Create replayable events without consulting CP-specific rules or case evidence."""

    by_id = {unit.unit_id: unit for unit in policy.units}
    selected_ids = set(policy_unit_ids)
    detected_group_specs, ambiguous_parents = _detect_event_groups(policy, selected_ids)
    bindings: list[NormSpanBinding] = []
    events: list[NormEvent] = []
    event_groups: list[NormEventGroup] = []
    unresolved: set[str] = set()
    review_codes: set[str] = set()

    for parent_id in sorted(ambiguous_parents):
        review_codes.add("COORDINATION_AMBIGUOUS")
        if parent_id not in by_id:
            unresolved.add(parent_id)

    group_inputs: list[tuple[_EventGroupSpec, NormSpanBinding, NormSpanBinding]] = []
    for spec in detected_group_specs:
        parent = by_id[spec.parent_unit_id]
        connector_unit = by_id[spec.connector_unit_id]
        parent_binding = _binding(parent, role=NormSpanRole.PREDICATE)
        connector_binding = _binding(
            connector_unit,
            role=NormSpanRole.CONNECTOR,
            exact_raw_text=spec.connector_exact_text,
        )
        if parent_binding is None or connector_binding is None:
            unresolved.add(spec.parent_unit_id)
            review_codes.add("ORIGINAL_TEXT_ANCHOR_REPLAY_FAILED")
            continue
        group_inputs.append((spec, parent_binding, connector_binding))

    group_specs = [spec for spec, _parent, _connector in group_inputs]
    spec_by_child = {child_id: spec for spec in group_specs for child_id in spec.child_unit_ids}

    event_ids = {
        unit_id: _event_id(cp_id, unit_id, "ENUM_CHILD" if unit_id in spec_by_child else "PRIMARY")
        for unit_id in selected_ids
        if unit_id in by_id
    }
    for spec in group_specs:
        event_ids[spec.parent_unit_id] = _event_id(cp_id, spec.parent_unit_id, "CHAPEAU")

    for spec, parent_binding, connector_binding in group_inputs:
        parent = by_id[spec.parent_unit_id]
        kind, modality, issues = _classify(parent, "PRIMARY_NORM")
        parent_issue_ids = [_issue_id(cp_id, parent.unit_id, code) for code in issues]
        child_event_ids = [event_ids[unit_id] for unit_id in spec.child_unit_ids]
        event_payload = {
            "event_kind": kind,
            "modality": modality,
            "voice": NormVoice.OTHER,
            "actor_entity_ids": [],
            "source_policy_unit_id": parent.unit_id,
            "span_binding_ids": [parent_binding.binding_id],
            "parent_event_id": None,
            "child_event_ids": child_event_ids,
            "reference_ids": [],
            "extraction_method": "RULE",
            "extraction_status": "AMBIGUOUS" if issues else "COMPLETE",
            "issue_ids": parent_issue_ids,
        }
        bindings.extend([parent_binding, connector_binding])
        events.append(
            NormEvent(
                event_id=event_ids[parent.unit_id],
                event_sha256=sha256_digest(event_payload),
                **event_payload,
            )
        )
        review_codes.update(issues)

        group_payload = {
            "parent_event_id": event_ids[parent.unit_id],
            "child_event_ids": child_event_ids,
            "connector_binding_ids": [connector_binding.binding_id],
            "aggregation_operator": spec.aggregation_operator,
            "rule_set_relation": spec.rule_set_relation,
            "compile_rule_id": "EXPLICIT_CHAPEAU_ENUM_CONNECTOR_V1",
        }
        event_groups.append(
            NormEventGroup(
                group_id=_stable_id("normgroup", group_payload),
                group_sha256=sha256_digest(group_payload),
                **group_payload,
            )
        )

    for unit_id in sorted(selected_ids):
        unit = by_id.get(unit_id)
        if unit is None or not unit.normative:
            unresolved.add(unit_id)
            review_codes.add("NORMATIVE_POLICY_UNIT_UNAVAILABLE")
            continue
        spec = spec_by_child.get(unit_id)
        binding = _binding(
            unit,
            role=NormSpanRole.OBJECT if spec else NormSpanRole.PREDICATE,
        )
        if binding is None:
            unresolved.add(unit_id)
            review_codes.add("ORIGINAL_TEXT_ANCHOR_REPLAY_FAILED")
            continue
        if spec:
            parent = by_id[spec.parent_unit_id]
            kind, modality, issues = _classify(parent, "PRIMARY_NORM")
            parent_event_id = event_ids[parent.unit_id]
        else:
            relation = relation_by_unit_id.get(unit_id, "UNRESOLVED")
            kind, modality, issues = _classify(unit, relation)
            parent_event_id = None
        issue_ids = [_issue_id(cp_id, unit_id, code) for code in issues]
        event_payload = {
            "event_kind": kind,
            "modality": modality,
            "voice": NormVoice.OTHER,
            "actor_entity_ids": [],
            "source_policy_unit_id": unit.unit_id,
            "span_binding_ids": [binding.binding_id],
            "parent_event_id": parent_event_id,
            "child_event_ids": [],
            "reference_ids": [],
            "extraction_method": "RULE",
            "extraction_status": "AMBIGUOUS" if issues else "COMPLETE",
            "issue_ids": issue_ids,
        }
        bindings.append(binding)
        events.append(
            NormEvent(
                event_id=event_ids[unit_id],
                event_sha256=sha256_digest(event_payload),
                **event_payload,
            )
        )
        review_codes.update(issues)

    source_ids = selected_ids | {spec.parent_unit_id for spec in group_specs}
    payload = {
        "cp_id": cp_id,
        "source_policy_unit_ids": sorted(source_ids),
        "span_bindings": sorted(bindings, key=lambda item: item.binding_id),
        "events": sorted(events, key=lambda item: item.event_id),
        "event_groups": sorted(event_groups, key=lambda item: item.group_id),
        "unresolved_policy_unit_ids": sorted(unresolved),
        "review_required_reason_codes": sorted(review_codes),
    }
    digest = sha256_digest(payload)
    return NormEventBundle(
        bundle_id=f"normbundle-{digest.split(':', 1)[1][:20]}",
        bundle_sha256=digest,
        **payload,
    )
