"""Domain-specific errors for storage and workflow invariants."""


class FrecaError(Exception):
    """Base exception for expected FRECA failures."""


class ArtifactStoreError(FrecaError):
    """Base exception for artifact storage failures."""


class ArtifactNotFoundError(ArtifactStoreError):
    """Raised when an artifact record does not exist."""


class ArtifactConflictError(ArtifactStoreError):
    """Raised when an existing artifact id is reused with different content."""


class CorruptArtifactError(ArtifactStoreError):
    """Raised when a stored artifact fails parsing or hash validation."""

