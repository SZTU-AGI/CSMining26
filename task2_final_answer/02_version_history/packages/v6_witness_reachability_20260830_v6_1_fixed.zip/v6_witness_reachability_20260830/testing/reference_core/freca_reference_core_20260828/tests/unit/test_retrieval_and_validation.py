"""Tests for evidence retrieval and the deterministic argument validator.

Fixtures are built in-process. The point of each test is stated in its docstring
because several assert *absences* (no leakage, no over-pruning) that would
otherwise look arbitrary.
"""

from __future__ import annotations

import pytest

from freca.domain.enums import (
    ClaimRelation,
    ClaimStatus,
    ClaimType,
    EvidenceIdentityState,
    FinalLabel,
    GateDecision,
    PremiseSourceType,
    Sufficiency,
    VerificationIssueCode,
)
from freca.domain.models import (
    AuditArgument,
    AuditClaim,
    ClaimPremise,
    EvidenceAtom,
    EvidenceLocator,
    IdentityAssessment,
)
from freca.retrieval.evidence_index import (
    EVIDENCE_CONFIGS,
    CaseEvidenceIndex,
    HashingVectorIndex,
    build_query,
    with_top_k,
)
from freca.verification.argument_validator import ArgumentValidator, ValidationContext

HASH = "sha256:" + "ab" * 32


def atom(
    evidence_id: str,
    content: str,
    *,
    case_id: str = "CASE-1",
    doc_id: str = "CASE-1.T1",
    track: str = "T1",
    state: EvidenceIdentityState = EvidenceIdentityState.SELF,
    paragraph: int = 0,
) -> EvidenceAtom:
    return EvidenceAtom(
        evidence_id=evidence_id,
        case_id=case_id,
        doc_id=doc_id,
        track=track,
        source_type="docx.section",
        locator=EvidenceLocator(document_path=f"/{doc_id}.docx", paragraph_index=paragraph),
        content=content,
        identity=IdentityAssessment(state=state),
        source_hash=HASH,
        parse_confidence=1.0,
    )


@pytest.fixture
def index() -> CaseEvidenceIndex:
    return CaseEvidenceIndex(
        [
            atom("a1", "Fumigation treatment applied to stored chickpeas on 2024-03-02"),
            atom("a2", "Fumigation treatment applied to stored chickpeas on 2024-03-09", paragraph=1),
            atom("a3", "Pest monitoring inspection completed monthly by the occupier",
                 doc_id="CASE-1.T7", track="T7"),
            atom("a4", "Calibration certificate for the moisture meter",
                 doc_id="CASE-1.T6", track="T6"),
            atom("a5", "Fumigation treatment record signed by Midwest Grain Holdings",
                 doc_id="CASE-1.T3", track="T3", state=EvidenceIdentityState.FOREIGN),
        ]
    )


# -- retrieval --------------------------------------------------------------


def test_dense_index_is_deterministic_across_instances() -> None:
    """A seeded hashing vectoriser must not depend on process-level hash salt.

    Python's builtin ``hash()`` is randomised per interpreter, which would make
    every run produce a different vector-only ranking and silently destroy
    reproducibility. blake2b removes that.
    """

    documents = {"x": "fumigation record", "y": "calibration certificate"}
    first = HashingVectorIndex(documents).score("fumigation")
    second = HashingVectorIndex(documents).score("fumigation")
    assert [hit.doc_id for hit in first] == [hit.doc_id for hit in second]
    assert first[0].doc_id == "x"


def test_source_aware_mmr_beats_top_k_on_source_diversity(index: CaseEvidenceIndex) -> None:
    """Near-duplicate rows must not monopolise the selected set.

    a1 and a2 differ only by date and come from the same document; a plain top-k
    happily takes both, which spends a citation slot on no new information.
    """

    plain = index.retrieve("fumigation treatment", config_name="rrf_reranker_no_mmr")
    diverse = index.retrieve("fumigation treatment", config_name="full_retrieval")
    assert diverse.unique_sources >= plain.unique_sources
    assert diverse.selected[0].evidence_id in {"a1", "a2", "a5"}


def test_identity_penalty_demotes_but_does_not_delete(index: CaseEvidenceIndex) -> None:
    """Foreign-signed evidence must fall in rank yet stay reachable.

    Deleting it would make "the only fumigation record is signed by another
    establishment" unrepresentable, and that finding is the whole point of the
    T3 track.
    """

    config = with_top_k(EVIDENCE_CONFIGS["full_identity_aware"], 5)
    trace = index.retrieve("fumigation treatment record", config=config)
    ranks = {item.evidence_id: item.rank for item in trace.selected}
    assert "a5" in ranks, "foreign atom must remain retrievable"
    assert any("identity" in item.penalties for item in trace.selected if item.evidence_id == "a5")


def test_hard_filter_removes_foreign_identity(index: CaseEvidenceIndex) -> None:
    """The hard-filter ablation is the contrast case, and must actually differ."""

    trace = index.retrieve("fumigation treatment record", config_name="full_identity_hard_filter")
    assert "a5" not in trace.evidence_ids
    assert "FOREIGN" not in trace.identity_states


def test_retrieval_is_scoped_to_allowed_ids(index: CaseEvidenceIndex) -> None:
    """Restricting the pool must be honoured — this is the leakage guard's basis."""

    trace = index.retrieve("fumigation", allowed_ids={"a3", "a4"})
    assert set(trace.evidence_ids) <= {"a3", "a4"}


def test_every_config_is_runnable_and_recorded(index: CaseEvidenceIndex) -> None:
    """An ablation table with an unrunnable row is worse than no table."""

    for name in EVIDENCE_CONFIGS:
        trace = index.retrieve("pest control record", config_name=name)
        assert trace.selected
        assert trace.to_dict()["config"]["recall_mode"]
        assert trace.dense_backend == "synthetic_dense_hashing_v1"


def test_build_query_deduplicates_facets() -> None:
    assert build_query("pest control", "", "pest control", "records") == "pest control records"


# -- validator --------------------------------------------------------------


def context(index: CaseEvidenceIndex) -> ValidationContext:
    return ValidationContext(
        case_id="CASE-1",
        evidence=dict(index.atoms),
        policy_source_ids={"s11-5", "s11-7"},
        deterministic_result_ids={"det.dates"},
    )


def _compliant_argument(**overrides: object) -> AuditArgument:
    claims = [
        AuditClaim(
            claim_id="c1",
            claim_type=ClaimType.POLICY,
            proposition={"requirement": "occupier must keep fumigation records"},
            premises=[
                ClaimPremise(
                    source_type=PremiseSourceType.POLICY_SOURCE,
                    source_id="s11-5",
                    relation=ClaimRelation.REQUIRES,
                )
            ],
        ),
        AuditClaim(
            claim_id="c2",
            claim_type=ClaimType.EVIDENCE,
            proposition={"fact": "fumigation record exists for 2024-03-02"},
            premises=[
                ClaimPremise(
                    source_type=PremiseSourceType.CASE_EVIDENCE,
                    source_id="a1",
                    relation=ClaimRelation.SUPPORTS,
                )
            ],
        ),
        AuditClaim(
            claim_id="c3",
            claim_type=ClaimType.VERDICT,
            proposition={"label": "1"},
            depends_on=["c1", "c2"],
        ),
    ]
    payload: dict[str, object] = {
        "argument_id": "CASE-1.CP22",
        "case_id": "CASE-1",
        "cp_id": "CP22",
        "claims": claims,
        "candidate_label": FinalLabel.COMPLIANT,
        "sufficiency": Sufficiency.SUFFICIENT,
    }
    payload.update(overrides)
    return AuditArgument(**payload)  # type: ignore[arg-type]


def test_well_formed_argument_passes(index: CaseEvidenceIndex) -> None:
    report = ArgumentValidator().validate(_compliant_argument(), context(index))
    assert report.decision is GateDecision.PASS
    assert not report.issues


def test_hallucinated_citation_is_ungrounded_and_retryable(index: CaseEvidenceIndex) -> None:
    """An id that does not exist must fail closed-world, not be assumed plausible."""

    argument = _compliant_argument()
    argument.claims[1].premises = [
        ClaimPremise(
            source_type=PremiseSourceType.CASE_EVIDENCE,
            source_id="a99",
            relation=ClaimRelation.SUPPORTS,
        )
    ]
    report = ArgumentValidator().validate(argument, context(index))
    codes = {issue.code for issue in report.issues}
    assert VerificationIssueCode.UNGROUNDED in codes
    assert report.decision is GateDecision.RETRY
    assert all(issue.retrieval_need for issue in report.issues if issue.retryable)


def test_cross_case_citation_blocks(index: CaseEvidenceIndex) -> None:
    """Citing another case's evidence is leakage and must never be retried into a pass."""

    other = atom("b1", "Fumigation record", case_id="CASE-2", doc_id="CASE-2.T1")
    ctx = context(index)
    ctx.evidence["b1"] = other
    argument = _compliant_argument()
    argument.claims[1].premises = [
        ClaimPremise(
            source_type=PremiseSourceType.CASE_EVIDENCE,
            source_id="b1",
            relation=ClaimRelation.SUPPORTS,
        )
    ]
    report = ArgumentValidator().validate(argument, ctx)
    assert report.decision is GateDecision.BLOCK
    assert any(issue.code is VerificationIssueCode.CITATION_INVALID for issue in report.issues)


def test_compliant_with_standing_counter_evidence_contradicts(index: CaseEvidenceIndex) -> None:
    argument = _compliant_argument()
    argument.claims.append(
        AuditClaim(
            claim_id="c4",
            claim_type=ClaimType.COUNTER_EVIDENCE,
            proposition={"fact": "no record for the March consignment"},
            premises=[
                ClaimPremise(
                    source_type=PremiseSourceType.CASE_EVIDENCE,
                    source_id="a3",
                    relation=ClaimRelation.CONTRADICTS,
                )
            ],
            status=ClaimStatus.VERIFIED,
        )
    )
    report = ArgumentValidator().validate(argument, context(index))
    assert any(issue.code is VerificationIssueCode.CONTRADICTION for issue in report.issues)
    assert report.decision is GateDecision.ESCALATE


def test_compliant_from_insufficient_evidence_is_rejected(index: CaseEvidenceIndex) -> None:
    """Compliance may never be inferred from absence — the frozen 0-mapping rule."""

    argument = _compliant_argument(sufficiency=Sufficiency.INSUFFICIENT)
    report = ArgumentValidator().validate(argument, context(index))
    assert any(issue.code is VerificationIssueCode.INSUFFICIENT for issue in report.issues)


def test_identity_mismatch_is_soft_by_default_and_hard_when_configured(
    index: CaseEvidenceIndex,
) -> None:
    """Whether foreign signature blocks a pass is a switch, not a hidden constant."""

    argument = _compliant_argument()
    argument.claims[1].premises = [
        ClaimPremise(
            source_type=PremiseSourceType.CASE_EVIDENCE,
            source_id="a5",
            relation=ClaimRelation.SUPPORTS,
        )
    ]
    soft = ArgumentValidator(identity_is_hard=False).validate(argument, context(index))
    hard = ArgumentValidator(identity_is_hard=True).validate(argument, context(index))
    assert soft.decision is GateDecision.ESCALATE
    assert hard.decision is GateDecision.RETRY
    assert {issue.code for issue in soft.issues} == {VerificationIssueCode.IDENTITY_MISMATCH}


def test_na_without_cited_applicability_claim_is_ungrounded(index: CaseEvidenceIndex) -> None:
    argument = _compliant_argument(
        candidate_label=FinalLabel.NOT_APPLICABLE,
        claims=[
            AuditClaim(
                claim_id="c1",
                claim_type=ClaimType.VERDICT,
                proposition={"label": "N/A"},
            )
        ],
    )
    report = ArgumentValidator().validate(argument, context(index))
    assert any(issue.code is VerificationIssueCode.UNGROUNDED for issue in report.issues)


def test_claim_missing_required_field_is_untranslatable(index: CaseEvidenceIndex) -> None:
    """An uncheckable claim is reported, never silently skipped."""

    argument = _compliant_argument()
    argument.claims[1] = AuditClaim(
        claim_id="c2",
        claim_type=ClaimType.EVIDENCE,
        proposition={"note": "looks fine"},
        premises=[
            ClaimPremise(
                source_type=PremiseSourceType.CASE_EVIDENCE,
                source_id="a1",
                relation=ClaimRelation.SUPPORTS,
            )
        ],
    )
    report = ArgumentValidator().validate(argument, context(index))
    assert any(issue.code is VerificationIssueCode.UNTRANSLATABLE for issue in report.issues)


def test_premise_on_rejected_prior_claim_contradicts(index: CaseEvidenceIndex) -> None:
    argument = _compliant_argument()
    argument.claims[0].status = ClaimStatus.REJECTED
    argument.claims[2].premises = [
        ClaimPremise(
            source_type=PremiseSourceType.PRIOR_CLAIM,
            source_id="c1",
            relation=ClaimRelation.DERIVED_FROM,
        )
    ]
    report = ArgumentValidator().validate(argument, context(index))
    assert any(issue.code is VerificationIssueCode.CONTRADICTION for issue in report.issues)
