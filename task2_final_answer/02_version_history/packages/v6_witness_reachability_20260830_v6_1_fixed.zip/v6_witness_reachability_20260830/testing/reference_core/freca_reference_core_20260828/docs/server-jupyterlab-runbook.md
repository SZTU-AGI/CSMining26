# Server / JupyterLab execution runbook

This runbook is the next execution order for the handoff package.  The local
machine is only used for static checks and deterministic smoke tests; the real
model run belongs on the server.

## 1. Prepare the notebook kernel

Run these cells from the package root:

```python
from pathlib import Path
import os, sys

PACKAGE = Path.cwd() / "freca_jupyterlab_package"
if (PACKAGE / "src").is_dir():
    PACKAGE = PACKAGE
else:
    PACKAGE = Path.cwd()
os.environ["PYTHONPATH"] = str(PACKAGE / "src")
sys.path.insert(0, str(PACKAGE / "src"))
```

Use absolute paths for the dataset, rules PDF, checking-point workbook, and the
official submission template.  Do not put an API key in a notebook cell or in a
command argument.

## 2. Run deterministic gates first

```python
!python -m compileall -q src tests
!python -m unittest discover -s tests -v
```

If the server image does not have `pytest`, that is not a reason to change the
pipeline.  Install the package's development extras only when convenient; the
runtime commands themselves do not require pytest.

## 3. Build and inspect the frozen inputs

Run the stages in this order:

```python
!python -m freca.cli --run-root artifacts/runs --run-id server_manifest manifest \
  --cases "/absolute/path/to/SFRE_cases" --no-hash

!python -m freca.cli --run-root artifacts/runs --run-id server_evidence evidence \
  --cases "/absolute/path/to/SFRE_cases" --policy differentiated

!python -m freca.cli --run-root artifacts/runs --run-id server_policy policy \
  --rules "/absolute/path/to/rules.pdf" \
  --checkpoints "/absolute/path/to/checkpoints.xlsx"

!python -m freca.cli --run-root artifacts/runs --run-id server_packs packs \
  --rules "/absolute/path/to/rules.pdf" \
  --checkpoints "/absolute/path/to/checkpoints.xlsx" \
  --config unit_level
```

Inspect the M0, evidence, anchor, and pack summaries before spending model
budget.  A pack with `adjudicable=false` remains a blocked R1 cell; it is not
silently omitted.

## 4. Prove the plumbing with a 3 × 7 slice

First run the offline backend.  A `RUN_INVALID` result with zero substantive
decisions is expected for `--backend none`; it proves that missing model reads
cannot become labels.

Then run the same 3 × 7 slice with the configured real backend and
`--mode evaluation`.  Use the seven frozen CPs:

```text
CP2 CP10 CP22 CP23 CP26 CP38 CP41
```

The run must produce `farm_profiles.jsonl`, `decisions.jsonl`,
`run_health.json`, and `model_calls.jsonl`.  In evaluation mode any synthetic
or unlabelled model decision blocks export.

## 5. Evaluate against the human gold set

Prepare a UTF-8 JSONL/CSV/TSV file with one row per labelled `case_id × cp_id`:

```json
{"case_id":"...","cp_id":"CP22","gold_label":"1","notes":"..."}
```

Then run:

```python
!python -m freca.cli evaluate \
  --run-dir artifacts/runs/server_slice7_real \
  --gold "/absolute/path/to/gold.jsonl"
```

`NO_GOLD` is a valid plumbing report but is never an accuracy result.  With
gold, read accuracy together with coverage, blocked cells, label counts,
stage metrics, and `error_cases.jsonl`.

For a controlled prompt/evidence perturbation, run the second audit into a
separate run directory and compare it with:

```python
!python -m freca.cli evaluate \
  --run-dir artifacts/runs/server_slice7_real \
  --gold "/absolute/path/to/gold.jsonl" \
  --perturbed-decisions artifacts/runs/server_slice7_perturbed/decisions.jsonl
```

## 6. Expand to all 100 × 41 cells

Only after the slice is inspectable, run the full audit with the same backend,
model configuration, policy version, and evidence configuration.  Keep each
run in a new `--run-id`; never overwrite a prior run when comparing changes.

Before any submission/export decision, verify:

1. `run_health.status == RUN_VALID`;
2. `export_blocked == false`;
3. `synthetic_rate == 0` for evaluation/production;
4. every model call has exact system/user prompt, response, model, hashes, and
   token/latency metadata;
5. the V0 report has the intended gold status and no unexpected leakage finding;
6. blocked cells and their gate reasons have been reviewed rather than counted
   as model predictions.

The current real-data smoke is intentionally not expected to contain a
validated N/A class yet: explicit `Not registered` activity facts exist in T1,
but a CP-specific legal scope predicate and a human gold decision are required
before those facts can be scored as N/A.
