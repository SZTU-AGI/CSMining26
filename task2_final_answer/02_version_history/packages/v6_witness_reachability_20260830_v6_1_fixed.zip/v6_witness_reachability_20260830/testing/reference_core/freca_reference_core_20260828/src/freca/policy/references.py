"""Mention-level internal/external reference extraction with explicit status."""

from __future__ import annotations

import re

from freca.governance.hashing import sha256_digest
from freca.policy.schemas_v2 import (
    PolicyReferenceMention,
    PolicyUnit,
    PolicyUnitType,
    ReferenceTarget,
)

_EXTERNAL = re.compile(
    r"\b(?P<kind>section|subsection|paragraph|subparagraph)s?\s+"
    r"(?P<citation>\d{1,3}(?:-\d{1,3}[A-Z]?)?(?:\([^)]+\))*)\s+"
    r"of\s+(?:the\s+)?(?:Export Control\s+)?Act(?:\s+2020)?",
    re.I,
)
_ABSOLUTE = re.compile(
    r"\b(?P<kind>section|subsection|paragraph|subparagraph)s?\s+"
    r"(?P<citation>\d{1,2}-\d{1,3}[A-Z]?(?:\([^)]+\))*)",
    re.I,
)
_RELATIVE = re.compile(
    r"\b(?P<kind>subsection|paragraph|subparagraph)s?\s+"
    r"(?P<label>\([^)]+\))(?:\s+(?:and|or)\s+(?P<label2>\([^)]+\)))?",
    re.I,
)
_STRUCTURAL = re.compile(r"\bthis\s+(?P<kind>Part|Division|Chapter|section)\b", re.I)


def extract_reference_mentions(units: list[PolicyUnit]) -> list[PolicyReferenceMention]:
    by_citation = {unit.citation: unit for unit in units}
    by_id = {unit.unit_id: unit for unit in units}
    mentions: list[PolicyReferenceMention] = []
    for unit in units:
        if not unit.normative:
            continue
        occupied: list[tuple[int, int]] = []
        for match in _EXTERNAL.finditer(unit.own_raw_text):
            occupied.append(match.span())
            target = ReferenceTarget(
                raw_target=match.group("citation"),
                normalized_citation=None,
                target_kind="EXTERNAL",
                resolution_status="EXTERNAL_NOT_FOLLOWED",
                resolution_reason="REFERENCE_EXPLICITLY_QUALIFIED_AS_ACT",
            )
            mentions.append(_mention(unit, match.group(0), "ABSOLUTE", [target], match.start()))
        for match in _ABSOLUTE.finditer(unit.own_raw_text):
            if _overlaps(match.span(), occupied):
                continue
            citation = match.group("citation")
            mentions.append(
                _mention(
                    unit,
                    match.group(0),
                    "ABSOLUTE",
                    [_internal_target(citation, by_citation)],
                    match.start(),
                )
            )
            occupied.append(match.span())
        for match in _RELATIVE.finditer(unit.own_raw_text):
            if _overlaps(match.span(), occupied):
                continue
            base = unit.citation.split("(", 1)[0].split(":", 1)[0]
            labels = [match.group("label")]
            if match.group("label2"):
                labels.append(match.group("label2"))
            targets = [_internal_target(f"{base}{label}", by_citation) for label in labels]
            mentions.append(
                _mention(
                    unit,
                    match.group(0),
                    "LIST" if len(targets) > 1 else "RELATIVE",
                    targets,
                    match.start(),
                )
            )
            occupied.append(match.span())
        for match in _STRUCTURAL.finditer(unit.own_raw_text):
            if _overlaps(match.span(), occupied):
                continue
            kind = match.group("kind").upper()
            expected_type = PolicyUnitType.SECTION if kind == "SECTION" else PolicyUnitType(kind)
            candidates = [
                by_id[item]
                for item in reversed(unit.context_unit_ids)
                if item in by_id and by_id[item].unit_type is expected_type
            ]
            if kind == "SECTION":
                section = unit.citation.split("(", 1)[0].split(":", 1)[0]
                candidate = by_citation.get(section)
            else:
                candidate = candidates[0] if candidates else None
            target = ReferenceTarget(
                raw_target=match.group(0),
                normalized_citation=candidate.citation if candidate else None,
                target_unit_id=candidate.unit_id if candidate else None,
                target_kind="INTERNAL",
                resolution_status="RESOLVED" if candidate else "UNRESOLVED",
                resolution_reason="ANCESTOR_STRUCTURE" if candidate else "NO_MATCHING_ANCESTOR",
            )
            mentions.append(_mention(unit, match.group(0), "STRUCTURAL", [target], match.start()))
    return sorted(mentions, key=lambda item: (item.source_unit_id, item.reference_id))


def _internal_target(citation: str, by_citation: dict[str, PolicyUnit]) -> ReferenceTarget:
    target = by_citation.get(citation)
    return ReferenceTarget(
        raw_target=citation,
        normalized_citation=citation,
        target_unit_id=target.unit_id if target else None,
        target_kind="INTERNAL",
        resolution_status="RESOLVED" if target else "UNRESOLVED",
        resolution_reason="EXACT_CITATION_MATCH" if target else "CITATION_NOT_IN_POLICY_INDEX",
    )


def _mention(
    unit: PolicyUnit,
    raw: str,
    grammar: str,
    targets: list[ReferenceTarget],
    offset: int,
) -> PolicyReferenceMention:
    digest = sha256_digest({"source_unit_id": unit.unit_id, "raw_mention": raw, "offset": offset})
    return PolicyReferenceMention(
        reference_id=f"ref-{digest.split(':', 1)[1][:24]}",
        source_unit_id=unit.unit_id,
        raw_mention=raw,
        mention_locator=unit.locator,
        grammar_type=grammar,
        targets=targets,
    )


def _overlaps(span: tuple[int, int], occupied: list[tuple[int, int]]) -> bool:
    return any(span[0] < other[1] and other[0] < span[1] for other in occupied)
