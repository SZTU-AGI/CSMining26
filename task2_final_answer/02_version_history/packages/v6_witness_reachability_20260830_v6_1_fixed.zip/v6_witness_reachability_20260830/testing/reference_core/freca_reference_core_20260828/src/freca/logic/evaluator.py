"""Independent deterministic evaluator for the exception-free Logic AST subset."""

from __future__ import annotations

from pydantic import Field

from freca.domain.models import SafeId, StrictModel
from freca.logic.ast import LogicDAG, LogicOperator
from freca.logic.four_valued import FourValuedState, all_of, any_of, if_then, negate


class NonComparableOperatorError(ValueError):
    """Raised when a caller asks the Boolean shadow to evaluate legal exceptions."""

    def __init__(self, node_id: str, operator: LogicOperator) -> None:
        super().__init__(f"{operator.value} at {node_id} requires argument-graph semantics")
        self.node_id = node_id
        self.operator = operator


class ASTEvaluationTrace(StrictModel):
    interpretation_id: SafeId
    evaluated_node_states: dict[SafeId, FourValuedState]
    evaluated_root_states: dict[SafeId, FourValuedState]
    noncomparable_root_ids: list[SafeId] = Field(default_factory=list)
    missing_atom_proposition_ids: list[SafeId] = Field(default_factory=list)


def evaluate_logic_dag(
    dag: LogicDAG,
    atom_states: dict[str, FourValuedState],
    *,
    root_ids: list[str] | None = None,
    skip_noncomparable_roots: bool = False,
) -> ASTEvaluationTrace:
    """Evaluate roots without interpreting ``UNLESS`` or ``EXCEPTION_GATE``.

    Missing atoms remain ``UNKNOWN`` and are disclosed.  Exception-bearing roots
    can either raise or be explicitly classified as non-comparable.
    """

    node_by_id = dag.node_map()
    cache: dict[str, FourValuedState] = {}
    missing: set[str] = set()

    def evaluate(node_id: str) -> FourValuedState:
        if node_id in cache:
            return cache[node_id]
        node = node_by_id[node_id]
        if node.operator is LogicOperator.ATOM:
            assert node.proposition_id is not None
            if node.proposition_id not in atom_states:
                missing.add(node.proposition_id)
            value = atom_states.get(node.proposition_id, FourValuedState.UNKNOWN)
        elif node.operator is LogicOperator.NOT:
            value = negate(evaluate(node.child_ids[0]))
        elif node.operator is LogicOperator.ALL_OF:
            value = all_of(evaluate(child_id) for child_id in node.child_ids)
        elif node.operator is LogicOperator.ANY_OF:
            value = any_of(evaluate(child_id) for child_id in node.child_ids)
        elif node.operator is LogicOperator.IF_THEN:
            value = if_then(evaluate(node.child_ids[0]), evaluate(node.child_ids[1]))
        else:
            raise NonComparableOperatorError(node.node_id, node.operator)
        cache[node_id] = value
        return value

    selected = root_ids or list(dag.roots.as_dict().values())
    root_states: dict[str, FourValuedState] = {}
    noncomparable: list[str] = []
    for root_id in selected:
        try:
            root_states[root_id] = evaluate(root_id)
        except NonComparableOperatorError:
            if not skip_noncomparable_roots:
                raise
            noncomparable.append(root_id)

    return ASTEvaluationTrace(
        interpretation_id=dag.interpretation_id,
        evaluated_node_states=cache,
        evaluated_root_states=root_states,
        noncomparable_root_ids=sorted(noncomparable),
        missing_atom_proposition_ids=sorted(missing),
    )
