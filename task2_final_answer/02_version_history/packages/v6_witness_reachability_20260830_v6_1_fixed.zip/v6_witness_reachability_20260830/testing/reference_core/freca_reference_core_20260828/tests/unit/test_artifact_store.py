from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from freca.domain.errors import ArtifactConflictError, CorruptArtifactError
from freca.domain.models import ArtifactEnvelope, RunEvent
from freca.harness.artifact_store import FileArtifactStore, sha256_digest

ZERO_HASH = "sha256:" + ("0" * 64)


class FileArtifactStoreTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary_directory = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary_directory.name)
        self.store = FileArtifactStore(self.root)

    def tearDown(self) -> None:
        self.temporary_directory.cleanup()

    @staticmethod
    def envelope() -> ArtifactEnvelope:
        return ArtifactEnvelope(
            artifact_id="evidence-1",
            artifact_type="evidence",
            run_id="run-1",
            case_id="FRECA-T2-S096",
            cp_id="CP22",
            producer_node="E3",
            producer_version="test",
            config_hash=ZERO_HASH,
        )

    def test_round_trip_preserves_payload_and_hash(self) -> None:
        payload = {"text": "保存记录至少两年", "score": 1.0}
        reference = self.store.put(self.envelope(), payload)
        record = self.store.get("evidence", "evidence-1")

        self.assertEqual(record.payload, payload)
        self.assertEqual(reference.payload_sha256, sha256_digest(payload))
        self.assertEqual(record.envelope.payload_path, "evidence/evidence-1.json")

    def test_same_write_is_idempotent(self) -> None:
        payload = {"text": "同一产物"}
        first = self.store.put(self.envelope(), payload)
        second = self.store.put(self.envelope(), payload)
        self.assertEqual(first, second)

    def test_existing_id_with_different_payload_is_rejected(self) -> None:
        self.store.put(self.envelope(), {"text": "版本 A"})
        with self.assertRaises(ArtifactConflictError):
            self.store.put(self.envelope(), {"text": "版本 B"})

    def test_tampered_payload_is_detected(self) -> None:
        reference = self.store.put(self.envelope(), {"text": "原内容"})
        record_path = self.root / reference.record_path
        raw = json.loads(record_path.read_text(encoding="utf-8"))
        raw["payload"]["text"] = "被篡改"
        record_path.write_text(
            json.dumps(raw, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

        with self.assertRaises(CorruptArtifactError):
            self.store.get("evidence", "evidence-1")

    def test_run_events_are_append_only_and_ordered(self) -> None:
        first = RunEvent(
            run_id="run-1",
            sequence=0,
            event_type="NODE_STARTED",
            node="M0",
        )
        second = RunEvent(
            run_id="run-1",
            sequence=1,
            event_type="NODE_SUCCEEDED",
            node="M0",
            artifact_ids=["manifest-1"],
        )
        self.store.append_event(first)
        self.store.append_event(second)

        events = self.store.read_events("run-1")
        self.assertEqual([event.sequence for event in events], [0, 1])
        self.assertEqual(events[1].artifact_ids, ["manifest-1"])

    def test_run_event_sequence_gap_is_rejected(self) -> None:
        event = RunEvent(
            run_id="run-1",
            sequence=1,
            event_type="NODE_STARTED",
            node="M0",
        )
        with self.assertRaises(ValueError):
            self.store.append_event(event)

    def test_path_traversal_is_rejected_by_schema(self) -> None:
        with self.assertRaises(ValueError):
            self.store.get("../outside", "artifact")


if __name__ == "__main__":
    unittest.main()
