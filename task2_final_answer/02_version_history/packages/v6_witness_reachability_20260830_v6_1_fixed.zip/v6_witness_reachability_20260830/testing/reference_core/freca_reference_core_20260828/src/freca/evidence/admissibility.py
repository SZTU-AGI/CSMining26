"""Whether a document may be used as evidence *about this establishment*.

The question this module answers is deliberately separate from "what does the
document say". A pest-control record signed by another company may be perfectly
compliant in content and still be worthless as proof that *this* establishment
controls pests.

What the corpus actually contains (measured over all 898 files)
----------------------------------------------------------------
* **T3 pest-control records: 100/100 carry someone else's name**, recycled from
  only eight fictional establishments. Each of the eight is internally coherent —
  its own commodity, state and registration number — and its commodity
  contradicts the case's own commodity in **97 of 98** comparable files. This is
  a deliberately generated foreign document, not sloppy naming.
* **T9 traceability records: 100/100 also carry another name**, but each is
  unique to its case, declares **no** registration number, and its trailing digits
  equal the case serial in **100/100** files (case 92 -> ``Hinterland Packing
  092``). That reads as one entity trading under a second name.
* Both are 100 % constant across cases, so signature mismatch is **not** a
  per-case discriminative signal. It is an admissibility question.

Because there is no ground truth, the project owner's decision was to implement
all three readings and let an ablation choose. Hence :class:`IdentityPolicy`.

Deriving the distinction without naming tracks
-----------------------------------------------
``DIFFERENTIATED`` must not hardcode "T3 is bad, T9 is fine" — that would encode
the answer instead of reasoning to it, and it would not survive a re-shuffled
dataset. The principled discriminator is the **registration number**, which is
the statutory identity key:

* the document asserts a well-formed RE number that **conflicts** with the case's
  -> it is about a different registered establishment -> inadmissible;
* the document asserts **no** RE number and differs only in name -> an unverified
  alias -> admissible but flagged.

Applied to this corpus that derivation reproduces exactly "T3 inadmissible, T9
admissible", without either track appearing in the code.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum

from freca.domain.enums import EvidenceIdentityState
from freca.domain.models import IdentityAssessment
from freca.evidence.identity import IdentityAnchors, IdentityReference


class IdentityPolicy(str, Enum):
    """How identity mismatch affects a document's use as evidence."""

    #: Any non-SELF document is inadmissible.
    STRICT = "strict"
    #: Identity never blocks; mismatch is recorded and surfaces in review only.
    LENIENT = "lenient"
    #: Conflicting registration number blocks; a bare name difference does not.
    DIFFERENTIATED = "differentiated"


class AdmissibilityReason(str, Enum):
    SELF_SIGNED = "self_signed"
    ALIAS_UNVERIFIED = "alias_unverified"
    CONFLICTING_REGISTRATION = "conflicting_registration"
    FOREIGN_SIGNATURE = "foreign_signature"
    NO_IDENTITY_DECLARED = "no_identity_declared"


@dataclass(slots=True)
class Admissibility:
    admissible: bool
    reason: AdmissibilityReason
    policy: IdentityPolicy
    state: EvidenceIdentityState
    #: Set when the document is admitted despite an unresolved identity, so the
    #: downstream verdict can be forced through review instead of asserted.
    review_required: bool
    detail: str

    def to_dict(self) -> dict[str, object]:
        return {
            "admissible": self.admissible,
            "reason": self.reason.value,
            "policy": self.policy.value,
            "state": self.state.value,
            "review_required": self.review_required,
            "detail": self.detail,
        }


_TRAILING_SERIAL = re.compile(r"(\d{1,4})\s*$")


def alias_binds_to_case(anchors: IdentityAnchors, reference: IdentityReference) -> bool:
    """True when a differently-named document still encodes the case's own serial.

    ``Hinterland Packing 092`` for case serial 92. This is corroboration that the
    document belongs to the case despite the name, and it is the reason an alias
    is treated as weaker evidence of foreignness than a conflicting RE number.
    """

    if reference.serial is None:
        return False
    for name in anchors.names:
        match = _TRAILING_SERIAL.search(name)
        if match and int(match.group(1)) == reference.serial:
            return True
    return False


def decide_admissibility(
    assessment: IdentityAssessment,
    anchors: IdentityAnchors,
    reference: IdentityReference,
    policy: IdentityPolicy,
) -> Admissibility:
    """Apply ``policy`` to one document's resolved identity."""

    conflicting_registration = any(
        number != reference.re_number for number in anchors.re_numbers
    ) or bool(anchors.malformed_re_numbers)
    declares_nothing = not anchors.names and not anchors.re_numbers

    if assessment.state is EvidenceIdentityState.SELF:
        return Admissibility(
            admissible=True,
            reason=AdmissibilityReason.SELF_SIGNED,
            policy=policy,
            state=assessment.state,
            review_required=False,
            detail="document identifies the audited establishment",
        )

    if declares_nothing:
        # Nothing asserted either way. Unknown is not the same as foreign, so the
        # document is admitted and flagged rather than discarded.
        return Admissibility(
            admissible=True,
            reason=AdmissibilityReason.NO_IDENTITY_DECLARED,
            policy=policy,
            state=assessment.state,
            review_required=True,
            detail="document declares no establishment name or registration number",
        )

    if conflicting_registration:
        reason = AdmissibilityReason.CONFLICTING_REGISTRATION
        detail = (
            f"document asserts registration {anchors.re_numbers or anchors.malformed_re_numbers} "
            f"against case {reference.re_number}"
        )
    elif alias_binds_to_case(anchors, reference):
        reason = AdmissibilityReason.ALIAS_UNVERIFIED
        detail = (
            f"name {anchors.names!r} differs from {reference.establishment!r} but encodes the "
            f"case serial {reference.serial}; no conflicting registration number"
        )
    else:
        reason = AdmissibilityReason.FOREIGN_SIGNATURE
        detail = f"name {anchors.names!r} does not match {reference.establishment!r}"

    if policy is IdentityPolicy.LENIENT:
        admissible = True
    elif policy is IdentityPolicy.STRICT:
        admissible = False
    else:
        admissible = reason is AdmissibilityReason.ALIAS_UNVERIFIED

    return Admissibility(
        admissible=admissible,
        reason=reason,
        policy=policy,
        state=assessment.state,
        review_required=admissible,
        detail=detail,
    )
