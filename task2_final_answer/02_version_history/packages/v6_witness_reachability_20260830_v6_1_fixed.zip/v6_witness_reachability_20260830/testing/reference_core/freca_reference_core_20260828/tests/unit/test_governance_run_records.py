from __future__ import annotations

import json
import tempfile
import unittest
from datetime import UTC, datetime
from pathlib import Path

from freca.governance.config import RunMode
from freca.governance.event_log import EventLogIntegrityError, EventWriter
from freca.governance.models import (
    CodeState,
    EnvironmentSnapshot,
    EventType,
    RunCompletion,
    RunManifest,
    build_replay_key,
)
from freca.governance.run_ledger import RunLedger, RunLedgerError

HASH = "sha256:" + "1" * 64


def code_state() -> CodeState:
    return CodeState(git_commit="no-git-snapshot", git_dirty=False)


def environment() -> EnvironmentSnapshot:
    return EnvironmentSnapshot(
        os="test",
        python_version="3.12-test",
        dependency_lock_sha256=HASH,
        installed_packages_sha256=HASH,
        package_version="0.1.0",
    )


class GovernanceRunRecordTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def manifest(self) -> RunManifest:
        return RunManifest(
            run_id="run-1",
            mode=RunMode.DIAGNOSTIC,
            replay_key=HASH,
            source_catalog_id="sources-1",
            source_catalog_sha256=HASH,
            config_sha256=HASH,
            prompt_bundle_sha256=HASH,
            code_state=code_state(),
            environment=environment(),
            requested_models=[],
            human_availability_profile="NO_HUMAN",
            fold_assumption_register_sha256=HASH,
            started_at=datetime.now(UTC),
        )

    def test_replay_key_ignores_order_of_model_fingerprints(self) -> None:
        common = {
            "mode": RunMode.EXPERIMENT,
            "source_catalog_sha256": HASH,
            "semantic_config_sha256": HASH,
            "prompt_bundle_sha256": HASH,
            "method_policy_bundle_sha256": HASH,
            "code_state": code_state(),
            "environment": environment(),
        }
        models = [
            {"role": "TEAM_B", "provider_id": "b", "requested_model": "m2"},
            {"role": "POLICY_EXTRACTOR", "provider_id": "a", "requested_model": "m1"},
        ]
        self.assertEqual(
            build_replay_key(model_fingerprints=models, **common),
            build_replay_key(model_fingerprints=list(reversed(models)), **common),
        )

    def test_manifest_and_completion_are_exclusive(self) -> None:
        ledger = RunLedger(self.root, "run-1")
        ledger.create_manifest(self.manifest())
        self.assertEqual(ledger.read_manifest().run_id, "run-1")
        with self.assertRaises(RunLedgerError):
            ledger.create_manifest(self.manifest())
        completion = RunCompletion(
            run_id="run-1",
            status="RUN_VALID",
            finished_at=datetime.now(UTC),
            source_integrity_end_check="UNCHANGED",
            resolved_model_versions=[],
            event_log_sha256=HASH,
            output_artifact_ids=[],
            blocking_findings=[],
            warnings=[],
        )
        ledger.write_completion(completion)
        with self.assertRaises(RunLedgerError):
            ledger.write_completion(completion)

    def test_event_chain_detects_tampering(self) -> None:
        writer = EventWriter(self.root, "run-1")
        first = writer.append(EventType.RUN_STARTED)
        second = writer.append(EventType.NODE_STARTED, node="LAYER1")
        self.assertEqual(second.previous_event_sha256, first.event_sha256)
        self.assertEqual(len(writer.read_verified()), 2)

        lines = writer.path.read_text(encoding="utf-8").splitlines()
        payload = json.loads(lines[0])
        payload["detail"] = {"tampered": True}
        lines[0] = json.dumps(payload)
        writer.path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        with self.assertRaises(EventLogIntegrityError):
            writer.read_verified()


if __name__ == "__main__":
    unittest.main()
