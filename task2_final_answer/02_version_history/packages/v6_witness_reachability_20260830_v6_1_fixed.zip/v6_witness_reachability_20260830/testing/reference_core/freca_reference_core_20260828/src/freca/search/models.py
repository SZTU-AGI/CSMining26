"""Shared state/action/observation/budget schema for every search A/B arm."""

from __future__ import annotations

from typing import Literal

from pydantic import Field, model_validator

from freca.domain.models import SafeId, StrictModel


class SearchBudget(StrictModel):
    max_expansions: int = Field(default=24, ge=1)
    max_depth: int = Field(default=4, ge=1)
    branch_factor: int = Field(default=3, ge=1)
    beam_width: int = Field(default=3, ge=1)
    monte_carlo_completions: int = Field(default=3, ge=1)
    seed: int = 0


class SearchState(StrictModel):
    state_id: SafeId
    depth: int = Field(ge=0)
    artifact_ids: list[SafeId] = Field(default_factory=list)
    resolved_goal_ids: list[SafeId] = Field(default_factory=list)
    unresolved_goal_ids: list[SafeId] = Field(default_factory=list)
    action_history: list[SafeId] = Field(default_factory=list)
    terminal: bool = False


class SearchMove(StrictModel):
    move_id: SafeId
    action_signature: SafeId
    action_type: str = Field(min_length=1)
    target_goal_id: SafeId
    expected_signal_types: list[str] = Field(min_length=1)
    model_score: float | None = None
    generated_by_model: bool = False


class SearchObservation(StrictModel):
    observation_id: SafeId
    move_id: SafeId
    verified_external_signal_ids: list[SafeId] = Field(default_factory=list)
    new_artifact_ids: list[SafeId] = Field(default_factory=list)
    validator_passed: bool
    external_reward: float = Field(ge=0.0, le=1.0)
    simulation_only: bool = False
    failure_reason_codes: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def reward_requires_verified_external_signal(self) -> SearchObservation:
        if self.external_reward > 0 and not self.verified_external_signal_ids:
            raise ValueError("positive search reward requires a verified external signal")
        if self.simulation_only and self.verified_external_signal_ids:
            raise ValueError("simulated observations cannot claim verified external signals")
        return self


class SearchTraceStep(StrictModel):
    sequence: int = Field(ge=0)
    parent_state_id: SafeId
    move: SearchMove
    child_state: SearchState
    observation: SearchObservation
    cumulative_external_reward: float = Field(ge=0.0)
    reflection_text: str | None = None
    reflection_is_evidence: Literal[False] = False


class SearchResult(StrictModel):
    strategy_id: str
    initial_state_id: SafeId
    selected_state: SearchState
    trace_steps: list[SearchTraceStep]
    expansions: int = Field(ge=0)
    verified_signal_gain: int = Field(ge=0)
    exhausted_budget: bool
    production_pruning_used: bool = False
    final_label_emitted: Literal[False] = False


class SearchGateDecision(StrictModel):
    route: Literal[
        "TARGETED_REPAIR",
        "RERANK_OR_DEFER",
        "SEARCH_RESEARCH_NO_PRUNING",
        "SEARCH_PRODUCTION_PRUNING_ALLOWED",
    ]
    reason_codes: list[str]
    permanent_pruning_allowed: bool
