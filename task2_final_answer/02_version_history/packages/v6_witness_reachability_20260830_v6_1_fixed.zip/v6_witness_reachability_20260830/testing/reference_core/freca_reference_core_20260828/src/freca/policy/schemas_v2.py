"""Page-aware, replayable, semantically neutral Layer 1 schemas."""

from __future__ import annotations

from enum import StrEnum
from typing import Any, Literal

from pydantic import Field, model_validator

from freca.domain.models import SafeId, Sha256, StrictModel


class LineClass(StrEnum):
    BODY = "BODY"
    STRUCTURAL_HEADING = "STRUCTURAL_HEADING"
    SECTION_HEADING = "SECTION_HEADING"
    INTERNAL_HEADING = "INTERNAL_HEADING"
    TOC_ENTRY = "TOC_ENTRY"
    RUNNING_HEADER = "RUNNING_HEADER"
    RUNNING_FOOTER = "RUNNING_FOOTER"
    PAGE_NUMBER = "PAGE_NUMBER"
    BLANK = "BLANK"


class PolicyUnitType(StrEnum):
    CHAPTER = "CHAPTER"
    PART = "PART"
    DIVISION = "DIVISION"
    SUBDIVISION = "SUBDIVISION"
    SECTION = "SECTION"
    SUBSECTION = "SUBSECTION"
    PARAGRAPH = "PARAGRAPH"
    SUBPARAGRAPH = "SUBPARAGRAPH"
    DEFINITION_ITEM = "DEFINITION_ITEM"
    NOTE = "NOTE"
    EXAMPLE = "EXAMPLE"
    INTERNAL_HEADING = "INTERNAL_HEADING"
    TABLE = "TABLE"
    TABLE_ROW = "TABLE_ROW"
    TABLE_CELL = "TABLE_CELL"
    UNRESOLVED_BLOCK = "UNRESOLVED_BLOCK"


class ToolFingerprint(StrictModel):
    tool: SafeId
    version: str = Field(min_length=1)
    executable_path: str
    executable_sha256: Sha256


class PolicyLine(StrictModel):
    line_id: SafeId
    physical_page: int = Field(ge=1)
    page_line_index: int = Field(ge=1)
    raw_text: str
    normalized_text: str
    raw_char_start: int = Field(ge=0)
    raw_char_end: int = Field(ge=0)
    classification: LineClass = LineClass.BODY

    @model_validator(mode="after")
    def offsets_are_ordered(self) -> PolicyLine:
        if self.raw_char_end < self.raw_char_start:
            raise ValueError("line char offsets are reversed")
        return self


class PolicyPage(StrictModel):
    physical_page: int = Field(ge=1)
    printed_page_label: str | None = None
    raw_text: str
    normalized_text: str
    raw_sha256: Sha256
    line_ids: list[SafeId]


class ExtractedPolicyText(StrictModel):
    schema_version: Literal["freca.policy-text.v1"] = "freca.policy-text.v1"
    source_id: SafeId
    source_pdf_sha256: Sha256
    page_count: int = Field(ge=1)
    pages: list[PolicyPage]
    lines: list[PolicyLine]
    pdftotext: ToolFingerprint
    pdfinfo: ToolFingerprint
    extraction_sha256: Sha256

    @model_validator(mode="after")
    def pages_and_lines_are_complete(self) -> ExtractedPolicyText:
        if len(self.pages) != self.page_count:
            raise ValueError("page count does not match extracted pages")
        expected_pages = list(range(1, self.page_count + 1))
        if [page.physical_page for page in self.pages] != expected_pages:
            raise ValueError("physical pages must be contiguous and 1-based")
        line_ids = [line.line_id for line in self.lines]
        if len(line_ids) != len(set(line_ids)):
            raise ValueError("policy line IDs must be unique")
        known = set(line_ids)
        if any(set(page.line_ids) - known for page in self.pages):
            raise ValueError("page references unknown line IDs")
        return self


class PolicySpanSegment(StrictModel):
    physical_page: int = Field(ge=1)
    page_line_start: int = Field(ge=1)
    page_line_end: int = Field(ge=1)
    raw_char_start: int = Field(ge=0)
    raw_char_end: int = Field(ge=0)

    @model_validator(mode="after")
    def interval_is_ordered(self) -> PolicySpanSegment:
        if self.page_line_end < self.page_line_start:
            raise ValueError("line interval is reversed")
        if self.raw_char_end < self.raw_char_start:
            raise ValueError("char interval is reversed")
        return self


class PolicyLocator(StrictModel):
    segments: list[PolicySpanSegment] = Field(min_length=1)
    printed_page_labels: list[str] = Field(default_factory=list)


class SectionOccurrence(StrictModel):
    occurrence_id: SafeId
    section_id: str = Field(pattern=r"^\d{1,2}-\d{1,3}[A-Z]?$")
    page_start: int = Field(ge=1)
    title_line_ids: list[SafeId]
    body_line_ids: list[SafeId]
    occurrence_role: Literal["TOC", "BODY", "RUNNING_HEADER", "UNKNOWN"]
    selection_reasons: list[str]


class PolicyUnit(StrictModel):
    unit_id: SafeId
    citation: str = Field(min_length=1)
    unit_type: PolicyUnitType
    title: str | None = None
    label: str | None = None
    own_raw_text: str
    full_raw_text: str
    normalized_text: str
    context_unit_ids: list[SafeId] = Field(default_factory=list)
    locator: PolicyLocator
    parent_id: SafeId | None = None
    child_ids: list[SafeId] = Field(default_factory=list)
    normative: bool
    source_pdf_sha256: Sha256
    unit_sha256: Sha256


class DefinitionEntry(StrictModel):
    unit_id: SafeId
    defined_term_raw: str
    defined_term_normalized: str
    qualifier_text: str | None = None
    operator: Literal["MEANS", "INCLUDES"]
    definition_text: str
    child_unit_ids: list[SafeId] = Field(default_factory=list)
    locator: PolicyLocator


class ReferenceTarget(StrictModel):
    raw_target: str
    normalized_citation: str | None = None
    target_unit_id: SafeId | None = None
    target_kind: Literal["INTERNAL", "EXTERNAL"]
    resolution_status: Literal["RESOLVED", "EXTERNAL_NOT_FOLLOWED", "UNRESOLVED"]
    resolution_reason: str


class PolicyReferenceMention(StrictModel):
    reference_id: SafeId
    source_unit_id: SafeId
    raw_mention: str
    mention_locator: PolicyLocator
    grammar_type: Literal["ABSOLUTE", "RELATIVE", "STRUCTURAL", "LIST", "RANGE"]
    targets: list[ReferenceTarget] = Field(min_length=1)


class PolicyGraphEdge(StrictModel):
    edge_id: SafeId
    source_id: SafeId
    target_id: SafeId
    edge_type: Literal["CONTAINS", "REFERS_TO", "DEFINES"]
    source_span_ids: list[SafeId] = Field(default_factory=list)


class PolicyCue(StrictModel):
    cue_id: SafeId
    unit_id: SafeId
    cue_type: Literal["DEONTIC", "EXCEPTION", "DEEMING", "TEMPORAL", "CONDITION"]
    raw_text: str
    locator: PolicyLocator


class PolicyParseIssue(StrictModel):
    issue_code: str = Field(min_length=1)
    severity: Literal["INFO", "WARNING", "FATAL"]
    locator: PolicyLocator | None = None
    unit_id: SafeId | None = None
    raw_excerpt: str | None = None
    details: dict[str, Any] = Field(default_factory=dict)


class PolicyIndex(StrictModel):
    schema_version: Literal["freca.policy-index.v1"] = "freca.policy-index.v1"
    source_id: SafeId
    source_pdf_sha256: Sha256
    parser_version: str
    pages: list[PolicyPage]
    lines: list[PolicyLine]
    section_occurrences: list[SectionOccurrence]
    units: list[PolicyUnit]
    definitions: list[DefinitionEntry]
    reference_mentions: list[PolicyReferenceMention]
    graph_edges: list[PolicyGraphEdge]
    cues: list[PolicyCue]
    issues: list[PolicyParseIssue]
    index_sha256: Sha256
