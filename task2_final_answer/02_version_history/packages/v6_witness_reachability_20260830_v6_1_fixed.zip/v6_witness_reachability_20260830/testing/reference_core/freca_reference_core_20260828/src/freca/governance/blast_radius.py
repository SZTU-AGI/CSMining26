"""Compute downstream invalidation and review priority from artifact dependencies."""

from __future__ import annotations

from pydantic import Field

from freca.domain.models import SafeId, StrictModel


class BlastRadiusReviewRecord(StrictModel):
    changed_artifact_ids: list[SafeId]
    affected_artifact_ids: list[SafeId]
    affected_case_cp_ids: list[SafeId]
    affected_case_ids: list[SafeId]
    affected_cp_ids: list[SafeId]
    dependency_fanout: int = Field(ge=0)
    review_priority: str


def compute_blast_radius(
    *,
    changed_artifact_ids: list[str],
    dependency_edges: dict[str, list[str]],
    artifact_case_cp_ids: dict[str, list[str]],
    artifact_case_ids: dict[str, list[str]],
    artifact_cp_ids: dict[str, list[str]],
) -> BlastRadiusReviewRecord:
    reached: set[str] = set()
    queue = list(changed_artifact_ids)
    while queue:
        current = queue.pop(0)
        if current in reached:
            continue
        reached.add(current)
        queue.extend(sorted(dependency_edges.get(current, [])))
    case_cp = sorted({value for item in reached for value in artifact_case_cp_ids.get(item, [])})
    cases = sorted({value for item in reached for value in artifact_case_ids.get(item, [])})
    cps = sorted({value for item in reached for value in artifact_cp_ids.get(item, [])})
    fanout = max(0, len(reached) - len(set(changed_artifact_ids)))
    priority = "CRITICAL" if len(case_cp) >= 100 else "HIGH" if fanout >= 20 else "NORMAL"
    return BlastRadiusReviewRecord(
        changed_artifact_ids=sorted(set(changed_artifact_ids)),
        affected_artifact_ids=sorted(reached),
        affected_case_cp_ids=case_cp,
        affected_case_ids=cases,
        affected_cp_ids=cps,
        dependency_fanout=fanout,
        review_priority=priority,
    )
