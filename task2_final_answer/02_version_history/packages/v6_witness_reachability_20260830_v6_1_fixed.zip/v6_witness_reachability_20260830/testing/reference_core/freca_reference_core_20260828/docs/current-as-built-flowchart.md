# FRECA 当前实现流程图（as-built）

本文只描述当前 `freca_jupyterlab_package/src/freca` 已经存在的代码路径，
用于审阅服务器运行结果。目标设计中尚未落地的模块不会画成已完成节点。

下一版目标架构见 [`target-architecture-v2.md`](target-architecture-v2.md)。V2 明确保留
独立 C3 N/A 活动反证检查、P1 自动回查相关 CP，以及 Original / Verdict-Masked /
Structure-Masked 三路评测。

## 总流程

```mermaid
flowchart TD
    INPUT["案例目录 + 规则 PDF + CP workbook + template"]
    M0["M0\nmanifest.build + validate_manifest"]
    R0["R0\nsectionize + NormGraph"]
    R1["R1\nanchor_checking_points + extract_pack"]
    E["E0–E3\nbuild_case_evidence\nDOCX/XLSX atoms + identity"]
    A0["A0\nbuild_farm_profile\nSELF only + provenance"]
    C0["C0\nc0_bind_anchor"]
    C1["C1\nc1_applicability\nAPPLICABLE / N/A / UNKNOWN"]
    SCOPE_BLOCK["C6 scope review\nUNKNOWN → blocked"]
    C2["C2\nc2_needs"]
    C3["C3\nc3_retrieve\nBM25 CaseEvidenceIndex"]
    C4["C4\nc4_assemble\noptional real model read"]
    C5["C5\nArgumentValidator"]
    REPAIR["C6.rN\nrepair retrieval\nmax 2 rounds"]
    C7["C7\nc7_decide"]
    P01["P0/P1\ncheck_all consistency"]
    HEALTH["RunHealth\nassess_run"]
    P2["P2\nassemble_submission"]
    V0["V0\nevaluate_run_directory"]
    BLOCK["blocked\nrecorded, not scored"]
    OUT["run artifacts\nhealth / decisions / profiles / reports"]

    INPUT --> M0
    M0 -->|pass| R0
    M0 -->|pass| E
    M0 -->|fail unless --force| BLOCK
    R0 --> R1
    R1 --> C0
    E --> A0
    A0 --> C0
    C0 --> C1
    C1 -->|UNKNOWN| SCOPE_BLOCK
    C1 -->|APPLICABLE or N/A| C2
    C2 -->|needs| C3
    C2 -->|no needs| C4
    C3 --> C4
    C4 --> C5
    C5 -->|PASS| C7
    C5 -->|RETRY| REPAIR
    REPAIR --> C4
    C5 -->|BLOCK| BLOCK
    C7 --> P01
    P01 --> HEALTH
    HEALTH -->|RUN_VALID| P2
    HEALTH -->|RUN_INVALID| BLOCK
    P2 --> OUT
    BLOCK --> OUT
    OUT --> V0
```

## 节点实现对照

| 阶段 | 代码入口 | 当前真实行为 | 主要产物 |
|---|---|---|---|
| M0 | `freca.manifest.build`, `freca.manifest.validate` | 建立 100 个 logical case，检查重复、缺 track、拆分目录 | `manifest.json`、manifest report |
| R0 | `freca.policy.sectionize`, `freca.policy.norm_graph` | 读取法规、分节、建立主体/适用关系图 | sections、norm graph |
| R1 | `freca.policy.anchor`, `freca.policy.pack` | 先锚定 CP，再按 unit-level 抽取 PolicyPack；每个 CP 只构建一次 | anchors、packs |
| E0–E3 | `freca.evidence.pipeline` | 解析 DOCX/XLSX 为 evidence atoms，保存 locator、hash 和身份状态 | evidence atoms、identity states |
| A0 | `freca.audit.nodes.farm_profile` | 只用 `SELF` 文档构造农场画像；foreign/mixed 只进 conflict | `farm_profiles.jsonl` |
| C0 | `c0_bind_anchor` | 排除不属于当前 CP 主体/范围的法规 anchor | C0 gate trace |
| C1 | `c1_applicability` | 读取 A0 与 `scope_predicates`；明确否定为 N/A，缺失/冲突为 UNKNOWN | C1 trace、scope result |
| C2 | `c2_needs` | 从 `required_facts` / `violation_facts` 形成检索需求 | retrieval needs |
| C3 | `c3_retrieve` | 使用 `CaseEvidenceIndex` 和当前 evidence config 检索；保留 selected/locator/score | retrieval traces |
| C4 | `c4_assemble` | 组装 Policy/Applicability/Evidence/Counter claims；有真实 backend 才读取证据并产生 label | AuditArgument、C4 trace |
| C5 | `ArgumentValidator.validate` | 验证 premise、引用、身份、充分性和标签结构 | validation gate |
| C6 | `adjudicate` 内部 | scope UNKNOWN 时人工复核阻断；C5 retry 时最多两轮定向补检索 | C6 trace |
| C7 | `c7_decide` | 只有有候选标签且依赖通过时才发出 FinalDecision | `decisions.jsonl` |
| P0/P1 | `consistency.check_all` | 检查同案共享事实和 CP 间预定义一致性；不使用多数票修正 | consistency reports |
| RunHealth/P2 | `evaluation.assess_run`, `consistency.assemble_submission` | 先检查 coverage/synthetic；无效 run 不写 submission；blocked cell 不进入 scored cells | `run_health.json`、`submission.xlsx` |
| V0 | `evaluation.v0`, CLI `evaluate` | 读取既有 run；无 gold 输出 `NO_GOLD`，有 gold 才计算 accuracy | `v0_report.json`、`summary.json`、`stage_metrics.json`、`error_cases.jsonl` |

## 三种关键分支

### 1. 范围分支

```mermaid
flowchart LR
    PROFILE["A0 FarmProfile"] --> C1["C1 scope evaluator"]
    PRED["PolicyPack scope_predicates"] --> C1
    C1 -->|明确满足| APP["APPLICABLE\n进入证据判定"]
    C1 -->|明确否定| NA["NOT_APPLICABLE\n候选 N/A"]
    C1 -->|缺失/冲突| UNKNOWN["UNKNOWN\nC6 manual review\nblocked"]
```

注意：真实案例中的 `Not registered` 活动事实不能自动泛化为所有 CP 的
N/A；必须能与当前 CP 的 scope predicate 对应，并由 gold/人工复核确认。

### 2. 模型读取分支

```mermaid
flowchart LR
    C4["C4 evidence reading"] -->|backend=none| B1["no reading\nC4 blocked"]
    C4 -->|fake default no label| B2["unlabelled\nC4 blocked"]
    C4 -->|real backend + valid label| C5["C5 validation"]
    C4 -->|N/A deterministic path| C5
```

因此，`--backend fake` 只能验证接口和 trace，不能作为准确率结果；
`--mode evaluation/production` 中任何 synthetic decision 都会使整个 run
`RUN_INVALID` 并禁止导出。

### 3. 评测分支

```mermaid
flowchart TD
    RUN["audit run"] --> HEALTH["run_health.json"]
    RUN --> DEC["decisions.jsonl"]
    RUN --> CALLS["model_calls.jsonl"]
    DEC --> V0["evaluate"]
    HEALTH --> V0
    GOLD["gold.jsonl\noptional"] --> V0
    PERT["perturbed decisions\noptional"] --> V0
    V0 --> NOGOLD["NO_GOLD\ncoverage only"]
    V0 --> SCORE["SCORED/PARTIAL\naccuracy + confusion"]
    V0 --> REPORT["stage_metrics + error_cases + leakage"]
```

## 当前阶段的判断标准

服务器 3×7 slice 先检查：

1. M0 是否 `PASS`；
2. 是否生成 A0 profile 和完整 provenance；
3. `UNKNOWN` 是否进入 C6，而不是 N/A；
4. 真实 backend 是否产生 `synthetic=false`、有合法 `label` 的 model call；
5. `run_health.status` 是否为 `RUN_VALID`；
6. V0 是否明确显示 `NO_GOLD` 或正式 gold 结果；
7. blocked cells 是否与实际 gate 原因一致。

只有 slice 通过后，才扩展到 100×41。详细服务器命令见
[`server-jupyterlab-runbook.md`](server-jupyterlab-runbook.md)。
