from __future__ import annotations

import hashlib
import tempfile
import unittest
from pathlib import Path

from pydantic import ValidationError

from freca.governance.config import (
    InputPaths,
    OutputConfig,
    ReproducibilityConfig,
    RunConfig,
    RunMode,
    SourceExpectations,
)
from freca.governance.source_guard import (
    FileSystemSourceGuard,
    SourceGuardError,
    SourceRef,
    evidence_manifest_digest,
)
from freca.governance.source_resolver import CatalogSourceResolver

ZERO_HASH = "sha256:" + ("0" * 64)


def file_hash(data: bytes) -> str:
    return f"sha256:{hashlib.sha256(data).hexdigest()}"


class SourceGuardTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.task = self.root / "task"
        self.cases = self.task / "cases" / "case-1"
        self.cases.mkdir(parents=True)
        self.rules_bytes = b"%PDF-1.7\nOfficial rules fixture"
        self.cp_bytes = b"official checking points fixture"
        (self.task / "rules.pdf").write_bytes(self.rules_bytes)
        (self.task / "cp.xlsx").write_bytes(self.cp_bytes)
        (self.task / "Task2 Description.docx").write_bytes(b"task governance")
        (self.task / "submission_template.xlsx").write_bytes(b"output schema")
        self.evidence_data = {
            "cases/case-1/1_Farm.docx": b"farm evidence",
            "cases/case-1/2_Record.xlsx": b"record evidence",
        }
        for relative, data in self.evidence_data.items():
            (self.task / relative).write_bytes(data)

    def tearDown(self) -> None:
        self.temp.cleanup()

    def config(self, *, task: Path | None = None) -> RunConfig:
        task = task or self.task
        manifest_sources = [
            SourceRef(
                source_id=f"test-source-{index}",
                role="CASE_EVIDENCE",
                decision_visibility="FACTUAL",
                allowed_consumers=["LAYER4"],
                canonical_path=str(task / relative),
                sha256=file_hash(data),
                relative_path=Path(relative).relative_to("cases").as_posix(),
                size_bytes=len(data),
                mtime_ns=0,
                extension=Path(relative).suffix,
                mime_type="application/octet-stream",
            )
            for index, (relative, data) in enumerate(sorted(self.evidence_data.items()))
        ]
        return RunConfig(
            mode=RunMode.DIAGNOSTIC,
            inputs=InputPaths(
                task_root=str(task),
                rules_pdf="rules.pdf",
                official_cp_xlsx="cp.xlsx",
                case_root="cases",
                task_governance="Task2 Description.docx",
                submission_template="submission_template.xlsx",
            ),
            expected=SourceExpectations(
                rules_pdf_sha256=file_hash(self.rules_bytes),
                cp_xlsx_sha256=file_hash(self.cp_bytes),
                evidence_manifest_sha256=evidence_manifest_digest(manifest_sources),
                evidence_file_count=2,
            ),
            reproducibility=ReproducibilityConfig(
                prompt_bundle_version="test-v1",
                method_policy_bundle_sha256=ZERO_HASH,
                cache_policy="DISABLED",
            ),
            output=OutputConfig(run_root=str(self.root / "runs")),
        )

    def test_valid_catalog_is_role_separated_and_cross_environment_stable(self) -> None:
        guard = FileSystemSourceGuard()
        first = guard.validate(self.config())
        self.assertEqual(len(first.evidence), 2)
        self.assertEqual(first.task_governance.decision_visibility, "NON_DECISION")
        self.assertEqual(guard.verify_unchanged(first).status, "UNCHANGED")

        clone = self.root / "clone"
        for relative, data in {
            "rules.pdf": self.rules_bytes,
            "cp.xlsx": self.cp_bytes,
            "Task2 Description.docx": b"task governance",
            "submission_template.xlsx": b"output schema",
            **self.evidence_data,
        }.items():
            path = clone / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
        second = guard.validate(self.config(task=clone))
        self.assertEqual(first.catalog_sha256, second.catalog_sha256)

    def test_unknown_evidence_extension_fails_closed(self) -> None:
        (self.cases / "manual_scoring_table.csv").write_text("forbidden", encoding="utf-8")
        with self.assertRaisesRegex(SourceGuardError, "UNKNOWN_EVIDENCE_EXTENSION"):
            FileSystemSourceGuard().validate(self.config())

    def test_nondecision_source_cannot_be_read_by_policy_compiler(self) -> None:
        catalog = FileSystemSourceGuard().validate(self.config())
        resolver = CatalogSourceResolver(catalog)
        with self.assertRaises(SourceGuardError):
            resolver.read_bytes(catalog.task_governance.source_id, consumer="LAYER2")
        self.assertEqual(
            resolver.read_bytes(catalog.task_governance.source_id, consumer="LAYER0"),
            b"task governance",
        )

    def test_source_mutation_is_detected_at_read_and_end_check(self) -> None:
        guard = FileSystemSourceGuard()
        catalog = guard.validate(self.config())
        target = Path(catalog.evidence[0].canonical_path)
        target.write_bytes(b"mutated evidence")
        self.assertEqual(guard.verify_unchanged(catalog).status, "RUN_INVALID")
        with self.assertRaises(SourceGuardError):
            CatalogSourceResolver(catalog).read_bytes(
                catalog.evidence[0].source_id,
                consumer="LAYER4",
            )

    def test_non_diagnostic_fixture_count_is_rejected(self) -> None:
        config = self.config().model_dump(mode="json")
        config["mode"] = RunMode.PRODUCTION.value
        with self.assertRaises(ValidationError):
            RunConfig.model_validate(config)


if __name__ == "__main__":
    unittest.main()
