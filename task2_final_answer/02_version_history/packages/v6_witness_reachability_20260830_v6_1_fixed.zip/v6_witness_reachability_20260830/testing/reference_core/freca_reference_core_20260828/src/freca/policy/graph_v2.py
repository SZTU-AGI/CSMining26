"""Neutral Layer 1 graph with only CONTAINS, REFERS_TO, and DEFINES."""

from __future__ import annotations

import re

from freca.governance.hashing import sha256_digest
from freca.policy.schemas_v2 import (
    DefinitionEntry,
    PolicyGraphEdge,
    PolicyReferenceMention,
    PolicyUnit,
)


def build_policy_graph(
    units: list[PolicyUnit],
    definitions: list[DefinitionEntry],
    references: list[PolicyReferenceMention],
) -> list[PolicyGraphEdge]:
    edges: list[PolicyGraphEdge] = []
    for unit in units:
        if unit.parent_id:
            edges.append(_edge(unit.parent_id, unit.unit_id, "CONTAINS"))
    for mention in references:
        for target in mention.targets:
            if target.resolution_status == "RESOLVED" and target.target_unit_id:
                edges.append(
                    _edge(
                        mention.source_unit_id,
                        target.target_unit_id,
                        "REFERS_TO",
                        source_span_ids=[mention.reference_id],
                    )
                )
    for definition in definitions:
        term_id = "term-" + re.sub(r"[^a-z0-9]+", "-", definition.defined_term_normalized).strip(
            "-"
        )
        edges.append(_edge(definition.unit_id, term_id[:128], "DEFINES"))
    unique = {edge.edge_id: edge for edge in edges}
    return sorted(unique.values(), key=lambda item: item.edge_id)


def _edge(
    source: str,
    target: str,
    edge_type: str,
    source_span_ids: list[str] | None = None,
) -> PolicyGraphEdge:
    payload = {"source": source, "target": target, "edge_type": edge_type}
    digest = sha256_digest(payload)
    return PolicyGraphEdge(
        edge_id=f"edge-{digest.split(':', 1)[1][:24]}",
        source_id=source,
        target_id=target,
        edge_type=edge_type,
        source_span_ids=source_span_ids or [],
    )
