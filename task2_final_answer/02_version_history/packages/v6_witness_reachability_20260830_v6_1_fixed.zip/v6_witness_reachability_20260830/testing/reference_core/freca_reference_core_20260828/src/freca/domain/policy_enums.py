"""Enums that belong to the policy chain (R0/R1) and the identity gate (E3).

These are separated from ``freca.domain.enums`` because they were frozen later,
on 2026-07-31, after the CP-to-section anchoring measurement. Keeping them in a
second module makes the provenance of each frozen decision auditable.
"""

from enum import Enum


class NormEdge(str, Enum):
    """Edge types of the norm graph built over the regulation's own structure."""

    STRUCTURAL_PARENT = "STRUCTURAL_PARENT"
    REFERS_TO = "REFERS_TO"
    DEFINES = "DEFINES"
    APPLIES_VIA = "APPLIES_VIA"
    EXCEPTS = "EXCEPTS"
    PART_SCOPE = "PART_SCOPE"


class ActorRole(str, Enum):
    """Who the regulation addresses, and who signed a piece of evidence.

    The audit target is always ``OCCUPIER`` of a registered establishment.
    Chapter 3 addresses ``MANAGER`` of an accredited property with near-identical
    wording, which is the single largest source of policy mis-anchoring.
    """

    OCCUPIER = "OCCUPIER"
    MANAGER = "MANAGER"
    EXPORTER = "EXPORTER"
    AUTHORISED_OFFICER = "AUTHORISED_OFFICER"
    SUPPLIER = "SUPPLIER"
    REGULATOR = "REGULATOR"
    OTHER = "OTHER"
    UNKNOWN = "UNKNOWN"


class NormScope(str, Enum):
    """Which regulated object a norm governs."""

    REGISTERED_ESTABLISHMENT = "REGISTERED_ESTABLISHMENT"
    ACCREDITED_PROPERTY = "ACCREDITED_PROPERTY"
    EXPORT_PERMIT = "EXPORT_PERMIT"
    GOODS = "GOODS"
    OFFICIALS = "OFFICIALS"
    GENERAL = "GENERAL"
    UNKNOWN = "UNKNOWN"


class SubjectResolution(str, Enum):
    """How a norm's subject was determined."""

    DIRECT = "DIRECT"
    INHERITED = "INHERITED"
    UNRESOLVED = "UNRESOLVED"


class PolicyIssueCode(str, Enum):
    """Policy-chain gate codes. ``MISMATCH`` is hard, ``UNRESOLVED`` is not."""

    POLICY_SUBJECT_MISMATCH = "POLICY_SUBJECT_MISMATCH"
    POLICY_SCOPE_MISMATCH = "POLICY_SCOPE_MISMATCH"
    POLICY_SUBJECT_UNRESOLVED = "POLICY_SUBJECT_UNRESOLVED"
    POLICY_GRAPH_PATH_MISSING = "POLICY_GRAPH_PATH_MISSING"


class MissingEvidenceCause(str, Enum):
    """Why required evidence was not found.

    Only ``EVIDENCE_NOT_PRESENT`` and ``CASE_PACKAGE_INCOMPLETE`` may be mapped
    to label ``0``. ``SYSTEM_FAILURE`` must never be silently mapped to a label.
    """

    EVIDENCE_NOT_PRESENT = "EVIDENCE_NOT_PRESENT"
    CASE_PACKAGE_INCOMPLETE = "CASE_PACKAGE_INCOMPLETE"
    SYSTEM_FAILURE = "SYSTEM_FAILURE"


class IdentityMatchState(str, Enum):
    """Whether an evidence atom's signing entity is the audited establishment."""

    SELF = "SELF"
    RELATED = "RELATED"
    FOREIGN = "FOREIGN"
    MIXED = "MIXED"
    UNKNOWN = "UNKNOWN"
