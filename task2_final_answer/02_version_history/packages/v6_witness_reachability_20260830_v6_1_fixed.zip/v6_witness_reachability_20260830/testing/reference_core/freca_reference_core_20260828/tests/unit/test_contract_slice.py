from __future__ import annotations

import unittest

from freca.governance.hashing import sha256_digest
from freca.policy.contract_slice import (
    ClosureConfig,
    ContractSliceStatus,
    compile_contract_slice,
)
from freca.policy.retrieval_v2 import (
    CandidateDecision,
    CandidateLedger,
    PolicyCandidate,
    QueryBundle,
    ScopeCompatibility,
)
from freca.policy.schemas_v2 import (
    PolicyGraphEdge,
    PolicyIndex,
    PolicyLocator,
    PolicySpanSegment,
    PolicyUnit,
    PolicyUnitType,
)

HASH = "sha256:" + "1" * 64
LOCATOR = PolicyLocator(
    segments=[
        PolicySpanSegment(
            physical_page=7,
            page_line_start=3,
            page_line_end=3,
            raw_char_start=0,
            raw_char_end=64,
        )
    ],
    printed_page_labels=["5"],
)


def _unit(
    unit_id: str,
    text: str,
    *,
    unit_type: PolicyUnitType = PolicyUnitType.PARAGRAPH,
    normative: bool = True,
    parent_id: str | None = "rules2021.section-7",
    context_unit_ids: list[str] | None = None,
) -> PolicyUnit:
    return PolicyUnit(
        unit_id=unit_id,
        citation="7(1)",
        unit_type=unit_type,
        own_raw_text=text,
        full_raw_text=text,
        normalized_text=" ".join(text.split()),
        context_unit_ids=context_unit_ids or [],
        locator=LOCATOR,
        parent_id=parent_id,
        normative=normative,
        source_pdf_sha256=HASH,
        unit_sha256=sha256_digest({"unit_id": unit_id, "text": text}),
    )


def _policy(*, two_primary_units: bool = False) -> PolicyIndex:
    section = _unit(
        "rules2021.section-7",
        "7 Treatment records",
        unit_type=PolicyUnitType.SECTION,
        normative=False,
        parent_id=None,
    )
    primary = _unit(
        "rules2021.section-7.1",
        "(1) A registered establishment must keep treatment records.",
        context_unit_ids=[section.unit_id],
    )
    definition = _unit(
        "rules2021.definition-record",
        "record means a written or electronic record",
        unit_type=PolicyUnitType.DEFINITION_ITEM,
        normative=False,
        parent_id=None,
    )
    units = [section, primary, definition]
    if two_primary_units:
        units.append(
            _unit(
                "rules2021.section-7.2",
                "(2) A registered establishment must retain each record.",
                context_unit_ids=[section.unit_id],
            )
        )
    return PolicyIndex(
        source_id="official-rules-2021",
        source_pdf_sha256=HASH,
        parser_version="synthetic-test-v1",
        pages=[],
        lines=[],
        section_occurrences=[],
        units=units,
        definitions=[],
        reference_mentions=[],
        graph_edges=[
            PolicyGraphEdge(
                edge_id="edge-primary-definition",
                source_id=primary.unit_id,
                target_id=definition.unit_id,
                edge_type="REFERS_TO",
            )
        ],
        cues=[],
        issues=[],
        index_sha256=sha256_digest([unit.unit_sha256 for unit in units]),
    )


def _candidate(unit_id: str, *, selected: bool, relation: str) -> PolicyCandidate:
    decision = CandidateDecision(
        relation=relation,
        selected=selected,
        reason_code="SYNTHETIC_STRUCTURE_TEST",
        criterion_span_ids=["cell-all-elements-c3"],
        policy_span_ids=[unit_id],
        decided_by="RULE",
    )
    return PolicyCandidate(
        candidate_id=f"candidate-{unit_id.replace('.', '-')}",
        cp_id="CP1",
        policy_unit_id=unit_id,
        retrieval_signals=[],
        rrf_score=1.0,
        scope_compatibility=ScopeCompatibility.POSSIBLY_COMPATIBLE,
        decision=decision,
    )


def _ledger(candidates: list[PolicyCandidate]) -> CandidateLedger:
    query_bundle = QueryBundle(
        bundle_id="queries-synthetic-cp1",
        cp_id="CP1",
        queries=[],
        bundle_sha256=sha256_digest([]),
    )
    payload = {
        "cp_id": "CP1",
        "query_bundle": query_bundle,
        "candidates": candidates,
        "config_sha256": sha256_digest({"fixture": True}),
    }
    return CandidateLedger(
        ledger_id="ledger-synthetic-cp1",
        ledger_sha256=sha256_digest(payload),
        **payload,
    )


class ContractSliceTest(unittest.TestCase):
    def test_single_primary_norm_preserves_anchor_and_projects_exactly(self) -> None:
        policy = _policy()
        ledger = _ledger(
            [_candidate("rules2021.section-7.1", selected=True, relation="PRIMARY_NORM")]
        )

        result = compile_contract_slice(ledger, policy)

        self.assertEqual(result.status, ContractSliceStatus.VALID)
        self.assertEqual(result.review_required_reason_codes, [])
        self.assertEqual(
            result.closure.included_policy_unit_ids,
            [
                "rules2021.definition-record",
                "rules2021.section-7",
                "rules2021.section-7.1",
            ],
        )
        self.assertEqual(len(result.norm_event_bundle.events), 1)
        self.assertEqual(
            result.norm_event_bundle.span_bindings[0].exact_raw_text,
            "(1) A registered establishment must keep treatment records.",
        )
        self.assertIsNotNone(result.logic_dag)
        self.assertIsNotNone(result.indexed_requirement_view)
        self.assertIsNotNone(result.argument_graph_template)
        self.assertIsNotNone(result.projection_conformance)
        assert result.logic_dag is not None
        assert result.indexed_requirement_view is not None
        assert result.projection_conformance is not None
        self.assertEqual(len(set(result.logic_dag.roots.as_dict().values())), 4)
        self.assertEqual(len(result.indexed_requirement_view.rows), 4)
        self.assertTrue(result.projection_conformance.exact_projection_passed)
        self.assertFalse(hasattr(result, "final_label"))

        replay = compile_contract_slice(ledger, policy)
        self.assertEqual(replay.model_dump(mode="json"), result.model_dump(mode="json"))

    def test_multiple_primary_norms_stop_before_inventing_all_of(self) -> None:
        policy = _policy(two_primary_units=True)
        ledger = _ledger(
            [
                _candidate("rules2021.section-7.1", selected=True, relation="PRIMARY_NORM"),
                _candidate("rules2021.section-7.2", selected=True, relation="PRIMARY_NORM"),
            ]
        )

        result = compile_contract_slice(ledger, policy)

        self.assertEqual(result.status, ContractSliceStatus.REVIEW_REQUIRED)
        self.assertIn(
            "MULTIPLE_PRIMARY_NORMS_REQUIRE_CONNECTOR_BASIS",
            result.review_required_reason_codes,
        )
        self.assertIsNone(result.logic_dag)
        self.assertIsNone(result.argument_graph_template)

    def test_unresolved_candidate_is_not_promoted_to_a_norm_event(self) -> None:
        policy = _policy()
        ledger = _ledger(
            [_candidate("rules2021.section-7.1", selected=False, relation="UNRESOLVED")]
        )

        result = compile_contract_slice(ledger, policy)

        self.assertEqual(result.status, ContractSliceStatus.REVIEW_REQUIRED)
        self.assertIn("NO_SELECTED_PRIMARY_NORM", result.review_required_reason_codes)
        self.assertEqual(result.closure.seed_policy_unit_ids, [])
        self.assertEqual(result.norm_event_bundle.events, [])
        self.assertIsNone(result.proposition_catalog)

    def test_anchor_replay_failure_stops_before_propositions(self) -> None:
        policy = _policy()
        policy.units[1].full_raw_text = "Different extracted text."
        ledger = _ledger(
            [_candidate("rules2021.section-7.1", selected=True, relation="PRIMARY_NORM")]
        )

        result = compile_contract_slice(ledger, policy)

        self.assertEqual(result.status, ContractSliceStatus.REVIEW_REQUIRED)
        self.assertIn(
            "ORIGINAL_TEXT_ANCHOR_REPLAY_FAILED",
            result.review_required_reason_codes,
        )
        self.assertIsNone(result.proposition_catalog)
        self.assertIsNone(result.logic_dag)

    def test_closure_budget_exhaustion_is_review_required(self) -> None:
        policy = _policy()
        ledger = _ledger(
            [_candidate("rules2021.section-7.1", selected=True, relation="PRIMARY_NORM")]
        )

        result = compile_contract_slice(
            ledger,
            policy,
            closure_config=ClosureConfig(max_added_units=0),
        )

        self.assertEqual(result.status, ContractSliceStatus.REVIEW_REQUIRED)
        self.assertIn(
            "BOUNDED_CLOSURE_BUDGET_EXCEEDED",
            result.review_required_reason_codes,
        )
        self.assertIsNone(result.logic_dag)


if __name__ == "__main__":
    unittest.main()
