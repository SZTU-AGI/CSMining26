from __future__ import annotations

from types import SimpleNamespace

from freca.audit.nodes.farm_profile import build_farm_profile
from freca.audit.nodes.adjudicate import c1_applicability, c7_decide
from freca.domain.enums import (
    Applicability,
    ClaimRelation,
    ClaimType,
    EvidenceIdentityState,
    FinalLabel,
    GateDecision,
    PremiseSourceType,
    Sufficiency,
)
from freca.domain.models import AuditArgument, AuditClaim, ClaimPremise, PolicyPack, PolicySpan, RuleSlots
from freca.evidence.identity import IdentityAnchors, IdentityReference


def _document(
    track: str,
    *,
    names: list[str],
    numbers: list[str],
    products: list[str],
    atoms: list[str],
    state: EvidenceIdentityState = EvidenceIdentityState.SELF,
) -> SimpleNamespace:
    anchors = IdentityAnchors(names=names, re_numbers=numbers, products=products)
    return SimpleNamespace(
        track=track,
        anchors=anchors,
        admissibility=SimpleNamespace(state=state),
        atoms=[SimpleNamespace(content=text, evidence_id=f"case.{track}.{i}") for i, text in enumerate(atoms)],
    )


def test_a0_uses_self_evidence_and_keeps_provenance() -> None:
    evidence = SimpleNamespace(
        case_id="CASE-1",
        reference=IdentityReference("Example Grain Pty Ltd", "RE-NSW-2020-0001"),
        documents=[
            _document(
                "T1",
                names=["Example Grain Pty Ltd"],
                numbers=["RE-NSW-2020-0001"],
                products=["Barley"],
                atoms=[
                    "3 Registration Status The registration period lapsed on 30 June 2024.",
                    "2 Registered Export Operations — Activity: Barley receival; Scope Status: Within scope",
                    "6.1 Buildings and Structures — Main receival shed: steel frame",
                ],
            ),
            _document(
                "T4",
                names=["Example Grain"],
                numbers=["RE-NSW-2020-9999"],
                products=["Field Peas"],
                atoms=["irrelevant supporting plan"],
            ),
            _document(
                "T3",
                names=["Foreign Grain"],
                numbers=["RE-QLD-2020-0002"],
                products=["Maize"],
                atoms=["foreign evidence"],
                state=EvidenceIdentityState.FOREIGN,
            ),
        ],
    )

    profile = build_farm_profile(evidence)

    assert profile.registered_entity == "Example Grain Pty Ltd"
    assert profile.registration_number == "RE-NSW-2020-0001"
    assert profile.registration_status == "lapsed"
    assert profile.registered_commodities == ["Barley", "Field Peas"]
    assert profile.registered_activities == ["Barley receival"]
    assert profile.registered_facilities == ["Main receival shed"]
    assert profile.identity_conflicts
    assert "registered_entity" in profile.field_provenance
    assert "T3" not in profile.field_provenance.get("registered_commodities", [])


def test_a0_does_not_turn_missing_identity_into_false() -> None:
    evidence = SimpleNamespace(
        case_id="CASE-2",
        reference=IdentityReference("Example Grain", "RE-NSW-2020-0002"),
        documents=[
            _document(
                "T2",
                names=[],
                numbers=[],
                products=[],
                atoms=["no identity claims"],
                state=EvidenceIdentityState.UNKNOWN,
            )
        ],
    )

    profile = build_farm_profile(evidence)

    assert profile.registered_entity is None
    assert profile.registration_number is None
    assert "registered_entity" in profile.unknown_fields
    assert "registration_number" in profile.unknown_fields
    assert profile.scope_context()["registered_entity"] is None


def test_scope_predicate_negative_is_not_applicable_but_unknown_is_not_na() -> None:
    span = PolicySpan(
        source_id="s1",
        locator="s1",
        text="scope",
        source_hash="sha256:" + "0" * 64,
    )
    pack = PolicyPack(
        cp_id="CP-X",
        policy_version="2021",
        authoritative_spans=[span],
        rule_slots=RuleSlots(subject="farm", deontic="must", action="act", object="thing"),
        scope_predicates=["handles_fumigated_goods"],
        required_facts=["thing exists"],
    )

    negative, negative_gate, matched = c1_applicability(
        cp_id="CP-X", pack=pack, profile={"handles_fumigated_goods": False}
    )
    unknown, unknown_gate, unknown_matched = c1_applicability(
        cp_id="CP-X", pack=pack, profile={}
    )

    assert negative is Applicability.NOT_APPLICABLE
    assert negative_gate.decision is GateDecision.PASS
    assert matched == ["handles_fumigated_goods"]
    assert unknown is Applicability.UNKNOWN
    assert unknown_gate.decision is GateDecision.ESCALATE
    assert unknown_matched == []


def test_typed_profile_supports_explicit_legal_exemption_lookup() -> None:
    span = PolicySpan(
        source_id="s2",
        locator="s2",
        text="scope",
        source_hash="sha256:" + "1" * 64,
    )
    pack = PolicyPack(
        cp_id="CP-Y",
        policy_version="2021",
        authoritative_spans=[span],
        rule_slots=RuleSlots(subject="farm", deontic="must", action="act", object="thing"),
        explicit_legal_exemptions=["legal_exclusion_applies"],
        required_facts=["thing exists"],
    )
    profile = build_farm_profile(
        SimpleNamespace(
            case_id="CASE-EXEMPT",
            reference=IdentityReference("Example Grain", "RE-NSW-2020-0003"),
            documents=[],
        )
    )
    # The typed profile has no dynamic ``get`` method.  The lookup must still
    # execute and remain UNKNOWN rather than raising an AttributeError.
    applicability, gate, matched = c1_applicability(
        cp_id="CP-Y", pack=pack, profile=profile
    )
    assert applicability is Applicability.APPLICABLE
    assert gate.decision is GateDecision.PASS
    assert matched == []


def test_explicit_a0_non_applicability_survives_c7() -> None:
    argument = AuditArgument(
        argument_id="CASE-3.CP-X",
        case_id="CASE-3",
        cp_id="CP-X",
        claims=[
            AuditClaim(
                claim_id="c-applicability",
                claim_type=ClaimType.APPLICABILITY,
                proposition={"applicable": False},
                premises=[
                    ClaimPremise(
                        source_type=PremiseSourceType.DETERMINISTIC_RESULT,
                        source_id="profile.na_conditions",
                        relation=ClaimRelation.EXCEPTS,
                    )
                ],
            ),
            AuditClaim(
                claim_id="c-verdict",
                claim_type=ClaimType.VERDICT,
                proposition={"label": "N/A"},
                depends_on=["c-applicability"],
            ),
        ],
        candidate_label=FinalLabel.NOT_APPLICABLE,
        sufficiency=Sufficiency.SUFFICIENT,
    )

    decision = c7_decide(
        argument=argument,
        applicability=Applicability.NOT_APPLICABLE,
        gate_report_ids=["CP-X.c1"],
        review_required=False,
        reasoning="explicit A0 scope fact",
    )

    assert decision is not None
    assert decision.label is FinalLabel.NOT_APPLICABLE
    assert decision.supporting_evidence_ids == ["profile.na_conditions"]
