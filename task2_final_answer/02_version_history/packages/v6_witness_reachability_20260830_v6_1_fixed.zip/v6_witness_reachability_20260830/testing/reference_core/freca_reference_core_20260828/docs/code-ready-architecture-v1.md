# FRECA 扩充版准备实施架构 v1

> 状态：当前代码已完成第一版可运行纵切面；本文同时区分“当前 as-built”和“目标设计”。  
> 约束：保留现有 `M0 → R0/R1 → E0–E3 → A0 → C0–C7 → P0–P2 → V0` 主干。  
> 新增内容只作为节点内部机制、节点后的验证门和包围主干的工程运行层，不重排、不替换原架构。

> 2026-08-01 V2 冻结：旧版中的独立 C3 N/A 活动反证检查、P1 自动回查相关 CP、
> Verdict-Masked / Structure-Masked 流水线必须保留。合并后的目标图见
> [`target-architecture-v2.md`](target-architecture-v2.md)。

## 0. 本轮结论

### 0.1 当前实现映射

当前可运行代码位于 `src/freca/`，与本设计的对应关系如下：

| 设计节点 | 当前实现 | 运行产物 |
|---|---|---|
| M0 | `manifest.build` | `manifest.json`、`manifest_report.json` |
| R0/R1 | `policy.anchor`、`policy.pack` | policy sections、anchors、packs |
| E0–E3 | `evidence.pipeline` | evidence atoms / identity states |
| A0 | `audit.nodes.farm_profile` | `farm_profiles.jsonl` |
| C0–C7 | `audit.nodes.adjudicate` | `decisions.jsonl`、gate traces |
| P0–P2 | `consistency` | `consistency_summary.json`、submission report |
| V0 | `evaluation.run_gate`、`evaluation.v0` | `run_health.json`、V0 四类报告 |

实现中的重要语义：`UNKNOWN` scope 在 C6 阻断并等待人工复核；blocked 单元格的格式占位值不进入 scored cells；无 gold 时 V0 输出 `NO_GOLD`，不输出 accuracy。

### 0.2 当前 as-built 与目标设计的边界

下面这张图描述的是当前代码真实执行的路径；后文较早写下的“设计目标”仍保留，
但不能当作已经全部实现的模块清单。

```mermaid
flowchart LR
    M0["M0\nmanifest build + validate"]
    R["R0/R1\nsectionize + NormGraph + anchor + PolicyPack"]
    E["E0–E3\nDOCX/XLSX evidence + identity"]
    A0["A0\nFarmProfile from SELF evidence"]
    C0["C0\nanchor admission"]
    C1["C1\nscope applicability"]
    C2["C2\nretrieval needs"]
    C3["C3\nBM25 evidence retrieval"]
    C4["C4\nargument assembly + model read"]
    C5["C5\nArgumentValidator"]
    C6S["C6\nscope manual-review block"]
    C6R["C6.rN\nbounded repair retrieval"]
    C7["C7\nfinal decision emission"]
    P01["P0/P1\ncase + cross-CP consistency"]
    H["RunHealth\ncoverage + synthetic hard gate"]
    P2["P2\nsubmission assembly"]
    V0["V0\ngold / perturbation / leakage report"]
    BLOCK["blocked artifact\nno scored verdict"]

    M0 --> R
    M0 --> E
    R --> A0
    E --> A0
    R --> C0
    A0 --> C0
    C0 --> C1
    C1 -->|UNKNOWN| C6S
    C1 -->|APPLICABLE or N/A| C2
    C2 -->|needs exist| C3
    C2 -->|no needs| C4
    C3 --> C4
    C4 --> C5
    C5 -->|PASS| C7
    C5 -->|RETRY| C6R
    C6R --> C4
    C5 -->|BLOCK| BLOCK
    C6S --> BLOCK
    C7 --> P01
    P01 --> H
    H -->|RUN_VALID| P2
    H -->|RUN_INVALID| BLOCK
    P2 --> V0
```

当前实现不是“每个节点都调用一次 LLM”：R0、A0、C0–C3、C5、P0/P1 和
RunHealth 主要由确定性代码完成；LLM 只在 C4 读取证据（以及显式启用时的
model-assisted PolicyPack 槽位填充）使用。`--backend none` 或 fake 无有效 label
时，C4 会阻断，不会把缺少阅读误写成 `1` 或 `0`。

| 当前已实现 | 当前状态 | 目标设计中尚未完全落地的部分 |
|---|---|---|
| M0/E0–E3 | 100 logical cases、898 个已索引文件、身份五态和 locator | 完整 artifact envelope/runtime resume 仍是目标层 |
| R0/R1 | sectionize、NormGraph、subject closure、anchor、unit-level PolicyPack | dense/hybrid RAG 对照和人工冻结全量 pack 仍需实验 |
| A0 | `FarmProfile`、SELF 过滤、provenance、conflict、unknown | CP-specific scope predicate 仍需人工 gold 校准 |
| C0–C7 | typed argument、三值 scope、C6 阻断/重检索、C7 发决策 | 独立 blind semantic reviewer、复杂 Z3 约束暂未启用 |
| P0–P2 | consistency 检查、blocked 占位、run-health 后才允许导出 | 正式 100×41 gold 结果尚未产生 |
| V0 | `NO_GOLD`、coverage、blocked、label distribution、扰动、leakage | 需要服务器真实模型和人工 gold 才能计算正式准确率 |

本轮吸收两类思想：

1. [VeriCoT](https://arxiv.org/abs/2511.04662) 的“显式前提—逐步主张—蕴含/矛盾/无依据检查”；
2. [Harness Engineering for Self-Improvement](https://lilianweng.github.io/posts/2026-07-04-harness/) 的“工作流、工具、上下文、持久状态、验证器、权限和回归评测共同构成运行时”。

但不直接照搬：

- 不记录或验证模型隐藏的自由形式思维链；
- 不在 MVP 中把 132 页法规全文自动翻译成一阶逻辑；
- 不允许模型用“常识前提”直接支撑审计结论；
- 不做自动改代码、自动改提示或自动改评测配置的在线自进化；
- 不改变现有 A–D RAG 对照和 M0–V0 业务主线。

最终采用的实现形态是：

> **外层 Audit Harness 管运行，内层原有节点做业务；Agent 是受状态机约束的控制器，RAG 是取证工具，Typed Audit Argument 是可复核中间产物，确定性 Validator 是硬门，独立 Reviewer 是语义门。**

## 1. 不变的业务主线

```mermaid
flowchart LR
    M0["M0 Manifest"] --> R["R0/R1 PolicyPack"]
    M0 --> E["E0–E3 Evidence"]
    R --> A0["A0 FarmProfile"]
    E --> A0
    R --> C0["C0 Anchor admission"]
    A0 --> C0
    C0 --> C1["C1 Scope applicability"]
    C1 -->|UNKNOWN → block| C6S["C6 Scope manual review"]
    C1 -->|APPLICABLE/N/A| C2["C2 Retrieval needs"]
    C2 --> C3["C3 BM25 retrieval"]
    C3 --> C4["C4 Argument + model reading"]
    C4 --> C5["C5 Deterministic validation"]
    C5 -->|RETRY| C6R["C6.rN Targeted retrieval"]
    C6R --> C4
    C5 -->|PASS| C7["C7 Final CP"]
    C6S --> B["Blocked / review queue"]
    C7 --> P["P0/P1 Consistency"]
    P --> H["RunHealth gate"]
    H -->|valid| P2["P2 Submission"]
    H -->|invalid| B
    P2 --> V0["V0 Evaluation"]
```

需要特别冻结的语义：

- `N/A`：法规明确不适用于本案，且已完成反向核查；
- `INSUFFICIENT`：内部证据状态，不是最终标签；
- 若赛题强制三值，适用但缺少必需证据时，按预先冻结的全局协议映射为 `0`，同时保留：
  - `basis = missing_required_evidence`
  - `sufficiency = insufficient`
  - `review_required = true`
- 外来主体证据可以成为冲突线索，但不得直接支持本案合规。

## 2. 外层 Audit Harness：包围主干，不增加业务步骤

Harness 不是新的裁决 Agent，也不是另一条流水线。它是所有原节点共用的工程底座。

```mermaid
flowchart TB
    subgraph H["Audit Harness"]
      RT["Workflow Runtime"]
      AS["Artifact Store"]
      CB["Context Builder"]
      TR["Tool Registry"]
      VR["Validator Registry"]
      EV["Event / Trace Recorder"]
      CF["Frozen Config & Prompt Registry"]
      ER["Evaluation & Regression Runner"]
      PM["Permission Boundary"]
    end

    CORE["M0 → R0/R1 → E0–E3 → A0 → C0–C7 → P0–P2 → V0"]

    RT --> CORE
    AS <--> CORE
    CB --> CORE
    TR --> CORE
    VR --> CORE
    CORE --> EV
    CF --> CORE
    ER --> CORE
    PM --> H
```

### 2.1 Harness 的九项职责

| 组件 | 只负责什么 | 明确不负责什么 |
|---|---|---|
| Workflow Runtime | 节点顺序、状态迁移、重试、暂停、恢复 | 不判断合规 |
| Artifact Store | 原子落盘、版本、哈希、依赖关系 | 不把文件内容偷偷拼进 prompt |
| Context Builder | 按节点组装最小输入包 | 不携带无限聊天历史 |
| Tool Registry | 暴露解析、检索、日期/数值计算等工具 | 不决定最终标签 |
| Validator Registry | 运行确定性和语义验证门 | 不自行补造证据 |
| Trace Recorder | 记录事件、输入输出引用、耗时和错误 | 默认不重复保存完整敏感原文 |
| Config Registry | 冻结模型、prompt、阈值、法规和 schema 版本 | 运行中不可被 Agent 修改 |
| Eval Runner | 基线、消融、扰动和回归测试 | 不参与生产裁决 |
| Permission Boundary | 原始数据、验证器、评测集只读 | MVP 不开放自修改代码 |

### 2.2 统一产物封套

每个节点的输出都使用同一个 envelope，禁止只靠内存或聊天消息传递：

```json
{
  "artifact_id": "art_...",
  "artifact_type": "evidence_atom_set",
  "schema_version": "1.0",
  "run_id": "run_...",
  "case_id": "FRECA-T2-S096",
  "cp_id": "CP22",
  "producer_node": "E3",
  "producer_version": "git_sha_or_package_version",
  "input_artifact_ids": ["art_..."],
  "input_hashes": {"source_file": "sha256:..."},
  "config_hash": "sha256:...",
  "prompt_hash": null,
  "status": "SUCCEEDED",
  "created_at": "ISO-8601",
  "payload_path": "artifacts/evidence/...",
  "validation_report_ids": ["gate_..."]
}
```

这使任意一个最终 `1/0/N/A` 都能反向追到：

```text
FinalDecision
  → VerificationReport
  → AuditArgument
  → EvidenceAtom / PolicyPack
  → 原始 DOCX 段落、表格或 XLSX 单元格
```

## 3. VeriCoT 的适配：验证“审计论证”，不验证隐藏思维链

### 3.0 R0 法规链的实测后细化

41 CP × 184 条款节的开发实测显示，manager、occupier、exporter 和
authorised officer 的近同文平行义务会使纯 BM25 top-1 越界；孤立主体过滤
又会误剪 11-2 这类通过其他条款适用的通用规范。因此 R0 内部冻结为：

```text
Norm Corpus
  → Norm Graph
  → Subject Closure
  → Scope/Subject Gate
  → Lexical Anchor
  → PolicyPack
```

至少支持 `APPLIES_VIA`，并保存主体继承路径。新增
`POLICY_SUBJECT_MISMATCH / POLICY_SCOPE_MISMATCH /
POLICY_SUBJECT_UNRESOLVED / POLICY_GRAPH_PATH_MISSING`。

法规锚定单独做 P-A/P-B/P-C 实验；证据侧 A–F 使用相同的 R1 冻结
PolicyPack。完整冻结说明见
[`policy-chain-design-freeze.md`](policy-chain-design-freeze.md)。

### 3.1 新增 Typed Audit Argument

在 C2–C5 内部生成显式、短小、可机器检查的论证图。它不是另一条业务链，也不改变 C0–C7。

```mermaid
flowchart BT
    P["PolicyClaim：法规要求什么"] --> V["VerdictClaim：本 CP 的候选结论"]
    A["ApplicabilityClaim：是否适用"] --> V
    E1["EvidenceClaim：支持事实"] --> V
    E2["CounterEvidenceClaim：反证/冲突"] --> V
    S["SufficiencyClaim：必需事实是否齐全"] --> V
```

允许的 claim 类型：

- `POLICY`
- `APPLICABILITY`
- `EVIDENCE`
- `COUNTER_EVIDENCE`
- `DERIVED_FACT`
- `SUFFICIENCY`
- `VERDICT`

允许的 premise 来源：

- `POLICY_SOURCE`：R0/R1 冻结的法规原文；
- `CASE_EVIDENCE`：E1–E3 产生且可定位的本案证据；
- `DETERMINISTIC_RESULT`：日期、数值、集合、表格运算结果；
- `PRIOR_CLAIM`：同一论证图中已验证的上游主张。

**禁止 `COMMONSENSE` 成为最终 verdict 的硬前提。** 模型可用常识生成查询词，但必须重新找到法规或案例来源。

允许的边：

- `SUPPORTS`
- `CONTRADICTS`
- `REQUIRES`
- `EXCEPTS`
- `DERIVED_FROM`

### 3.2 三类论文错误信号在本项目中的扩展

| VeriCoT 信号 | FRECA 中的实现 | 下一动作 |
|---|---|---|
| `UNGROUNDED` | 主张无 citation、citation 不含该事实、必需事实缺失 | C6 定向补检索或升级人工 |
| `CONTRADICTION` | 主张与法规、同案证据或已验证事实冲突 | 进入 conflict review |
| `UNTRANSLATABLE` | 法规/事实不能可靠放入固定 schema，或歧义无法消除 | 禁止强行形式化，ESCALATE |
| — | `IDENTITY_MISMATCH` | 外来主体只进冲突通道 |
| — | `TEMPORAL_MISMATCH` | 重新核对有效期/时间窗口 |
| — | `INSUFFICIENT` | 按缺证协议处理，不得改成 N/A |
| — | `CITATION_INVALID` | 删除无效支持，必要时返回 C6 |

### 3.3 MVP 先做规则验证器，Z3 作为可插拔扩展

VeriCoT 使用 SMT-LIB 和 Z3，但其论文也明确指出：自动形式化错误和错误前提仍可能导致“形式上成立、自然语言上错误”。

因此第一版采用：

```text
ArgumentValidator protocol
  ├─ RuleBasedArgumentValidator   # MVP，Pydantic + Python 规则
  └─ Z3ArgumentValidator          # 后续消融或复杂数值/时序 CP
```

第一版硬规则：

```text
N/A:
  applicability == NOT_APPLICABLE
  AND explicit_na_condition has valid policy citation
  AND supporting case evidence exists
  AND na_countercheck == PASS

1:
  applicability == APPLICABLE
  AND all required facts are supported
  AND all supporting evidence passes identity/time/citation gates
  AND no unresolved blocking contradiction exists

0:
  applicability == APPLICABLE
  AND (
      a violation fact is supported
      OR required evidence is absent under the frozen global protocol
  )

Any:
  verdict cannot depend on UNKNOWN / INVALID / FOREIGN supporting evidence
  all PRIOR_CLAIM dependencies must be acyclic and already verified
```

只有当规则验证器已经稳定、某些 CP 确实需要组合逻辑或数值/时间约束时，才添加 Z3 backend。这样可以把“形式化器错误”与“审计错误”分开测量。

## 4. 原有每个节点的扩充与复核门

| 节点 | 业务输出不变 | 新增验证门 | 失败后的唯一允许动作 |
|---|---|---|---|
| M0 | 100 个逻辑案例 manifest | 数量、双案例拆分、缺 T1、文件 hash、case_id 唯一性 | BLOCK，修 manifest |
| R0 | 41 个 PolicyPack 草案 | schema、引用存在性、槽位可回指原文 | RETRY 抽取 |
| R1 | 冻结 PolicyPack | 人工只核忠实性；记录法规/prompt/model hash | BLOCK，等待核验 |
| E0 | 文档结构图 | DOCX 段/表顺序、XLSX sheet/range 计数 | 重解析 |
| E1 | 原子证据 | locator 可回开、文本非空、source hash 匹配 | 重解析/标异常 |
| E2 | provenance | case、track、文档、页/段/cell 路径完整 | BLOCK 对应证据 |
| E3 | 身份与时间 | 多锚点一致；`SELF/SUPPLIER/FOREIGN/MIXED/UNKNOWN` | 降级/冲突通道 |
| A0 | farm profile | 字段必须来自已验证证据；冲突不静默覆盖 | 保留多值并标冲突 |
| C0 | 当前 CP 的 anchor admission | 检查 anchor 是否属于允许的法规主体/范围 | BLOCK 当前 CP |
| C1 | A0 scope applicability | `scope_predicates`、显式法律豁免与 A0 profile 三值评估 | `UNKNOWN` 进入 C6 scope review |
| C2 | retrieval needs | 从 required/violation facts 形成 query facets | 无 need 时阻断当前 CP |
| C3 | evidence retrieval | case_id 硬过滤、locator、分数 trace、SELF/FOREIGN 状态 | 空结果进入 C4 blocked |
| C4 | argument + candidate verdict | Typed Audit Argument；真实 backend 才能产生 substantive label | 无读取/无 label 则 BLOCK |
| C5 | deterministic validation | claim dependency、引用、身份、充分性和标签一致性 | RETRY/BLOCK |
| C6 | scope review 或 targeted retrieval | 范围 UNKNOWN 终止；C5 retry 最多两轮且必须有新证据 | BLOCK/回 C4 |
| C7 | final CP | label、basis、citations、argument、gate reports 齐全 | 无候选标签则 BLOCK |
| P0 | case shared facts | 共享实体/RE/商品/日期不能静默冲突 | 标记受影响 CP |
| P1 | cross-CP consistency | 只检查预定义关系和共享事实，不靠多数票 | 局部重跑 |
| P2 | final output | 4100 格完整、三值合法、审计附件齐全 | BLOCK 导出 |
| V0 | 实验结果 | gold、coverage、blocked、label distribution、扰动、leakage | 无 gold 不报告 accuracy |

### 4.1 “每一步复核”不是每步再问一次同一个 LLM

复核按错误类型选择机制：

- 结构/数量/哈希/坐标/标签约束：确定性程序；
- 引用是否真的包含声称事实：独立 Evidence Reviewer；
- 候选 verdict 是否由已验证事实推出：Argument Validator；
- 跨 CP 冲突：Case Consistency Reviewer；
- 高风险或无法结构化：人工复核。

这样能减少“同一个模型用相同上下文重复同一个错误”。

## 5. C0–C7 的可编码状态机

```text
INIT
  → POLICY_READY
  → PRIMARY_EVIDENCE_READY
  → APPLICABILITY_READY
  → NA_CHECKED
  → ARGUMENT_DRAFTED
  → VERIFYING
      → VERIFIED
      → NEED_TARGETED_RETRIEVAL
      → ESCALATED
  → FINALIZED
```

状态转移必须由 `GateReport` 驱动，LLM 文本不能直接修改状态。

```python
class GateDecision(str, Enum):
    PASS = "PASS"
    RETRY = "RETRY"
    ESCALATE = "ESCALATE"
    BLOCK = "BLOCK"

class VerificationIssueCode(str, Enum):
    UNGROUNDED = "UNGROUNDED"
    CONTRADICTION = "CONTRADICTION"
    UNTRANSLATABLE = "UNTRANSLATABLE"
    IDENTITY_MISMATCH = "IDENTITY_MISMATCH"
    TEMPORAL_MISMATCH = "TEMPORAL_MISMATCH"
    INSUFFICIENT = "INSUFFICIENT"
    CITATION_INVALID = "CITATION_INVALID"
```

C6 的重试约束：

```text
retry_count <= 2
query must reference one or more issue_id
same normalized query cannot repeat
no new evidence_atom_id => stop
new evidence still fails the same hard gate => escalate
```

## 6. 核心数据契约

### 6.1 EvidenceAtom

```json
{
  "evidence_id": "ev_...",
  "case_id": "FRECA-T2-S096",
  "doc_id": "doc_...",
  "track": "T6",
  "source_type": "xlsx_range",
  "locator": {
    "sheet": "Records",
    "range": "B12:H18",
    "headers": ["Date", "Product", "Lot"]
  },
  "content": "...",
  "identity": {
    "state": "SELF",
    "farm": "...",
    "re_number": "...",
    "product": "...",
    "address": "...",
    "effective_time": "..."
  },
  "source_hash": "sha256:...",
  "parse_confidence": 1.0
}
```

### 6.2 PolicyPack

```json
{
  "cp_id": "CP22",
  "policy_version": "policy-2026-01",
  "authoritative_spans": [],
  "rule_slots": {
    "subject": "...",
    "deontic": "MUST",
    "action": "...",
    "object": "...",
    "conditions": [],
    "temporal": "..."
  },
  "scope_predicates": [],
  "required_facts": [],
  "violation_facts": [],
  "explicit_legal_exemptions": [],
  "counter_facts": [],
  "related_cp_ids": []
}
```

### 6.3 AuditClaim / AuditArgument

```json
{
  "argument_id": "arg_...",
  "case_id": "FRECA-T2-S096",
  "cp_id": "CP22",
  "claims": [{
    "claim_id": "claim_1",
    "claim_type": "EVIDENCE",
    "proposition": {
      "predicate": "record_retention_period_at_least",
      "subject": "farm",
      "object": "2_years"
    },
    "premises": [{
      "source_type": "CASE_EVIDENCE",
      "source_id": "ev_...",
      "role": "SUPPORTS"
    }],
    "depends_on": [],
    "status": "UNVERIFIED"
  }],
  "candidate_label": "1",
  "sufficiency": "SUFFICIENT"
}
```

### 6.4 GateReport

```json
{
  "gate_id": "gate_...",
  "gate_name": "argument_grounding",
  "decision": "RETRY",
  "severity": "HARD",
  "issues": [{
    "issue_id": "issue_...",
    "code": "UNGROUNDED",
    "claim_id": "claim_1",
    "artifact_ids": ["ev_..."],
    "message": "引用片段没有覆盖声称的保存期限",
    "retryable": true,
    "retrieval_need": {
      "fact_type": "retention_period",
      "query_facets": ["record retention", "two years"]
    }
  }]
}
```

### 6.5 FinalDecision

```json
{
  "case_id": "FRECA-T2-S096",
  "cp_id": "CP22",
  "label": "0",
  "applicability": "APPLICABLE",
  "sufficiency": "INSUFFICIENT",
  "basis": "missing_required_evidence",
  "supporting_evidence_ids": [],
  "contrary_evidence_ids": [],
  "argument_id": "arg_...",
  "gate_report_ids": [],
  "review_required": true,
  "reasoning_summary": "由已验证结构自动生成的简短说明"
}
```

`reasoning_summary` 只能从已验证 argument 渲染，不能成为新的事实来源。

## 7. Python 仓库结构

```text
FRECA/
  pyproject.toml
  README.md
  configs/
    base.yaml
    models.yaml
    retrieval/
      full_context.yaml
      bm25_spotlight.yaml
      hybrid_spotlight.yaml
      pure_hybrid.yaml
    prompts/
      policy_extract/
      applicability/
      argument_build/
      evidence_review/
  src/freca/
    cli.py
    domain/
      enums.py
      models.py
      errors.py
      protocols.py
    harness/
      runtime.py
      state_machine.py
      artifact_store.py
      context_builder.py
      tool_registry.py
      validator_registry.py
      trace.py
      cache.py
      permissions.py
    manifest/
      build.py
      validate.py
    policy/
      extract.py
      validate.py
      store.py
    evidence/
      structure_map.py
      docx_parser.py
      xlsx_parser.py
      provenance.py
      identity.py
      store.py
    retrieval/
      protocols.py
      full_context.py
      bm25.py
      dense.py
      hybrid.py
      rerank.py
      teammate_adapter.py
    audit/
      controller.py
      nodes/
        c0_load_policy.py
        c1_primary_retrieval.py
        c2_applicability.py
        c3_na_countercheck.py
        c4_candidate_verdict.py
        c5_review_state.py
        c6_targeted_search.py
        c7_finalize.py
      argument_builder.py
      evidence_reviewer.py
    verification/
      deterministic.py
      citation.py
      argument_rules.py
      z3_backend.py
    consistency/
      shared_facts.py
      reviewer.py
      exporter.py
    evaluation/
      baselines.py
      metrics.py
      leakage.py
      perturbations.py
      propagation.py
      regression.py
  artifacts/
    manifests/
    policy_packs/
    evidence/
    retrieval/
    arguments/
    verification/
    decisions/
    case_reports/
    runs/
  tests/
    unit/
    integration/
    golden/
    regression/
```

### 7.1 核心接口

```python
class Node(Protocol):
    name: str
    def run(self, ctx: NodeContext, state: CPRunState) -> NodeResult: ...

class Validator(Protocol):
    name: str
    def validate(self, result: NodeResult, ctx: NodeContext) -> GateReport: ...

class Retriever(Protocol):
    def search(self, request: RetrievalRequest) -> RetrievalResponse: ...

class ArtifactStore(Protocol):
    def put(self, envelope: ArtifactEnvelope, payload: BaseModel) -> ArtifactRef: ...
    def get(self, artifact_id: str) -> BaseModel: ...
```

同学 RAG 和另一位同学的 RAG 都只实现 `Retriever`，不会侵入 C2–C7。

## 8. 上下文与持久记忆

每个节点只接收 `ContextPacket`：

```json
{
  "node": "C4",
  "case_id": "FRECA-T2-S096",
  "cp_id": "CP22",
  "policy_pack_id": "art_policy_...",
  "farm_profile_id": "art_profile_...",
  "evidence_ids": ["ev_1", "ev_2"],
  "prior_claim_ids": ["claim_app_..."],
  "token_budget": 12000
}
```

原则：

- 原始 evidence 不重复写入大量日志；
- 长轨迹按文件保存，当前节点只读摘要和 artifact id；
- 所有关键状态落盘，可从最后一个成功节点恢复；
- 失败也落盘，不能只保留成功结果；
- cache key 至少包含输入 hash、prompt hash、model config hash 和 schema version。

## 9. 权限与防止“评测作弊”

运行期目录权限：

```text
只读：
  数据集/
  冻结法规/
  gold/
  evaluation/verifiers/
  configs/frozen_run/

可写：
  artifacts/runs/<run_id>/
  cache/<run_id>/
  reports/<run_id>/
```

MVP 禁止：

- Agent 修改验证器；
- Agent 修改 gold 或 V0 扰动集；
- Agent提高 token/重试上限后把结果与旧配置直接比较；
- Agent自动合并 prompt 或代码改动；
- 失败运行被覆盖或删除。

后续若研究 Harness 改进，只允许离线流程：

```text
失败聚类
  → 人工审核的局部修改提案
  → held-in 验证
  → held-out 无回归检查
  → 人工批准
  → 新版本
```

这不是首篇论文 MVP 的必要组成。

## 10. 首个纵切面与开发阶段

### Phase 0：协议冻结与仓库骨架（1–2 天）

- 创建 `pyproject.toml`、包目录、测试目录；
- 实现 enums、Pydantic models、ArtifactEnvelope；
- 冻结 label/applicability/sufficiency/basis 语义；
- 建立配置 hash、run_id 和 JSONL event log；
- 不接 LLM，不做检索。

**验收：** schema round-trip、非法状态拒绝、相同输入生成稳定 hash。

### Phase 1：M0 + E0–E3（3–5 天）

- 生成 100 logical cases manifest；
- 正确处理 99 个物理目录、一个双案例目录、两处缺 T1；
- 实现 DOCX 段表顺序和 XLSX sheet/cell locator；
- 实现 identity 五态和外来证据三通道。

**验收：** 任一 EvidenceAtom 可重新打开到原始位置；跨 case 数据不能进入同一检索请求。

### Phase 2：R0/R1 + A0（3–5 天）

- 先人工准备 7 个代表 CP 的冻结 PolicyPack；
- 同步实现通用自动抽取器，但其产物必须经 R1 忠实性核验；
- 从已验证证据生成 A0，不静默合并冲突字段。

**验收：** 每个 required fact 和 N/A 条件都能回到法规 span。

### Phase 3：A–D RAG 基线 + C0/C1（4–6 天）

- Full Context；
- BM25 Spotlight + Full Context；
- Hybrid Spotlight + Full Context；
- Pure Hybrid RAG；
- 统一 RetrievalRequest/Response 和 trace；
- 暂不加入 Agent 纠错，以保留干净基线。

**验收：** S096 × 7 CP 可输出召回记录；所有 hit 的 case_id/locator 可验证。

### Phase 4：C2–C7 纵切面（5–8 天）

- C2 适用性；
- C3 N/A counter-check；
- C4 Typed Audit Argument；
- C5 rule validator + blind evidence reviewer；
- C6 bounded targeted retrieval；
- C7 final decision。

**验收：** S096 + 另外 2 案 × 7 CP 全程可恢复、可追溯；每个最终格有 argument 和 gate report。

### Phase 5：P0–P2 + V0（5–7 天）

- shared facts；
- 跨 CP consistency；
- 4100 格导出；
- 10 案 micro-gold；
- verdict-masked / structure-masked / missing / foreign / conflict 扰动；
- A–F 消融。

**验收：** 既报告最终标签，也报告检索、引用、验证门和错误传播指标。

## 11. 第一批必须先写的测试

### Unit

1. 物理目录中的双案例被拆成两个 logical case；
2. 两处缺 T1 显式记录而非崩溃或静默跳过；
3. DOCX 段落和表格顺序不被打乱；
4. XLSX locator 能回到 sheet/range/header；
5. `FOREIGN` evidence 不能进入 supporting evidence；
6. 适用但缺证不能输出 `N/A`；
7. N/A 没有 explicit condition 或 counter-check 时不得通过；
8. citation 不含 claim 内容时触发 `CITATION_INVALID`；
9. claim dependency cycle 被拒绝；
10. C6 重复查询、无新增证据或超过两轮时停止。

### Integration

1. `M0 → E3` 产生可回溯 EvidenceAtom；
2. `C0 → C7` 使用 fake LLM/fake retriever 跑通；
3. 进程中断后从 artifact store 恢复；
4. 同一输入与冻结配置可复现相同结构化产物；
5. 换 RAG backend 不改变 C2–C7 接口。

### Golden / Regression

- 第一套 golden：`S096 × 7 CP`；
- 第二套：一个缺失证据案；
- 第三套：一个外来主体/冲突证据案；
- 每次 prompt、retrieval 或 validator 变化，都运行 held-in 和 held-out；
- 同时保留修复项与风险回归项，不只看平均分。

## 12. 论文实验保持原方案，新增两组验证

原有 A–D 不变：

- A Full Context；
- B BM25 Spotlight + Full Context；
- C Hybrid Spotlight + Full Context；
- D Pure Hybrid RAG。

Agent 部分：

- E Agentic Hybrid：有 C0–C7 控制和补检索，但去掉逐步验证门；
- F 完整方法：原主架构 + Audit Harness + Typed Audit Argument + 逐步验证门。

新增内部消融：

- F–Argument Validator；
- F–Blind Evidence Reviewer；
- F–Identity Gate；
- F–N/A Counter-check；
- F–P0/P1 Consistency；
- F–Bounded Retry。

新增指标：

- 最终：macro-F1、MCC、N/A F1；
- 检索：support/contrary Recall@k、MRR、跨 case 泄漏率；
- 引用：precision、completeness、locator validity；
- 论证：argument verification coverage、ungrounded/contradiction/untranslatable rate；
- 验证门：Error Detection、Recovery、Propagation、False Block；
- 鲁棒性：Missing/Foreign/Conflict/Distractor 下的翻转率；
- 效率：调用数、token、平均重试轮数、成功 CP 延迟。

## 13. 开工时的提交顺序

建议前六个小提交：

1. `chore: scaffold freca package and test layout`
2. `feat: add domain enums and artifact schemas`
3. `feat: add append-only artifact store and run events`
4. `feat: build and validate logical case manifest`
5. `feat: parse docx/xlsx into provenance-preserving evidence atoms`
6. `test: add manifest, provenance, identity and label invariants`

第一周不要写：

- 多 Agent 对话；
- Z3 自动形式化；
- 自动 prompt 优化；
- 图数据库；
- 训练 reranker；
- 全 41 CP prompt。

先确保数据、状态、产物和三值语义正确。否则上层 Agent 只会更快地传播错误。

## 14. 正式开工门

以下全部满足即可开始写主代码：

- [x] 研究问题和核心假设已定义；
- [x] 主架构边界已冻结，不用同学方案替换主线；
- [x] 两篇新增材料的可采用项和限制已明确；
- [x] 100/99/898、双案例和缺 T1 事实已记录；
- [ ] 7 个代表 CP 最终名单由项目方确认；
- [ ] `N/A` 与缺证映射协议形成一页冻结说明；
- [ ] S096 的 7 CP golden evidence spans 整理为统一 schema；
- [ ] Python 运行版本和首个模型/embedding backend 写入 config；

前三项属于实现前硬门；模型和检索 backend 可以通过接口后换，不阻止先写 Phase 0–1。
