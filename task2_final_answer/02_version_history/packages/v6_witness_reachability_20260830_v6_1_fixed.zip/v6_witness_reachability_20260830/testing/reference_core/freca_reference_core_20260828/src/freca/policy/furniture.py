"""Two-pass page furniture and legal-line classification."""

from __future__ import annotations

import re
from collections import Counter

from freca.policy.schemas_v2 import ExtractedPolicyText, LineClass, PolicyLine

_TOC = re.compile(r"\.{4,}\s*\d+\s*$")
_STRUCTURAL = re.compile(r"^(Chapter|Part|Division|Subdivision)\s+\d+[A-Z]?—\S")
_SECTION = re.compile(r"^\s{0,12}\d{1,2}-\d{1,3}[A-Z]?\s+\S")
_RUNNING_STRUCTURAL = re.compile(
    r"^(Chapter|Part|Division|Subdivision|Section)\s+\d+(?:-\d+[A-Z]?)?\b(?!.*—)"
)
_FOOTER_CUE = re.compile(r"^(Compilation No\.|Compilation date:|Authorised Version |Registered:)")
_DOCUMENT_TITLE = re.compile(r"Export Control \(Plants and Plant Products\) Rules 2021")
_PAGE_NUMBER = re.compile(r"^[ivxlcdm]+$|^\d{1,4}$", re.IGNORECASE)


def classify_policy_lines(extracted: ExtractedPolicyText) -> list[PolicyLine]:
    by_page: dict[int, list[PolicyLine]] = {}
    for line in extracted.lines:
        by_page.setdefault(line.physical_page, []).append(line)
    repeated_top, repeated_bottom = _repeated_signatures(by_page)
    results: list[PolicyLine] = []
    for page_number in range(1, extracted.page_count + 1):
        page_lines = by_page[page_number]
        nonblank = [line for line in page_lines if line.normalized_text]
        toc_page = sum(bool(_TOC.search(line.normalized_text)) for line in nonblank) >= 3
        top_ids = {line.line_id for line in nonblank[:8]}
        bottom_ids = {line.line_id for line in nonblank[-8:]}
        for line in page_lines:
            classification = _classify(
                line,
                top=line.line_id in top_ids,
                bottom=line.line_id in bottom_ids,
                repeated_top=repeated_top,
                repeated_bottom=repeated_bottom,
                toc_page=toc_page,
            )
            results.append(line.model_copy(update={"classification": classification}))
    return results


def _repeated_signatures(
    by_page: dict[int, list[PolicyLine]],
) -> tuple[set[str], set[str]]:
    top: Counter[str] = Counter()
    bottom: Counter[str] = Counter()
    for page_lines in by_page.values():
        nonblank = [line for line in page_lines if line.normalized_text]
        top.update({_signature(line.normalized_text) for line in nonblank[:8]})
        bottom.update({_signature(line.normalized_text) for line in nonblank[-8:]})
    threshold = max(3, len(by_page) // 20)
    return (
        {signature for signature, count in top.items() if count >= threshold},
        {signature for signature, count in bottom.items() if count >= threshold},
    )


def _signature(text: str) -> str:
    text = re.sub(r"\b(?:[ivxlcdm]+|\d{1,4})\b", "<PAGE>", text, flags=re.I)
    return " ".join(text.split())


def _classify(
    line: PolicyLine,
    *,
    top: bool,
    bottom: bool,
    repeated_top: set[str],
    repeated_bottom: set[str],
    toc_page: bool,
) -> LineClass:
    text = line.normalized_text
    if not text:
        return LineClass.BLANK
    if _TOC.search(text):
        return LineClass.TOC_ENTRY
    signature = _signature(text)
    if top and (_RUNNING_STRUCTURAL.match(text) or signature in repeated_top):
        return LineClass.RUNNING_HEADER
    if bottom and (
        _FOOTER_CUE.match(text) or _DOCUMENT_TITLE.search(text) or signature in repeated_bottom
    ):
        return LineClass.RUNNING_FOOTER
    if bottom and _PAGE_NUMBER.fullmatch(text):
        return LineClass.PAGE_NUMBER
    if toc_page and not _FOOTER_CUE.match(text) and not _DOCUMENT_TITLE.fullmatch(text):
        return LineClass.TOC_ENTRY
    if _STRUCTURAL.match(text):
        return LineClass.STRUCTURAL_HEADING
    if _SECTION.match(line.raw_text):
        return LineClass.SECTION_HEADING
    return LineClass.BODY
