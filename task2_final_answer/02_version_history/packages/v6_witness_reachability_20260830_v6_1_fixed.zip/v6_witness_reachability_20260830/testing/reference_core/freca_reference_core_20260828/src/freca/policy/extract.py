"""Deterministic page-aware extraction of the admitted Rules PDF."""

from __future__ import annotations

import re
import shutil
import subprocess
from pathlib import Path

from freca.governance.hashing import sha256_bytes, sha256_digest, sha256_file
from freca.governance.source_guard import SourceRef
from freca.governance.source_resolver import CatalogSourceResolver
from freca.policy.schemas_v2 import (
    ExtractedPolicyText,
    PolicyLine,
    PolicyPage,
    ToolFingerprint,
)

_PAGES = re.compile(r"^Pages:\s+(\d+)\s*$", re.MULTILINE)
_PRINTED_PAGE = re.compile(r"^\s*([ivxlcdm]+|\d{1,4})\s*$", re.IGNORECASE)


class PolicyExtractionError(RuntimeError):
    pass


def extract_policy_text(
    source: SourceRef,
    resolver: CatalogSourceResolver,
) -> ExtractedPolicyText:
    if source.role != "RULES_PDF":
        raise PolicyExtractionError("Layer 1 accepts only the admitted RULES_PDF source")
    path = resolver.readonly_path(source.source_id, consumer="LAYER1")
    pdfinfo = _fingerprint("pdfinfo")
    pdftotext = _fingerprint("pdftotext")
    info = _run([pdfinfo.executable_path, str(path)])
    match = _PAGES.search(info.decode("utf-8", errors="strict"))
    if match is None:
        raise PolicyExtractionError("pdfinfo did not report a page count")
    page_count = int(match.group(1))

    output = _run(
        [
            pdftotext.executable_path,
            "-layout",
            "-enc",
            "UTF-8",
            "-eol",
            "unix",
            str(path),
            "-",
        ]
    )
    try:
        text = output.decode("utf-8", errors="strict")
    except UnicodeDecodeError as error:
        raise PolicyExtractionError("pdftotext output is not strict UTF-8") from error
    page_texts = text.split("\f")
    if page_texts and page_texts[-1] == "":
        page_texts.pop()
    if len(page_texts) != page_count:
        raise PolicyExtractionError(
            f"PDF page count {page_count} does not match form-feed pages {len(page_texts)}"
        )

    pages: list[PolicyPage] = []
    lines: list[PolicyLine] = []
    for page_number, raw_text in enumerate(page_texts, start=1):
        if not raw_text.strip():
            raise PolicyExtractionError(f"L1_PDF_TEXT_EMPTY: physical page {page_number}")
        page_lines = _page_lines(page_number, raw_text)
        lines.extend(page_lines)
        pages.append(
            PolicyPage(
                physical_page=page_number,
                printed_page_label=_printed_page_label(page_lines),
                raw_text=raw_text,
                normalized_text="\n".join(line.normalized_text for line in page_lines),
                raw_sha256=sha256_bytes(raw_text.encode("utf-8")),
                line_ids=[line.line_id for line in page_lines],
            )
        )
    payload = {
        "source_id": source.source_id,
        "source_pdf_sha256": source.sha256,
        "page_count": page_count,
        "pages": pages,
        "lines": lines,
        "pdftotext": pdftotext,
        "pdfinfo": pdfinfo,
    }
    return ExtractedPolicyText(
        **payload,
        extraction_sha256=sha256_digest(payload),
    )


def _page_lines(page_number: int, raw_text: str) -> list[PolicyLine]:
    results: list[PolicyLine] = []
    cursor = 0
    chunks = raw_text.splitlines(keepends=True)
    if not chunks:
        chunks = [raw_text]
    for line_number, chunk in enumerate(chunks, start=1):
        content = chunk.rstrip("\n")
        if content.endswith("\r"):
            content = content[:-1]
        end = cursor + len(content)
        results.append(
            PolicyLine(
                line_id=f"line-p{page_number:03d}-l{line_number:03d}",
                physical_page=page_number,
                page_line_index=line_number,
                raw_text=content,
                normalized_text=" ".join(content.split()),
                raw_char_start=cursor,
                raw_char_end=end,
            )
        )
        cursor += len(chunk)
    return results


def _printed_page_label(lines: list[PolicyLine]) -> str | None:
    for line in reversed(lines[-12:]):
        match = _PRINTED_PAGE.fullmatch(line.raw_text)
        if match:
            return match.group(1)
        embedded = re.search(r"Rules 2021\s+([ivxlcdm]+|\d{1,4})\s*$", line.raw_text, re.I)
        if embedded:
            return embedded.group(1)
    return None


def _fingerprint(name: str) -> ToolFingerprint:
    executable = shutil.which(name)
    if executable is None:
        raise PolicyExtractionError(f"required PDF tool is unavailable: {name}")
    version_output = subprocess.run(
        [executable, "-v"],
        capture_output=True,
        check=False,
    )
    version_bytes = version_output.stdout or version_output.stderr
    version = version_bytes.decode("utf-8", errors="replace").splitlines()[0].strip()
    if not version:
        raise PolicyExtractionError(f"cannot determine {name} version")
    return ToolFingerprint(
        tool=name,
        version=version,
        executable_path=str(Path(executable).resolve()),
        executable_sha256=sha256_file(executable),
    )


def _run(command: list[str]) -> bytes:
    completed = subprocess.run(command, capture_output=True, check=False)
    if completed.returncode != 0:
        detail = completed.stderr.decode("utf-8", errors="replace")[:500]
        raise PolicyExtractionError(f"PDF command failed ({completed.returncode}): {detail}")
    return completed.stdout
