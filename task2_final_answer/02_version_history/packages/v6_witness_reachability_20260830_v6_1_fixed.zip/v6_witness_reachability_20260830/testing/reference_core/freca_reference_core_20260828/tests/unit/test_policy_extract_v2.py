from __future__ import annotations

import unittest

from freca.policy.extract import _page_lines, _printed_page_label
from freca.policy.furniture import classify_policy_lines
from freca.policy.schemas_v2 import (
    ExtractedPolicyText,
    LineClass,
    PolicyPage,
    ToolFingerprint,
)

HASH = "sha256:" + "1" * 64


class PolicyExtractV2Tests(unittest.TestCase):
    def fixture(self) -> ExtractedPolicyText:
        raw = (
            "Chapter 4 Registered establishments\n"
            "Section 4-7B\n\n"
            "                    (b) pests must be controlled; and\n"
            "4-7B Plants must be traced\n"
            "                Plants must be traced.\n\n"
            "38 Export Control (Plants and Plant Products) Rules 2021\n"
        )
        lines = _page_lines(48, raw)
        tool = ToolFingerprint(
            tool="fixture",
            version="1",
            executable_path="fixture",
            executable_sha256=HASH,
        )
        return ExtractedPolicyText(
            source_id="source-rules",
            source_pdf_sha256=HASH,
            page_count=1,
            pages=[
                PolicyPage(
                    physical_page=1,
                    printed_page_label="38",
                    raw_text=raw,
                    normalized_text=raw,
                    raw_sha256=HASH,
                    line_ids=[line.line_id for line in lines],
                )
            ],
            lines=[line.model_copy(update={"physical_page": 1}) for line in lines],
            pdftotext=tool,
            pdfinfo=tool,
            extraction_sha256=HASH,
        )

    def test_line_offsets_replay_and_printed_page_detection(self) -> None:
        raw = "alpha\n  beta\n37\n"
        lines = _page_lines(1, raw)
        for line in lines:
            self.assertEqual(raw[line.raw_char_start : line.raw_char_end], line.raw_text)
        self.assertEqual(_printed_page_label(lines), "37")

    def test_running_section_header_does_not_open_a_body_section(self) -> None:
        lines = classify_policy_lines(self.fixture())
        by_text = {
            line.normalized_text: line.classification for line in lines if line.normalized_text
        }
        self.assertEqual(by_text["Section 4-7B"], LineClass.RUNNING_HEADER)
        self.assertEqual(by_text["4-7B Plants must be traced"], LineClass.SECTION_HEADING)
        self.assertEqual(
            by_text["(b) pests must be controlled; and"],
            LineClass.BODY,
        )


if __name__ == "__main__":
    unittest.main()
