from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from freca.governance.config import load_run_config, semantic_config_sha256


class RunConfigV2Tests(unittest.TestCase):
    def test_checked_in_example_loads_and_has_portable_semantic_hash(self) -> None:
        package_root = Path(__file__).resolve().parents[2]
        first = load_run_config(package_root / "configs" / "run.example.toml")
        payload = first.model_dump(mode="json")
        payload["inputs"]["task_root"] = "E:/relocated/task"
        payload["output"]["run_root"] = "E:/relocated/runs"
        payload["output"]["run_id"] = "another-attempt"
        relocated_path = package_root / "configs" / "run.example.toml"
        second = first.model_validate(payload)
        self.assertTrue(relocated_path.is_file())
        self.assertEqual(semantic_config_sha256(first), semantic_config_sha256(second))

    def test_literal_secret_field_is_rejected_before_schema_parsing(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "bad.toml"
            path.write_text(
                "\n".join(
                    [
                        'schema_version = "freca.run-config.v1"',
                        'mode = "DIAGNOSTIC"',
                        'api_key = "must-not-enter-config"',
                    ]
                ),
                encoding="utf-8",
            )
            with self.assertRaisesRegex(ValueError, "literal secret"):
                load_run_config(path)


if __name__ == "__main__":
    unittest.main()
