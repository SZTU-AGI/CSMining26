from __future__ import annotations

import unittest

from freca.argument.evaluator import ArgumentGraphEvaluation, evaluate_argument_graph
from freca.argument.projection import project_argument_graph
from freca.argument.reference_evaluator import (
    compare_evaluators,
    reference_evaluate_argument_graph,
)
from freca.evaluation.ab_registry import full_ab_registry
from freca.governance.blast_radius import compute_blast_radius
from freca.logic.four_valued import FourValuedState
from freca.policy.indexed_requirement_view import build_indexed_requirement_view
from freca.verification.common_mode import assess_anchor_compiler_independence
from tests.unit.test_v2_reasoning_core import ZERO_HASH, ast_complete_dag


class ReferenceEvaluatorTests(unittest.TestCase):
    def test_independent_iterative_evaluator_matches_primary(self) -> None:
        dag = ast_complete_dag()
        view = build_indexed_requirement_view(dag, proposition_catalog_sha256=ZERO_HASH)
        graph = project_argument_graph(view, logic_roots=dag.roots)
        states = {
            "p-app": FourValuedState.TRUE,
            "p-a": FourValuedState.TRUE,
            "p-b": FourValuedState.BOTH,
            "p-vio": FourValuedState.FALSE,
            "p-na": FourValuedState.FALSE,
        }
        primary = evaluate_argument_graph(graph, states)
        reference = reference_evaluate_argument_graph(graph, states)
        self.assertEqual(compare_evaluators(primary, reference).status, "PASS")

        sat = graph.root_statement_ids["satisfaction"]
        corrupted = ArgumentGraphEvaluation(
            interpretation_id=primary.interpretation_id,
            statement_states=primary.statement_states,
            root_states={**primary.root_states, sat: FourValuedState.FALSE},
        )
        disagreement = compare_evaluators(corrupted, reference)
        self.assertEqual(disagreement.status, "EVALUATOR_DISAGREEMENT_BLOCK")
        self.assertEqual(disagreement.mismatch_root_statement_ids, [sat])


class IndependenceTests(unittest.TestCase):
    def test_same_model_dual_compile_is_only_engineering_agreement(self) -> None:
        profile = assess_anchor_compiler_independence(
            profile_id="profile-1",
            component_a_id="compiler-a",
            component_b_id="compiler-b",
            parser_independent=True,
            query_independent=True,
            model_independent=False,
            deterministic_source_relation_validator_passed=True,
        )
        self.assertFalse(profile.reliance_permitted)
        self.assertEqual(profile.independence_status, "ENGINEERING_AGREEMENT_ONLY")


class BlastRadiusTests(unittest.TestCase):
    def test_shared_contract_change_reaches_every_dependent_case(self) -> None:
        report = compute_blast_radius(
            changed_artifact_ids=["contract-cp6"],
            dependency_edges={
                "contract-cp6": ["eval-1", "eval-2"],
                "eval-1": ["fold-1"],
                "eval-2": ["fold-2"],
            },
            artifact_case_cp_ids={
                "fold-1": ["case-1.CP6"],
                "fold-2": ["case-2.CP6"],
            },
            artifact_case_ids={"fold-1": ["case-1"], "fold-2": ["case-2"]},
            artifact_cp_ids={"contract-cp6": ["CP6"]},
        )
        self.assertEqual(report.affected_case_cp_ids, ["case-1.CP6", "case-2.CP6"])
        self.assertIn("CP6", report.affected_cp_ids)


class ABRegistryTests(unittest.TestCase):
    def test_b00_through_b31_are_complete_and_unique(self) -> None:
        arms = full_ab_registry()
        self.assertEqual([arm.arm_id for arm in arms], [f"B{i:02d}" for i in range(32)])
        self.assertTrue(next(arm for arm in arms if arm.arm_id == "B31").production_candidate)
        self.assertTrue(next(arm for arm in arms if arm.arm_id == "B30").research_only)


if __name__ == "__main__":
    unittest.main()
