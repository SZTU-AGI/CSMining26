from __future__ import annotations

import math
import unittest
from datetime import UTC, datetime, timedelta, timezone
from pathlib import Path

from freca.governance.hashing import canonical_json_bytes, sha256_digest


class GovernanceHashingTests(unittest.TestCase):
    def test_mapping_and_set_order_do_not_change_hash(self) -> None:
        first = {"b": frozenset({"z", "a"}), "a": 1}
        second = {"a": 1, "b": frozenset({"a", "z"})}
        self.assertEqual(sha256_digest(first), sha256_digest(second))

    def test_paths_and_datetimes_are_portable(self) -> None:
        local = datetime(2026, 8, 28, 16, tzinfo=timezone(timedelta(hours=8)))
        utc = datetime(2026, 8, 28, 8, tzinfo=UTC)
        self.assertEqual(sha256_digest(local), sha256_digest(utc))
        self.assertEqual(canonical_json_bytes(Path("a/b")), b'"a/b"')

    def test_non_finite_and_naive_time_are_rejected(self) -> None:
        with self.assertRaises(ValueError):
            sha256_digest(math.nan)
        with self.assertRaises(ValueError):
            sha256_digest(datetime(2026, 8, 28))


if __name__ == "__main__":
    unittest.main()
