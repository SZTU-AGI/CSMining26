"""Frozen FRECA-CAES-DAG-v1 template models.

This is a deliberately bounded profile.  It does not claim semantic equivalence
with Carneades 4, which additionally supports cycles, weighing functions and
cumulative arguments.
"""

from __future__ import annotations

from enum import StrEnum
from typing import Literal

from pydantic import Field, model_validator

from freca.domain.models import SafeId, StrictModel
from freca.logic.ast import ContractRoots, LogicOperator


class PremiseRole(StrEnum):
    ORDINARY = "ORDINARY"
    ASSUMPTION = "ASSUMPTION"
    EXCEPTION = "EXCEPTION"


class RequiredPolarity(StrEnum):
    POSITIVE = "POSITIVE"
    NEGATIVE = "NEGATIVE"


class ArgumentDirection(StrEnum):
    PRO = "PRO"
    CON = "CON"


class StatementTemplate(StrictModel):
    statement_id: SafeId
    logic_node_id: SafeId
    proposition_id: SafeId | None = None
    semantic_role: str = Field(min_length=1)
    logic_operator: LogicOperator
    direct_alignment_policy: Literal["ALLOW_OBSERVABLE_ONLY", "FORBID"]
    proof_standard_id: SafeId
    burden_rule_id: SafeId
    source_span_ids: list[SafeId] = Field(default_factory=list)

    @model_validator(mode="after")
    def direct_alignment_is_observable_only(self) -> StatementTemplate:
        if (
            self.direct_alignment_policy == "ALLOW_OBSERVABLE_ONLY"
            and self.semantic_role != "OBSERVABLE_CASE_FACT"
        ):
            raise ValueError("direct alignment is only legal for OBSERVABLE_CASE_FACT")
        return self


class ArgumentPremiseTemplate(StrictModel):
    statement_id: SafeId
    premise_role: PremiseRole
    required_polarity: RequiredPolarity


class ArgumentTemplate(StrictModel):
    argument_id: SafeId
    scheme: Literal[
        "RULE_APPLICATION",
        "RULE_VIOLATION",
        "EXPLICIT_EXCEPTION",
        "NON_APPLICABILITY",
        "DEEMING",
        "ALTERNATIVE_PERFORMANCE",
        "REBUTTAL",
        "BENCHMARK_OPERATIONALIZATION",
    ]
    premises: list[ArgumentPremiseTemplate] = Field(min_length=1)
    conclusion_statement_id: SafeId
    direction: ArgumentDirection
    source_norm_event_ids: list[SafeId] = Field(default_factory=list)
    source_span_ids: list[SafeId] = Field(default_factory=list)


class ArgumentGraphTemplate(StrictModel):
    statement_nodes: list[StatementTemplate] = Field(min_length=1)
    argument_nodes: list[ArgumentTemplate] = Field(default_factory=list)
    logic_roots: ContractRoots
    root_statement_ids: dict[str, SafeId]
    interpretation_id: SafeId
    semantic_profile_id: Literal["FRECA-CAES-DAG-v1"] = "FRECA-CAES-DAG-v1"
    indexed_requirement_view_id: SafeId

    @model_validator(mode="after")
    def validate_graph(self) -> ArgumentGraphTemplate:
        statement_ids = {item.statement_id for item in self.statement_nodes}
        logic_ids = {item.logic_node_id for item in self.statement_nodes}
        argument_ids = {item.argument_id for item in self.argument_nodes}
        if len(statement_ids) != len(self.statement_nodes):
            raise ValueError("statement IDs must be unique")
        if len(logic_ids) != len(self.statement_nodes):
            raise ValueError("each logic node must have exactly one projected statement")
        if len(argument_ids) != len(self.argument_nodes):
            raise ValueError("argument IDs must be unique")
        for argument in self.argument_nodes:
            if argument.conclusion_statement_id not in statement_ids:
                raise ValueError(f"argument {argument.argument_id} has unknown conclusion")
            unknown = {premise.statement_id for premise in argument.premises} - statement_ids
            if unknown:
                raise ValueError(
                    f"argument {argument.argument_id} has unknown premises: {sorted(unknown)}"
                )
        if set(self.root_statement_ids) != set(self.logic_roots.as_dict()):
            raise ValueError("root_statement_ids must contain the four frozen root names")
        unknown_roots = set(self.root_statement_ids.values()) - statement_ids
        if unknown_roots:
            raise ValueError(f"graph roots reference unknown statements: {sorted(unknown_roots)}")
        return self
