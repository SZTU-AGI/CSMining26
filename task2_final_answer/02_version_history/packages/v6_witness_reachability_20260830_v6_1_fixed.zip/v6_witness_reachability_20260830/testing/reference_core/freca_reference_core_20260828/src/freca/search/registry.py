"""Permanent registry of all frozen non-tree and tree-search experiment arms."""

from __future__ import annotations

from enum import StrEnum

from pydantic import Field

from freca.domain.models import StrictModel


class SearchStrategy(StrEnum):
    B00_DIRECT_DETERMINISTIC = "B00_DIRECT_DETERMINISTIC"
    B01_DIRECT_MODEL = "B01_DIRECT_MODEL"
    B02_SELF_CONSISTENCY = "B02_SELF_CONSISTENCY"
    B03_RERANK = "B03_RERANK"
    B04_ITERATIVE_CORRECTION = "B04_ITERATIVE_CORRECTION"
    B05_TARGETED_REPAIR = "B05_TARGETED_REPAIR"
    B06_BOUNDED_BEST_FIRST_AND_OR = "B06_BOUNDED_BEST_FIRST_AND_OR"
    B07_TOT_BFS_VALUE = "B07_TOT_BFS_VALUE"
    B08_TOT_BFS_VOTE = "B08_TOT_BFS_VOTE"
    B09_TOT_DFS = "B09_TOT_DFS"
    B10_TOT_BEAM = "B10_TOT_BEAM"
    B11_CHEN_HEAP_MC_MAX = "B11_CHEN_HEAP_MC_MAX"
    B12_CHEN_HEAP_MC_MEAN = "B12_CHEN_HEAP_MC_MEAN"
    B13_UCT_MCTS = "B13_UCT_MCTS"
    B14_RAP_MCTS_EXTERNAL_REWARD = "B14_RAP_MCTS_EXTERNAL_REWARD"
    B15_RAP_SELF_EVAL_ABLATION = "B15_RAP_SELF_EVAL_ABLATION"
    B16_LATS_MCTS_EXTERNAL_VALUE = "B16_LATS_MCTS_EXTERNAL_VALUE"
    B17_LATS_REFLECTION_ABLATION = "B17_LATS_REFLECTION_ABLATION"


class SearchArmSpec(StrictModel):
    strategy: SearchStrategy
    family: str
    tree_based: bool
    uses_world_model: bool = False
    uses_environment_observation: bool = False
    uses_reflection: bool = False
    backup_rule: str | None = None
    production_eligible_by_default: bool = False
    required_prompt_roles: list[str] = Field(default_factory=list)


def default_search_arm_registry() -> list[SearchArmSpec]:
    specs = [
        SearchArmSpec(
            strategy=SearchStrategy.B00_DIRECT_DETERMINISTIC, family="DIRECT", tree_based=False
        ),
        SearchArmSpec(
            strategy=SearchStrategy.B01_DIRECT_MODEL,
            family="DIRECT",
            tree_based=False,
            required_prompt_roles=["SEARCH_MOVE_GENERATOR"],
        ),
        SearchArmSpec(
            strategy=SearchStrategy.B02_SELF_CONSISTENCY,
            family="SELF_CONSISTENCY",
            tree_based=False,
            required_prompt_roles=["SEARCH_MOVE_GENERATOR"],
        ),
        SearchArmSpec(
            strategy=SearchStrategy.B03_RERANK,
            family="RERANK",
            tree_based=False,
            required_prompt_roles=["SEARCH_EVALUATOR"],
        ),
        SearchArmSpec(
            strategy=SearchStrategy.B04_ITERATIVE_CORRECTION,
            family="ITERATIVE_CORRECTION",
            tree_based=False,
        ),
        SearchArmSpec(
            strategy=SearchStrategy.B05_TARGETED_REPAIR,
            family="TARGETED_REPAIR",
            tree_based=False,
            production_eligible_by_default=True,
        ),
        SearchArmSpec(
            strategy=SearchStrategy.B06_BOUNDED_BEST_FIRST_AND_OR,
            family="BEST_FIRST",
            tree_based=True,
        ),
        SearchArmSpec(
            strategy=SearchStrategy.B07_TOT_BFS_VALUE,
            family="TOT",
            tree_based=True,
            required_prompt_roles=["SEARCH_MOVE_GENERATOR", "SEARCH_EVALUATOR"],
        ),
        SearchArmSpec(
            strategy=SearchStrategy.B08_TOT_BFS_VOTE,
            family="TOT",
            tree_based=True,
            required_prompt_roles=["SEARCH_MOVE_GENERATOR", "SEARCH_EVALUATOR"],
        ),
        SearchArmSpec(
            strategy=SearchStrategy.B09_TOT_DFS,
            family="TOT",
            tree_based=True,
            required_prompt_roles=["SEARCH_MOVE_GENERATOR"],
        ),
        SearchArmSpec(
            strategy=SearchStrategy.B10_TOT_BEAM,
            family="TOT",
            tree_based=True,
            required_prompt_roles=["SEARCH_MOVE_GENERATOR", "SEARCH_EVALUATOR"],
        ),
        SearchArmSpec(
            strategy=SearchStrategy.B11_CHEN_HEAP_MC_MAX,
            family="CHEN_MC",
            tree_based=True,
            backup_rule="MAX",
        ),
        SearchArmSpec(
            strategy=SearchStrategy.B12_CHEN_HEAP_MC_MEAN,
            family="CHEN_MC",
            tree_based=True,
            backup_rule="MEAN",
        ),
        SearchArmSpec(
            strategy=SearchStrategy.B13_UCT_MCTS, family="MCTS", tree_based=True, backup_rule="UCT"
        ),
        SearchArmSpec(
            strategy=SearchStrategy.B14_RAP_MCTS_EXTERNAL_REWARD,
            family="RAP",
            tree_based=True,
            uses_world_model=True,
            uses_environment_observation=True,
            backup_rule="UCT",
            required_prompt_roles=["RAP_WORLD_MODEL"],
        ),
        SearchArmSpec(
            strategy=SearchStrategy.B15_RAP_SELF_EVAL_ABLATION,
            family="RAP",
            tree_based=True,
            uses_world_model=True,
            backup_rule="UCT",
            required_prompt_roles=["RAP_WORLD_MODEL", "SEARCH_EVALUATOR"],
        ),
        SearchArmSpec(
            strategy=SearchStrategy.B16_LATS_MCTS_EXTERNAL_VALUE,
            family="LATS",
            tree_based=True,
            uses_world_model=True,
            uses_environment_observation=True,
            uses_reflection=True,
            backup_rule="UCT",
            required_prompt_roles=["LATS_REFLECTION"],
        ),
        SearchArmSpec(
            strategy=SearchStrategy.B17_LATS_REFLECTION_ABLATION,
            family="LATS",
            tree_based=True,
            uses_world_model=True,
            uses_environment_observation=True,
            backup_rule="UCT",
        ),
    ]
    if {spec.strategy for spec in specs} != set(SearchStrategy):
        raise RuntimeError("search registry is incomplete")
    return specs
