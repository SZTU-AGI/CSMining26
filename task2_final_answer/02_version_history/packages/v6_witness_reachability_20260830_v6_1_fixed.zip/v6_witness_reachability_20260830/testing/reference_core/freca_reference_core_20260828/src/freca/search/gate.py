"""Chen-style search gate: validate the discriminator before granting pruning power."""

from freca.search.models import SearchGateDecision


def decide_search_route(
    *,
    deterministic_repair_available: bool,
    task_requires_multistep_planning: bool,
    external_signal_environment_available: bool,
    discriminator_validated_in_domain: bool,
) -> SearchGateDecision:
    if deterministic_repair_available:
        return SearchGateDecision(
            route="TARGETED_REPAIR",
            reason_codes=["DETERMINISTIC_ACTION_AVAILABLE"],
            permanent_pruning_allowed=False,
        )
    if not task_requires_multistep_planning or not external_signal_environment_available:
        return SearchGateDecision(
            route="RERANK_OR_DEFER",
            reason_codes=["NO_VALIDATED_MULTISTEP_EXTERNAL_SIGNAL_CASE"],
            permanent_pruning_allowed=False,
        )
    if discriminator_validated_in_domain:
        return SearchGateDecision(
            route="SEARCH_PRODUCTION_PRUNING_ALLOWED",
            reason_codes=["IN_DOMAIN_DISCRIMINATOR_AND_EXTERNAL_SIGNAL_AVAILABLE"],
            permanent_pruning_allowed=True,
        )
    return SearchGateDecision(
        route="SEARCH_RESEARCH_NO_PRUNING",
        reason_codes=["DISCRIMINATOR_NOT_VALIDATED_IN_DOMAIN"],
        permanent_pruning_allowed=False,
    )
