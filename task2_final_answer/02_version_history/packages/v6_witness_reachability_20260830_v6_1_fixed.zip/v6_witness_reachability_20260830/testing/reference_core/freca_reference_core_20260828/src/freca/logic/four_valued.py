"""Belnap-style evidence pairs used by the FRECA deterministic evaluators.

The two bits mean "there is accepted support" and "there is accepted attack".
They deliberately do not collapse conflict or absence into ordinary booleans.
"""

from __future__ import annotations

from collections.abc import Iterable
from enum import StrEnum


class FourValuedState(StrEnum):
    TRUE = "TRUE"
    FALSE = "FALSE"
    BOTH = "BOTH"
    UNKNOWN = "UNKNOWN"

    @property
    def pair(self) -> tuple[bool, bool]:
        return {
            FourValuedState.UNKNOWN: (False, False),
            FourValuedState.TRUE: (True, False),
            FourValuedState.FALSE: (False, True),
            FourValuedState.BOTH: (True, True),
        }[self]

    @classmethod
    def from_pair(cls, support: bool, attack: bool) -> FourValuedState:
        return {
            (False, False): cls.UNKNOWN,
            (True, False): cls.TRUE,
            (False, True): cls.FALSE,
            (True, True): cls.BOTH,
        }[(support, attack)]


def negate(value: FourValuedState) -> FourValuedState:
    support, attack = value.pair
    return FourValuedState.from_pair(attack, support)


def all_of(values: Iterable[FourValuedState]) -> FourValuedState:
    pairs = [value.pair for value in values]
    if not pairs:
        raise ValueError("ALL_OF requires at least one value")
    return FourValuedState.from_pair(
        support=all(support for support, _ in pairs),
        attack=any(attack for _, attack in pairs),
    )


def any_of(values: Iterable[FourValuedState]) -> FourValuedState:
    pairs = [value.pair for value in values]
    if not pairs:
        raise ValueError("ANY_OF requires at least one value")
    return FourValuedState.from_pair(
        support=any(support for support, _ in pairs),
        attack=all(attack for _, attack in pairs),
    )


def if_then(antecedent: FourValuedState, consequent: FourValuedState) -> FourValuedState:
    """Evaluate implication as ``ANY_OF(NOT(A), B)`` per frozen D2.29."""

    return any_of((negate(antecedent), consequent))
