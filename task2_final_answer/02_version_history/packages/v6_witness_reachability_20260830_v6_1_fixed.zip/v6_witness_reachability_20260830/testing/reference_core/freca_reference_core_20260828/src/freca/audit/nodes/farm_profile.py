"""A0: build a farm profile from identity-admissible evidence.

The profile is deliberately a fact inventory, not a verdict.  It keeps the
source of every field and preserves conflicting claims instead of selecting a
winner silently.  Scope applicability is a later node: a missing or conflicting
profile fact must remain distinguishable from an explicit negative fact.
"""

from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass, field
from typing import Iterable

from freca.domain.enums import EvidenceIdentityState
from freca.evidence.pipeline import CaseEvidence, DocumentEvidence
from freca.evidence.identity import normalise_entity


@dataclass(slots=True)
class FarmProfile:
    """Structured A0 facts for one logical case.

    ``None`` means that a scalar fact was not established.  An empty list means
    that no value was extracted for a repeated field.  Neither is an assertion
    that the corresponding fact is false.
    """

    case_id: str
    registered_entity: str | None = None
    registration_number: str | None = None
    registration_status: str | None = None
    registered_commodities: list[str] = field(default_factory=list)
    registered_activities: list[str] = field(default_factory=list)
    registered_facilities: list[str] = field(default_factory=list)
    endorsements_or_conditions: list[str] = field(default_factory=list)
    effective_period: str | None = None
    identity_conflicts: list[str] = field(default_factory=list)
    unknown_fields: list[str] = field(default_factory=list)
    field_provenance: dict[str, list[str]] = field(default_factory=dict)

    def to_dict(self) -> dict[str, object]:
        return {
            "case_id": self.case_id,
            "registered_entity": self.registered_entity,
            "registration_number": self.registration_number,
            "registration_status": self.registration_status,
            "registered_commodities": list(self.registered_commodities),
            "registered_activities": list(self.registered_activities),
            "registered_facilities": list(self.registered_facilities),
            "endorsements_or_conditions": list(self.endorsements_or_conditions),
            "effective_period": self.effective_period,
            "identity_conflicts": list(self.identity_conflicts),
            "unknown_fields": list(self.unknown_fields),
            "field_provenance": {
                field: list(sources) for field, sources in self.field_provenance.items()
            },
        }

    def scope_context(self) -> dict[str, object]:
        """Expose only extracted facts to the applicability node.

        This is a convenience boundary for C1.  It intentionally does not turn
        absent values into ``False``; a caller can therefore distinguish
        ``UNKNOWN`` from ``NOT_APPLICABLE``.
        """

        return {
            "registered_entity": self.registered_entity,
            "registration_number": self.registration_number,
            "registration_status": self.registration_status,
            "registered_commodities": list(self.registered_commodities),
            "registered_activities": list(self.registered_activities),
            "registered_facilities": list(self.registered_facilities),
            "endorsements_or_conditions": list(self.endorsements_or_conditions),
            "effective_period": self.effective_period,
            "identity_conflicts": list(self.identity_conflicts),
        }


def _unique(values: Iterable[str]) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for value in values:
        value = " ".join(value.split()).strip()
        if value and value not in seen:
            result.append(value)
            seen.add(value)
    return result


def _source(document: DocumentEvidence, value: str) -> str:
    where = document.anchors.provenance.get(value)
    return f"{document.track}:{where}" if where else document.track


def _add_provenance(profile: FarmProfile, field_name: str, source: str) -> None:
    profile.field_provenance.setdefault(field_name, [])
    if source not in profile.field_provenance[field_name]:
        profile.field_provenance[field_name].append(source)


def _record_values(
    profile: FarmProfile,
    field_name: str,
    values: Iterable[str],
    source: str,
) -> list[str]:
    clean = _unique(values)
    target = getattr(profile, field_name)
    for value in clean:
        if value not in target:
            target.append(value)
    if clean:
        _add_provenance(profile, field_name, source)
    return clean


def _primary_documents(evidence: CaseEvidence) -> list[DocumentEvidence]:
    """Return self-identified documents, with the registration record first."""

    self_docs = [
        document
        for document in evidence.documents
        if document.admissibility.state is EvidenceIdentityState.SELF
    ]
    return sorted(self_docs, key=lambda document: (document.track != "T1", document.track))


def _atom_text(document: DocumentEvidence) -> list[tuple[str, str]]:
    return [(atom.content, atom.evidence_id) for atom in document.atoms]


def _extract_status_and_period(
    profile: FarmProfile, registration_document: DocumentEvidence | None
) -> None:
    if registration_document is None:
        return

    status_atoms: list[tuple[str, str]] = []
    period_atoms: list[tuple[str, str]] = []
    for content, evidence_id in _atom_text(registration_document):
        lowered = content.lower()
        if "registration status" in lowered or "registration period" in lowered:
            status_atoms.append((content, evidence_id))
            period_atoms.append((content, evidence_id))
        if "registration expiry" in lowered or "effective from" in lowered:
            period_atoms.append((content, evidence_id))

    if status_atoms:
        text = " ".join(content for content, _ in status_atoms)
        terms = (
            "revoked",
            "cancelled",
            "suspended",
            "lapsed",
            "expired",
            "renewal",
            "active",
            "current",
        )
        found = next((term for term in terms if re.search(rf"\b{term}\b", text.lower())), None)
        profile.registration_status = found or "stated; requires human normalization"
        for _, evidence_id in status_atoms:
            _add_provenance(profile, "registration_status", evidence_id)

    if period_atoms:
        profile.effective_period = " ".join(_unique(content for content, _ in period_atoms))
        for _, evidence_id in period_atoms:
            _add_provenance(profile, "effective_period", evidence_id)


def _extract_t1_fields(profile: FarmProfile, document: DocumentEvidence) -> None:
    """Extract fields whose labels are defined by the registration record."""

    for content, evidence_id in _atom_text(document):
        lower = content.lower()
        if "registered export operations" in lower and "activity:" in lower:
            match = re.search(r"Activity:\s*([^;]+)", content, re.I)
            if match:
                _record_values(profile, "registered_activities", [match.group(1)], evidence_id)
            status = re.search(r"Scope Status:\s*([^;]+)", content, re.I)
            if status:
                _record_values(
                    profile,
                    "endorsements_or_conditions",
                    [f"{match.group(1).strip() if match else 'activity'}: {status.group(1).strip()}"],
                    evidence_id,
                )

        if "buildings and structures" in lower:
            match = re.search(r"—\s*([^:;]+):", content)
            if match and match.group(1).strip().lower() not in {"description", "building / structure"}:
                _record_values(profile, "registered_facilities", [match.group(1)], evidence_id)

        if "scope status:" in lower or "condition" in lower or "endorsement" in lower:
            _record_values(profile, "endorsements_or_conditions", [content], evidence_id)


def _detect_identity_conflicts(profile: FarmProfile, evidence: CaseEvidence, documents: list[DocumentEvidence]) -> None:
    names = _unique(
        name for document in documents for name in document.anchors.names
    )
    name_groups = {normalise_entity(name) for name in names if normalise_entity(name)}
    if len(name_groups) > 1:
        profile.identity_conflicts.append(
            f"self-identified establishment names disagree: {names}"
        )
        for document in documents:
            if document.anchors.names:
                _add_provenance(profile, "identity_conflicts", _source(document, document.anchors.names[0]))

    numbers = _unique(
        number for document in documents for number in document.anchors.re_numbers
    )
    if len(set(numbers)) > 1 or any(number != evidence.reference.re_number for number in numbers):
        profile.identity_conflicts.append(
            f"self-identified registration numbers disagree with the case reference: {numbers}"
        )
        for document in documents:
            for number in document.anchors.re_numbers:
                _add_provenance(profile, "identity_conflicts", _source(document, number))

    # A foreign or mixed document is itself an identity conflict for the case,
    # even though its facts are excluded from the registered profile. Keeping
    # that signal here lets downstream scope review explain why evidence was not
    # silently treated as a farm fact.
    for document in evidence.documents:
        state = document.admissibility.state
        if state in {EvidenceIdentityState.FOREIGN, EvidenceIdentityState.MIXED}:
            claims = [*document.anchors.names, *document.anchors.re_numbers]
            detail = ", ".join(claims) if claims else "no self identity could be established"
            profile.identity_conflicts.append(
                f"{document.track} is {state.value} for this case ({detail})"
            )
            _add_provenance(profile, "identity_conflicts", document.track)


def build_farm_profile(evidence: CaseEvidence) -> FarmProfile:
    """Build A0 facts without using inadmissible or merely mentioned identity."""

    profile = FarmProfile(case_id=evidence.case_id)
    documents = _primary_documents(evidence)
    registration_document = next(
        (document for document in documents if document.track == "T1"), None
    )

    names = [name for document in documents for name in document.anchors.names]
    numbers = [number for document in documents for number in document.anchors.re_numbers]
    if names:
        # A T1 registration record outranks supporting plans.  If it is absent,
        # choose the most frequently repeated normalized identity while retaining
        # all claims in the conflict/provenance trail.
        if registration_document and registration_document.anchors.names:
            profile.registered_entity = registration_document.anchors.names[0]
            _add_provenance(
                profile,
                "registered_entity",
                _source(registration_document, profile.registered_entity),
            )
        else:
            counts = Counter(normalise_entity(name) for name in names)
            chosen_key = counts.most_common(1)[0][0]
            profile.registered_entity = next(name for name in names if normalise_entity(name) == chosen_key)
            for document in documents:
                if profile.registered_entity in document.anchors.names:
                    _add_provenance(profile, "registered_entity", _source(document, profile.registered_entity))
                    break

    matching_numbers = [number for number in numbers if number == evidence.reference.re_number]
    if matching_numbers:
        profile.registration_number = evidence.reference.re_number
        for document in documents:
            if evidence.reference.re_number in document.anchors.re_numbers:
                _add_provenance(
                    profile,
                    "registration_number",
                    _source(document, evidence.reference.re_number),
                )
    elif numbers:
        profile.registration_number = numbers[0]
        for document in documents:
            if profile.registration_number in document.anchors.re_numbers:
                _add_provenance(profile, "registration_number", _source(document, profile.registration_number))
                break

    for document in documents:
        _record_values(
            profile,
            "registered_commodities",
            document.anchors.products,
            f"{document.track}:anchors",
        )

    if registration_document:
        _extract_t1_fields(profile, registration_document)
    _extract_status_and_period(profile, registration_document)
    _detect_identity_conflicts(profile, evidence, documents)

    scalar_fields = (
        "registered_entity",
        "registration_number",
        "registration_status",
        "effective_period",
    )
    repeated_fields = (
        "registered_commodities",
        "registered_activities",
        "registered_facilities",
        "endorsements_or_conditions",
    )
    for field_name in (*scalar_fields, *repeated_fields):
        value = getattr(profile, field_name)
        if value is None or value == []:
            profile.unknown_fields.append(field_name)

    if not documents:
        profile.unknown_fields.extend(
            field_name
            for field_name in ("registered_entity", "registration_number")
            if field_name not in profile.unknown_fields
        )
    return profile


__all__ = ["FarmProfile", "build_farm_profile"]
