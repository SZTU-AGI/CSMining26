"""Segment a parsed DOCX into numbered sections.

Design decision, measured rather than assumed
---------------------------------------------
Over 20 sampled cases (140 DOCX), paragraph-style usage per track is::

    T1  Heading1 x280  Heading2 x76    T2  (no heading style at all)
    T4  Heading1 x180  Heading2 x180   T7  (no heading style at all)
    T5  Heading1 x160                  T8  (no heading style at all)
    T6  Heading1 x240  Heading2 x135

So a style-driven segmenter yields **zero sections for T2, T7 and T8** — three of
the seven DOCX tracks. Every track does, however, use explicit decimal numbering
in the paragraph text (T2 240, T7 100, T8 100 numbered paragraphs in the sample).

Therefore: the numbering pattern is the *primary* signal, the ``Heading*`` style
is *corroborating*, and either alone is enough to open a section. The
``detected_by`` field records which signal fired so that a systematic parse
failure is attributable instead of invisible.

Sections matter because they are the unit an audit citation should point at:
"``5_Farm-Site-Plan``, §3 Registered Area" is checkable by a human, whereas
"paragraph 27" is not.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from freca.evidence.docx_reader import DocxDocument, DocxParagraph, DocxTable

#: ``1.`` / ``2)`` / ``6.3`` / ``10.1.2`` followed by a title.
NUMBERED_HEADING = re.compile(r"^(?P<number>\d+(?:\.\d+)*)\s*[.)]?\s+(?P<title>\S.*)$")

#: A heading is a *label*, not prose. Long numbered lines are list items or
#: numbered clauses inside body text, so they must not open a section.
MAX_HEADING_CHARS = 120


@dataclass(slots=True)
class DocSection:
    """A numbered (or styled) region of one document."""

    section_key: str
    number: str | None
    title: str
    level: int
    detected_by: str
    heading_paragraph_index: int | None
    paragraphs: list[DocxParagraph] = field(default_factory=list)
    tables: list[DocxTable] = field(default_factory=list)

    @property
    def heading(self) -> str:
        """Citable heading; empty for the synthetic preamble, which has no title."""

        if self.detected_by == "synthetic":
            return ""
        return f"{self.number} {self.title}".strip() if self.number else self.title

    def text(self) -> str:
        parts = [paragraph.text for paragraph in self.paragraphs]
        parts.extend(table.as_text() for table in self.tables)
        return "\n".join(part for part in parts if part.strip())

    def to_dict(self) -> dict[str, object]:
        return {
            "section_key": self.section_key,
            "number": self.number,
            "title": self.title,
            "level": self.level,
            "detected_by": self.detected_by,
            "heading_paragraph_index": self.heading_paragraph_index,
            "paragraph_indexes": [p.paragraph_index for p in self.paragraphs],
            "table_indexes": [t.table_index for t in self.tables],
        }


def _style_level(style: str | None) -> int | None:
    if not style or not style.startswith("Heading"):
        return None
    suffix = style[len("Heading") :]
    return int(suffix) if suffix.isdigit() else 1


def classify_heading(paragraph: DocxParagraph) -> tuple[str | None, str, int, str] | None:
    """Return ``(number, title, level, detected_by)`` if the paragraph is a heading.

    ``detected_by`` is one of ``"number"``, ``"style"`` or ``"number+style"``.
    """

    text = paragraph.text.strip()
    if not text or "\n" in text or len(text) > MAX_HEADING_CHARS:
        return None
    if paragraph.is_bullet:
        return None

    style_level = _style_level(paragraph.style)
    match = NUMBERED_HEADING.match(text)

    if match is not None:
        number = match.group("number")
        title = match.group("title").strip()
        # A trailing sentence period means prose, not a label.
        if title.endswith(".") and len(title.split()) > 12:
            return None
        level = number.count(".") + 1
        return number, title, level, "number+style" if style_level else "number"
    if style_level is not None:
        return None, text, style_level, "style"
    return None


def segment_document(document: DocxDocument) -> list[DocSection]:
    """Split a document into sections, attributing every block to exactly one.

    Content appearing before the first heading is kept in a synthetic
    ``"__preamble__"`` section rather than dropped: the cover block holds the
    establishment name and RE number, which is exactly what E3 needs.
    """

    sections: list[DocSection] = []
    current = DocSection(
        section_key="__preamble__",
        number=None,
        title="(preamble)",
        level=0,
        detected_by="synthetic",
        heading_paragraph_index=None,
    )

    for _order, kind, index in document.block_order:
        if kind == "tbl":
            current.tables.append(document.tables[index])
            continue

        paragraph = document.paragraphs[index]
        classified = classify_heading(paragraph)
        if classified is None:
            if paragraph.text.strip():
                current.paragraphs.append(paragraph)
            continue

        number, title, level, detected_by = classified
        if current.paragraphs or current.tables or current.section_key != "__preamble__":
            sections.append(current)
        key = number if number else re.sub(r"[^A-Za-z0-9]+", "-", title).strip("-").lower()
        current = DocSection(
            section_key=key or f"p{paragraph.paragraph_index}",
            number=number,
            title=title,
            level=level,
            detected_by=detected_by,
            heading_paragraph_index=paragraph.paragraph_index,
        )

    sections.append(current)
    return [
        section
        for section in sections
        if section.paragraphs or section.tables or section.heading_paragraph_index is not None
    ]
