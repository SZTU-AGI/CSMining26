"""FRECA compliance-auditing package."""

__version__ = "0.1.0"

