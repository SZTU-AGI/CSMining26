"""One guarded entry point for the v2 dual-representation reasoning slice."""

from __future__ import annotations

from freca.argument.evaluator import ArgumentGraphEvaluation, evaluate_argument_graph
from freca.argument.indexed_shadow_evaluator import (
    IndexedShadowEvaluationReport,
    audit_indexed_shadow,
)
from freca.argument.models import ArgumentGraphTemplate
from freca.argument.projection import project_argument_graph
from freca.argument.reference_evaluator import (
    EvaluatorAgreementReport,
    compare_evaluators,
    reference_evaluate_argument_graph,
)
from freca.domain.models import Sha256, StrictModel
from freca.logic.ast import LogicDAG
from freca.logic.four_valued import FourValuedState
from freca.policy.graph_projection_conformance import (
    GraphProjectionConformanceReport,
    audit_graph_projection,
)
from freca.policy.indexed_requirement_view import (
    IndexedRequirementView,
    build_indexed_requirement_view,
)
from freca.policy.representation_capability import (
    ContractRepresentationCapability,
    classify_representation_capability,
)


class ReasoningIntegrityError(RuntimeError):
    pass


class DualReasoningBundle(StrictModel):
    indexed_requirement_view: IndexedRequirementView
    argument_graph_template: ArgumentGraphTemplate
    projection_conformance: GraphProjectionConformanceReport
    representation_capability: ContractRepresentationCapability
    primary_graph_evaluation: ArgumentGraphEvaluation
    reference_graph_evaluation: ArgumentGraphEvaluation
    evaluator_agreement: EvaluatorAgreementReport
    indexed_shadow_evaluation: IndexedShadowEvaluationReport


def run_dual_reasoning(
    *,
    case_uid: str,
    cp_id: str,
    contract_id: str,
    logic_dag: LogicDAG,
    proposition_catalog_sha256: Sha256,
    atom_states: dict[str, FourValuedState],
    contains_dynamic_burden: bool = False,
    contains_case_dependent_assumption: bool = False,
    contains_nonreducible_rebuttal: bool = False,
) -> DualReasoningBundle:
    """Run every mandatory representation/evaluator gate in dependency order."""

    view = build_indexed_requirement_view(
        logic_dag,
        proposition_catalog_sha256=proposition_catalog_sha256,
    )
    graph = project_argument_graph(view, logic_roots=logic_dag.roots)
    projection = audit_graph_projection(view, graph)
    if not projection.exact_projection_passed:
        raise ReasoningIntegrityError("AST_TO_ARGUMENT_GRAPH_CONSERVATION_BLOCK")

    capability = classify_representation_capability(
        logic_dag,
        contract_id=contract_id,
        contains_dynamic_burden=contains_dynamic_burden,
        contains_case_dependent_assumption=contains_case_dependent_assumption,
        contains_nonreducible_rebuttal=contains_nonreducible_rebuttal,
    )
    primary = evaluate_argument_graph(graph, atom_states)
    reference = reference_evaluate_argument_graph(graph, atom_states)
    agreement = compare_evaluators(primary, reference)
    if agreement.status != "PASS":
        raise ReasoningIntegrityError("EVALUATOR_DISAGREEMENT_BLOCK")

    shadow = audit_indexed_shadow(
        case_uid=case_uid,
        cp_id=cp_id,
        view=view,
        dag=logic_dag,
        graph=graph,
        graph_evaluation=primary,
        capability=capability,
        atom_states=atom_states,
    )
    if shadow.comparison_status == "MISMATCH":
        raise ReasoningIntegrityError("INDEXED_SHADOW_MISMATCH_BLOCK")
    return DualReasoningBundle(
        indexed_requirement_view=view,
        argument_graph_template=graph,
        projection_conformance=projection,
        representation_capability=capability,
        primary_graph_evaluation=primary,
        reference_graph_evaluation=reference,
        evaluator_agreement=agreement,
        indexed_shadow_evaluation=shadow,
    )
