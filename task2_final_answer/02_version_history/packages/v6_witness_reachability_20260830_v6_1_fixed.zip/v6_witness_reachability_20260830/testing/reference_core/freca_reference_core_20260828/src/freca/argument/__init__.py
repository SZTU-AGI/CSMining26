"""Argument-graph projection and evaluation for FRECA-CAES-DAG-v1."""

from freca.argument.models import (
    ArgumentGraphTemplate,
    ArgumentPremiseTemplate,
    ArgumentTemplate,
    StatementTemplate,
)
from freca.argument.pipeline import DualReasoningBundle, run_dual_reasoning

__all__ = [
    "ArgumentGraphTemplate",
    "ArgumentPremiseTemplate",
    "ArgumentTemplate",
    "DualReasoningBundle",
    "StatementTemplate",
    "run_dual_reasoning",
]
