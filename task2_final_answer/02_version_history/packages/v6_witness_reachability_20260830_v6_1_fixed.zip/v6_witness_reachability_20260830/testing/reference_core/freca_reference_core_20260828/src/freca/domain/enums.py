"""Enums that freeze the semantics shared across the FRECA workflow."""

from enum import Enum


class FinalLabel(str, Enum):
    COMPLIANT = "1"
    NON_COMPLIANT = "0"
    NOT_APPLICABLE = "N/A"


class Applicability(str, Enum):
    APPLICABLE = "APPLICABLE"
    NOT_APPLICABLE = "NOT_APPLICABLE"
    UNKNOWN = "UNKNOWN"


class Sufficiency(str, Enum):
    SUFFICIENT = "SUFFICIENT"
    INSUFFICIENT = "INSUFFICIENT"
    CONFLICTING = "CONFLICTING"
    UNKNOWN = "UNKNOWN"


class DecisionBasis(str, Enum):
    COMPLIANT_EVIDENCE = "compliant_evidence"
    VIOLATION_EVIDENCE = "violation_evidence"
    EXPLICIT_NON_APPLICABILITY = "explicit_non_applicability"
    MISSING_REQUIRED_EVIDENCE = "missing_required_evidence"


class EvidenceIdentityState(str, Enum):
    SELF = "SELF"
    SUPPLIER = "SUPPLIER"
    FOREIGN = "FOREIGN"
    MIXED = "MIXED"
    UNKNOWN = "UNKNOWN"


class ArtifactStatus(str, Enum):
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"
    BLOCKED = "BLOCKED"


class GateDecision(str, Enum):
    PASS = "PASS"
    RETRY = "RETRY"
    ESCALATE = "ESCALATE"
    BLOCK = "BLOCK"


class GateSeverity(str, Enum):
    HARD = "HARD"
    SOFT = "SOFT"


class VerificationIssueCode(str, Enum):
    UNGROUNDED = "UNGROUNDED"
    CONTRADICTION = "CONTRADICTION"
    UNTRANSLATABLE = "UNTRANSLATABLE"
    IDENTITY_MISMATCH = "IDENTITY_MISMATCH"
    TEMPORAL_MISMATCH = "TEMPORAL_MISMATCH"
    INSUFFICIENT = "INSUFFICIENT"
    CITATION_INVALID = "CITATION_INVALID"


class ClaimType(str, Enum):
    POLICY = "POLICY"
    APPLICABILITY = "APPLICABILITY"
    EVIDENCE = "EVIDENCE"
    COUNTER_EVIDENCE = "COUNTER_EVIDENCE"
    DERIVED_FACT = "DERIVED_FACT"
    SUFFICIENCY = "SUFFICIENCY"
    VERDICT = "VERDICT"


class PremiseSourceType(str, Enum):
    POLICY_SOURCE = "POLICY_SOURCE"
    CASE_EVIDENCE = "CASE_EVIDENCE"
    DETERMINISTIC_RESULT = "DETERMINISTIC_RESULT"
    PRIOR_CLAIM = "PRIOR_CLAIM"


class ClaimRelation(str, Enum):
    SUPPORTS = "SUPPORTS"
    CONTRADICTS = "CONTRADICTS"
    REQUIRES = "REQUIRES"
    EXCEPTS = "EXCEPTS"
    DERIVED_FROM = "DERIVED_FROM"


class ClaimStatus(str, Enum):
    UNVERIFIED = "UNVERIFIED"
    VERIFIED = "VERIFIED"
    REJECTED = "REJECTED"

