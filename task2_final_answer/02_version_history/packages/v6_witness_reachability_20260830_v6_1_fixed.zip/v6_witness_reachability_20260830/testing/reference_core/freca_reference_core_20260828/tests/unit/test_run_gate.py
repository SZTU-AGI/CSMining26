"""Tests for the run-mode gate.

The gate exists because of a run that passed every structural check while being
substantively empty, so the tests are written the same way round: most of them
assert that a *well-formed* run is still rejected when it did not reason.
"""

from __future__ import annotations

import pytest

from freca.evaluation.run_gate import RunMode, RunStatus, assess_run


def _decisions(
    n: int, *, label: str = "1", synthetic: bool = False
) -> list[dict[str, object]]:
    return [{"label": label, "synthetic": synthetic} for _ in range(n)]


# -- the headline rule ------------------------------------------------------


def test_a_single_synthetic_decision_invalidates_a_production_run() -> None:
    """Not a rate threshold: one synthetic cell is enough.

    A partially synthetic run has no honest interpretation — you cannot say which
    cells were reasoned about without checking each one, and the aggregate score
    mixes the two.
    """

    health = assess_run(
        mode=RunMode.PRODUCTION,
        n_cells_attempted=100,
        decisions=_decisions(99) + _decisions(1, synthetic=True),
    )
    assert health.status is RunStatus.RUN_INVALID
    assert health.export_blocked is True
    assert any("synthetic" in finding for finding in health.blocking_findings)


def test_evaluation_mode_is_as_strict_as_production() -> None:
    health = assess_run(
        mode=RunMode.EVALUATION,
        n_cells_attempted=10,
        decisions=_decisions(10, synthetic=True),
    )
    assert health.status is RunStatus.RUN_INVALID
    assert health.export_blocked is True


def test_dev_mode_permits_synthetic_but_still_reports_it() -> None:
    """Dev mode must stay usable offline — that is how the defects were found.

    What it must not do is go quiet: the finding moves from blocking to warning,
    it does not disappear.
    """

    health = assess_run(
        mode=RunMode.DEV,
        n_cells_attempted=10,
        decisions=_decisions(10, synthetic=True),
    )
    assert health.export_blocked is False
    assert health.status is RunStatus.RUN_DEGRADED
    assert any("synthetic" in warning for warning in health.warnings)
    assert health.synthetic_rate == 1.0


def test_the_measured_degenerate_run_is_rejected() -> None:
    """Replays the actual failure: 120 decisions, all synthetic, 98% labelled 1.

    Every validator passed on this run and the workbook was well-formed. If this
    test ever goes green under production mode, the gate has been defeated.
    """

    decisions = _decisions(118, label="1", synthetic=True) + _decisions(
        2, label="0", synthetic=True
    )
    health = assess_run(
        mode=RunMode.PRODUCTION, n_cells_attempted=120, decisions=decisions
    )
    assert health.status is RunStatus.RUN_INVALID
    assert health.export_blocked is True
    # And the two independent symptoms are each named, not merged into one alarm.
    assert any("N/A" in warning for warning in health.warnings)
    assert any("near-constant" in warning for warning in health.warnings)


def test_a_real_run_with_three_classes_is_valid() -> None:
    decisions = (
        _decisions(60, label="1") + _decisions(30, label="0") + _decisions(10, label="N/A")
    )
    health = assess_run(
        mode=RunMode.PRODUCTION, n_cells_attempted=100, decisions=decisions
    )
    assert health.status is RunStatus.RUN_VALID
    assert health.export_blocked is False
    assert health.warnings == []
    assert health.unreachable_labels == []


# -- denominators -----------------------------------------------------------


def test_placeholder_zeros_do_not_count_toward_accuracy() -> None:
    """The fill value for a blocked cell is a formatting obligation, not a guess.

    Scoring it would credit the model with the majority class every time the
    pipeline fell over, which is exactly backwards. Blocked cells arrive with an
    empty label, so they are excluded from the scored set by never entering it.
    """

    decisions = (
        _decisions(70, label="1")
        + [{"label": "", "synthetic": False} for _ in range(30)]
    )
    health = assess_run(
        mode=RunMode.DEV,
        n_cells_attempted=100,
        decisions=decisions,
        n_blocked_filled=30,
    )
    assert health.n_decided == 70
    assert health.scored_cells == 70
    assert health.accuracy_denominator() == 70
    # The 30 placeholders are still on the record, just not in the denominator.
    assert health.n_blocked_filled == 30
    assert health.to_dict()["n_blocked_filled"] == 30


def test_blocked_cells_do_not_inflate_the_synthetic_rate() -> None:
    """A cell that produced no verdict cannot be a synthetic verdict.

    Counting blocked rows on the numerator and decided rows on the denominator
    produced the nonsense line "120 synthetic (0.0% of decisions)" on a run that
    decided nothing. Both sides must be the same population.
    """

    decisions = [{"label": "", "synthetic": True} for _ in range(120)]
    health = assess_run(
        mode=RunMode.DEV, n_cells_attempted=123, decisions=decisions, n_blocked_filled=120
    )
    assert health.n_decided == 0
    assert health.n_synthetic == 0
    assert health.synthetic_rate == 0.0
    assert health.status is RunStatus.RUN_INVALID


def test_coverage_is_reported_when_cells_never_reached_a_verdict() -> None:
    health = assess_run(
        mode=RunMode.DEV,
        n_cells_attempted=100,
        decisions=_decisions(40, label="1"),
    )
    assert health.decision_coverage == pytest.approx(0.4)
    assert any("coverage" in warning for warning in health.warnings)


def test_full_coverage_raises_no_coverage_warning() -> None:
    health = assess_run(
        mode=RunMode.DEV,
        n_cells_attempted=3,
        decisions=_decisions(1, label="1")
        + _decisions(1, label="0")
        + _decisions(1, label="N/A"),
    )
    assert health.decision_coverage == 1.0
    assert not any("coverage" in warning for warning in health.warnings)


def test_attempted_can_never_be_less_than_decided() -> None:
    """Guards against a caller passing a stale attempt count and reporting >100%."""

    health = assess_run(mode=RunMode.DEV, n_cells_attempted=0, decisions=_decisions(5))
    assert health.n_cells_attempted == 5
    assert health.decision_coverage == 1.0


def test_an_empty_run_is_invalid_rather_than_perfect() -> None:
    """Zero decisions must not divide out to a clean sheet."""

    health = assess_run(mode=RunMode.PRODUCTION, n_cells_attempted=100, decisions=[])
    assert health.status is RunStatus.RUN_INVALID
    assert health.decision_coverage == 0.0
    assert health.synthetic_rate == 0.0
    assert any("no decisions" in finding for finding in health.blocking_findings)


def test_blank_labels_are_not_counted_as_decisions() -> None:
    """A blocked cell arrives with ``label=""``; it is not a verdict."""

    health = assess_run(
        mode=RunMode.DEV,
        n_cells_attempted=10,
        decisions=_decisions(6, label="1") + [{"label": "", "synthetic": False}] * 4,
    )
    assert health.n_decided == 6
    assert health.decision_coverage == pytest.approx(0.6)


# -- reporting --------------------------------------------------------------


def test_summary_always_prints_coverage_next_to_the_counts() -> None:
    health = assess_run(
        mode=RunMode.DEV,
        n_cells_attempted=100,
        decisions=_decisions(50, label="1"),
        n_blocked_filled=10,
    )
    text = "\n".join(health.summary_lines())
    assert "coverage" in text
    assert "scored cells" in text
    assert "synthetic" in text


def test_to_dict_round_trips_the_numbers_needed_to_audit_the_run() -> None:
    health = assess_run(
        mode=RunMode.PRODUCTION,
        n_cells_attempted=120,
        decisions=_decisions(120, synthetic=True),
    )
    payload = health.to_dict()
    for key in (
        "mode",
        "status",
        "export_blocked",
        "decision_coverage",
        "synthetic_rate",
        "scored_cells",
        "unreachable_labels",
        "blocking_findings",
    ):
        assert key in payload
    assert payload["status"] == "RUN_INVALID"


def test_mode_accepts_a_plain_string() -> None:
    health = assess_run(mode="production", n_cells_attempted=1, decisions=_decisions(1))
    assert health.mode is RunMode.PRODUCTION
