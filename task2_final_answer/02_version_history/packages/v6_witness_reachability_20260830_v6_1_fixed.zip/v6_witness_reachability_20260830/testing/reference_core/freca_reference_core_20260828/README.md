# FRECA

FRECA is a verification-gated agentic compliance auditing system for heterogeneous
DOCX/XLSX evidence.

The business workflow remains:

```text
M0 → R0/R1 → E0–E3 → A0 → C0–C7 → P0–P2 → V0
```

Current implementation status: A0 + C0-C7 + P0-P2 + V0 foundation implemented.

- strict domain models and three-value decision semantics;
- append-only, hash-verified filesystem artifact store;
- run-event records for later error propagation analysis;
- unit tests for semantic invariants and storage integrity.
- A0 farm profiles with provenance, conflicts, and unknown fields;
- scope tri-state gate: explicit negative → N/A, unresolved → C6 review;
- synthetic/fallback hard gate and exact model-call audit records;
- V0 gold/coverage/perturbation/leakage report generation.

Architecture and evaluation notes:

- `outputs/research_ideation/code-ready-architecture-v1.md`
- `outputs/research_ideation/model-evaluation-playbook.md`

Run the dependency-light test suite with the bundled Python:

```powershell
$env:PYTHONPATH = "src"
python -m unittest discover -s tests -v
```

After installing the development extras, the same tests can be run with:

```powershell
python -m pip install -e ".[dev]"
pytest
```

Run the frozen seven-CP vertical slice:

```powershell
$env:PYTHONPATH = "src"
python -m freca.cli --run-root artifacts/runs --run-id slice7 audit `
  --cases <cases> --rules <rules.pdf> --checkpoints <checkpoints.xlsx> `
  --template <submission_template.xlsx> --cp-ids CP2 CP10 CP22 CP23 CP26 CP38 CP41 `
  --backend fake --mode dev
```

Evaluate an existing run. Without gold, the result is explicitly `NO_GOLD`:

```powershell
python -m freca.cli evaluate --run-dir artifacts/runs/<run_id> --gold <gold.jsonl>
```

Server/JupyterLab execution order and real-backend checks:
`docs/server-jupyterlab-runbook.md`.

当前代码流程图和节点实现对照：
`docs/current-as-built-flowchart.md`。

保留 N/A 反证、P1 自动回查和三路 masking 的下一版目标架构：
`docs/target-architecture-v2.md`。
