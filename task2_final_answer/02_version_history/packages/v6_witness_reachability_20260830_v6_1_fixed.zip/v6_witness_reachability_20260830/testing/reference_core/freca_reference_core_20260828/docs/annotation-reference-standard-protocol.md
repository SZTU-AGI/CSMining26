# FRECA 人工标注与 Reference Standard 协议 v1

> 决策：学生标注不称为 expert gold 或绝对 ground truth。  
> 正式称谓：**source-grounded, adjudicated reference standard**。  
> 目标：让有限人工判断可以复核、可以保留分歧，并限制论文能够声称的结论。

## 1. 为什么不能把学生多数票直接叫标准答案

两名学生答案一致，只能证明一致，不能证明专业正确。共同误读法规时，一致率仍可能很高。

因此 reference item 必须同时包含：

```text
label
policy span
supporting/contrary evidence span
identity anchors
decision basis
annotator confidence
adjudication status
```

没有来源坐标的标签不能进入主评测集。

## 2. 把标注拆成三层

### Layer P：法规锚点与 PolicyPack

标注单位是 `CP`，不是 `case × CP`。每个 CP 只做一次：

- 对应直接条款；
- 通用条款与 `APPLIES_VIA` 路径；
- subject/scope；
- required facts；
- explicit N/A conditions；
- violation/counter facts。

学生不需要各自在 132 页中搜索。系统先给候选条款和图路径，标注者只做忠实性核验。
教师或更熟悉法规的人优先复核 41 个 PolicyPack、无法达成一致的法规解释和会影响多个 CP 的通用条款。

### Layer I：证据身份与角色

这个任务不是判断合规，而是较窄的实体匹配任务，主要依据 farm name、RE number、
product、address、date、signature 和文件角色。

```text
IdentityMatchState:
  SELF / RELATED / FOREIGN / MIXED / UNKNOWN

ActorRole:
  OCCUPIER / MANAGER / EXPORTER / AUTHORISED_OFFICER /
  SUPPLIER / REGULATOR / OTHER / UNKNOWN
```

身份层不要求专业审计知识，但每个标签必须列出使用了哪些 identity anchors。

### Layer D：最终 CP 决策

标注者只接收冻结 PolicyPack、当前 case 候选证据、原始 locator 和统一三值协议，
不要求凭记忆解释整部法规。

## 3. Reference Standard 状态

```text
CLEAR
  两人独立一致，证据和法规出处完整

ADJUDICATED
  初始不一致，经重开原文和结构化讨论后形成结论

DISPUTED
  仍存在两种合理解释，但能描述争议点

UNRESOLVED
  数据缺失或法规解释超出当前能力，暂不作为正确率分母
```

主准确率只在 `CLEAR + ADJUDICATED` 上计算，同时报告 coverage。
`DISPUTED` 单独用于评估模型能否识别不确定性，不强迫成唯一标签。

## 4. 标注流程

```text
Annotator A 独立标注
Annotator B 独立标注
  ↓
比较 label + evidence span + basis
  ↓
一致且出处完整 → CLEAR
不一致 → 只展示双方依据，重新打开法规/证据
  ↓
达成一致 → ADJUDICATED
仍不能解决 → DISPUTED / UNRESOLVED
  ↓
教师/领域人员只抽查 PolicyPack、争议项和高影响规则
```

禁止：

- 用待评模型自己的答案作为仲裁依据；
- 用多个模型多数票代替人工 reference；
- 标注者看到实验变体名称；
- 人工表进入模型推理后，又用同一表评价模型；
- 为了凑唯一答案而隐藏真实分歧。

## 5. 分阶段标注规模

### Phase A：工程调试

`3 cases × 7 CP = 21` 个决策项。全部双人独立标注，只用于发现 schema 和说明书问题。

### Phase B：小型 reference evaluation

`10 cases × 7 CP = 70` 个决策项。按 case 隔离开发/测试，覆盖正常、缺失、foreign、
mixed、conflict 和 table reasoning。

### Phase C：资源允许时扩展

`10 cases × 41 CP = 410` 个决策项。只有在 Phase B 协议稳定、分歧原因可解释后再扩展。

## 6. E3 身份检测的 V0 评测

完全没有人工参考时，V0 只能报告 consistency 和 coverage，不能报告 accuracy。

第一步建立小型身份 reference：

```text
30 份文件用于协议校准
  → 两人独立标注
  → 修改说明书
  → 不作为最终无偏测试

随后从 20–30 个 case 中抽取至少 100 个 evidence atoms
  → 随机分层 reference set
  → 另建 hard-case diagnostic set
```

抽样覆盖 T2、T9、其他 Track、明显 self、suspected foreign、supplier/related、mixed
以及 anchor 缺失或冲突。

评测：

```text
人工协议：raw agreement、Cohen's kappa、类别分歧矩阵
E3：per-class precision/recall/F1、macro-F1、
    FOREIGN false-accept、SELF false-reject、UNKNOWN/MIXED coverage
```

类别不均衡时不能只报 accuracy。

## 7. 最终 CP 标注质量

标签一致性报告 raw agreement、Cohen's kappa 和 `1/0/N/A` confusion matrix。

证据一致性还要报告 supporting locator overlap、contrary locator overlap、
required-fact coverage 和 policy anchor agreement。两人即使都判 0，但采用完全不同条款，
也不能算高质量一致。

## 8. T2 小节标题中的 CP 编号

### 决定

采用：**软先验 + 证据融合 + V0 遮蔽消融。**

```json
{
  "track": "T2",
  "declared_cp_ids": ["CP17", "CP18"],
  "heading_locator": "...",
  "body_evidence_ids": ["..."]
}
```

使用规则：

- 标题列出的 CP：提升其下正文 chunk 候选分数；
- 标题没有列出的 CP：不降分、不判负、不阻止其他 Track 召回；
- 标题本身不能证明 `1`；
- 仍需正文证据、identity 和时间门；
- 不把 14/41 的出现关系写成整个数据集的硬路由表。

V0 比较：

```text
T2-A 使用原始标题
T2-B mask "Checking Point X.Y"，保留正文
T2-C 不使用 T2 heading prior
```

分别报告 retrieval Recall@k、最终 F1，以及 14 个相关 CP 与 27 个其他 CP 的变化。

## 9. 论文中的允许表述

允许：

> We construct a source-grounded, doubly annotated and adjudicated reference set.

> Ambiguous items are retained as disputed and excluded from the primary accuracy denominator.

> The reference standard was produced by trained student annotators rather than professional auditors.

不允许声称 `expert-verified gold labels` 或 `objective ground truth for all 4100 decisions`。
如果没有专业审计员复核，应明确写入 limitation。

## 10. 当前开工门

无需等完整标注才能继续写 M0、R0、E0–E3 和接口代码。但在声称模型准确前，至少完成：

```text
41 个 R1 PolicyPack 的来源核验
30 份身份协议校准样本
100 个 identity evidence-atom reference items
3 cases × 7 CP 的双人结构化标注
```

如果暂时做不到，只能报告可追溯性、约束通过率和人工一致性，不能报告真实审计准确率。

