# 在服务器 JupyterLab 中运行 FRECA

## 1. 上传目录

上传并解压服务器 bundle 后，进入其中的
`freca_jupyterlab_package` 目录。不要只上传 `src/freca`，因为运行和测试
还需要 `pyproject.toml`、`tests`、`docs` 和 `artifacts` 输出目录。

## 2. 在 JupyterLab Terminal 安装

进入上传后的目录：

```bash
cd /你的路径/freca_jupyterlab_package
python --version
python -m pip install -e .
```

开发和测试环境：

```bash
python -m pip install -e ".[dev]"
pytest
```

当前要求 Python 3.12 或 3.13。若服务器只有更低版本，请先创建兼容环境。

## 3. 在 Notebook 中安装

如果 Notebook 的当前目录就是项目根目录：

```python
%pip install -e .
```

安装后重启 Kernel，然后：

```python
import freca
from freca.harness import FileArtifactStore

print(freca.__version__)
```

也可以直接打开：

```text
notebooks/00_smoke_test.ipynb
```

## 4. 不安装时的临时导入方式

仅用于快速检查，不建议作为正式实验方式：

```python
import sys
from pathlib import Path

project_root = Path.cwd()
sys.path.insert(0, str(project_root / "src"))

import freca
```

正式实验应使用 editable install，因为它能让所有 Notebook、脚本和测试使用
同一份包。

## 5. 当前能运行什么

当前 bundle 已包含：

- M0 manifest、证据身份分层和 A0 FarmProfile；
- PolicyPack、C0–C7、P0–P2 审计链；
- fake/offline 与 OpenAI-compatible backend；
- synthetic hard gate、exact model-call audit；
- V0 gold、coverage、perturbation、leakage 报告；
- 服务器执行手册：`docs/server-jupyterlab-runbook.md`。

先用 `--backend none` 或 `--backend fake --mode dev` 验证管线，再用真实模型
和 `--mode evaluation` 运行正式评测。无真实模型读取或无 gold 时，不应把输出
解释为准确率。
