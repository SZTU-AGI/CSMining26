# 法规链与四项开工决策冻结说明

> 状态：Frozen for implementation v1  
> 日期：2026-07-31  
> 依据：41 CP × 184 条款节的 BM25 实测，以及现有三值判定协议。  
> 边界：不改变 `M0 → R0/R1 → E0–E3 → A0 → C0–C7 → P0–P2 → V0` 主干。

## 一、法规链的实现决策

### R0 内部顺序

不新增一条平行流水线，也不新建 `R-1`。将 R0 细化为：

```text
R0.0 Norm Corpus
  132 页法规 → 184 个条款节节点

R0.1 Norm Graph
  建立 STRUCTURAL_PARENT / REFERS_TO / DEFINES / APPLIES_VIA / EXCEPTS

R0.2 Subject Closure
  沿有出处的规范图路径继承 scope 与 subject

R0.3 Scope / Subject Gate
  只保留与 registered establishment + occupier 相容的候选及通用条款闭包

R0.4 Lexical Anchor
  在相容候选池中用“小节标题 + CP 文本”做 BM25

R0.5 PolicyPack Assembly
  汇总直接条款、通用条款、定义、例外和交叉引用

R1 Fidelity Review
  人工只核对 PolicyPack 是否忠实于法规，不加入案例答案
```

`11-2 → 11-7` 表示：11-2 的通用记录质量要求通过 11-7 的记录保留义务，
对 registered establishment 的 occupier 生效。继承后的 subject 必须保存完整路径，
不能只写最终槽位。

### 必加错误码

```text
POLICY_SUBJECT_MISMATCH
POLICY_SCOPE_MISMATCH
POLICY_SUBJECT_UNRESOLVED
POLICY_GRAPH_PATH_MISSING
```

其中 `POLICY_SUBJECT_MISMATCH` 是硬门；`UNRESOLVED` 不能被当成 mismatch 剪掉，
应进入图扩展或人工复核。

### 必加法规链回归测试

```text
CP1 / CP2 / CP6 / CP20 / CP22 / CP26 / CP29 / CP33
  加 gate 后，top-1 不得再落到不相容主体体系

CP22
  不能因相同的 retain-records 措辞误锚 exporter/officer 条款

CP38
  必须通过 subject 区分平行的两年保存义务

CP23 / CP40
  11-2 不能被孤立主体过滤剪掉，必须通过 APPLIES_VIA 保留
```

## 二、问题 1：署名错配

### 决定

采用：

> **管道内抽取 + 人工署名表只作离线评测标签。**

人工表不得作为 held-out/test 推理输入，不得预先删除 Track，也不得直接决定 CP 标签。

### 数据模型必须拆开两件事

当前单一 identity 枚举不够，应拆为：

```text
IdentityMatchState:
  SELF / RELATED / FOREIGN / MIXED / UNKNOWN

ActorRole:
  OCCUPIER / MANAGER / EXPORTER / AUTHORISED_OFFICER /
  SUPPLIER / REGULATOR / OTHER / UNKNOWN
```

署名指向别的农场不自动等于“无效”：

- 可能是供应商证据；
- 可能是监管或授权人员签署；
- 可能是混合文档；
- 是否可支持当前 CP，取决于 PolicyPack 要求的 actor role。

E3 必须按 evidence atom 判断，不能按整个 T2/T9 Track 一刀切。

人工署名表用途：

```text
允许：
  identity detector 的 precision / recall / confusion matrix
  开发集规则校准
  错误案例分析

禁止：
  测试时检索过滤
  作为模型上下文
  直接推导 1/0/N/A
```

## 三、问题 2：首个 7 CP 纵切面

### 决定

采用：

```text
CP2 / CP10 / CP22 / CP23 / CP26 / CP38 / CP41
```

选择目标是覆盖故障类型，不追求 Element 数量均衡：

| CP | 首轮主要覆盖 |
|---|---|
| CP2 | scope/subject 越界与正确条款修复 |
| CP10 | 4-2 嵌套款项的精确锚定 |
| CP22 | 近同文 retention 条款、主体消歧 |
| CP23 | 11-2 通用义务与 APPLIES_VIA |
| CP26 | 9-16 词汇陷阱、subject gate |
| CP38 | 平行两年保存义务的主体消歧 |
| CP41 | 4-7 锚定与跨条款事实组合 |

这 7 个 CP 只用于打通工程链，不能用其结果估计全 41 CP 总体性能。
开发完成后必须盲跑未参与调试的 CP，防止写出七套隐式专用规则。

## 四、问题 3：服务器模型与 embedding

### 决定

采用：

> **先写可切换接口 + 内置 deterministic fake backend。**

首阶段不把代码绑死在 OpenAI endpoint 或本地开源模型上。

```text
LLMBackend
  ├─ FakeStructuredLLM
  └─ OpenAICompatibleLLM

EmbeddingBackend
  ├─ NoEmbedding
  ├─ FakeHashEmbedding
  └─ OpenAICompatibleEmbedding / LocalEmbedding
```

真实 endpoint、API key、模型名只通过环境变量或服务器私有配置提供，不能写入 ZIP。

法规侧和证据侧必须使用不同配置：

```yaml
retrieval:
  policy:
    lexical: bm25
    dense: false
    scope_subject_gate: true
    norm_graph: true

  evidence:
    lexical: bm25
    dense: optional
    identity_gate: true
    metadata_rerank: true
```

在没有服务器 GPU/endpoint 信息前，不能负责任地冻结真实模型，但这不阻塞
M0、R0、E0–E3、Artifact Store 和 fake vertical slice。

## 五、问题 4：适用但缺少必需证据

### 决定

最终强制三值映射采用：

```text
label = 0
sufficiency = INSUFFICIENT
basis = missing_required_evidence
review_required = true
```

明确禁止映射为 `N/A`。

但必须区分缺证来源：

```text
EVIDENCE_NOT_PRESENT
  文件清点、解析和检索均通过，确实没有必需记录
  → 可完成上述 0 映射

CASE_PACKAGE_INCOMPLETE
  M0 已知缺文件或缺 Track
  → 强制输出时可按冻结协议映射 0，但必须保留 package_incomplete
    与 review_required，论文中单独报告

SYSTEM_FAILURE
  解析失败、检索异常、模型超时、上下文截断
  → 不得伪装成 0；内部 BLOCK/ESCALATE，计入 coverage failure
```

换言之，模型或系统自己没找到证据，不等于证据不存在。

## 六、实验设计冻结

法规链和证据链分开评测。

### Policy Anchor Experiment

比较：

```text
P-A BM25
P-B BM25 + scope/subject gate
P-C BM25 + scope/subject gate + norm graph
```

指标：

- Anchor Accuracy@1；
- correct regulation Recall@k；
- policy subject mismatch rate；
- general-clause false-prune rate；
- 41 CP 的人工忠实性通过率。

当前观察 `8/41 → 0/41` 作为待复现结果，不提前写成普遍结论。

### Evidence / Decision Experiment

A–F 所有变体使用同一批 R1 冻结 PolicyPack，只改变证据提供和验证流程。
这样最终差异才能归因于 Full Context、BM25、Hybrid、Agent 或验证门，
而不是法规锚点同时发生变化。

新增独立消融：

```text
F - policy subject gate
F - norm graph
```

但法规侧消融首先报告 anchor 指标，最终标签变化作为下游影响。

## 七、尚需补齐的证据

为把本次观察升级为可引用实验结论，需要保存：

```text
184 节法规切分文件
41 条 CP 查询文件
原始 BM25 ranking JSONL
subject/scope gate 后 ranking JSONL
规范图节点与边 JSON
运行命令、代码 commit、配置 hash
```

否则只能称为“项目开发观察”，不能在论文中写成可复现实验结果。

