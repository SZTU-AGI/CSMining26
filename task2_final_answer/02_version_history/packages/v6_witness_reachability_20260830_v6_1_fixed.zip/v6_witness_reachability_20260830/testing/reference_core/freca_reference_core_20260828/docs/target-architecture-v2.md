# FRECA 目标架构 V2

> 状态：目标架构，等待继续编码。  
> 当前已经运行的代码仍以 [`current-as-built-flowchart.md`](current-as-built-flowchart.md)
> 为准。V2 在现有实现上强制补回三条闭环：独立 C3 N/A 活动反证检查、P1
> 自动回查相关 CP、Original/Verdict-Masked/Structure-Masked 三路 V0。

## 1. V2 总体逻辑图

```mermaid
flowchart TD
    INPUT["输入层\nRules PDF + 41 CP + 898 evidence files + template"]
    M0["M0 Logical Case Manifest\n确定性文件归属、100 case、缺失与 split 检查"]

    R0["R0 Regulation Layer\nsectionize + NormGraph + subject closure"]
    R1["R1 Frozen PolicyPack\nanchor + unit-level obligation extraction"]

    E0["E0 Structure Mapping\nDOCX/XLSX 模板与 locator"]
    E13["E1-E3 Evidence Layer\natoms + provenance + identity/admissibility"]
    A0["A0 FarmProfile\nSELF facts + conflicts + unknown + provenance"]

    C0["C0 Policy/Anchor Gate\n锁定 CP、主体和法规范围"]
    C1["C1 Preliminary Applicability\nA0 + scope predicates\nAPPLICABLE / N/A candidate / UNKNOWN"]
    C2["C2 Planned Primary Retrieval\nrequired/violation facts -> BM25 or hybrid evidence pack"]
    C3["C3 Independent N/A Counter-check\n跨 admissible evidence 搜索活动实际发生痕迹"]
    C4["C4 Typed Audit Argument + Model Reading\npolicy/applicability/evidence/counter/verdict claims"]
    C5["C5 Argument Validator\ngrounding + identity + sufficiency + contradiction"]
    C6["C6 Targeted Repair\nissue-bound retrieval, max 2 rounds"]
    HUMAN["Manual Review\n范围仍未知、重试耗尽或不可结构化"]
    C7["C7 Final CP Decision\n1 / 0 / N/A + citations + gate trace"]

    P0["P0 Case Consistency Detection\n共享事实、适用性、相同法规基础、极性冲突"]
    P1["P1 Automatic Related-CP Rerun Plan\nfinding -> affected CPs + issue IDs + retrieval needs"]
    PLIMIT["P1 Loop Guard\n每 case 最多 2 轮、禁止重复 finding/query"]
    HEALTH["RunHealth Gate\ncoverage + synthetic + blocked + label reachability"]
    P2["P2 Submission Assembly\n仅 RUN_VALID 导出；blocked 不计 accuracy"]

    V0["V0 Paired Evaluation\nGold + masking + perturbation + leakage + stage metrics"]
    BLOCK["Blocked Artifact\n保留原因和 trace，不产生 scored verdict"]

    INPUT --> M0
    M0 -->|PASS| R0
    M0 -->|PASS| E0
    M0 -->|FAIL| BLOCK
    R0 --> R1
    E0 --> E13
    E13 --> A0
    R1 --> C0
    A0 --> C0

    C0 --> C1
    C1 -->|APPLICABLE| C2
    C1 -->|N/A candidate| C3
    C1 -->|UNKNOWN| C6

    C3 -->|未发现活动反证| C4
    C3 -->|发现活动反证，取消 N/A| C2
    C3 -->|证据冲突/检索不足| C6

    C2 --> C4
    C4 --> C5
    C5 -->|PASS| C7
    C5 -->|RETRY| C6
    C5 -->|BLOCK| BLOCK
    C6 -->|新证据解决问题| C1
    C6 -->|仅裁决证据需修复| C4
    C6 -->|无新增或达到上限| HUMAN
    HUMAN --> BLOCK

    C7 -->|41 CP 完成| P0
    P0 -->|无冲突| HEALTH
    P0 -->|发现可修复冲突| P1
    P1 --> PLIMIT
    PLIMIT -->|允许重跑| C6
    PLIMIT -->|重复/超限| HUMAN

    HEALTH -->|RUN_VALID| P2
    HEALTH -->|RUN_INVALID| BLOCK
    P2 --> V0
    BLOCK --> V0
```

## 2. 三条必须保留的闭环

### 2.1 C3 独立 N/A 活动反证检查

```mermaid
flowchart LR
    A0["A0 明确否定 scope predicate"] --> NAC["N/A candidate"]
    NAC --> Q["构造活动反证查询\nactivity synonyms + identifiers + time window"]
    Q --> IDX["CaseEvidenceIndex\n只检索本 case 的 admissible evidence"]
    IDX --> FOUND{"发现实际活动痕迹？"}
    FOUND -->|否，且检索充分| NA["保留 N/A candidate"]
    FOUND -->|是| APP["取消 N/A -> APPLICABLE"]
    FOUND -->|冲突或检索不足| REVIEW["C6 targeted repair / manual review"]
```

C3 不是一般的合规反证搜索，只回答：

> A0 声称某项活动不在注册/经营范围，但其他可采证据中是否出现该活动实际发生的痕迹？

硬约束：

1. 缺少活动证据不等于没有活动；只有检索覆盖门通过后才能确认“未发现反证”。
2. `FOREIGN` 证据不能证明本案实际开展活动，但必须作为 identity conflict 进入 review。
3. C3 必须输出查询、命中、locator、identity state 和 coverage status。
4. N/A 的最终论证同时引用 scope predicate、A0 字段和 C3 counter-check report。

### 2.2 P1 自动回查相关 CP

```mermaid
flowchart LR
    P0["P0 consistency findings"] --> PLAN["P1 rerun planner"]
    PLAN --> F["finding_id + affected_cp_ids + shared_fact + required action"]
    F --> C6["逐 CP 送回 C6"]
    C6 --> C7["更新受影响 CP 的决定"]
    C7 --> P0B["重新运行 P0"]
    P0B -->|resolved| DONE["进入 RunHealth"]
    P0B -->|same finding| STOP["停止自动循环 -> manual review"]
```

P1 只能触发局部重跑，不能直接改标签。每个 rerun request 必须绑定：

- `finding_id`；
- `affected_cp_ids`；
- 冲突的共享事实或法规 basis；
- 需要补查的 `RetrievalNeed`；
- 原决定和新决定的版本关系。

循环门：每个 case 最多两轮；相同 finding、相同规范化查询、无新增 evidence ID
时立即停止并升级人工。

### 2.3 V0 三路 Masking 流水线

```mermaid
flowchart TD
    SOURCE["Frozen source cases"] --> MASKER["Deterministic Mask Generator"]
    MASKER --> O["Original"]
    MASKER --> VM["Verdict-Masked\n遮蔽显式 verdict/answer cues"]
    MASKER --> SM["Structure-Masked\n在 VM 基础上遮蔽 local C code、模板标题和结构捷径"]

    RULES["Frozen masking rules + mask manifest + hashes"] --> MASKER
    GOLD["同一 case-cluster gold"] --> EVAL["Paired V0 Evaluation"]

    O --> RUNO["相同 model/prompt/retrieval config"]
    VM --> RUNV["相同 model/prompt/retrieval config"]
    SM --> RUNS["相同 model/prompt/retrieval config"]
    RUNO --> EVAL
    RUNV --> EVAL
    RUNS --> EVAL

    EVAL --> DELTA["Original - Verdict-Masked\nVerdict leakage effect"]
    EVAL --> DELTAS["Verdict-Masked - Structure-Masked\nStructure shortcut effect"]
    EVAL --> ROBUST["coverage / macro-F1 / N/A-F1 / citation / flip rate"]
```

Masking 规则必须在测试集运行前冻结；三路使用同一批 case、同一 gold、同一模型和
同一预算。每个被遮蔽位置写入 `mask_manifest.jsonl`，保留原文件 hash、locator、
mask type 和转换后 hash，避免 masking 自身改变任务语义而无法追责。

## 3. V2 节点与方法

| 节点 | 方法 | 失败动作 |
|---|---|---|
| M0 | 确定性文件名/公司名归属、100-case gate | BLOCK |
| R0/R1 | NormGraph、subject closure、BM25 anchor、unit-level PolicyPack | pack review |
| E0-E3 | DOCX/XLSX structure parsing、EvidenceAtom、provenance、identity policy | 重解析/排除支持 |
| A0 | SELF-only profile、conflict/unknown/provenance | C1 UNKNOWN |
| C0 | policy subject/scope admission | BLOCK CP |
| C1 | tri-state scope predicate evaluation | C3/C6 |
| C2 | PlanRAG-like required-fact planning + primary retrieval | C6 |
| C3 | independent activity counterevidence retrieval | 取消 N/A/C6 |
| C4 | JSON model reading + Typed Audit Argument | BLOCK if unread/unlabelled |
| C5 | rule-based ArgumentValidator | PASS/RETRY/BLOCK |
| C6 | issue-bound bounded retrieval | 回 C1/C4 或人工 |
| C7 | deterministic label emission | BLOCK if no valid candidate |
| P0 | predefined cross-CP consistency rules | P1 |
| P1 | finding-bound local rerun planner | C6/manual |
| RunHealth/P2 | synthetic/coverage hard gate + template assembly | BLOCK export |
| V0 | three-way masking + gold/perturbation/leakage evaluation | 不通过不宣称效果 |

## 4. 与当前代码的实施差异

V2 需要新增或改造：

1. 将当前 C3 普通检索职责并入 C2，并增加独立 `c3_na_countercheck`；
2. 为 N/A argument 增加 `countercheck_report_id` 和活动反证 coverage；
3. 增加 `ConsistencyRerunRequest`、P1 loop guard 和 selective CP rerun；
4. 增加 deterministic masking generator、mask manifest 和三路 paired runner；
5. RunHealth 增加 unresolved P0/P1 finding 和 masking provenance 检查；
6. 保持现有 synthetic hard gate、exact model-call audit、blocked/scored 分离不变。

这些改动完成之前，当前代码仍应被描述为 V1 vertical slice，不能声称已经具备完整的
N/A 反证闭环、自动 consistency recovery 或 masked robustness evaluation。
