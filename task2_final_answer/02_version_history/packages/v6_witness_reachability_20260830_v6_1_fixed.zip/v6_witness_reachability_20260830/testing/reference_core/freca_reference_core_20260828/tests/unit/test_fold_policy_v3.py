from __future__ import annotations

import unittest

from freca.domain.enums import FinalLabel
from freca.finalization.fold_policy_v3 import (
    BranchEvaluation,
    Finality,
    FoldGateReport,
    FoldInvariantError,
    InternalOutcome,
    InterpretationBranchResult,
    InterpretationEnvelope,
    OneNaTiePolicy,
    RunMode,
    fold_branch,
    fold_envelope,
)
from freca.policy.condition_structure import (
    ConditionScopeClass,
    ConditionStructureDecision,
    ConditionTriggerEvidenceState,
    FalseTriggerSemantics,
    evaluate_false_trigger_eligibility,
)


def branch(branch_id: str, outcome: InternalOutcome, gates: FoldGateReport):
    return InterpretationBranchResult(
        branch_id=branch_id,
        evaluation=BranchEvaluation(internal_outcome=outcome, fold_gate_report=gates),
    )


def one_branch() -> InterpretationBranchResult:
    return branch(
        "branch-one",
        InternalOutcome.PROVEN_COMPLIANT,
        FoldGateReport(
            false_trigger_proven=True,
            vacuous_satisfaction_proven=True,
            vacuous_satisfaction_basis_id="basis-vacuous",
        ),
    )


def na_branch() -> InterpretationBranchResult:
    return branch(
        "branch-na",
        InternalOutcome.PROVEN_NOT_APPLICABLE,
        FoldGateReport(
            positive_non_applicability_proven=True,
            na_countercheck_passed=True,
        ),
    )


class FoldPolicyTests(unittest.TestCase):
    def test_one_na_tie_can_never_create_zero(self) -> None:
        envelope = InterpretationEnvelope(
            envelope_id="env-one-na",
            case_id="case-1",
            cp_id="CP6",
            accepted_branches=[one_branch(), na_branch()],
        )
        main = fold_envelope(
            envelope,
            mode=RunMode.SUBMISSION,
            one_na_policy=OneNaTiePolicy.PREFER_NA_APPLICABILITY,
        )
        research = fold_envelope(
            envelope,
            mode=RunMode.SUBMISSION,
            one_na_policy=OneNaTiePolicy.PREFER_ONE_NONVIOLATION,
        )
        self.assertEqual(main.label, FinalLabel.NOT_APPLICABLE)
        self.assertEqual(main.finality, Finality.ONE_NA_TIE_PREFER_NA)
        self.assertEqual(research.label, FinalLabel.COMPLIANT)
        self.assertEqual(research.finality, Finality.ONE_NA_TIE_PREFER_ONE)
        self.assertTrue(main.benchmark_fallback)
        self.assertNotEqual(main.label, FinalLabel.NON_COMPLIANT)
        self.assertNotEqual(research.label, FinalLabel.NON_COMPLIANT)

    def test_na_requires_positive_basis_and_countercheck(self) -> None:
        invalid = branch(
            "branch-na-invalid",
            InternalOutcome.PROVEN_NOT_APPLICABLE,
            FoldGateReport(positive_non_applicability_proven=True, na_countercheck_passed=False),
        )
        with self.assertRaises(FoldInvariantError):
            fold_branch(invalid)

    def test_not_demonstrated_is_disclosed_as_benchmark_fallback(self) -> None:
        result = fold_branch(
            branch(
                "branch-missing",
                InternalOutcome.NOT_DEMONSTRATED,
                FoldGateReport(
                    insufficient_evidence_benchmark_fallback_permitted=True,
                    burden_application_id="burden-1",
                ),
            )
        )
        self.assertEqual(result.label, FinalLabel.NON_COMPLIANT)
        self.assertEqual(result.finality, Finality.INSUFFICIENT_EVIDENCE_BENCHMARK_FALLBACK)
        self.assertTrue(result.benchmark_fallback)

    def test_no_valid_interpretation_blocks_diagnostic_and_forces_submission(self) -> None:
        invalid = one_branch().model_copy(
            update={"valid": False, "invalid_reason_codes": ["ANCHOR_NOT_CONFORMANT"]}
        )
        envelope = InterpretationEnvelope(
            envelope_id="env-invalid",
            case_id="case-1",
            cp_id="CP1",
            accepted_branches=[invalid],
        )
        with self.assertRaises(FoldInvariantError):
            fold_envelope(
                envelope,
                mode=RunMode.DIAGNOSTIC,
                one_na_policy=OneNaTiePolicy.PREFER_NA_APPLICABILITY,
            )
        forced = fold_envelope(
            envelope,
            mode=RunMode.SUBMISSION,
            one_na_policy=OneNaTiePolicy.PREFER_NA_APPLICABILITY,
        )
        self.assertTrue(forced.system_forced)
        self.assertEqual(forced.finality, Finality.SYSTEM_FORCED_FALLBACK)


class ConditionBoundaryTests(unittest.TestCase):
    def test_subrequirement_false_trigger_cannot_create_whole_cp_na(self) -> None:
        decision = ConditionStructureDecision(
            decision_id="condition-1",
            condition_proposition_id="condition-prop",
            condition_scope_class=ConditionScopeClass.SUBREQUIREMENT_TRIGGER,
            controlled_requirement_ids=["req-controlled"],
            residual_requirement_ids=["req-residual"],
            false_trigger_semantics=FalseTriggerSemantics.NOT_REACHED_SUBREQUIREMENT_ONLY,
            official_source_span_ids=["span-official"],
        )
        result = evaluate_false_trigger_eligibility(
            decision,
            ConditionTriggerEvidenceState.PROVEN_NOT_OCCURRED,
        )
        self.assertFalse(result.eligible_for_whole_cp_branch)
        self.assertIn("CONDITION_DOES_NOT_CONTROL_WHOLE_CP", result.reason_codes)
        self.assertIn("RESIDUAL_DECISIVE_REQUIREMENTS_REMAIN", result.reason_codes)

    def test_unknown_trigger_is_not_positive_nonoccurrence(self) -> None:
        decision = ConditionStructureDecision(
            decision_id="condition-2",
            condition_proposition_id="condition-prop",
            condition_scope_class=ConditionScopeClass.WHOLE_CP_TRIGGER,
            false_trigger_semantics=FalseTriggerSemantics.INTERPRETATION_OPEN,
            official_source_span_ids=["span-official"],
        )
        result = evaluate_false_trigger_eligibility(
            decision,
            ConditionTriggerEvidenceState.UNKNOWN,
        )
        self.assertFalse(result.eligible_for_whole_cp_branch)
        self.assertIn("FALSE_TRIGGER_NOT_POSITIVELY_PROVEN", result.reason_codes)


if __name__ == "__main__":
    unittest.main()
