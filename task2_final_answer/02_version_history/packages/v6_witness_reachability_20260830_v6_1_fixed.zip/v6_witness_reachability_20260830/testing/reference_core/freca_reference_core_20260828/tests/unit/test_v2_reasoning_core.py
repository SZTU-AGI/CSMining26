from __future__ import annotations

import unittest

from pydantic import ValidationError

from freca.argument.evaluator import ArgumentGraphEvaluation, evaluate_argument_graph
from freca.argument.indexed_shadow_evaluator import audit_indexed_shadow
from freca.argument.models import ArgumentGraphTemplate, PremiseRole, RequiredPolarity
from freca.argument.pipeline import run_dual_reasoning
from freca.argument.projection import project_argument_graph
from freca.logic.ast import ContractRoots, LogicDAG, LogicNode, LogicOperator
from freca.logic.evaluator import NonComparableOperatorError, evaluate_logic_dag
from freca.logic.four_valued import FourValuedState, all_of, any_of, if_then, negate
from freca.policy.graph_projection_conformance import audit_graph_projection
from freca.policy.indexed_requirement_view import build_indexed_requirement_view
from freca.policy.representation_capability import classify_representation_capability

ZERO_HASH = "sha256:" + ("0" * 64)


def atom(node_id: str, proposition_id: str, role: str = "OBSERVABLE_CASE_FACT") -> LogicNode:
    return LogicNode(
        node_id=node_id,
        operator=LogicOperator.ATOM,
        proposition_id=proposition_id,
        compile_rule_id="TEST.ATOM",
        semantic_role=role,
        source_span_ids=[f"span-{node_id}"],
    )


def ast_complete_dag() -> LogicDAG:
    nodes = [
        atom("app", "p-app", "LEGAL_APPLICABILITY"),
        atom("a", "p-a"),
        atom("b", "p-b"),
        atom("vio", "p-vio", "LEGAL_VIOLATION"),
        atom("na", "p-na", "LEGAL_NON_APPLICABILITY"),
        LogicNode(
            node_id="sat",
            operator=LogicOperator.ALL_OF,
            child_ids=["a", "b"],
            compile_rule_id="TEST.ALL",
            semantic_role="LEGAL_SATISFACTION",
            source_span_ids=["span-and"],
        ),
    ]
    return LogicDAG(
        interpretation_id="interpretation-main",
        nodes=nodes,
        roots=ContractRoots(
            applicability_root_id="app",
            satisfaction_root_id="sat",
            violation_root_id="vio",
            non_applicability_root_id="na",
        ),
    )


def exception_dag() -> LogicDAG:
    nodes = [
        atom("app", "p-app", "LEGAL_APPLICABILITY"),
        atom("main", "p-main"),
        atom("exc", "p-exc"),
        atom("vio", "p-vio", "LEGAL_VIOLATION"),
        atom("na", "p-na", "LEGAL_NON_APPLICABILITY"),
        LogicNode(
            node_id="sat-exception",
            operator=LogicOperator.EXCEPTION_GATE,
            child_ids=["main", "exc"],
            compile_rule_id="TEST.EXCEPTION",
            semantic_role="LEGAL_SATISFACTION",
            source_span_ids=["span-unless"],
        ),
    ]
    return LogicDAG(
        interpretation_id="interpretation-exception",
        nodes=nodes,
        roots=ContractRoots(
            applicability_root_id="app",
            satisfaction_root_id="sat-exception",
            violation_root_id="vio",
            non_applicability_root_id="na",
        ),
    )


class FourValuedLogicTests(unittest.TestCase):
    def test_frozen_pair_truth_tables_preserve_conflict(self) -> None:
        self.assertEqual(negate(FourValuedState.BOTH), FourValuedState.BOTH)
        self.assertEqual(
            all_of([FourValuedState.TRUE, FourValuedState.BOTH]),
            FourValuedState.BOTH,
        )
        self.assertEqual(
            any_of([FourValuedState.TRUE, FourValuedState.FALSE]),
            FourValuedState.TRUE,
        )
        self.assertEqual(
            if_then(FourValuedState.FALSE, FourValuedState.UNKNOWN),
            FourValuedState.TRUE,
        )

    def test_logic_node_arity_and_dag_cycle_are_hard_failures(self) -> None:
        with self.assertRaises(ValidationError):
            LogicNode(
                node_id="bad-not",
                operator=LogicOperator.NOT,
                child_ids=["a", "b"],
                compile_rule_id="TEST.BAD",
            )
        with self.assertRaises(ValidationError):
            LogicDAG(
                interpretation_id="cycle",
                nodes=[
                    LogicNode(
                        node_id="x",
                        operator=LogicOperator.NOT,
                        child_ids=["y"],
                        compile_rule_id="TEST.CYCLE",
                    ),
                    LogicNode(
                        node_id="y",
                        operator=LogicOperator.NOT,
                        child_ids=["x"],
                        compile_rule_id="TEST.CYCLE",
                    ),
                ],
                roots=ContractRoots(
                    applicability_root_id="x",
                    satisfaction_root_id="x",
                    violation_root_id="y",
                    non_applicability_root_id="y",
                ),
            )


class DualRepresentationTests(unittest.TestCase):
    def build(self, dag: LogicDAG):
        view = build_indexed_requirement_view(dag, proposition_catalog_sha256=ZERO_HASH)
        graph = project_argument_graph(view, logic_roots=dag.roots)
        return view, graph

    def test_ast_complete_projection_and_shadow_full_match(self) -> None:
        dag = ast_complete_dag()
        view, graph = self.build(dag)
        projection = audit_graph_projection(view, graph)
        self.assertTrue(projection.exact_projection_passed)

        states = {
            "p-app": FourValuedState.TRUE,
            "p-a": FourValuedState.TRUE,
            "p-b": FourValuedState.BOTH,
            "p-vio": FourValuedState.FALSE,
            "p-na": FourValuedState.FALSE,
        }
        graph_result = evaluate_argument_graph(graph, states)
        capability = classify_representation_capability(dag, contract_id="contract-1")
        self.assertEqual(capability.required_execution_mode, "AST_COMPLETE_DUAL_AUDIT")
        report = audit_indexed_shadow(
            case_uid="case-1",
            cp_id="CP1",
            view=view,
            dag=dag,
            graph=graph,
            graph_evaluation=graph_result,
            capability=capability,
            atom_states=states,
        )
        self.assertEqual(report.comparison_status, "FULL_MATCH")
        self.assertEqual(report.mismatch_root_ids, [])

    def test_exception_root_is_graph_required_and_never_full_match(self) -> None:
        dag = exception_dag()
        view, graph = self.build(dag)
        capability = classify_representation_capability(dag, contract_id="contract-exception")
        self.assertTrue(capability.contains_nonreducible_exception)
        self.assertFalse(capability.indexed_ast_complete)
        self.assertEqual(capability.required_execution_mode, "GRAPH_REQUIRED_SHADOW_PARTIAL")
        self.assertEqual(capability.shadow_noncomparable_root_ids, ["sat-exception"])

        states = {
            "p-app": FourValuedState.TRUE,
            "p-main": FourValuedState.TRUE,
            "p-exc": FourValuedState.FALSE,
            "p-vio": FourValuedState.FALSE,
            "p-na": FourValuedState.FALSE,
        }
        with self.assertRaises(NonComparableOperatorError):
            evaluate_logic_dag(dag, states)
        graph_result = evaluate_argument_graph(graph, states)
        report = audit_indexed_shadow(
            case_uid="case-1",
            cp_id="CP6",
            view=view,
            dag=dag,
            graph=graph,
            graph_evaluation=graph_result,
            capability=capability,
            atom_states=states,
        )
        self.assertEqual(report.comparison_status, "PARTIAL_MATCH")
        self.assertNotIn("sat-exception", report.shadow_root_states)

    def test_boolean_lowering_of_exception_is_detected_by_projection_gate(self) -> None:
        dag = exception_dag()
        view, graph = self.build(dag)
        target = next(
            argument
            for argument in graph.argument_nodes
            if argument.conclusion_statement_id == "stmt-sat-exception"
        )
        lowered_premises = [
            premise.model_copy(
                update={
                    "premise_role": PremiseRole.ORDINARY,
                    "required_polarity": (
                        RequiredPolarity.NEGATIVE
                        if premise.statement_id == "stmt-exc"
                        else premise.required_polarity
                    ),
                }
            )
            for premise in target.premises
        ]
        mutated_arguments = [
            argument.model_copy(update={"premises": lowered_premises})
            if argument.argument_id == target.argument_id
            else argument
            for argument in graph.argument_nodes
        ]
        lowered = ArgumentGraphTemplate.model_validate(
            graph.model_copy(update={"argument_nodes": mutated_arguments}).model_dump(mode="json")
        )
        report = audit_graph_projection(view, lowered)
        self.assertFalse(report.exact_projection_passed)
        self.assertIn("sat-exception", report.premise_role_mismatch_ids)
        self.assertIn("sat-exception", report.polarity_mismatch_ids)

    def test_shadow_mismatch_is_a_hard_distinct_status(self) -> None:
        dag = ast_complete_dag()
        view, graph = self.build(dag)
        states = {
            "p-app": FourValuedState.TRUE,
            "p-a": FourValuedState.TRUE,
            "p-b": FourValuedState.TRUE,
            "p-vio": FourValuedState.FALSE,
            "p-na": FourValuedState.FALSE,
        }
        graph_result = evaluate_argument_graph(graph, states)
        sat_statement = graph.root_statement_ids["satisfaction"]
        corrupted = ArgumentGraphEvaluation(
            interpretation_id=graph_result.interpretation_id,
            statement_states=graph_result.statement_states,
            root_states={**graph_result.root_states, sat_statement: FourValuedState.FALSE},
        )
        capability = classify_representation_capability(dag, contract_id="contract-1")
        report = audit_indexed_shadow(
            case_uid="case-1",
            cp_id="CP1",
            view=view,
            dag=dag,
            graph=graph,
            graph_evaluation=corrupted,
            capability=capability,
            atom_states=states,
        )
        self.assertEqual(report.comparison_status, "MISMATCH")
        self.assertEqual(report.mismatch_root_ids, ["sat"])

    def test_guarded_pipeline_runs_every_gate_in_dependency_order(self) -> None:
        dag = exception_dag()
        bundle = run_dual_reasoning(
            case_uid="case-1",
            cp_id="CP6",
            contract_id="contract-6",
            logic_dag=dag,
            proposition_catalog_sha256=ZERO_HASH,
            atom_states={
                "p-app": FourValuedState.TRUE,
                "p-main": FourValuedState.TRUE,
                "p-exc": FourValuedState.FALSE,
                "p-vio": FourValuedState.FALSE,
                "p-na": FourValuedState.FALSE,
            },
        )
        self.assertTrue(bundle.projection_conformance.exact_projection_passed)
        self.assertEqual(bundle.evaluator_agreement.status, "PASS")
        self.assertEqual(
            bundle.indexed_shadow_evaluation.comparison_status,
            "PARTIAL_MATCH",
        )
        self.assertEqual(
            bundle.representation_capability.required_execution_mode,
            "GRAPH_REQUIRED_SHADOW_PARTIAL",
        )


if __name__ == "__main__":
    unittest.main()
