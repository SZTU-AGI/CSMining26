"""Fail-closed input whitelist and cross-environment source catalog."""

from __future__ import annotations

import hashlib
from datetime import UTC, datetime
from pathlib import Path
from typing import Literal

from pydantic import Field, model_validator

from freca.domain.models import SafeId, Sha256, StrictModel
from freca.governance.config import RunConfig
from freca.governance.hashing import sha256_digest

SourceRole = Literal[
    "RULES_PDF",
    "CP_DEFINITIONS",
    "CASE_EVIDENCE",
    "TASK_GOVERNANCE",
    "OUTPUT_SCHEMA",
]

MIME_BY_EXTENSION = {
    ".pdf": "application/pdf",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
}


class SourceRef(StrictModel):
    source_id: SafeId
    role: SourceRole
    decision_visibility: Literal["NORMATIVE", "FACTUAL", "NON_DECISION"]
    allowed_consumers: list[str]
    canonical_path: str
    sha256: Sha256
    relative_path: str
    size_bytes: int = Field(ge=0)
    mtime_ns: int = Field(ge=0)
    extension: str
    mime_type: str


class IgnoredSource(StrictModel):
    relative_path: str
    reason: Literal["MACOS_METADATA", "EXPLICIT_IGNORE"]
    size_bytes: int = Field(ge=0)


class SourceCatalog(StrictModel):
    schema_version: Literal["freca.source-catalog.v1"] = "freca.source-catalog.v1"
    catalog_id: SafeId
    rules_pdf: SourceRef
    cp_definitions: SourceRef
    evidence: list[SourceRef]
    task_governance: SourceRef | None = None
    output_schema: SourceRef | None = None
    ignored: list[IgnoredSource] = Field(default_factory=list)
    evidence_manifest_sha256: Sha256
    catalog_sha256: Sha256
    created_at: datetime

    @model_validator(mode="after")
    def enforce_roles_and_uniqueness(self) -> SourceCatalog:
        if self.rules_pdf.role != "RULES_PDF" or self.rules_pdf.decision_visibility != "NORMATIVE":
            raise ValueError("rules_pdf must be the normative Rules source")
        if self.cp_definitions.role != "CP_DEFINITIONS":
            raise ValueError("cp_definitions has the wrong role")
        if any(
            item.role != "CASE_EVIDENCE" or item.decision_visibility != "FACTUAL"
            for item in self.evidence
        ):
            raise ValueError("evidence catalog can contain only factual CASE_EVIDENCE")
        optional = [item for item in (self.task_governance, self.output_schema) if item]
        if any(item.decision_visibility != "NON_DECISION" for item in optional):
            raise ValueError("task governance and output schema must be NON_DECISION")
        all_sources = [self.rules_pdf, self.cp_definitions, *self.evidence, *optional]
        if len({item.source_id for item in all_sources}) != len(all_sources):
            raise ValueError("source IDs must be unique")
        if len({item.relative_path for item in all_sources}) != len(all_sources):
            raise ValueError("source relative paths must be unique")
        if self.created_at.tzinfo is None:
            raise ValueError("catalog timestamp must be timezone-aware")
        return self


class SourceIntegrityReport(StrictModel):
    catalog_id: SafeId
    checked_source_ids: list[SafeId]
    changed_source_ids: list[SafeId]
    missing_source_ids: list[SafeId]
    status: Literal["UNCHANGED", "RUN_INVALID"]


class SourceGuardError(ValueError):
    pass


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return f"sha256:{digest.hexdigest()}"


def _source_id(role: str, relative_path: str, digest: str) -> str:
    stable = sha256_digest({"role": role, "relative_path": relative_path, "sha256": digest})
    return f"source-{stable.split(':', 1)[1][:20]}"


def evidence_manifest_digest(evidence: list[SourceRef]) -> str:
    """Hash the frozen tab-delimited manifest, independent of machine paths."""
    lines = [
        f"{item.relative_path}\t{item.size_bytes}\t{item.sha256.removeprefix('sha256:').lower()}"
        for item in sorted(evidence, key=lambda source: source.relative_path)
    ]
    return f"sha256:{hashlib.sha256(chr(10).join(lines).encode('utf-8')).hexdigest()}"


def _ref(
    path: Path,
    *,
    identity_root: Path,
    role: SourceRole,
    visibility: Literal["NORMATIVE", "FACTUAL", "NON_DECISION"],
    consumers: list[str],
) -> SourceRef:
    if not path.is_file():
        raise SourceGuardError(f"required source is not a file: {path}")
    stat = path.stat()
    relative = path.relative_to(identity_root).as_posix()
    digest = _file_sha256(path)
    extension = path.suffix.lower()
    try:
        mime_type = MIME_BY_EXTENSION[extension]
    except KeyError as error:
        raise SourceGuardError(f"unsupported source extension: {relative}") from error
    return SourceRef(
        source_id=_source_id(role, relative, digest),
        role=role,
        decision_visibility=visibility,
        allowed_consumers=consumers,
        canonical_path=str(path),
        sha256=digest,
        relative_path=relative,
        size_bytes=stat.st_size,
        mtime_ns=stat.st_mtime_ns,
        extension=extension,
        mime_type=mime_type,
    )


class FileSystemSourceGuard:
    def validate(self, config: RunConfig) -> SourceCatalog:
        task_root = Path(config.inputs.task_root).resolve()
        if not task_root.is_dir():
            raise SourceGuardError(f"task_root is not a directory: {task_root}")

        def resolve(value: str) -> Path:
            path = Path(value)
            result = (task_root / path).resolve() if not path.is_absolute() else path.resolve()
            if not result.is_relative_to(task_root):
                raise SourceGuardError(f"source escapes task_root: {value}")
            return result

        rules_path = resolve(config.inputs.rules_pdf)
        cp_path = resolve(config.inputs.official_cp_xlsx)
        case_root = resolve(config.inputs.case_root)
        if rules_path.suffix.lower() != ".pdf" or cp_path.suffix.lower() != ".xlsx":
            raise SourceGuardError("Rules must be PDF and official CP definitions must be XLSX")
        rules = _ref(
            rules_path,
            identity_root=task_root,
            role="RULES_PDF",
            visibility="NORMATIVE",
            consumers=["LAYER1", "LAYER2", "TEAM_B_POLICY"],
        )
        cp = _ref(
            cp_path,
            identity_root=task_root,
            role="CP_DEFINITIONS",
            visibility="NORMATIVE",
            consumers=["LAYER2", "TEAM_B_POLICY"],
        )
        if rules.sha256 != config.expected.rules_pdf_sha256:
            raise SourceGuardError("L0_HASH_MISMATCH: Rules PDF")
        if cp.sha256 != config.expected.cp_xlsx_sha256:
            raise SourceGuardError("L0_HASH_MISMATCH: official CP XLSX")

        evidence: list[SourceRef] = []
        ignored: list[IgnoredSource] = []
        if not case_root.is_dir():
            raise SourceGuardError(f"case_root is not a directory: {case_root}")
        for path in sorted(case_root.rglob("*"), key=lambda item: item.as_posix().casefold()):
            if not path.is_file():
                continue
            relative = path.relative_to(case_root).as_posix()
            if path.name == ".DS_Store" or "__MACOSX" in path.parts:
                ignored.append(
                    IgnoredSource(
                        relative_path=relative,
                        reason="MACOS_METADATA",
                        size_bytes=path.stat().st_size,
                    )
                )
                continue
            if path.suffix.lower() not in config.expected.allowed_evidence_extensions:
                raise SourceGuardError(f"L0_UNKNOWN_EVIDENCE_EXTENSION: {relative}")
            evidence.append(
                _ref(
                    path,
                    identity_root=case_root,
                    role="CASE_EVIDENCE",
                    visibility="FACTUAL",
                    consumers=["LAYER3", "LAYER4", "LAYER5", "LAYER6", "LAYER7", "TEAM_B_EVIDENCE"],
                )
            )
        if len(evidence) != config.expected.evidence_file_count:
            raise SourceGuardError(
                f"L0_EVIDENCE_COUNT_MISMATCH: expected {config.expected.evidence_file_count}, "
                f"got {len(evidence)}"
            )

        evidence_hash = evidence_manifest_digest(evidence)
        if evidence_hash != config.expected.evidence_manifest_sha256:
            raise SourceGuardError("L0_HASH_MISMATCH: evidence manifest")

        task_governance = (
            _ref(
                resolve(config.inputs.task_governance),
                identity_root=task_root,
                role="TASK_GOVERNANCE",
                visibility="NON_DECISION",
                consumers=["LAYER0"],
            )
            if config.inputs.task_governance
            else None
        )
        if (
            task_governance
            and config.expected.task_governance_sha256
            and task_governance.sha256 != config.expected.task_governance_sha256
        ):
            raise SourceGuardError("L0_HASH_MISMATCH: task governance")
        output_schema = (
            _ref(
                resolve(config.inputs.submission_template),
                identity_root=task_root,
                role="OUTPUT_SCHEMA",
                visibility="NON_DECISION",
                consumers=["LAYER11"],
            )
            if config.inputs.submission_template
            else None
        )
        if (
            output_schema
            and config.expected.submission_template_sha256
            and output_schema.sha256 != config.expected.submission_template_sha256
        ):
            raise SourceGuardError("L0_HASH_MISMATCH: submission template")
        cross_environment_payload = {
            "rules_pdf": _portable(rules),
            "cp_definitions": _portable(cp),
            "evidence": [_portable(item) for item in evidence],
            "task_governance": _portable(task_governance) if task_governance else None,
            "output_schema": _portable(output_schema) if output_schema else None,
            "ignored": [item.model_dump(mode="json") for item in ignored],
            "evidence_manifest_sha256": evidence_hash,
        }
        catalog_hash = sha256_digest(cross_environment_payload)
        return SourceCatalog(
            catalog_id=f"sources-{catalog_hash.split(':', 1)[1][:12]}",
            rules_pdf=rules,
            cp_definitions=cp,
            evidence=evidence,
            task_governance=task_governance,
            output_schema=output_schema,
            ignored=ignored,
            evidence_manifest_sha256=evidence_hash,
            catalog_sha256=catalog_hash,
            created_at=datetime.now(UTC),
        )

    def verify_unchanged(self, catalog: SourceCatalog) -> SourceIntegrityReport:
        sources = [catalog.rules_pdf, catalog.cp_definitions, *catalog.evidence]
        sources.extend(item for item in (catalog.task_governance, catalog.output_schema) if item)
        changed: list[str] = []
        missing: list[str] = []
        checked: list[str] = []
        for source in sources:
            path = Path(source.canonical_path)
            if not path.is_file():
                missing.append(source.source_id)
                continue
            checked.append(source.source_id)
            if _file_sha256(path) != source.sha256:
                changed.append(source.source_id)
        return SourceIntegrityReport(
            catalog_id=catalog.catalog_id,
            checked_source_ids=sorted(checked),
            changed_source_ids=sorted(changed),
            missing_source_ids=sorted(missing),
            status="UNCHANGED" if not changed and not missing else "RUN_INVALID",
        )


def _portable(source: SourceRef) -> dict:
    return source.model_dump(
        mode="json",
        exclude={"canonical_path", "mtime_ns"},
    )
