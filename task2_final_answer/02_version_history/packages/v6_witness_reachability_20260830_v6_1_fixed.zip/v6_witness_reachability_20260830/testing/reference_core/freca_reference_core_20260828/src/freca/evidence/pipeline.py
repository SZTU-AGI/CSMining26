"""E0-E3: build a case's complete evidence set from its manifest entry.

Pipeline per document::

    read (docx|xlsx) -> segment -> extract identity anchors
                     -> resolve against the case reference -> decide admissibility
                     -> emit evidence atoms carrying that identity

Inadmissible documents are **kept, not deleted**. A verdict that rests on absent
evidence has to be able to say *why* it is absent — "the only pest-control record
in this case is signed by another registered establishment" is an auditable
finding, whereas an empty evidence set is indistinguishable from a parser bug.
The admissible/inadmissible split is therefore recorded explicitly and both sets
are persisted.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from freca.domain.models import EvidenceAtom
from freca.evidence.admissibility import Admissibility, IdentityPolicy, decide_admissibility
from freca.evidence.atoms import build_docx_atoms, build_xlsx_atoms
from freca.evidence.docx_reader import DocxParseError, read_docx
from freca.evidence.identity import (
    IdentityAnchors,
    IdentityReference,
    extract_anchors_docx,
    extract_anchors_xlsx,
    resolve_identity,
)
from freca.evidence.segment import segment_document
from freca.evidence.xlsx_reader import XlsxParseError, read_xlsx
from freca.manifest.build import CaseFile, LogicalCase


@dataclass(slots=True)
class DocumentEvidence:
    track: str
    path: str
    file_name: str
    doc_type: str
    anchors: IdentityAnchors
    admissibility: Admissibility
    atoms: list[EvidenceAtom] = field(default_factory=list)
    section_headings: list[str] = field(default_factory=list)
    parse_error: str | None = None

    def to_dict(self) -> dict[str, object]:
        return {
            "track": self.track,
            "path": self.path,
            "file_name": self.file_name,
            "doc_type": self.doc_type,
            "identity": self.admissibility.state.value,
            "admissibility": self.admissibility.to_dict(),
            "anchors": self.anchors.to_dict(),
            "section_headings": self.section_headings,
            "n_atoms": len(self.atoms),
            "parse_error": self.parse_error,
        }


@dataclass(slots=True)
class CaseEvidence:
    case_id: str
    reference: IdentityReference
    policy: IdentityPolicy
    documents: list[DocumentEvidence] = field(default_factory=list)
    missing_tracks: list[str] = field(default_factory=list)

    @property
    def admissible_atoms(self) -> list[EvidenceAtom]:
        return [
            atom
            for document in self.documents
            if document.admissibility.admissible
            for atom in document.atoms
        ]

    @property
    def inadmissible_atoms(self) -> list[EvidenceAtom]:
        return [
            atom
            for document in self.documents
            if not document.admissibility.admissible
            for atom in document.atoms
        ]

    @property
    def excluded_tracks(self) -> list[str]:
        return sorted(
            document.track for document in self.documents if not document.admissibility.admissible
        )

    def to_dict(self) -> dict[str, object]:
        return {
            "case_id": self.case_id,
            "reference": {
                "establishment": self.reference.establishment,
                "re_number": self.reference.re_number,
                "serial": self.reference.serial,
            },
            "identity_policy": self.policy.value,
            "missing_tracks": self.missing_tracks,
            "excluded_tracks": self.excluded_tracks,
            "n_admissible_atoms": len(self.admissible_atoms),
            "n_inadmissible_atoms": len(self.inadmissible_atoms),
            "documents": [document.to_dict() for document in self.documents],
        }


def _process_document(
    case_id: str,
    case_file: CaseFile,
    reference: IdentityReference,
    policy: IdentityPolicy,
) -> DocumentEvidence:
    is_docx = case_file.path.lower().endswith(".docx")
    try:
        if is_docx:
            document = read_docx(case_file.path)
            anchors = extract_anchors_docx(document)
        else:
            document = read_xlsx(case_file.path)
            anchors = extract_anchors_xlsx(document)
    except (DocxParseError, XlsxParseError) as error:
        anchors = IdentityAnchors()
        assessment = resolve_identity(anchors, reference)
        return DocumentEvidence(
            track=case_file.track,
            path=case_file.path,
            file_name=case_file.file_name,
            doc_type=case_file.doc_type,
            anchors=anchors,
            admissibility=decide_admissibility(assessment, anchors, reference, policy),
            parse_error=str(error),
        )

    assessment = resolve_identity(anchors, reference)
    admissibility = decide_admissibility(assessment, anchors, reference, policy)

    if is_docx:
        sections = segment_document(document)
        atoms = build_docx_atoms(
            case_id=case_id,
            track=case_file.track,
            document=document,
            sections=sections,
            identity=assessment,
        )
        headings = [section.heading for section in sections if section.heading]
    else:
        atoms = build_xlsx_atoms(
            case_id=case_id,
            track=case_file.track,
            document=document,
            identity=assessment,
        )
        headings = [sheet.sheet_name for sheet in document.sheets]

    return DocumentEvidence(
        track=case_file.track,
        path=case_file.path,
        file_name=case_file.file_name,
        doc_type=case_file.doc_type,
        anchors=anchors,
        admissibility=admissibility,
        atoms=atoms,
        section_headings=headings,
    )


def build_case_evidence(
    case: LogicalCase,
    *,
    policy: IdentityPolicy = IdentityPolicy.DIFFERENTIATED,
) -> CaseEvidence:
    """Parse every file of one logical case into identity-tagged evidence atoms."""

    reference = IdentityReference(
        establishment=case.declared_establishment,
        re_number=case.re_number,
        serial=case.declared_serial,
    )
    evidence = CaseEvidence(
        case_id=case.case_id,
        reference=reference,
        policy=policy,
        missing_tracks=list(case.missing_tracks),
    )
    for case_file in sorted(case.files, key=lambda f: f.track):
        evidence.documents.append(_process_document(case.case_id, case_file, reference, policy))
    return evidence
