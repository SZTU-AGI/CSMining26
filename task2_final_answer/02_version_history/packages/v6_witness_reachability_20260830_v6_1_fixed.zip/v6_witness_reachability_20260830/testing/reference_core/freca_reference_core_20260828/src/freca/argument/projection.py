"""Deterministic IndexedRequirementView -> FRECA-CAES-DAG-v1 projection."""

from __future__ import annotations

from freca.argument.models import (
    ArgumentDirection,
    ArgumentGraphTemplate,
    ArgumentPremiseTemplate,
    ArgumentTemplate,
    PremiseRole,
    RequiredPolarity,
    StatementTemplate,
)
from freca.logic.ast import ContractRoots, LogicOperator
from freca.policy.indexed_requirement_view import IndexedRequirementRow, IndexedRequirementView


def _statement_id(logic_node_id: str) -> str:
    result = f"stmt-{logic_node_id}"
    if len(result) > 128:
        raise ValueError(f"logic node ID too long for projected statement ID: {logic_node_id}")
    return result


def _argument_id(logic_node_id: str, index: int) -> str:
    result = f"arg-{logic_node_id}-{index}"
    if len(result) > 128:
        raise ValueError(f"logic node ID too long for projected argument ID: {logic_node_id}")
    return result


def _ordinary(row_id: str, polarity: RequiredPolarity) -> ArgumentPremiseTemplate:
    return ArgumentPremiseTemplate(
        statement_id=_statement_id(row_id.removeprefix("row-")),
        premise_role=PremiseRole.ORDINARY,
        required_polarity=polarity,
    )


def _arguments_for_row(row: IndexedRequirementRow) -> list[ArgumentTemplate]:
    if row.operator is LogicOperator.ATOM:
        return []

    children = row.ordered_child_row_ids
    premise_sets: list[list[ArgumentPremiseTemplate]]
    if row.operator is LogicOperator.ALL_OF:
        premise_sets = [[_ordinary(child, RequiredPolarity.POSITIVE) for child in children]]
    elif row.operator is LogicOperator.ANY_OF:
        premise_sets = [[_ordinary(child, RequiredPolarity.POSITIVE)] for child in children]
    elif row.operator is LogicOperator.NOT:
        premise_sets = [[_ordinary(children[0], RequiredPolarity.NEGATIVE)]]
    elif row.operator is LogicOperator.IF_THEN:
        premise_sets = [
            [_ordinary(children[0], RequiredPolarity.NEGATIVE)],
            [_ordinary(children[1], RequiredPolarity.POSITIVE)],
        ]
    elif row.operator in {LogicOperator.UNLESS, LogicOperator.EXCEPTION_GATE}:
        premises = [_ordinary(children[0], RequiredPolarity.POSITIVE)]
        premises.extend(
            ArgumentPremiseTemplate(
                statement_id=_statement_id(child.removeprefix("row-")),
                premise_role=PremiseRole.EXCEPTION,
                required_polarity=RequiredPolarity.POSITIVE,
            )
            for child in children[1:]
        )
        premise_sets = [premises]
    else:  # pragma: no cover - enum exhaustiveness guard
        raise ValueError(f"unsupported logic operator: {row.operator}")

    scheme = (
        "EXPLICIT_EXCEPTION"
        if row.operator in {LogicOperator.UNLESS, LogicOperator.EXCEPTION_GATE}
        else "RULE_APPLICATION"
    )
    return [
        ArgumentTemplate(
            argument_id=_argument_id(row.logic_node_id, index),
            scheme=scheme,
            premises=premises,
            conclusion_statement_id=_statement_id(row.logic_node_id),
            direction=ArgumentDirection.PRO,
            source_span_ids=row.source_span_ids,
        )
        for index, premises in enumerate(premise_sets)
    ]


def project_argument_graph(
    view: IndexedRequirementView,
    *,
    logic_roots: ContractRoots,
    proof_standard_id: str = "proof-standard-default",
    burden_rule_id: str = "burden-rule-default",
) -> ArgumentGraphTemplate:
    statements = []
    arguments = []
    for row in view.rows:
        statements.append(
            StatementTemplate(
                statement_id=_statement_id(row.logic_node_id),
                logic_node_id=row.logic_node_id,
                proposition_id=row.proposition_id,
                semantic_role=row.semantic_role,
                logic_operator=row.operator,
                direct_alignment_policy=(
                    "ALLOW_OBSERVABLE_ONLY"
                    if row.operator is LogicOperator.ATOM
                    and row.semantic_role == "OBSERVABLE_CASE_FACT"
                    else "FORBID"
                ),
                proof_standard_id=proof_standard_id,
                burden_rule_id=burden_rule_id,
                source_span_ids=row.source_span_ids,
            )
        )
        arguments.extend(_arguments_for_row(row))

    row_by_id = {row.row_id: row for row in view.rows}
    root_statements = {
        name: _statement_id(row_by_id[row_id].logic_node_id)
        for name, row_id in view.root_row_ids.items()
    }
    return ArgumentGraphTemplate(
        statement_nodes=statements,
        argument_nodes=arguments,
        logic_roots=logic_roots,
        root_statement_ids=root_statements,
        interpretation_id=view.interpretation_id,
        indexed_requirement_view_id=view.view_id,
    )
