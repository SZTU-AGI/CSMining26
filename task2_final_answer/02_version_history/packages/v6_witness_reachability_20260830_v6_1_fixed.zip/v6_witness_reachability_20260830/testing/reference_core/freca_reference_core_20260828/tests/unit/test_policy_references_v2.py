from __future__ import annotations

import unittest

from freca.policy.references import extract_reference_mentions
from freca.policy.schemas_v2 import PolicyLocator, PolicySpanSegment, PolicyUnit, PolicyUnitType

HASH = "sha256:" + "1" * 64
LOCATOR = PolicyLocator(
    segments=[
        PolicySpanSegment(
            physical_page=1,
            page_line_start=1,
            page_line_end=1,
            raw_char_start=0,
            raw_char_end=100,
        )
    ]
)


def unit(citation: str, text: str, *, parent: str | None = None) -> PolicyUnit:
    safe = "rules-" + citation.replace("(", "-").replace(")", "").replace(":", "-")
    return PolicyUnit(
        unit_id=safe,
        citation=citation,
        unit_type=PolicyUnitType.SECTION if "(" not in citation else PolicyUnitType.SUBSECTION,
        own_raw_text=text,
        full_raw_text=text,
        normalized_text=" ".join(text.split()),
        locator=LOCATOR,
        parent_id=parent,
        normative=True,
        source_pdf_sha256=HASH,
        unit_sha256=HASH,
    )


class PolicyReferenceV2Tests(unittest.TestCase):
    def test_external_act_is_never_resolved_to_internal_rule(self) -> None:
        source = unit(
            "4-7A",
            "See paragraph 145(1)(b) of the Act and section 1-7 of this instrument.",
        )
        internal = unit("1-7", "Internal target")
        mentions = extract_reference_mentions([source, internal])
        statuses = [target.resolution_status for item in mentions for target in item.targets]
        self.assertIn("EXTERNAL_NOT_FOLLOWED", statuses)
        self.assertIn("RESOLVED", statuses)
        external = next(
            target
            for item in mentions
            for target in item.targets
            if target.resolution_status == "EXTERNAL_NOT_FOLLOWED"
        )
        self.assertIsNone(external.target_unit_id)

    def test_relative_subsection_resolves_inside_current_section(self) -> None:
        section = unit("4-7A", "Section")
        subsection = unit("4-7A(1)", "Target", parent=section.unit_id)
        source = unit(
            "4-7A(2)",
            "Without limiting subsection (1), further requirements apply.",
            parent=section.unit_id,
        )
        mentions = extract_reference_mentions([section, subsection, source])
        target = mentions[0].targets[0]
        self.assertEqual(target.target_unit_id, subsection.unit_id)


if __name__ == "__main__":
    unittest.main()
