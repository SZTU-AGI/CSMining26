"""One canonical hashing implementation for every reproducibility boundary."""

from __future__ import annotations

import hashlib
import json
import math
from collections.abc import Mapping, Sequence, Set
from datetime import UTC, datetime
from enum import Enum
from pathlib import Path
from typing import Any

from pydantic import BaseModel


def normalize_for_hash(value: Any) -> Any:
    """Convert supported values into a deterministic, JSON-safe structure."""
    if isinstance(value, BaseModel):
        return normalize_for_hash(value.model_dump(mode="python"))
    if isinstance(value, Enum):
        return normalize_for_hash(value.value)
    if isinstance(value, Path):
        return value.as_posix()
    if isinstance(value, datetime):
        if value.tzinfo is None:
            raise ValueError("naive datetime cannot enter a reproducibility hash")
        return value.astimezone(UTC).isoformat()
    if isinstance(value, Mapping):
        return {str(key): normalize_for_hash(item) for key, item in value.items()}
    if isinstance(value, Set) and not isinstance(value, (str, bytes, bytearray)):
        normalized = [normalize_for_hash(item) for item in value]
        return sorted(normalized, key=canonical_json_bytes)
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        return [normalize_for_hash(item) for item in value]
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("NaN and Infinity cannot enter a reproducibility hash")
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    raise TypeError(f"unsupported hash value: {type(value).__name__}")


def canonical_json_bytes(value: Any) -> bytes:
    return json.dumps(
        normalize_for_hash(value),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def sha256_bytes(data: bytes) -> str:
    return f"sha256:{hashlib.sha256(data).hexdigest()}"


def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return f"sha256:{digest.hexdigest()}"


def sha256_digest(value: Any) -> str:
    return sha256_bytes(canonical_json_bytes(value))


def hash_directory_manifest(rows: Sequence[Mapping[str, Any]]) -> str:
    """Hash already-normalized logical manifest rows in deterministic order."""
    normalized = [normalize_for_hash(row) for row in rows]
    normalized.sort(key=canonical_json_bytes)
    return sha256_digest(normalized)
