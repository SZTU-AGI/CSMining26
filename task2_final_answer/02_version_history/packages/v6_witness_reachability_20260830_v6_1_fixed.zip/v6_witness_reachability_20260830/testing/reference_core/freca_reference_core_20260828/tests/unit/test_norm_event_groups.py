from __future__ import annotations

import unittest

from freca.logic.ast import LogicOperator
from freca.policy.contract_slice import ContractSliceStatus, compile_contract_slice
from freca.policy.norm_events import (
    NormModality,
    NormSpanRole,
    RuleSetRelation,
    build_norm_event_bundle,
)
from freca.policy.schemas_v2 import PolicyUnitType
from tests.unit.test_contract_slice import _candidate, _ledger, _policy, _unit


def _enum_policy(connector_text: str):
    policy = _policy()
    chapeau = _unit(
        "rules2021.section-7.3",
        f"(3) A treatment record must contain {connector_text}:",
        unit_type=PolicyUnitType.SUBSECTION,
        parent_id="rules2021.section-7",
    )
    first = _unit(
        "rules2021.section-7.3.a",
        "(a) the treatment date;",
        parent_id=chapeau.unit_id,
    )
    second = _unit(
        "rules2021.section-7.3.b",
        "(b) the operator name.",
        parent_id=chapeau.unit_id,
    )
    chapeau.child_ids = [first.unit_id, second.unit_id]
    policy.units.extend([chapeau, first, second])
    return policy, chapeau, first, second


class NormEventGroupTest(unittest.TestCase):
    def test_explicit_all_of_chapeau_creates_grounded_event_group(self) -> None:
        policy, chapeau, first, second = _enum_policy("all of the following")

        bundle = build_norm_event_bundle(
            cp_id="CP1",
            policy=policy,
            policy_unit_ids=[first.unit_id, second.unit_id],
            relation_by_unit_id={
                first.unit_id: "PRIMARY_NORM",
                second.unit_id: "PRIMARY_NORM",
            },
        )

        self.assertEqual(bundle.review_required_reason_codes, [])
        self.assertEqual(len(bundle.event_groups), 1)
        group = bundle.event_groups[0]
        self.assertEqual(group.aggregation_operator, "ALL_OF")
        self.assertEqual(group.rule_set_relation, RuleSetRelation.CUMULATIVE)
        binding_by_id = {item.binding_id: item for item in bundle.span_bindings}
        connector = binding_by_id[group.connector_binding_ids[0]]
        self.assertEqual(connector.role, NormSpanRole.CONNECTOR)
        self.assertEqual(connector.policy_unit_id, chapeau.unit_id)
        self.assertEqual(connector.exact_raw_text, "all of the following")

        event_by_id = {item.event_id: item for item in bundle.events}
        parent = event_by_id[group.parent_event_id]
        self.assertEqual(parent.child_event_ids, group.child_event_ids)
        for child_id in group.child_event_ids:
            child = event_by_id[child_id]
            self.assertEqual(child.parent_event_id, parent.event_id)
            self.assertEqual(child.modality, NormModality.MUST)
            self.assertEqual(child.extraction_status, "COMPLETE")

    def test_explicit_any_of_chapeau_creates_alternative_group(self) -> None:
        policy, _chapeau, first, second = _enum_policy("any of the following")

        bundle = build_norm_event_bundle(
            cp_id="CP1",
            policy=policy,
            policy_unit_ids=[first.unit_id, second.unit_id],
            relation_by_unit_id={
                first.unit_id: "PRIMARY_NORM",
                second.unit_id: "PRIMARY_NORM",
            },
        )

        self.assertEqual(bundle.event_groups[0].aggregation_operator, "ANY_OF")
        self.assertEqual(
            bundle.event_groups[0].rule_set_relation,
            RuleSetRelation.ALTERNATIVE,
        )

    def test_trailing_and_connector_is_preserved_as_exact_span(self) -> None:
        policy, _chapeau, first, second = _enum_policy("the following")
        first.own_raw_text = "(a) the treatment date; and"
        first.full_raw_text = first.own_raw_text
        first.normalized_text = first.own_raw_text

        bundle = build_norm_event_bundle(
            cp_id="CP1",
            policy=policy,
            policy_unit_ids=[first.unit_id, second.unit_id],
            relation_by_unit_id={
                first.unit_id: "PRIMARY_NORM",
                second.unit_id: "PRIMARY_NORM",
            },
        )

        group = bundle.event_groups[0]
        binding_by_id = {item.binding_id: item for item in bundle.span_bindings}
        connector = binding_by_id[group.connector_binding_ids[0]]
        self.assertEqual(group.aggregation_operator, "ALL_OF")
        self.assertEqual(connector.policy_unit_id, first.unit_id)
        self.assertEqual(connector.exact_raw_text, "and")

    def test_non_exhaustive_or_ungrounded_enum_stays_ambiguous(self) -> None:
        for connector_text in ("including but not limited to", "the following"):
            with self.subTest(connector_text=connector_text):
                policy, _chapeau, first, second = _enum_policy(connector_text)

                bundle = build_norm_event_bundle(
                    cp_id="CP1",
                    policy=policy,
                    policy_unit_ids=[first.unit_id, second.unit_id],
                    relation_by_unit_id={
                        first.unit_id: "PRIMARY_NORM",
                        second.unit_id: "PRIMARY_NORM",
                    },
                )

                self.assertEqual(bundle.event_groups, [])
                self.assertIn("COORDINATION_AMBIGUOUS", bundle.review_required_reason_codes)
                ledger = _ledger(
                    [
                        _candidate(first.unit_id, selected=True, relation="PRIMARY_NORM"),
                        _candidate(second.unit_id, selected=True, relation="PRIMARY_NORM"),
                    ]
                )
                result = compile_contract_slice(ledger, policy)
                self.assertEqual(result.status, ContractSliceStatus.REVIEW_REQUIRED)
                self.assertIsNone(result.logic_dag)

    def test_broken_chapeau_anchor_does_not_leave_dangling_event_links(self) -> None:
        policy, chapeau, first, second = _enum_policy("all of the following")
        chapeau.full_raw_text = "Corrupted source replay."

        bundle = build_norm_event_bundle(
            cp_id="CP1",
            policy=policy,
            policy_unit_ids=[first.unit_id, second.unit_id],
            relation_by_unit_id={
                first.unit_id: "PRIMARY_NORM",
                second.unit_id: "PRIMARY_NORM",
            },
        )

        self.assertEqual(bundle.event_groups, [])
        self.assertIn(
            "ORIGINAL_TEXT_ANCHOR_REPLAY_FAILED",
            bundle.review_required_reason_codes,
        )
        self.assertTrue(all(event.parent_event_id is None for event in bundle.events))

    def test_grounded_event_group_is_the_only_multi_primary_compile_path(self) -> None:
        for connector_text, expected_operator in (
            ("all of the following", LogicOperator.ALL_OF),
            ("any of the following", LogicOperator.ANY_OF),
        ):
            with self.subTest(connector_text=connector_text):
                policy, _chapeau, first, second = _enum_policy(connector_text)
                ledger = _ledger(
                    [
                        _candidate(first.unit_id, selected=True, relation="PRIMARY_NORM"),
                        _candidate(second.unit_id, selected=True, relation="PRIMARY_NORM"),
                    ]
                )

                result = compile_contract_slice(ledger, policy)

                self.assertEqual(result.status, ContractSliceStatus.VALID)
                assert result.logic_dag is not None
                assert result.projection_conformance is not None
                satisfaction = result.logic_dag.node_map()[
                    result.logic_dag.roots.satisfaction_root_id
                ]
                group = result.norm_event_bundle.event_groups[0]
                self.assertEqual(satisfaction.operator, expected_operator)
                self.assertEqual(len(satisfaction.child_ids), 2)
                self.assertEqual(
                    satisfaction.connector_span_ids,
                    group.connector_binding_ids,
                )
                self.assertTrue(
                    set(group.connector_binding_ids).issubset(satisfaction.source_span_ids)
                )
                assert result.indexed_requirement_view is not None
                root_row_id = result.indexed_requirement_view.root_row_ids["satisfaction"]
                root_row = next(
                    row for row in result.indexed_requirement_view.rows if row.row_id == root_row_id
                )
                self.assertTrue(set(group.connector_binding_ids).issubset(root_row.source_span_ids))
                self.assertTrue(result.projection_conformance.exact_projection_passed)
                replay = compile_contract_slice(ledger, policy)
                self.assertEqual(
                    replay.model_dump(mode="json"),
                    result.model_dump(mode="json"),
                )


if __name__ == "__main__":
    unittest.main()
