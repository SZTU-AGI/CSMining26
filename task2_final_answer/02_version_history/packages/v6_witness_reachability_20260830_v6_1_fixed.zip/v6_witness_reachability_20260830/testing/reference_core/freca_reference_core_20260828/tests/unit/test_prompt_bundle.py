from __future__ import annotations

import hashlib
import tempfile
import unittest
from pathlib import Path

from freca.governance.prompt_bundle import PromptBundleError, load_prompt_bundle


def digest(data: bytes) -> str:
    return f"sha256:{hashlib.sha256(data).hexdigest()}"


class PromptBundleTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.template = self.root / "policy.txt"
        self.template.write_bytes(b"Official: {official_cp_text}\n")
        self.write_manifest(digest(self.template.read_bytes()))

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def write_manifest(self, sha256: str) -> None:
        self.root.joinpath("manifest.toml").write_text(
            "\n".join(
                [
                    'schema_version = "freca.prompt-manifest.v1"',
                    'bundle_version = "test-v1"',
                    "",
                    "[[template]]",
                    'logical_name = "policy"',
                    'role = "POLICY_EXTRACT_USER"',
                    'version = "v1"',
                    'filename = "policy.txt"',
                    f'sha256 = "{sha256}"',
                    'allowed_variables = ["official_cp_text"]',
                    "",
                ]
            ),
            encoding="utf-8",
        )

    def test_load_and_render_are_hash_verified(self) -> None:
        bundle = load_prompt_bundle(self.root)
        rendered = bundle.render("policy", official_cp_text="CP text")
        self.assertEqual(rendered.text, "Official: CP text\n")
        self.assertTrue(rendered.prompt_sha256.startswith("sha256:"))

    def test_missing_unknown_and_unused_variables_fail(self) -> None:
        bundle = load_prompt_bundle(self.root)
        with self.assertRaises(PromptBundleError):
            bundle.render("policy")
        with self.assertRaises(PromptBundleError):
            bundle.render("policy", official_cp_text="x", unexpected="y")

    def test_changed_file_and_unresolved_marker_fail(self) -> None:
        self.template.write_bytes(b"changed")
        with self.assertRaisesRegex(PromptBundleError, "hash mismatch"):
            load_prompt_bundle(self.root)
        self.template.write_bytes(b"TODO {official_cp_text}")
        self.write_manifest(digest(self.template.read_bytes()))
        with self.assertRaisesRegex(PromptBundleError, "unresolved marker"):
            load_prompt_bundle(self.root)


if __name__ == "__main__":
    unittest.main()
