"""Structure-only routing between dual-audit and graph-required execution."""

from __future__ import annotations

from typing import Literal

from pydantic import Field, model_validator

from freca.domain.models import SafeId, Sha256, StrictModel
from freca.harness.artifact_store import sha256_digest
from freca.logic.ast import LogicDAG, LogicOperator


class ContractRepresentationCapability(StrictModel):
    capability_id: SafeId
    contract_id: SafeId
    interpretation_id: SafeId
    indexed_ast_complete: bool
    contains_dynamic_burden: bool
    contains_case_dependent_assumption: bool
    contains_nonreducible_rebuttal: bool
    contains_nonreducible_exception: bool
    shadow_comparable_root_ids: list[SafeId] = Field(default_factory=list)
    shadow_noncomparable_root_ids: list[SafeId] = Field(default_factory=list)
    required_execution_mode: Literal[
        "AST_COMPLETE_DUAL_AUDIT",
        "GRAPH_REQUIRED_SHADOW_PARTIAL",
    ]
    classification_rule_ids: list[str]
    capability_sha256: Sha256

    @model_validator(mode="after")
    def enforce_mode(self) -> ContractRepresentationCapability:
        graph_required = any(
            (
                self.contains_dynamic_burden,
                self.contains_case_dependent_assumption,
                self.contains_nonreducible_rebuttal,
                self.contains_nonreducible_exception,
                bool(self.shadow_noncomparable_root_ids),
            )
        )
        if graph_required and self.required_execution_mode != "GRAPH_REQUIRED_SHADOW_PARTIAL":
            raise ValueError("dynamic/exception semantics require graph execution")
        if not graph_required and self.required_execution_mode != "AST_COMPLETE_DUAL_AUDIT":
            raise ValueError("exception-free complete AST must use dual audit mode")
        if self.indexed_ast_complete == graph_required:
            raise ValueError("indexed_ast_complete conflicts with structural capability flags")
        return self


def classify_representation_capability(
    dag: LogicDAG,
    *,
    contract_id: str,
    contains_dynamic_burden: bool = False,
    contains_case_dependent_assumption: bool = False,
    contains_nonreducible_rebuttal: bool = False,
) -> ContractRepresentationCapability:
    node_by_id = dag.node_map()
    comparable: list[str] = []
    noncomparable: list[str] = []
    exception_operators = {LogicOperator.UNLESS, LogicOperator.EXCEPTION_GATE}
    for root_id in dag.roots.as_dict().values():
        reached = dag.reachable_ids(root_id)
        if any(node_by_id[node_id].operator in exception_operators for node_id in reached):
            noncomparable.append(root_id)
        else:
            comparable.append(root_id)

    contains_exception = bool(noncomparable)
    graph_required = any(
        (
            contains_exception,
            contains_dynamic_burden,
            contains_case_dependent_assumption,
            contains_nonreducible_rebuttal,
        )
    )
    rules = ["ECF.14_STRUCTURE_ONLY_ROUTING", "ECF.15_EXCEPTION_NOT_BOOLEANIZED"]
    payload = {
        "contract_id": contract_id,
        "interpretation_id": dag.interpretation_id,
        "indexed_ast_complete": not graph_required,
        "contains_dynamic_burden": contains_dynamic_burden,
        "contains_case_dependent_assumption": contains_case_dependent_assumption,
        "contains_nonreducible_rebuttal": contains_nonreducible_rebuttal,
        "contains_nonreducible_exception": contains_exception,
        "shadow_comparable_root_ids": sorted(comparable),
        "shadow_noncomparable_root_ids": sorted(noncomparable),
        "required_execution_mode": (
            "GRAPH_REQUIRED_SHADOW_PARTIAL" if graph_required else "AST_COMPLETE_DUAL_AUDIT"
        ),
        "classification_rule_ids": rules,
    }
    digest = sha256_digest(payload)
    return ContractRepresentationCapability(
        capability_id=f"cap-{digest.split(':', 1)[1][:20]}",
        capability_sha256=digest,
        **payload,
    )
