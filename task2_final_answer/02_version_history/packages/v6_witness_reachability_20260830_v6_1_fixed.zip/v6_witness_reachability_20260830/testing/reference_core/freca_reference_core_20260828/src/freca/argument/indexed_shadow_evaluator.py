"""Compare graph roots with an independent, exception-bounded AST evaluator."""

from __future__ import annotations

from typing import Literal

from pydantic import Field

from freca.argument.evaluator import ArgumentGraphEvaluation
from freca.argument.models import ArgumentGraphTemplate
from freca.domain.models import SafeId, Sha256, StrictModel
from freca.harness.artifact_store import sha256_digest
from freca.logic.ast import LogicDAG
from freca.logic.evaluator import evaluate_logic_dag
from freca.logic.four_valued import FourValuedState
from freca.policy.indexed_requirement_view import IndexedRequirementView
from freca.policy.representation_capability import ContractRepresentationCapability


class IndexedShadowEvaluationReport(StrictModel):
    report_id: SafeId
    case_uid: SafeId
    cp_id: str
    interpretation_id: SafeId
    indexed_requirement_view_sha256: Sha256
    atomic_evidence_state_sha256: Sha256
    eligible_operator_ids: list[SafeId] = Field(default_factory=list)
    excluded_dynamic_argument_ids: list[SafeId] = Field(default_factory=list)
    shadow_root_states: dict[SafeId, FourValuedState]
    graph_root_states: dict[SafeId, FourValuedState]
    comparable_root_ids: list[SafeId]
    shadow_noncomparable_root_ids: list[SafeId]
    mismatch_root_ids: list[SafeId]
    comparison_status: Literal["FULL_MATCH", "PARTIAL_MATCH", "MISMATCH", "NOT_COMPARABLE"]
    report_sha256: Sha256


def audit_indexed_shadow(
    *,
    case_uid: str,
    cp_id: str,
    view: IndexedRequirementView,
    dag: LogicDAG,
    graph: ArgumentGraphTemplate,
    graph_evaluation: ArgumentGraphEvaluation,
    capability: ContractRepresentationCapability,
    atom_states: dict[str, FourValuedState],
) -> IndexedShadowEvaluationReport:
    if (
        view.interpretation_id != dag.interpretation_id
        or graph.interpretation_id != dag.interpretation_id
    ):
        raise ValueError("shadow inputs must use the same interpretation")
    if capability.interpretation_id != dag.interpretation_id:
        raise ValueError("capability must describe the evaluated interpretation")

    trace = evaluate_logic_dag(
        dag,
        atom_states,
        root_ids=capability.shadow_comparable_root_ids,
        skip_noncomparable_roots=False,
    )
    statement_by_logic = {item.logic_node_id: item.statement_id for item in graph.statement_nodes}
    graph_states_by_logic = {
        root_id: graph_evaluation.root_states[statement_by_logic[root_id]]
        for root_id in dag.roots.as_dict().values()
    }
    mismatch = sorted(
        root_id
        for root_id in capability.shadow_comparable_root_ids
        if trace.evaluated_root_states[root_id] != graph_states_by_logic[root_id]
    )
    if mismatch:
        status = "MISMATCH"
    elif not capability.shadow_comparable_root_ids:
        status = "NOT_COMPARABLE"
    elif capability.shadow_noncomparable_root_ids:
        status = "PARTIAL_MATCH"
    else:
        status = "FULL_MATCH"

    eligible_nodes = sorted(
        node_id
        for root_id in capability.shadow_comparable_root_ids
        for node_id in dag.reachable_ids(root_id)
    )
    payload = {
        "case_uid": case_uid,
        "cp_id": cp_id,
        "interpretation_id": dag.interpretation_id,
        "indexed_requirement_view_sha256": view.view_sha256,
        "atomic_evidence_state_sha256": sha256_digest(
            {key: value.value for key, value in sorted(atom_states.items())}
        ),
        "eligible_operator_ids": sorted(set(eligible_nodes)),
        "excluded_dynamic_argument_ids": [],
        "shadow_root_states": trace.evaluated_root_states,
        "graph_root_states": graph_states_by_logic,
        "comparable_root_ids": capability.shadow_comparable_root_ids,
        "shadow_noncomparable_root_ids": capability.shadow_noncomparable_root_ids,
        "mismatch_root_ids": mismatch,
        "comparison_status": status,
    }
    digest = sha256_digest(payload)
    return IndexedShadowEvaluationReport(
        report_id=f"shadow-{digest.split(':', 1)[1][:20]}",
        report_sha256=digest,
        **payload,
    )
