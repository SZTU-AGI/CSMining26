"""Auditable legal proposition templates derived from anchored NormEvents."""

from __future__ import annotations

from enum import StrEnum

from pydantic import Field, model_validator

from freca.domain.models import SafeId, Sha256, StrictModel
from freca.governance.hashing import sha256_digest
from freca.policy.norm_events import NormEvent


class PropositionRole(StrEnum):
    LEGAL_APPLICABILITY = "LEGAL_APPLICABILITY"
    LEGAL_SATISFACTION = "LEGAL_SATISFACTION"
    LEGAL_VIOLATION = "LEGAL_VIOLATION"
    LEGAL_NON_APPLICABILITY = "LEGAL_NON_APPLICABILITY"


class PropositionTemplate(StrictModel):
    proposition_id: SafeId
    cp_id: str = Field(min_length=1)
    semantic_role: PropositionRole
    proposition_text: str = Field(min_length=1)
    source_norm_event_ids: list[SafeId] = Field(min_length=1)
    source_span_binding_ids: list[SafeId] = Field(min_length=1)
    proposition_sha256: Sha256


class PropositionCatalog(StrictModel):
    catalog_id: SafeId
    cp_id: str = Field(min_length=1)
    propositions: list[PropositionTemplate] = Field(min_length=4)
    root_proposition_ids: dict[str, SafeId | None]
    catalog_sha256: Sha256

    @model_validator(mode="after")
    def validate_catalog(self) -> PropositionCatalog:
        known = {item.proposition_id for item in self.propositions}
        if len(known) != len(self.propositions):
            raise ValueError("proposition IDs must be unique")
        expected_roots = {"applicability", "satisfaction", "violation", "non_applicability"}
        if set(self.root_proposition_ids) != expected_roots:
            raise ValueError("proposition catalog must define exactly four roots")
        rooted_propositions = {
            item for item in self.root_proposition_ids.values() if item is not None
        }
        if rooted_propositions - known:
            raise ValueError("proposition roots reference unknown propositions")
        return self


_ROOT_SPECS = {
    "applicability": (
        PropositionRole.LEGAL_APPLICABILITY,
        "The selected legal norm applies to the case.",
    ),
    "satisfaction": (
        PropositionRole.LEGAL_SATISFACTION,
        "The conduct required by the selected legal norm is satisfied.",
    ),
    "violation": (
        PropositionRole.LEGAL_VIOLATION,
        "The selected legal norm is violated.",
    ),
    "non_applicability": (
        PropositionRole.LEGAL_NON_APPLICABILITY,
        "A positive legal basis establishes that the selected legal norm does not apply.",
    ),
}


def build_proposition_catalog(*, cp_id: str, primary_event: NormEvent) -> PropositionCatalog:
    propositions: list[PropositionTemplate] = []
    roots: dict[str, str] = {}
    for root_name, (role, text) in _ROOT_SPECS.items():
        payload = {
            "cp_id": cp_id,
            "semantic_role": role,
            "proposition_text": text,
            "source_norm_event_ids": [primary_event.event_id],
            "source_span_binding_ids": primary_event.span_binding_ids,
        }
        digest = sha256_digest(payload)
        proposition = PropositionTemplate(
            proposition_id=f"prop-{digest.split(':', 1)[1][:20]}",
            proposition_sha256=digest,
            **payload,
        )
        propositions.append(proposition)
        roots[root_name] = proposition.proposition_id
    payload = {
        "cp_id": cp_id,
        "propositions": propositions,
        "root_proposition_ids": roots,
    }
    digest = sha256_digest(payload)
    return PropositionCatalog(
        catalog_id=f"propcatalog-{digest.split(':', 1)[1][:20]}",
        catalog_sha256=digest,
        **payload,
    )


def build_grouped_proposition_catalog(
    *,
    cp_id: str,
    parent_event: NormEvent,
    child_events: list[NormEvent],
) -> PropositionCatalog:
    if len(child_events) < 2:
        raise ValueError("grouped proposition catalog requires at least two child events")

    propositions: list[PropositionTemplate] = []
    roots: dict[str, str | None] = {"satisfaction": None}
    for root_name in ("applicability", "violation", "non_applicability"):
        role, text = _ROOT_SPECS[root_name]
        payload = {
            "cp_id": cp_id,
            "semantic_role": role,
            "proposition_text": text,
            "source_norm_event_ids": [parent_event.event_id],
            "source_span_binding_ids": parent_event.span_binding_ids,
        }
        digest = sha256_digest(payload)
        proposition = PropositionTemplate(
            proposition_id=f"prop-{digest.split(':', 1)[1][:20]}",
            proposition_sha256=digest,
            **payload,
        )
        propositions.append(proposition)
        roots[root_name] = proposition.proposition_id

    for event in child_events:
        payload = {
            "cp_id": cp_id,
            "semantic_role": PropositionRole.LEGAL_SATISFACTION,
            "proposition_text": "The conduct required by this anchored norm event is satisfied.",
            "source_norm_event_ids": [event.event_id],
            "source_span_binding_ids": event.span_binding_ids,
        }
        digest = sha256_digest(payload)
        propositions.append(
            PropositionTemplate(
                proposition_id=f"prop-{digest.split(':', 1)[1][:20]}",
                proposition_sha256=digest,
                **payload,
            )
        )

    payload = {
        "cp_id": cp_id,
        "propositions": sorted(propositions, key=lambda item: item.proposition_id),
        "root_proposition_ids": roots,
    }
    digest = sha256_digest(payload)
    return PropositionCatalog(
        catalog_id=f"propcatalog-{digest.split(':', 1)[1][:20]}",
        catalog_sha256=digest,
        **payload,
    )
