from __future__ import annotations

import unittest
from pathlib import Path

from freca.governance.config import load_run_config
from freca.governance.source_guard import FileSystemSourceGuard
from freca.governance.source_resolver import CatalogSourceResolver
from freca.policy.cp_loader import load_official_cps
from freca.policy.pipeline_v2 import build_policy_index
from freca.policy.retrieval_v2 import retrieve_all_policy_candidates


class OfficialCPRetrievalTests(unittest.TestCase):
    def test_all_official_cps_have_isolated_queries_and_auditable_candidates(self) -> None:
        package_root = Path(__file__).resolve().parents[2]
        config = load_run_config(package_root / "configs" / "run.example.toml")
        if not Path(config.inputs.task_root).is_dir():
            self.skipTest("official Task2 bundle is not installed on this host")
        catalog = FileSystemSourceGuard().validate(config)
        resolver = CatalogSourceResolver(catalog)
        policy = build_policy_index(catalog.rules_pdf, resolver)
        cp_bundle = load_official_cps(catalog.cp_definitions, resolver)
        ledgers = retrieve_all_policy_candidates(cp_bundle.cps, policy)
        self.assertEqual(len(ledgers), 41)
        self.assertEqual([ledger.cp_id for ledger in ledgers], [f"CP{i}" for i in range(1, 42)])
        for cp, ledger in zip(cp_bundle.cps, ledgers, strict=True):
            direct = ledger.query_bundle.queries[0]
            self.assertEqual(direct.query_text, cp.retrieval_context_text)
            self.assertNotIn(f"{cp.cp_id} ", direct.query_text)
            self.assertTrue(ledger.candidates)
            exact_ids = {
                candidate.policy_unit_id
                for candidate in ledger.candidates
                if any(signal.channel == "EXACT" for signal in candidate.retrieval_signals)
            }
            self.assertTrue(
                all(
                    candidate.decision is not None
                    and candidate.decision.policy_span_ids == [candidate.policy_unit_id]
                    for candidate in ledger.candidates
                )
            )
            self.assertTrue(exact_ids.issubset({item.policy_unit_id for item in ledger.candidates}))


if __name__ == "__main__":
    unittest.main()
