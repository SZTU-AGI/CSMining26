from __future__ import annotations

import unittest
from collections import Counter
from pathlib import Path

from freca.governance.config import load_run_config
from freca.governance.source_guard import FileSystemSourceGuard
from freca.governance.source_resolver import CatalogSourceResolver
from freca.policy.pipeline_v2 import build_policy_index


class OfficialPolicyIndexTests(unittest.TestCase):
    def test_official_pdf_structural_baseline_and_determinism(self) -> None:
        package_root = Path(__file__).resolve().parents[2]
        config = load_run_config(package_root / "configs" / "run.example.toml")
        if not Path(config.inputs.task_root).is_dir():
            self.skipTest("official Task2 bundle is not installed on this host")
        catalog = FileSystemSourceGuard().validate(config)
        resolver = CatalogSourceResolver(catalog)
        first = build_policy_index(catalog.rules_pdf, resolver)
        second = build_policy_index(catalog.rules_pdf, resolver)
        self.assertEqual(first.index_sha256, second.index_sha256)
        self.assertEqual(len(first.pages), 132)
        self.assertEqual(
            sum(item.occurrence_role == "BODY" for item in first.section_occurrences),
            184,
        )
        self.assertEqual(sum(unit.unit_type.value == "TABLE" for unit in first.units), 5)
        self.assertEqual(
            Counter((issue.severity, issue.issue_code) for issue in first.issues),
            Counter({("WARNING", "L1_TABLE_PARSE_UNCERTAIN"): 5}),
        )
        self.assertEqual(
            first.index_sha256,
            "sha256:c9092cf99bf790c5a20d56663ddfff27cacb271c29b1383f336111b550445152",
        )


if __name__ == "__main__":
    unittest.main()
