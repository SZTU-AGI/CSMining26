"""Pydantic domain models and cross-field invariants for FRECA."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Annotated

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from freca.domain.enums import (
    Applicability,
    ArtifactStatus,
    ClaimRelation,
    ClaimStatus,
    ClaimType,
    DecisionBasis,
    EvidenceIdentityState,
    FinalLabel,
    GateDecision,
    GateSeverity,
    PremiseSourceType,
    Sufficiency,
    VerificationIssueCode,
)

NonEmptyStr = Annotated[str, Field(min_length=1)]
SafeId = Annotated[str, Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")]
Sha256 = Annotated[str, Field(pattern=r"^sha256:[0-9a-f]{64}$")]


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


class StrictModel(BaseModel):
    """Reject unknown fields so schema drift fails loudly."""

    model_config = ConfigDict(extra="forbid", validate_assignment=True)


class EvidenceLocator(StrictModel):
    document_path: NonEmptyStr
    page: int | None = Field(default=None, ge=1)
    paragraph_index: int | None = Field(default=None, ge=0)
    table_index: int | None = Field(default=None, ge=0)
    row_index: int | None = Field(default=None, ge=0)
    sheet: str | None = None
    cell_range: str | None = None
    headers: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def require_a_precise_coordinate(self) -> EvidenceLocator:
        coordinates = (
            self.page,
            self.paragraph_index,
            self.table_index,
            self.row_index,
            self.sheet,
            self.cell_range,
        )
        if all(value is None for value in coordinates):
            raise ValueError("locator must contain at least one page/paragraph/table/sheet coordinate")
        if (self.sheet is None) != (self.cell_range is None):
            raise ValueError("sheet and cell_range must be provided together")
        return self


class IdentityAssessment(StrictModel):
    state: EvidenceIdentityState
    farm: str | None = None
    re_number: str | None = None
    product: str | None = None
    address: str | None = None
    effective_time: str | None = None
    matched_anchors: list[str] = Field(default_factory=list)
    conflicting_anchors: list[str] = Field(default_factory=list)


class EvidenceAtom(StrictModel):
    evidence_id: SafeId
    case_id: NonEmptyStr
    doc_id: SafeId
    track: NonEmptyStr
    source_type: NonEmptyStr
    locator: EvidenceLocator
    content: NonEmptyStr
    identity: IdentityAssessment
    source_hash: Sha256
    parse_confidence: float = Field(ge=0.0, le=1.0)


class PolicySpan(StrictModel):
    source_id: SafeId
    locator: NonEmptyStr
    text: NonEmptyStr
    source_hash: Sha256


class RuleSlots(StrictModel):
    subject: NonEmptyStr
    deontic: NonEmptyStr
    action: NonEmptyStr
    object: NonEmptyStr
    conditions: list[str] = Field(default_factory=list)
    temporal: str | None = None


class PolicyPack(StrictModel):
    cp_id: NonEmptyStr
    policy_version: NonEmptyStr
    authoritative_spans: list[PolicySpan] = Field(min_length=1)
    rule_slots: RuleSlots
    #: Facts about the farm that determine whether this CP is in scope.  These
    #: are not legal exemptions and must be evaluated against A0 evidence.
    scope_predicates: list[str] = Field(default_factory=list)
    required_facts: list[str] = Field(default_factory=list)
    violation_facts: list[str] = Field(default_factory=list)
    #: Explicit legal exclusions, kept separate from farm-scope predicates.
    explicit_legal_exemptions: list[str] = Field(default_factory=list)
    counter_facts: list[str] = Field(default_factory=list)
    related_cp_ids: list[str] = Field(default_factory=list)

    # Compatibility fields for packs written by the pre-A0 package.  New code
    # should read ``scope_predicates`` and ``explicit_legal_exemptions``.  They
    # remain in the schema temporarily so old fixtures fail by behaviour, not by
    # import-time schema errors, while handoff artefacts are being migrated.
    applicability_predicates: list[str] = Field(default_factory=list)
    explicit_na_conditions: list[str] = Field(default_factory=list)

    @model_validator(mode="before")
    @classmethod
    def migrate_legacy_scope_fields(cls, value: Any) -> Any:
        if not isinstance(value, dict):
            return value
        data = dict(value)
        if not data.get("scope_predicates") and data.get("applicability_predicates"):
            data["scope_predicates"] = list(data["applicability_predicates"])
        if not data.get("explicit_legal_exemptions") and data.get("explicit_na_conditions"):
            data["explicit_legal_exemptions"] = list(data["explicit_na_conditions"])
        return data

    @model_validator(mode="after")
    def require_a_decision_path(self) -> PolicyPack:
        if not (
            self.required_facts
            or self.violation_facts
            or self.scope_predicates
            or self.explicit_legal_exemptions
        ):
            raise ValueError(
                "policy pack must define required facts, violation facts, or explicit N/A conditions"
            )
        return self


class ClaimPremise(StrictModel):
    source_type: PremiseSourceType
    source_id: SafeId
    relation: ClaimRelation


class AuditClaim(StrictModel):
    claim_id: SafeId
    claim_type: ClaimType
    proposition: dict[str, Any]
    premises: list[ClaimPremise] = Field(default_factory=list)
    depends_on: list[SafeId] = Field(default_factory=list)
    status: ClaimStatus = ClaimStatus.UNVERIFIED

    @field_validator("proposition")
    @classmethod
    def proposition_must_not_be_empty(cls, value: dict[str, Any]) -> dict[str, Any]:
        if not value:
            raise ValueError("proposition cannot be empty")
        return value


class AuditArgument(StrictModel):
    argument_id: SafeId
    case_id: NonEmptyStr
    cp_id: NonEmptyStr
    claims: list[AuditClaim] = Field(min_length=1)
    #: ``None`` means the evidence was never read, so no verdict was proposed. This
    #: is distinct from proposing 0: an unread cell is our failure, a 0 is a finding
    #: about the farm. Collapsing the two is what let a run return 1 for 98% of
    #: cells while every gate reported PASS, so the type keeps them apart and C7
    #: refuses to turn ``None`` into a label.
    candidate_label: FinalLabel | None = None
    sufficiency: Sufficiency

    @model_validator(mode="after")
    def validate_claim_graph(self) -> AuditArgument:
        claim_by_id = {claim.claim_id: claim for claim in self.claims}
        if len(claim_by_id) != len(self.claims):
            raise ValueError("claim_id values must be unique")

        for claim in self.claims:
            unknown = set(claim.depends_on) - claim_by_id.keys()
            if unknown:
                raise ValueError(f"claim {claim.claim_id} depends on unknown claims: {sorted(unknown)}")
            if claim.claim_id in claim.depends_on:
                raise ValueError(f"claim {claim.claim_id} cannot depend on itself")

        visiting: set[str] = set()
        visited: set[str] = set()

        def visit(claim_id: str) -> None:
            if claim_id in visiting:
                raise ValueError("claim dependency graph must be acyclic")
            if claim_id in visited:
                return
            visiting.add(claim_id)
            for dependency in claim_by_id[claim_id].depends_on:
                visit(dependency)
            visiting.remove(claim_id)
            visited.add(claim_id)

        for claim_id in claim_by_id:
            visit(claim_id)
        return self


class RetrievalNeed(StrictModel):
    fact_type: NonEmptyStr
    query_facets: list[NonEmptyStr] = Field(min_length=1)


class VerificationIssue(StrictModel):
    issue_id: SafeId
    code: VerificationIssueCode
    message: NonEmptyStr
    retryable: bool
    claim_id: SafeId | None = None
    artifact_ids: list[SafeId] = Field(default_factory=list)
    retrieval_need: RetrievalNeed | None = None

    @model_validator(mode="after")
    def retry_requires_a_retrieval_need(self) -> VerificationIssue:
        if self.retryable and self.retrieval_need is None:
            raise ValueError("retryable verification issues require retrieval_need")
        return self


class GateReport(StrictModel):
    gate_id: SafeId
    gate_name: NonEmptyStr
    decision: GateDecision
    severity: GateSeverity
    issues: list[VerificationIssue] = Field(default_factory=list)

    @model_validator(mode="after")
    def decision_must_match_issues(self) -> GateReport:
        if self.decision is GateDecision.PASS and self.issues:
            raise ValueError("PASS gate cannot contain unresolved issues")
        if self.decision is not GateDecision.PASS and not self.issues:
            raise ValueError("non-PASS gate must contain at least one issue")
        if self.decision is GateDecision.RETRY and not any(issue.retryable for issue in self.issues):
            raise ValueError("RETRY gate requires at least one retryable issue")
        return self


class ArtifactEnvelope(StrictModel):
    artifact_id: SafeId
    artifact_type: SafeId
    schema_version: NonEmptyStr = "1.0"
    run_id: SafeId
    case_id: str | None = None
    cp_id: str | None = None
    producer_node: NonEmptyStr
    producer_version: NonEmptyStr
    input_artifact_ids: list[SafeId] = Field(default_factory=list)
    input_hashes: dict[str, Sha256] = Field(default_factory=dict)
    config_hash: Sha256
    prompt_hash: Sha256 | None = None
    status: ArtifactStatus = ArtifactStatus.SUCCEEDED
    created_at: datetime = Field(default_factory=utc_now)
    payload_path: str | None = None
    validation_report_ids: list[SafeId] = Field(default_factory=list)

    @field_validator("created_at")
    @classmethod
    def created_at_must_be_timezone_aware(cls, value: datetime) -> datetime:
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError("created_at must be timezone-aware")
        return value


class ArtifactRecord(StrictModel):
    envelope: ArtifactEnvelope
    payload_sha256: Sha256
    payload: Any


class ArtifactRef(StrictModel):
    artifact_id: SafeId
    artifact_type: SafeId
    record_path: NonEmptyStr
    payload_sha256: Sha256


class RunEvent(StrictModel):
    run_id: SafeId
    sequence: int = Field(ge=0)
    event_type: NonEmptyStr
    node: str | None = None
    case_id: str | None = None
    cp_id: str | None = None
    artifact_ids: list[SafeId] = Field(default_factory=list)
    detail: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=utc_now)

    @field_validator("created_at")
    @classmethod
    def event_time_must_be_timezone_aware(cls, value: datetime) -> datetime:
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError("created_at must be timezone-aware")
        return value


class ModelCallRecord(StrictModel):
    call_id: SafeId
    run_id: SafeId
    node: NonEmptyStr
    model_name: NonEmptyStr
    model_config_hash: Sha256
    prompt_hash: Sha256
    input_artifact_ids: list[SafeId] = Field(default_factory=list)
    output_artifact_ids: list[SafeId] = Field(default_factory=list)
    input_tokens: int = Field(ge=0)
    output_tokens: int = Field(ge=0)
    latency_ms: int = Field(ge=0)
    succeeded: bool
    error_code: str | None = None
    created_at: datetime = Field(default_factory=utc_now)


class FinalDecision(StrictModel):
    case_id: NonEmptyStr
    cp_id: NonEmptyStr
    label: FinalLabel
    applicability: Applicability
    sufficiency: Sufficiency
    basis: DecisionBasis
    supporting_evidence_ids: list[SafeId] = Field(default_factory=list)
    contrary_evidence_ids: list[SafeId] = Field(default_factory=list)
    argument_id: SafeId
    gate_report_ids: list[SafeId] = Field(min_length=1)
    review_required: bool = False
    reasoning_summary: NonEmptyStr

    @model_validator(mode="after")
    def enforce_three_value_semantics(self) -> FinalDecision:
        overlap = set(self.supporting_evidence_ids) & set(self.contrary_evidence_ids)
        if overlap:
            raise ValueError(f"evidence cannot be both supporting and contrary: {sorted(overlap)}")

        if self.label is FinalLabel.NOT_APPLICABLE:
            if self.applicability is not Applicability.NOT_APPLICABLE:
                raise ValueError("N/A requires NOT_APPLICABLE")
            if self.sufficiency is not Sufficiency.SUFFICIENT:
                raise ValueError("N/A requires sufficient evidence of explicit non-applicability")
            if self.basis is not DecisionBasis.EXPLICIT_NON_APPLICABILITY:
                raise ValueError("N/A requires explicit_non_applicability basis")
            if not self.supporting_evidence_ids:
                raise ValueError("N/A requires evidence supporting non-applicability")

        elif self.label is FinalLabel.COMPLIANT:
            if self.applicability is not Applicability.APPLICABLE:
                raise ValueError("label 1 requires APPLICABLE")
            if self.sufficiency is not Sufficiency.SUFFICIENT:
                raise ValueError("label 1 requires SUFFICIENT evidence")
            if self.basis is not DecisionBasis.COMPLIANT_EVIDENCE:
                raise ValueError("label 1 requires compliant_evidence basis")
            if not self.supporting_evidence_ids:
                raise ValueError("label 1 requires supporting evidence")

        elif self.label is FinalLabel.NON_COMPLIANT:
            if self.applicability is not Applicability.APPLICABLE:
                raise ValueError("label 0 requires APPLICABLE")
            if self.basis is DecisionBasis.MISSING_REQUIRED_EVIDENCE:
                if self.sufficiency is not Sufficiency.INSUFFICIENT:
                    raise ValueError("missing evidence basis requires INSUFFICIENT")
                if not self.review_required:
                    raise ValueError("missing evidence basis requires review_required=true")
            elif self.basis is DecisionBasis.VIOLATION_EVIDENCE:
                if not self.supporting_evidence_ids:
                    raise ValueError("violation basis requires decision-supporting evidence")
            else:
                raise ValueError("label 0 requires violation or missing evidence basis")

        return self
