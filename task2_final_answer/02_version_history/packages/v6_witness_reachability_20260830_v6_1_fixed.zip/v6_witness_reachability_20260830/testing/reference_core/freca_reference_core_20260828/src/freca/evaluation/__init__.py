"""Evaluation and run-health layer (V0).

The layer keeps model/farm verdicts separate from run validity, gold scoring,
perturbation stability, and prompt-leakage findings.
"""

from freca.evaluation.run_gate import (
    MAJORITY_CLASS_THRESHOLD,
    RunHealth,
    RunMode,
    RunStatus,
    assess_run,
)
from freca.evaluation.v0 import (
    GoldEvaluation,
    LeakageFinding,
    PerturbationEvaluation,
    compare_perturbations,
    detect_prompt_leakage,
    evaluate_gold,
    evaluate_run_directory,
    load_labels,
)

__all__ = [
    "MAJORITY_CLASS_THRESHOLD",
    "RunHealth",
    "RunMode",
    "RunStatus",
    "assess_run",
    "GoldEvaluation",
    "LeakageFinding",
    "PerturbationEvaluation",
    "compare_perturbations",
    "detect_prompt_leakage",
    "evaluate_gold",
    "evaluate_run_directory",
    "load_labels",
]
