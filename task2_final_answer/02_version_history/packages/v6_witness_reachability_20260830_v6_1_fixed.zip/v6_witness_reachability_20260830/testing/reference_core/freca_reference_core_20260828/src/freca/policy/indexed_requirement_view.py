"""Deterministically flatten a validated Logic DAG into an audit-friendly index."""

from __future__ import annotations

from pydantic import Field, model_validator

from freca.domain.models import SafeId, Sha256, StrictModel
from freca.harness.artifact_store import sha256_digest
from freca.logic.ast import LogicDAG, LogicOperator


class IndexedRequirementRow(StrictModel):
    row_id: SafeId
    interpretation_id: SafeId
    logic_node_id: SafeId
    proposition_id: SafeId | None = None
    semantic_role: str = Field(min_length=1)
    operator: LogicOperator
    ordered_child_row_ids: list[SafeId] = Field(default_factory=list)
    source_span_ids: list[SafeId] = Field(default_factory=list)
    evidence_requirement_ids: list[SafeId] = Field(default_factory=list)
    row_sha256: Sha256


class IndexedRequirementView(StrictModel):
    view_id: SafeId
    interpretation_id: SafeId
    proposition_catalog_sha256: Sha256
    logic_ast_sha256: Sha256
    rows: list[IndexedRequirementRow]
    root_row_ids: dict[str, SafeId]
    view_sha256: Sha256

    @model_validator(mode="after")
    def validate_rows(self) -> IndexedRequirementView:
        ids = {row.row_id for row in self.rows}
        if len(ids) != len(self.rows):
            raise ValueError("indexed requirement row IDs must be unique")
        for row in self.rows:
            unknown = set(row.ordered_child_row_ids) - ids
            if unknown:
                raise ValueError(f"row {row.row_id} references unknown children: {sorted(unknown)}")
        unknown_roots = set(self.root_row_ids.values()) - ids
        if unknown_roots:
            raise ValueError(f"indexed roots reference unknown rows: {sorted(unknown_roots)}")
        return self


def _row_id(node_id: str) -> str:
    candidate = f"row-{node_id}"
    if len(candidate) > 128:
        raise ValueError(f"logic node ID is too long to derive a stable row ID: {node_id}")
    return candidate


def build_indexed_requirement_view(
    dag: LogicDAG,
    *,
    proposition_catalog_sha256: str,
) -> IndexedRequirementView:
    """Build the index without consulting an argument graph or model output."""

    logic_payload = dag.model_dump(mode="json")
    logic_hash = sha256_digest(logic_payload)
    rows: list[IndexedRequirementRow] = []
    for node in sorted(dag.nodes, key=lambda item: item.node_id):
        payload = {
            "interpretation_id": dag.interpretation_id,
            "logic_node_id": node.node_id,
            "proposition_id": node.proposition_id,
            "semantic_role": node.semantic_role,
            "operator": node.operator.value,
            "ordered_child_row_ids": [_row_id(child_id) for child_id in node.child_ids],
            "source_span_ids": node.source_span_ids,
            "evidence_requirement_ids": node.evidence_requirement_ids,
        }
        rows.append(
            IndexedRequirementRow(
                row_id=_row_id(node.node_id),
                row_sha256=sha256_digest(payload),
                **payload,
            )
        )
    roots = {name: _row_id(node_id) for name, node_id in dag.roots.as_dict().items()}
    view_payload = {
        "interpretation_id": dag.interpretation_id,
        "proposition_catalog_sha256": proposition_catalog_sha256,
        "logic_ast_sha256": logic_hash,
        "rows": [row.model_dump(mode="json") for row in rows],
        "root_row_ids": roots,
    }
    view_hash = sha256_digest(view_payload)
    return IndexedRequirementView(
        view_id=f"irv-{view_hash.split(':', 1)[1][:20]}",
        view_sha256=view_hash,
        **view_payload,
    )
