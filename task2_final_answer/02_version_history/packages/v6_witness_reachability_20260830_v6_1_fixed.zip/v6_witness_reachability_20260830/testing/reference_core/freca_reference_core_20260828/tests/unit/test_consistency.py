"""Tests for P0-P2: contradiction detection and submission assembly.

The hard requirement on this stage is not that it catches contradictions — a rule
that flags every disagreement catches all of them. It is that it stays silent on
disagreement that is *correct*. Roughly half the cases below are therefore negative:
they encode a legitimate pattern that a naive rule would flag, and assert that
nothing is reported. Those are the tests that constrain the design.
"""

from __future__ import annotations

import pytest

from freca.consistency.case_consistency import (
    CaseVerdict,
    ConsistencyRule,
    check_all,
    check_case,
    verdict_from_result,
)
from freca.consistency.submission import (
    BLOCKED_FILL,
    EXPECTED_HEADER,
    SubmissionError,
    assemble_submission,
    verify_submission,
)
from freca.domain.enums import (
    Applicability,
    DecisionBasis,
    FinalLabel,
    Sufficiency,
)


def _verdict(
    cp_id: str,
    label: str,
    *,
    case_id: str = "RE1",
    units: tuple[str, ...] = ("4-2(2)",),
    applicability: str | None = None,
    supporting: tuple[str, ...] = (),
    contrary: tuple[str, ...] = (),
    subsection: str = "",
    review: bool = False,
    blocked: str | None = None,
) -> CaseVerdict:
    if applicability is None:
        applicability = (
            Applicability.NOT_APPLICABLE.value
            if label == FinalLabel.NOT_APPLICABLE.value
            else Applicability.APPLICABLE.value
            if label
            else Applicability.UNKNOWN.value
        )
    return CaseVerdict(
        case_id=case_id,
        cp_id=cp_id,
        label=label,
        applicability=applicability,
        unit_ids=units,
        supporting_atom_ids=supporting,
        contrary_atom_ids=contrary,
        subsection=subsection,
        review_required=review,
        blocked_at=blocked,
    )


def _rules(report) -> set[str]:
    return {finding.rule.value for finding in report.findings}


# ---------------------------------------------------------------------------
# P0a — identical policy basis
# ---------------------------------------------------------------------------


def test_identical_basis_opposite_verdicts_is_a_contradiction():
    report = check_case(
        [
            _verdict("CP12", "1", units=("4-2(5)",)),
            _verdict("CP13", "0", units=("4-2(5)",)),
        ]
    )
    assert ConsistencyRule.IDENTICAL_BASIS_OPPOSITE_VERDICT.value in _rules(report)
    finding = report.findings[0]
    assert finding.cp_ids == ("CP12", "CP13")
    # The basis has to name the provision, or a reviewer cannot act on the finding.
    assert finding.basis == "4-2(5)"


def test_identical_basis_same_verdict_is_silent():
    report = check_case(
        [
            _verdict("CP12", "1", units=("4-2(5)",)),
            _verdict("CP13", "1", units=("4-2(5)",)),
        ]
    )
    assert report.ok


def test_different_basis_opposite_verdicts_is_not_a_contradiction():
    """Two checking points that read different provisions may disagree freely.

    This is the single most important negative case: it is what separates "shares a
    legal question" from "disagrees".
    """

    report = check_case(
        [
            _verdict("CP12", "1", units=("4-2(5)",)),
            _verdict("CP24", "0", units=("4-7A(2)(a)",)),
        ]
    )
    assert report.ok


def test_partially_overlapping_basis_does_not_trigger_verdict_conflict():
    """A multi-unit pack asks a wider question than its subset.

    CP24 rests on both limbs of s 4-7A(2); a checking point resting on only (2)(a)
    asks less. Compliance with a subset is not compliance with the whole, so 1 and 0
    are compatible. Only *applicability* is shared at unit granularity, and that is
    P0b's job — asserted below to prove the distinction is real and not an accident
    of this fixture.
    """

    verdicts = [
        _verdict("CP24", "0", units=("4-7A(2)(a)", "4-7A(2)(b)")),
        _verdict("CP25", "1", units=("4-7A(2)(a)",)),
    ]
    report = check_case(verdicts)
    assert ConsistencyRule.IDENTICAL_BASIS_OPPOSITE_VERDICT.value not in _rules(report)
    assert report.ok


def test_unit_order_does_not_affect_grouping():
    """The basis is a set. Two packs listing the same units in a different order are
    the same legal question, and BM25 ordering must not decide whether we notice."""

    report = check_case(
        [
            _verdict("CP12", "1", units=("4-2(5)", "4-2(6)")),
            _verdict("CP13", "0", units=("4-2(6)", "4-2(5)")),
        ]
    )
    assert ConsistencyRule.IDENTICAL_BASIS_OPPOSITE_VERDICT.value in _rules(report)


def test_na_is_not_the_opposite_of_a_substantive_verdict():
    """"This duty does not bind you" does not contradict "you complied with it".

    Applicability disagreement is caught by P0b through the applicability field, not
    by pairing labels — so this fixture keeps both verdicts APPLICABLE.
    """

    report = check_case(
        [
            _verdict("CP12", "1", units=("4-2(5)",)),
            _verdict(
                "CP13",
                "N/A",
                units=("4-2(5)",),
                applicability=Applicability.APPLICABLE.value,
            ),
        ]
    )
    assert ConsistencyRule.IDENTICAL_BASIS_OPPOSITE_VERDICT.value not in _rules(report)


def test_blocked_cells_have_no_basis_and_are_never_grouped():
    """An empty unit set is absence of evidence, not evidence of a shared question.

    Grouping on it would pair every blocked cell with every other, so blocked cells
    are excluded from grouping while still being counted.
    """

    report = check_case(
        [
            _verdict("CP1", "", units=(), blocked="C3"),
            _verdict("CP2", "", units=(), blocked="C3"),
            _verdict("CP3", "1", units=("4-2(5)",)),
        ]
    )
    assert report.ok
    assert report.n_blocked == 2
    assert report.n_basis_groups == 1


# ---------------------------------------------------------------------------
# P0b — applicability
# ---------------------------------------------------------------------------


def test_shared_unit_applicability_conflict_is_reported():
    """Whether a provision binds this occupier cannot depend on which CP asks."""

    report = check_case(
        [
            _verdict("CP30", "1", units=("11-2(1)",), applicability=Applicability.APPLICABLE.value),
            _verdict(
                "CP31",
                "N/A",
                units=("11-2(1)", "11-3(1)"),
                applicability=Applicability.NOT_APPLICABLE.value,
            ),
        ]
    )
    assert ConsistencyRule.SHARED_UNIT_APPLICABILITY_CONFLICT.value in _rules(report)
    finding = next(
        f for f in report.findings
        if f.rule is ConsistencyRule.SHARED_UNIT_APPLICABILITY_CONFLICT
    )
    assert finding.basis == "11-2(1)"


def test_applicability_conflict_fires_on_partial_overlap():
    """Unlike P0a, P0b triggers on *any* shared unit — applicability is a property of
    the unit alone, so a subset relationship does not excuse disagreement."""

    report = check_case(
        [
            _verdict("CP30", "1", units=("11-2(1)", "11-2(2)")),
            _verdict("CP31", "N/A", units=("11-2(1)",)),
        ]
    )
    assert ConsistencyRule.SHARED_UNIT_APPLICABILITY_CONFLICT.value in _rules(report)


def test_unknown_applicability_is_not_a_conflict():
    """UNKNOWN is not a claim. Treating it as one would flag every incomplete run."""

    report = check_case(
        [
            _verdict("CP30", "1", units=("11-2(1)",), applicability=Applicability.APPLICABLE.value),
            _verdict("CP31", "0", units=("11-2(1)",), applicability=Applicability.UNKNOWN.value),
        ]
    )
    assert ConsistencyRule.SHARED_UNIT_APPLICABILITY_CONFLICT.value not in _rules(report)


def test_disjoint_units_may_disagree_on_applicability():
    report = check_case(
        [
            _verdict("CP30", "1", units=("11-2(1)",), applicability=Applicability.APPLICABLE.value),
            _verdict(
                "CP40", "N/A", units=("9-4(1)",), applicability=Applicability.NOT_APPLICABLE.value
            ),
        ]
    )
    assert report.ok


# ---------------------------------------------------------------------------
# P1 — evidence polarity
# ---------------------------------------------------------------------------


def test_polarity_flip_on_shared_basis_is_reported():
    report = check_case(
        [
            _verdict("CP12", "1", units=("4-2(5)",), supporting=("atom-7",)),
            _verdict("CP13", "0", units=("4-2(5)",), contrary=("atom-7",)),
        ]
    )
    assert ConsistencyRule.EVIDENCE_POLARITY_FLIP.value in _rules(report)
    finding = next(
        f for f in report.findings if f.rule is ConsistencyRule.EVIDENCE_POLARITY_FLIP
    )
    assert finding.basis == "atom-7"


def test_same_atom_across_unrelated_checking_points_is_not_a_flip():
    """One inspection record can satisfy one duty and breach another.

    This is why P1 is scoped to a shared-basis group rather than applied globally —
    the unscoped rule would fire on sound work.
    """

    report = check_case(
        [
            _verdict("CP12", "1", units=("4-2(5)",), supporting=("atom-7",)),
            _verdict("CP24", "0", units=("4-7A(2)(a)",), contrary=("atom-7",)),
        ]
    )
    assert report.ok


def test_shared_supporting_atom_is_not_a_flip():
    """Both chains reading a document the same way is agreement, not conflict."""

    report = check_case(
        [
            _verdict("CP12", "1", units=("4-2(5)",), supporting=("atom-7",)),
            _verdict("CP13", "1", units=("4-2(5)",), supporting=("atom-7",)),
        ]
    )
    assert report.ok


# ---------------------------------------------------------------------------
# Reporting honesty
# ---------------------------------------------------------------------------


def test_comparable_group_count_is_reported():
    """"Zero contradictions" is uninterpretable without the number of groups that
    had two substantive verdicts to compare.

    Here every group has at most one substantive verdict, so ``ok`` is true purely
    because nothing was ever comparable — the report has to make that visible.
    """

    report = check_case(
        [
            _verdict("CP1", "1", units=("4-2(5)",)),
            _verdict("CP2", "", units=(), blocked="C3"),
            _verdict("CP3", "N/A", units=("4-9(2)",)),
        ]
    )
    assert report.ok
    assert report.n_basis_groups == 2  # the unit-less blocked cell contributes none
    assert report.n_comparable_groups == 0  # nothing was ever comparable


def test_check_all_carries_denominators():
    verdicts = [
        _verdict("CP12", "1", case_id="RE1", units=("4-2(5)",)),
        _verdict("CP13", "0", case_id="RE1", units=("4-2(5)",)),
        _verdict("CP12", "1", case_id="RE2", units=("4-2(5)",)),
        _verdict("CP13", "1", case_id="RE2", units=("4-2(5)",)),
    ]
    reports, summary = check_all(verdicts)
    assert len(reports) == 2
    assert summary["n_cases_with_findings"] == 1
    assert summary["n_cells"] == 4
    assert summary["n_comparable_groups"] == 2


def test_review_required_is_counted():
    report = check_case([_verdict("CP1", "0", review=True), _verdict("CP2", "1")])
    assert report.n_review_required == 1


def test_empty_input_is_not_a_crash():
    report = check_case([])
    assert report.ok and report.n_verdicts == 0


# ---------------------------------------------------------------------------
# verdict_from_result — the adapter over AdjudicationResult
# ---------------------------------------------------------------------------


class _StubResult:
    def __init__(self, decision, blocked_at=None):
        self.case_id = "RE1"
        self.cp_id = "CP1"
        self.decision = decision
        self.blocked_at = blocked_at

    @property
    def label(self):
        return self.decision.label.value if self.decision else ""


def test_verdict_from_result_reads_the_real_decision_fields():
    """Guards against field-name drift. An adapter that silently returns empty
    tuples would make P1 look permanently clean."""

    from freca.domain.models import FinalDecision

    decision = FinalDecision(
        case_id="RE1",
        cp_id="CP1",
        label=FinalLabel.NON_COMPLIANT,
        applicability=Applicability.APPLICABLE,
        sufficiency=Sufficiency.SUFFICIENT,
        basis=DecisionBasis.VIOLATION_EVIDENCE,
        supporting_evidence_ids=["atom-1"],
        contrary_evidence_ids=["atom-2"],
        argument_id="arg-1",
        gate_report_ids=["gate-1"],
        reasoning_summary="test",
    )
    verdict = verdict_from_result(_StubResult(decision), unit_ids=("4-2(2)",))
    assert verdict.label == "0"
    assert verdict.applicability == Applicability.APPLICABLE.value
    assert verdict.supporting_atom_ids == ("atom-1",)
    assert verdict.contrary_atom_ids == ("atom-2",)
    assert verdict.unit_ids == ("4-2(2)",)


def test_verdict_from_blocked_result_keeps_the_empty_label():
    verdict = verdict_from_result(_StubResult(None, blocked_at="C3"), unit_ids=("4-2(2)",))
    assert verdict.label == ""
    assert verdict.blocked_at == "C3"
    assert not verdict.is_substantive


# ---------------------------------------------------------------------------
# P2 — submission assembly
# ---------------------------------------------------------------------------


class _Case:
    def __init__(self, case_id: str, re_number: str):
        self.case_id = case_id
        self.re_number = re_number


def _template(path):
    from openpyxl import Workbook

    workbook = Workbook()
    workbook.active.append(list(EXPECTED_HEADER))
    workbook.save(path)
    return path


def _full_verdicts(cases, label="1"):
    return [
        _verdict(f"CP{index}", label, case_id=case.case_id)
        for case in cases
        for index in range(1, 42)
    ]


def test_assembly_writes_a_gradeable_grid(tmp_path):
    cases = [_Case("c1", "RE-1"), _Case("c2", "RE-2")]
    report = assemble_submission(
        _full_verdicts(cases),
        cases,
        template_path=_template(tmp_path / "t.xlsx"),
        output_path=tmp_path / "out.xlsx",
        expected_cases=None,
    )
    assert report.rows == 2
    assert report.n_cells == 82
    checked = verify_submission(tmp_path / "out.xlsx", expect_rows=3)
    assert checked["label_counts"] == {"1": 82}


def test_row_order_follows_the_manifest_not_the_verdict_list(tmp_path):
    """A permuted submission scores near zero while looking well-formed, so row
    order is taken from the manifest and never from verdict iteration order."""

    from openpyxl import load_workbook

    cases = [_Case("c1", "RE-1"), _Case("c2", "RE-2")]
    verdicts = [
        _verdict(f"CP{index}", "0", case_id="c2") for index in range(1, 42)
    ] + [_verdict(f"CP{index}", "1", case_id="c1") for index in range(1, 42)]
    assemble_submission(
        verdicts,
        cases,
        template_path=_template(tmp_path / "t.xlsx"),
        output_path=tmp_path / "out.xlsx",
        expected_cases=None,
    )
    sheet = load_workbook(tmp_path / "out.xlsx").active
    assert sheet.cell(2, 1).value == "RE-1"
    assert sheet.cell(2, 2).value == "1"
    assert sheet.cell(3, 1).value == "RE-2"
    assert sheet.cell(3, 2).value == "0"


def test_blocked_cell_is_filled_but_named_and_counted(tmp_path):
    """The format forbids a blank; the report must still say the cell was not a
    finding. A silent 0 here is a pipeline failure disguised as non-compliance."""

    cases = [_Case("c1", "RE-1")]
    verdicts = _full_verdicts(cases)
    verdicts[4] = _verdict("CP5", "", case_id="c1", units=(), blocked="C3")
    report = assemble_submission(
        verdicts,
        cases,
        template_path=_template(tmp_path / "t.xlsx"),
        output_path=tmp_path / "out.xlsx",
        expected_cases=None,
    )
    assert report.blocked_cells == ["c1/CP5"]
    assert report.candidate_only is True
    assert report.label_counts[BLOCKED_FILL] == 1
    assert any("blocked" in note for note in report.notes)
    verify_submission(tmp_path / "out.xlsx", expect_rows=2)


def test_missing_verdict_is_refused_unless_explicitly_allowed(tmp_path):
    """A cell with no verdict record at all is a different failure from a blocked
    one, and waiving the case-count gate must not waive this."""

    cases = [_Case("c1", "RE-1")]
    partial = _full_verdicts(cases)[:-1]
    with pytest.raises(SubmissionError, match="no verdict"):
        assemble_submission(
            partial,
            cases,
            template_path=_template(tmp_path / "t.xlsx"),
            output_path=tmp_path / "out.xlsx",
            expected_cases=None,
        )


def test_missing_verdict_may_be_waived_explicitly(tmp_path):
    cases = [_Case("c1", "RE-1")]
    partial = _full_verdicts(cases)[:-1]
    report = assemble_submission(
        partial,
        cases,
        template_path=_template(tmp_path / "t.xlsx"),
        output_path=tmp_path / "out.xlsx",
        expected_cases=None,
        allow_missing_verdicts=True,
    )
    assert report.blocked_cells == ["c1/CP41"]
    assert report.candidate_only is True


def test_duplicate_verdict_is_refused(tmp_path):
    """Two verdicts for one cell means mixed sources; picking one silently is how a
    stale verdict reaches the graded file."""

    cases = [_Case("c1", "RE-1")]
    verdicts = _full_verdicts(cases)
    verdicts.append(_verdict("CP1", "0", case_id="c1"))
    with pytest.raises(SubmissionError, match="duplicate verdict"):
        assemble_submission(
            verdicts,
            cases,
            template_path=_template(tmp_path / "t.xlsx"),
            output_path=tmp_path / "out.xlsx",
            expected_cases=None,
        )


def test_duplicate_re_number_marks_the_file_candidate_only(tmp_path):
    cases = [_Case("c1", "RE-1"), _Case("c2", "RE-1")]
    report = assemble_submission(
        _full_verdicts(cases),
        cases,
        template_path=_template(tmp_path / "t.xlsx"),
        output_path=tmp_path / "out.xlsx",
        expected_cases=None,
    )
    assert report.duplicate_re_numbers == ["RE-1"]
    assert report.candidate_only is True


def test_template_is_never_overwritten(tmp_path):
    template = _template(tmp_path / "t.xlsx")
    with pytest.raises(SubmissionError, match="overwrite"):
        assemble_submission([], [], template_path=template, output_path=template)


def test_wrong_header_is_refused(tmp_path):
    from openpyxl import Workbook

    workbook = Workbook()
    workbook.active.append(["RE Number", *[f"CP{i}" for i in range(1, 41)]])
    workbook.save(tmp_path / "bad.xlsx")
    with pytest.raises(SubmissionError, match="header"):
        assemble_submission(
            [], [], template_path=tmp_path / "bad.xlsx", output_path=tmp_path / "out.xlsx"
        )


def test_case_count_gate(tmp_path):
    cases = [_Case("c1", "RE-1")]
    with pytest.raises(SubmissionError, match="expected 100 cases"):
        assemble_submission(
            _full_verdicts(cases),
            cases,
            template_path=_template(tmp_path / "t.xlsx"),
            output_path=tmp_path / "out.xlsx",
        )


def test_verify_rejects_a_hand_edited_blank(tmp_path):
    """verify_submission exists to be runnable on a file someone touched by hand,
    which is exactly when a blank cell appears."""

    from openpyxl import load_workbook

    cases = [_Case("c1", "RE-1")]
    assemble_submission(
        _full_verdicts(cases),
        cases,
        template_path=_template(tmp_path / "t.xlsx"),
        output_path=tmp_path / "out.xlsx",
        expected_cases=None,
    )
    workbook = load_workbook(tmp_path / "out.xlsx")
    workbook.active.cell(2, 5).value = None
    workbook.save(tmp_path / "out.xlsx")
    with pytest.raises(SubmissionError, match="gradeable"):
        verify_submission(tmp_path / "out.xlsx", expect_rows=2)


def test_verify_rejects_an_out_of_vocabulary_verdict(tmp_path):
    cases = [_Case("c1", "RE-1")]
    verdicts = _full_verdicts(cases)
    verdicts[0] = _verdict("CP1", "TRUE", case_id="c1")
    with pytest.raises(SubmissionError, match="not one of"):
        assemble_submission(
            verdicts,
            cases,
            template_path=_template(tmp_path / "t.xlsx"),
            output_path=tmp_path / "out.xlsx",
            expected_cases=None,
        )
