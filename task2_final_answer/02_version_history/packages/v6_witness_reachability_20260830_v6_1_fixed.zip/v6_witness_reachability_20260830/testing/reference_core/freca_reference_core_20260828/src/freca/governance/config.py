"""Strict six-mode Layer 0 configuration."""

from __future__ import annotations

import tomllib
from enum import StrEnum
from pathlib import Path
from typing import Any, Literal
from urllib.parse import urlsplit

from pydantic import Field, field_validator, model_validator

from freca.domain.models import Sha256, StrictModel
from freca.governance.hashing import sha256_digest


class RunMode(StrEnum):
    POLICY_BUILD = "POLICY_BUILD"
    DIAGNOSTIC = "DIAGNOSTIC"
    PRODUCTION = "PRODUCTION"
    EXPERIMENT = "EXPERIMENT"
    RESPONSE_REPLAY = "RESPONSE_REPLAY"
    SUBMISSION_BUILD = "SUBMISSION_BUILD"


class SourceExpectations(StrictModel):
    rules_pdf_sha256: Sha256
    cp_xlsx_sha256: Sha256
    evidence_manifest_sha256: Sha256
    task_governance_sha256: Sha256 | None = None
    submission_template_sha256: Sha256 | None = None
    evidence_file_count: int = Field(default=898, ge=1)
    allowed_evidence_extensions: frozenset[str] = frozenset({".docx", ".xlsx"})
    ignored_patterns: tuple[str, ...] = (".DS_Store", "__MACOSX/**")

    @field_validator("allowed_evidence_extensions")
    @classmethod
    def normalize_extensions(cls, value: frozenset[str]) -> frozenset[str]:
        normalized = frozenset(item.lower() for item in value)
        if any(not item.startswith(".") for item in normalized):
            raise ValueError("allowed extensions must begin with a dot")
        return normalized


class InputPaths(StrictModel):
    task_root: str
    rules_pdf: str
    official_cp_xlsx: str
    case_root: str
    task_governance: str | None = None
    submission_template: str | None = None

    @model_validator(mode="before")
    @classmethod
    def accept_documented_task_description_name(cls, value: Any) -> Any:
        if not isinstance(value, dict):
            return value
        data = dict(value)
        if "task_description" in data:
            if "task_governance" in data:
                raise ValueError("use only one of task_description/task_governance")
            data["task_governance"] = data.pop("task_description")
        return data


class ModelSpec(StrictModel):
    role: Literal["POLICY_EXTRACTOR", "EVIDENCE_READER", "RERANKER", "TEAM_B"]
    backend: Literal["fake", "none", "openai_compatible", "vllm", "ollama"]
    provider_id: str = Field(default="local", min_length=1)
    requested_model: str = Field(min_length=1)
    expected_returned_model: str | None = None
    base_url: str | None = None
    api_key_env: str = Field(min_length=1)
    temperature: float = Field(default=0.0, ge=0.0)
    top_p: float = Field(default=1.0, gt=0.0, le=1.0)
    max_tokens: int = Field(gt=0)
    seed: int | None = None
    timeout_s: int = Field(gt=0)

    @field_validator("base_url")
    @classmethod
    def url_cannot_contain_secrets(cls, value: str | None) -> str | None:
        if value is None:
            return value
        parsed = urlsplit(value)
        if parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError("base_url cannot contain userinfo, query, or fragment")
        return value

    def fingerprint(self) -> dict[str, Any]:
        return {
            "role": self.role,
            "backend": self.backend,
            "provider_id": self.provider_id,
            "requested_model": self.requested_model,
            "expected_returned_model": self.expected_returned_model,
            "temperature": self.temperature,
            "top_p": self.top_p,
            "max_tokens": self.max_tokens,
            "seed": self.seed,
            "timeout_s": self.timeout_s,
        }


class ReproducibilityConfig(StrictModel):
    prompt_root: str = "prompts"
    prompt_bundle_version: str = Field(min_length=1)
    method_policy_bundle_sha256: Sha256
    allow_dirty_worktree: bool = False
    cache_policy: Literal["READ_WRITE", "READ_ONLY", "DISABLED"]
    atomic_writes: bool = True
    verify_inputs_at_end: bool = True


class OutputConfig(StrictModel):
    run_root: str
    run_id: str | None = None
    resume: bool = False
    write_submission: bool = False


class RunConfig(StrictModel):
    schema_version: Literal["freca.run-config.v1"] = "freca.run-config.v1"
    mode: RunMode
    inputs: InputPaths
    expected: SourceExpectations
    models: list[ModelSpec] = Field(default_factory=list)
    reproducibility: ReproducibilityConfig
    output: OutputConfig

    @model_validator(mode="after")
    def enforce_mode_and_path_boundaries(self) -> RunConfig:
        if self.output.resume and not self.output.run_id:
            raise ValueError("resume=true requires an explicit run_id")
        if self.mode is RunMode.SUBMISSION_BUILD:
            if not self.output.write_submission:
                raise ValueError("SUBMISSION_BUILD requires write_submission=true")
            if self.models:
                raise ValueError("SUBMISSION_BUILD cannot call models")
        if self.mode is not RunMode.DIAGNOSTIC and any(
            model.backend in {"fake", "none"} for model in self.models
        ):
            raise ValueError(f"{self.mode.value} cannot use fake/none model backends")
        if self.mode is not RunMode.DIAGNOSTIC and self.expected.evidence_file_count != 898:
            raise ValueError("official non-diagnostic runs require exactly 898 evidence files")
        if self.expected.task_governance_sha256 and not self.inputs.task_governance:
            raise ValueError("task_governance_sha256 requires a task governance source")
        if self.expected.submission_template_sha256 and not self.inputs.submission_template:
            raise ValueError("submission_template_sha256 requires a submission template")

        task_root = Path(self.inputs.task_root).resolve()
        case_root = _resolve_from(task_root, self.inputs.case_root)
        run_root = Path(self.output.run_root).resolve()
        if _contains(task_root, run_root) or _contains(case_root, run_root):
            raise ValueError("run_root cannot be inside task_root or case_root")
        if _contains(run_root, task_root) or _contains(run_root, case_root):
            raise ValueError("input roots cannot be inside run_root")
        return self


def load_run_config(path: str | Path) -> RunConfig:
    config_path = Path(path).resolve(strict=True)
    with config_path.open("rb") as stream:
        raw = tomllib.load(stream)
    _reject_secret_fields(raw)
    return RunConfig.model_validate(raw)


def semantic_config(config: RunConfig) -> dict[str, Any]:
    """Return inference-relevant settings without machine-local output paths."""
    return {
        "schema_version": config.schema_version,
        "mode": config.mode.value,
        "inputs": {
            "rules_pdf": config.inputs.rules_pdf,
            "official_cp_xlsx": config.inputs.official_cp_xlsx,
            "case_root": config.inputs.case_root,
            "task_governance": config.inputs.task_governance,
            "submission_template": config.inputs.submission_template,
        },
        "expected": config.expected,
        "models": sorted(
            (model.fingerprint() for model in config.models),
            key=lambda item: (item["role"], item["provider_id"], item["requested_model"]),
        ),
        "reproducibility": config.reproducibility.model_dump(exclude={"prompt_root"}),
    }


def semantic_config_sha256(config: RunConfig) -> str:
    return sha256_digest(semantic_config(config))


def _reject_secret_fields(value: Any, path: tuple[str, ...] = ()) -> None:
    if isinstance(value, dict):
        for key, item in value.items():
            normalized = str(key).casefold()
            if normalized in {"api_key", "token", "secret", "password"}:
                location = ".".join((*path, str(key)))
                raise ValueError(f"literal secret field is forbidden in config: {location}")
            _reject_secret_fields(item, (*path, str(key)))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            _reject_secret_fields(item, (*path, str(index)))


def _resolve_from(task_root: Path, value: str) -> Path:
    path = Path(value)
    return (task_root / path).resolve() if not path.is_absolute() else path.resolve()


def _contains(parent: Path, child: Path) -> bool:
    return child == parent or child.is_relative_to(parent)
