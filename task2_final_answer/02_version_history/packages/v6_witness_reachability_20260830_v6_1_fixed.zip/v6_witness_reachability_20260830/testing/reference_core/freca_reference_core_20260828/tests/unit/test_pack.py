"""Tests for R1 PolicyPack construction.

Every case below encodes a defect that was found by running the extractor over
the real 2021 compilation, not a behaviour imagined in advance. The docstrings
name the provision that produced each failure so that a future change which
"simplifies" one of these rules can see what it would reintroduce.

Fixtures are built in-process from hand-written text that mirrors the drafting
shape at issue. The real PDF is deliberately not loaded here: these are unit
tests of the parser's rules, and an end-to-end probe over the instrument is a
separate concern (it needs poppler and the dataset, neither of which belongs in
a unit test).
"""

from __future__ import annotations

import pytest

from freca.domain.policy_enums import ActorRole, NormScope, SubjectResolution
from freca.policy.anchor import CheckingPoint
from freca.policy.norm_graph import NormGraph, subjects_named_in
from freca.policy.pack import (
    Voice,
    extract_pack,
    resolve_subject,
    segment_obligations,
)
from freca.policy.sectionize import NormSection


def _section(
    section_id: str,
    title: str,
    body: str,
    *,
    chapter: tuple[str, str] = ("4", "Registered establishments"),
    part: tuple[str, str] = ("1", "Conditions of registration"),
) -> NormSection:
    return NormSection(
        section_id=section_id,
        title=title,
        chapter_no=chapter[0],
        chapter_title=chapter[1],
        part_no=part[0],
        part_title=part[1],
        division_no=None,
        division_title=None,
        lines=body.strip("\n").split("\n"),
    )


def _cp(cp_id: str, text: str, *, subsection: str = "") -> CheckingPoint:
    return CheckingPoint(cp_id=cp_id, element="E1", subsection=subsection, text=text)


# -- segmentation ------------------------------------------------------------


def test_example_does_not_yield_an_obligation():
    """An Example is not an operative provision, so its "must" is not a duty.

    Acts Interpretation Act 1901 s 15AD treats examples as illustrative only. The
    extractor previously mined s 4-7A(1)'s own Example and attributed a
    monitoring requirement to the section, which is a rule the instrument does
    not impose.
    """

    body = """
    (1) A registered establishment must be maintained in good repair.
        Example: Materials at the establishment must be monitored for contamination.
    """
    units = segment_obligations("4-7A", body.strip("\n").split("\n"))
    paths = [unit.path for unit in units]
    assert paths == ["(1)"]
    assert "monitored" not in units[0].action


def test_out_dented_list_members_are_siblings_not_descendants():
    """Page breaks re-indent lists, which produced the path ``(2)(a)(d)``.

    The compilation restarts indentation after a page break, so ``(d)`` appeared
    to be a child of ``(a)``. A path is used to address a duty, so a wrong path
    cites the wrong provision even when the text is right.
    """

    body = """
    (2) An establishment must have:
          (a) a floor that can be cleaned; and
          (b) walls that can be cleaned; and
      (c) lighting that is adequate; and
      (d) ventilation that is adequate.
    """
    units = segment_obligations("4-7A", body.strip("\n").split("\n"))
    paths = {unit.path for unit in units}
    assert "(2)(a)(d)" not in paths
    # Only (2) carries the modal; the paragraphs complete it rather than
    # restating it, so they are not separate deontic units.
    assert paths == {"(2)"}


def test_non_adjacent_label_is_not_rescued_as_a_sibling():
    """Sibling rescue must require adjacency, or nesting collapses entirely.

    Without the adjacency test, any out-dented label would be promoted to a peer
    and genuine sub-paragraph structure would be lost. ``(a)`` then ``(c)`` skips
    a letter, so ``(c)`` is not ``(a)``'s successor.

    Note what the parser does here and why it is right: ``(c)`` is out-dented
    relative to ``(a)``, so the indentation stack pops ``(a)`` and ``(c)`` lands
    as a *child of (2)* — a peer of ``(a)`` by depth, reached without the rescue.
    The rescue only matters when the successor is out-dented past its own parent,
    which is what a page break causes. Asserting ``(2)(a)(c)`` here would assert
    the bug the indentation stack already prevents.
    """

    body = """
    (2) An establishment must comply with the following:
          (a) it must be clean; and
      (c) it must be secure.
    """
    units = segment_obligations("4-7A", body.strip("\n").split("\n"))
    paths = {unit.path for unit in units}
    assert paths == {"(2)", "(2)(a)", "(2)(c)"}
    assert "(2)(a)(c)" not in paths


# -- voice and the object slot ----------------------------------------------


def test_passive_object_is_read_before_the_modal():
    """The passive promotes the duty's object into subject position.

    s 4-7A(2)(d) reads "the establishment must be appropriately treated", so the
    thing treated sits *before* "must". Reading forward here yielded
    "appropriately treated" as the object, which names the act, not its object.
    """

    body = "(2) The floors of the establishment must be appropriately treated."
    units = segment_obligations("4-7A", [body])
    assert units[0].voice is Voice.PASSIVE
    assert "establishment" in units[0].obligation_object
    assert "treated" not in units[0].obligation_object


def test_existential_object_is_read_after_the_modal():
    """"There must be X" puts the object after the modal, unlike the passive.

    The dummy subject "there" carries no content, so the passive's backward read
    would return the empty string or the previous sentence's tail.
    """

    body = "(3) There must be a system of controls for the establishment."
    units = segment_obligations("4-8", [body])
    assert units[0].voice is Voice.EXISTENTIAL
    assert "system of controls" in units[0].obligation_object


def test_active_object_excludes_the_modal():
    """Slicing from the start of the deontic match put "must" inside the object."""

    body = "(1) The occupier must keep a record of each treatment."
    units = segment_obligations("11-7", [body])
    assert units[0].voice is Voice.ACTIVE
    assert not units[0].obligation_object.lower().startswith("must")
    assert "record" in units[0].obligation_object


def test_adverb_between_auxiliary_and_participle_is_still_passive():
    """"must be appropriately treated" was misread as ACTIVE.

    Voice decides which side of the modal the object lives on, so a voice error
    silently corrupts the object slot rather than announcing itself.
    """

    assert segment_obligations("x", ["(1) It must be appropriately treated."])[0].voice is Voice.PASSIVE
    assert segment_obligations("x", ["(1) It must be treated."])[0].voice is Voice.PASSIVE


def test_bare_may_is_not_an_obligation():
    """A permission is not a duty; mining it would invent a requirement."""

    assert segment_obligations("x", ["(1) The occupier may keep a copy."]) == []


def test_relative_clause_modal_is_not_mistaken_for_the_duty():
    """s 11-2(1) qualifies its subject with a modal before imposing the real one.

    "A record **that is required to** be retained under this Part ... **must
    be**:" — the first modal says which records the section governs, the second
    imposes the duty. Taking the first turned the scope test into the obligation.
    Measured: 6 of 204 deontic units in the 2021 compilation have this shape.
    """

    body = (
        "(1) A record that is required to be retained under this Part must be "
        "accurate and legible."
    )
    unit = segment_obligations("11-2", [body])[0]
    assert unit.deontic == "must"
    assert unit.action.startswith("must be")
    assert "required to be retained" not in unit.action


def test_lone_is_required_to_is_still_an_obligation():
    """The skip must not fire when there is no later modal to fall back on.

    Several duties in Chapter 11 are drafted with "is required to" as their main
    verb; discarding those would lose the obligation entirely.
    """

    unit = segment_obligations("11-9", ["(1) The occupier is required to keep the record."])[0]
    assert unit.deontic == "is required to"


def test_chapeau_absorbs_its_paragraphs():
    """A chapeau ends in a colon and states no requirement by itself.

    s 11-2(1) says a record "must be:" with the content in (a)-(d), and those
    paragraphs carry no modal so they yield no unit of their own. Without this the
    duty reduced to "must be: is present and complete" — a fact naming nothing a
    retriever could look for. Measured: 56 of 204 deontic units are chapeaux.
    """

    body = """
    (1) A record must be:
          (a) in English; and
          (b) dated; and
          (c) accurate, legible and able to be audited.
    """
    units = segment_obligations("11-2", body.strip("\n").split("\n"))
    assert [unit.path for unit in units] == ["(1)"]
    action = units[0].action
    assert "in English" in action and "dated" in action and "legible" in action
    # Labels are retained so a reviewer can still tell the limbs apart.
    assert "(a)" in action and "(c)" in action


# -- subject resolution ------------------------------------------------------


def _graph_with(*sections: NormSection) -> NormGraph:
    return NormGraph({section.section_id: section for section in sections})


def test_direct_subject_uses_the_statutes_own_phrase():
    section = _section(
        "11-7",
        "Records of treatment",
        "(1) The occupier of a registered establishment must keep records of treatment.",
        chapter=("11", "Records"),
        part=("1", "Records"),
    )
    graph = _graph_with(section)
    finding = resolve_subject(graph.nodes["11-7"], ActorRole.OCCUPIER)
    assert finding.resolution is SubjectResolution.DIRECT
    assert "occupier" in finding.phrase
    assert finding.review_required is False


def test_impersonal_provision_still_yields_a_subject_but_flags_review():
    """The conditions of registration name no actor at all.

    Rejecting these as unfilled discarded 29 of 41 checking points — the same
    over-pruning error anchor config PB makes. The uncertainty is recorded
    instead of hidden, which is why ``review_required`` must be true here.
    """

    section = _section(
        "4-2",
        "Conditions of registration",
        "(2) An establishment must be designed so that it can be kept clean.",
    )
    graph = _graph_with(section)
    node = graph.nodes["4-2"]
    assert node.subjects == set()
    unit = segment_obligations("4-2", section.lines)[0]
    finding = resolve_subject(node, ActorRole.OCCUPIER, unit=unit)
    assert finding.phrase
    assert finding.resolution is SubjectResolution.UNRESOLVED
    assert finding.review_required is True


def test_shared_cue_table_is_used_by_both_levels():
    """Section-level and unit-level subject detection must not drift apart."""

    assert subjects_named_in("the occupier of the registered establishment must") == {
        ActorRole.OCCUPIER
    }
    assert subjects_named_in("the manager of the accredited property must") == {ActorRole.MANAGER}
    # A duty owed *to* the Secretary is not a duty owed *by* her.
    assert subjects_named_in("the occupier must notify the Secretary") == {ActorRole.OCCUPIER}


# -- pack assembly -----------------------------------------------------------


def test_pack_span_text_hashes_to_source_hash():
    """Truncating the span text made every span fail an independent hash check.

    The span is the audit trail's link back to the instrument; if its text does
    not hash to the recorded digest, a verifier cannot confirm the pack was built
    from the document it cites.
    """

    import hashlib

    section = _section(
        "11-7",
        "Records of treatment",
        "(1) The occupier of a registered establishment must keep records of treatment.",
        chapter=("11", "Records"),
        part=("1", "Records"),
    )
    graph = _graph_with(section)
    extraction = extract_pack(
        checking_point=_cp("CP1", "records of treatment are kept"),
        anchor_section_ids=["11-7"],
        graph=graph,
        policy_version="2021",
    )
    assert extraction.adjudicable
    for span in extraction.pack.authoritative_spans:
        digest = hashlib.sha256(span.text.encode("utf-8")).hexdigest()
        assert span.source_hash == f"sha256:{digest}"


def test_section_level_config_selects_exactly_one_unit():
    """The discarded one-rule-per-section design stays runnable for ablation."""

    section = _section(
        "4-7A",
        "Hygiene",
        """
    (2) An establishment must be operated so that:
          (a) all areas are kept in a clean condition; and
          (b) all areas are maintained in a hygienic condition.
        """,
    )
    graph = _graph_with(section)
    cp = _cp("CP24", "All areas of the establishment are clean and hygienic")
    per_section = extract_pack(
        checking_point=cp,
        anchor_section_ids=["4-7A"],
        graph=graph,
        policy_version="2021",
        config="section_level",
    )
    assert len(per_section.chosen_unit_ids) == 1


def test_conjunctive_checking_point_gets_every_matching_paragraph():
    """CP24 is tested against 4-7A(2)(a) *and* (2)(b).

    A pack built from one paragraph asks a narrower question than the checking
    point does, and would call a farm compliant on half the requirement.
    """

    section = _section(
        "4-7A",
        "Hygiene",
        """
    (1) A registered establishment must be operated as follows.
          (a) all areas of the establishment must be kept in a clean condition;
          (b) all areas of the establishment must be maintained in a hygienic condition;
        """,
    )
    graph = _graph_with(section)
    cp = _cp("CP24", "All areas of the establishment are operated and maintained in a clean and hygienic condition")
    extraction = extract_pack(
        checking_point=cp,
        anchor_section_ids=["4-7A"],
        graph=graph,
        policy_version="2021",
        config="unit_level",
    )
    assert extraction.adjudicable
    assert len(extraction.chosen_unit_ids) > 1
    facts = " ".join(extraction.pack.required_facts)
    assert "clean" in facts and "hygienic" in facts


def test_companion_governed_by_another_role_is_excluded_and_recorded():
    """A pack has one subject slot, so merging another role reassigns the duty.

    Measured on the real instrument: CP23 and CP40 paired s 11-2(1) (occupier)
    with s 8-8(4)(b), whose requirement falls on the translator. The section-level
    gate cannot catch this because s 8-8 does address occupiers elsewhere.
    """

    home = _section(
        "11-2",
        "Records to be kept",
        "(1) The occupier of the registered establishment is required to keep the record of the treatment.",
        chapter=("11", "Records"),
        part=("1", "Records"),
    )
    foreign = _section(
        "8-8",
        "Translations of records",
        "(4) The translation of the record of the treatment must be made available to the Secretary.",
        chapter=("8", "Trade descriptions"),
        part=("2", "Trade descriptions"),
    )
    graph = _graph_with(home, foreign)
    extraction = extract_pack(
        checking_point=_cp("CP23", "the record of the treatment is kept"),
        anchor_section_ids=["11-2", "8-8"],
        graph=graph,
        policy_version="2021",
        config="unit_level",
    )
    assert extraction.adjudicable
    # Precondition: the companion must actually be in contention, or this test
    # would pass for the wrong reason — a low BM25 score rather than the filter.
    scores = dict(extraction.unit_scores)
    assert scores["8-8(4)"] >= scores["11-2(1)"] * 0.55
    assert not any(uid.startswith("8-8") for uid in extraction.chosen_unit_ids)
    assert any(uid.startswith("8-8") for uid, _ in extraction.rejected_companions)


def test_unnamed_companion_is_admitted():
    """Silence is not conflict — the conditions of registration name no actor.

    Treating an unnamed paragraph as incompatible would dissolve exactly the
    conjunctive packs that multi-unit selection exists to build.
    """

    section = _section(
        "4-2",
        "Conditions of registration",
        """
    (2) An establishment must be designed so that it can be kept clean.
    (3) An establishment must be constructed of materials that can be cleaned.
        """,
    )
    graph = _graph_with(section)
    extraction = extract_pack(
        checking_point=_cp("CP10", "the establishment is designed and constructed so it can be cleaned"),
        anchor_section_ids=["4-2"],
        graph=graph,
        policy_version="2021",
        config="unit_level",
    )
    assert extraction.adjudicable
    assert extraction.rejected_companions == []


def test_must_not_becomes_a_violation_fact_not_a_requirement():
    """Sign errors invert the verdict, which is the worst failure available."""

    section = _section(
        "1-8",
        "Prohibited conduct",
        "(6) The occupier of the registered establishment must not tamper with the seal.",
        chapter=("1", "Preliminary"),
        part=("2", "Preliminary"),
    )
    graph = _graph_with(section)
    extraction = extract_pack(
        checking_point=_cp("CP33", "the seal has not been tampered with"),
        anchor_section_ids=["1-8"],
        graph=graph,
        policy_version="2021",
    )
    assert extraction.adjudicable
    assert extraction.pack.violation_facts
    assert not extraction.pack.required_facts


def test_facts_cite_the_unit_that_produced_them():
    """A fact whose provenance is only "the section" cannot be re-checked."""

    section = _section(
        "4-2",
        "Conditions of registration",
        "(2) An establishment must be designed so that it can be kept clean.",
    )
    graph = _graph_with(section)
    extraction = extract_pack(
        checking_point=_cp("CP10", "the establishment is designed so it can be cleaned"),
        anchor_section_ids=["4-2"],
        graph=graph,
        policy_version="2021",
    )
    assert all("[4-2(2)]" in fact for fact in extraction.pack.required_facts)


def test_no_deontic_statement_refuses_to_emit_a_pack():
    """Half a rule adjudicated confidently is worse than an abstention.

    CP2 hits this on the real instrument: its anchors contain no duty at all.
    """

    section = _section(
        "4-17",
        "Variation of registration",
        "(1) The Secretary may vary the registration of an establishment.",
    )
    graph = _graph_with(section)
    extraction = extract_pack(
        checking_point=_cp("CP2", "the establishment holds a current registration"),
        anchor_section_ids=["4-17"],
        graph=graph,
        policy_version="2021",
    )
    assert not extraction.adjudicable
    assert extraction.unfilled_slots
    # No pack object at all, rather than an empty one: an abstention must be
    # impossible to mistake for a verdict downstream.
    assert extraction.pack is None


def test_model_paraphrase_is_rejected_not_silently_accepted():
    """A slot value that is not a substring of the provision is not grounded.

    This is VeriCoT's grounding check applied one stage earlier: the rejection
    rate is a measurable quantity, so paraphrase becomes visible rather than
    becoming a fabricated citation.
    """

    from freca.llm.backends import FakeJSONLLM

    class Paraphraser(FakeJSONLLM):
        """A backend that answers plausibly but not verbatim.

        Subclassing the offline fake keeps the reproducibility fields
        (prompt hash, model name, config fingerprint) intact, so the test
        exercises the grounding check rather than the response plumbing.
        """

        def complete(self, system: str, user: str):
            response = super().complete(system, user)
            response.text = (
                '{"subject": "the farm owner", "deontic": "must", '
                '"action": "keep the place tidy", "object": "the premises"}'
            )
            return response

    section = _section(
        "4-2",
        "Conditions of registration",
        # Existential drafting with no stated duty-holder and a modal the object
        # pattern cannot fill from, so the model is actually consulted. Asking the
        # model when nothing is missing would not exercise the grounding check at
        # all — ``_model_fill`` returns early in that case.
        "(2) There must be.",
    )
    graph = _graph_with(section)
    extraction = extract_pack(
        checking_point=_cp("CP10", "the establishment is designed so it can be cleaned"),
        anchor_section_ids=["4-2"],
        graph=graph,
        policy_version="2021",
        backend=Paraphraser(),
        config="unit_level_model_assisted",
    )
    # Only ``object`` is offered to the model here: the scope fallback already
    # filled ``subject`` deterministically from the chapter's regulated object, so
    # the model is never asked for it. That is the intended order of authority —
    # the model fills gaps, it does not compete with the statute.
    assert extraction.model_rejected == ["object=the premises"]
    # The pack still stands, but on the deterministic scope fallback rather than on
    # anything the model supplied: rejection degrades the pack, it does not void it.
    assert extraction.adjudicable
    assert "farm owner" not in extraction.pack.rule_slots.subject
    assert "tidy" not in extraction.pack.rule_slots.action
    assert extraction.review_required


def test_model_abstention_is_distinguished_from_paraphrase():
    """"Would not answer" and "answered with a paraphrase" are different failures.

    The offline fake answers from a hash of the prompt and so never returns the
    requested keys — correct behaviour for it, since inventing statutory text
    would be worse. But if an abstention were recorded as nothing at all, a fake
    run would be indistinguishable from a clean one. Measured on the real
    instrument: the model is consulted on 2 of 41 checking points and abstains on
    both, so the grounding check is in fact untested until a real backend is
    configured — a fact the run summary must state rather than imply.
    """

    from freca.llm.backends import FakeJSONLLM

    section = _section("4-2", "Conditions of registration", "(2) There must be.")
    graph = _graph_with(section)
    extraction = extract_pack(
        checking_point=_cp("CP10", "the establishment is designed so it can be cleaned"),
        anchor_section_ids=["4-2"],
        graph=graph,
        policy_version="2021",
        backend=FakeJSONLLM(),
        config="unit_level_model_assisted",
    )
    assert extraction.model_consulted
    assert extraction.model_abstained
    assert extraction.model_rejected == []


def test_model_is_not_consulted_when_every_slot_is_filled():
    """A config that never asks must not be reported as one that answered well."""

    from freca.llm.backends import FakeJSONLLM

    section = _section(
        "11-7",
        "Records of treatment",
        "(1) The occupier of a registered establishment must keep records of treatment.",
        chapter=("11", "Records"),
        part=("1", "Records"),
    )
    graph = _graph_with(section)
    extraction = extract_pack(
        checking_point=_cp("CP39", "records of treatment are kept"),
        anchor_section_ids=["11-7"],
        graph=graph,
        policy_version="2021",
        backend=FakeJSONLLM(),
        config="unit_level_model_assisted",
    )
    assert extraction.adjudicable
    assert extraction.model_consulted is False
