"""C0-C7: the per-checking-point adjudication loop with a gate after every step.

The teacher's second point, taken literally
-------------------------------------------
"每个步骤可能需要加一个复核，因为一个步骤本身如果出现问题了那么这个问题会层层传递."
A gate after every node is only useful if the gate can *fail the run* rather than
annotate it. So each node here returns ``(payload, GateReport)`` and the loop
stops on ``BLOCK``, retries once on ``RETRY`` with a **different** retrieval, and
marks ``review_required`` on ``ESCALATE``. A node whose gate never fails is a node
that is not being checked, and is called out as such in the trace.

Node map
--------
======  ====================================================================
``C0``  Bind the checking point to its policy anchor (from the R-chain) and
        assert the anchor is subject-compatible. Gate: scope/subject.
``C1``  Decide applicability. The three-way rule is asymmetric on purpose —
        UNKNOWN applicability may not become N/A, because N/A requires
        *explicit* non-applicability in the statute (frozen decision).
``C2``  Formulate retrieval needs from the policy pack's required facts.
``C3``  Retrieve per need. Gate: at least one candidate, diversity satisfied.
``C4``  Assemble a typed audit argument over what was actually retrieved.
``C5``  Validate it deterministically (``ArgumentValidator``). Gate: the real one.
``C6``  Retry once on a retryable issue, using the issue's ``RetrievalNeed`` —
        never the same query again, which would be an unlogged second guess.
``C7``  Emit a ``FinalDecision`` whose invariants the domain model enforces.
======  ====================================================================

Why the LLM is optional here
----------------------------
``adjudicate`` accepts an ``LLMBackend`` but has a deterministic fallback. This is
not a convenience: it makes the *harness* measurable on its own. If the offline
run and the model run produce the same accuracy, the model is not contributing and
the finding is about plumbing. Any run using the fake backend is stamped
``synthetic`` in every artefact so the two can never be confused.

Competition constraint honoured throughout: no compliance rule is written into
any prompt or into this file. Requirements come from ``PolicyPack`` objects
derived from the statute text; this module only checks *structure*.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from collections.abc import Mapping
from typing import Any

from freca.domain.enums import (
    Applicability,
    ClaimRelation,
    ClaimType,
    DecisionBasis,
    EvidenceIdentityState,
    FinalLabel,
    GateDecision,
    GateSeverity,
    PremiseSourceType,
    Sufficiency,
    VerificationIssueCode,
)
from freca.domain.models import (
    AuditArgument,
    AuditClaim,
    ClaimPremise,
    FinalDecision,
    GateReport,
    PolicyPack,
    RetrievalNeed,
    VerificationIssue,
)
from freca.domain.policy_enums import ActorRole, MissingEvidenceCause, NormScope
from freca.audit.nodes.farm_profile import FarmProfile
from freca.llm.backends import LLMBackend, LLMError
from freca.policy.norm_graph import NormGraph
from freca.retrieval.evidence_index import (
    EVIDENCE_CONFIGS,
    CaseEvidenceIndex,
    RetrievalConfig,
    RetrievalTrace,
    build_query,
)
from freca.verification.argument_validator import ArgumentValidator, ValidationContext

#: A retryable gate gets exactly one second attempt. Unbounded retry turns a
#: reasoning failure into a token-budget failure and hides which one occurred.
MAX_REPAIRS = 1


def _pass(gate_id: str, name: str) -> GateReport:
    return GateReport(
        gate_id=gate_id,
        gate_name=name,
        decision=GateDecision.PASS,
        severity=GateSeverity.SOFT,
    )


def _fail(
    gate_id: str,
    name: str,
    decision: GateDecision,
    issues: list[VerificationIssue],
) -> GateReport:
    return GateReport(
        gate_id=gate_id,
        gate_name=name,
        decision=decision,
        severity=GateSeverity.HARD,
        issues=issues,
    )


@dataclass(slots=True)
class NodeTrace:
    """One node's outcome. Persisted so a wrong verdict is attributable to a step."""

    node: str
    gate: GateReport
    detail: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "node": self.node,
            "decision": self.gate.decision.value,
            "issues": [issue.model_dump(mode="json") for issue in self.gate.issues],
            "detail": self.detail,
        }


@dataclass(slots=True)
class AdjudicationResult:
    case_id: str
    cp_id: str
    decision: FinalDecision | None
    traces: list[NodeTrace] = field(default_factory=list)
    retrieval: list[RetrievalTrace] = field(default_factory=list)
    blocked_at: str | None = None
    synthetic: bool = False

    @property
    def gate_reports(self) -> list[GateReport]:
        return [trace.gate for trace in self.traces]

    @property
    def label(self) -> str:
        """Submission cell value. A blocked decision is *not* silently a 0."""

        return self.decision.label.value if self.decision else ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "case_id": self.case_id,
            "cp_id": self.cp_id,
            "label": self.label,
            "blocked_at": self.blocked_at,
            "synthetic": self.synthetic,
            "decision": self.decision.model_dump(mode="json") if self.decision else None,
            "traces": [trace.to_dict() for trace in self.traces],
            "retrieval": [trace.to_dict() for trace in self.retrieval],
        }


# --------------------------------------------------------------------------
# C0 - anchor binding
# --------------------------------------------------------------------------


def c0_bind_anchor(
    *,
    cp_id: str,
    anchor_section_ids: list[str],
    graph: NormGraph,
) -> tuple[list[str], GateReport]:
    """Keep only anchors compatible with an occupier of a registered establishment.

    Chapter 3 (MANAGER of an accredited property) is worded almost identically to
    Chapter 4, so a lexically perfect anchor can still be the wrong obligation
    regime. That is the single largest measured mis-anchoring source, hence a gate
    at step zero rather than a filter buried in retrieval.
    """

    admitted: list[str] = []
    rejected: list[str] = []
    for section_id in anchor_section_ids:
        node = graph.nodes.get(section_id)
        if node is None:
            rejected.append(section_id)
            continue
        if node.scope not in (NormScope.REGISTERED_ESTABLISHMENT, NormScope.GENERAL):
            rejected.append(section_id)
            continue
        if node.subjects and ActorRole.OCCUPIER not in node.subjects:
            rejected.append(section_id)
            continue
        admitted.append(section_id)

    if admitted:
        return admitted, _pass(f"{cp_id}.c0", "anchor_scope_gate")

    return admitted, _fail(
        f"{cp_id}.c0",
        "anchor_scope_gate",
        GateDecision.ESCALATE,
        [
            VerificationIssue(
                issue_id=f"{cp_id}.c0.noanchor",
                code=VerificationIssueCode.UNGROUNDED,
                message=(
                    "no policy anchor survives the occupier/registered-establishment "
                    f"gate; rejected {rejected}"
                ),
                retryable=False,
            )
        ],
    )


# --------------------------------------------------------------------------
# C1 - applicability
# --------------------------------------------------------------------------


def c1_applicability(
    *,
    cp_id: str,
    pack: PolicyPack,
    profile: FarmProfile | Mapping[str, Any],
) -> tuple[Applicability, GateReport, list[str]]:
    """Three-way applicability, with A0 scope facts kept separate from law.

    ``scope_predicates`` are evaluated against the A0 profile.  An explicit
    negative farm fact reaches ``NOT_APPLICABLE``; a missing or conflicting fact
    reaches ``UNKNOWN`` and escalates for review.  ``explicit_legal_exemptions``
    remains a separate compatibility path for statutory exclusions and is never
    inferred from missing evidence.
    """

    profile_values = profile.scope_context() if isinstance(profile, FarmProfile) else dict(profile)
    scope_predicates = pack.scope_predicates or pack.applicability_predicates
    legal_exemptions = pack.explicit_legal_exemptions or pack.explicit_na_conditions

    def predicate_state(predicate: str) -> bool | None:
        """Return True/False/None for a profile-backed scope predicate."""

        direct = profile_values.get(predicate)
        if isinstance(direct, bool):
            return direct
        if direct is not None and not isinstance(direct, (list, tuple, set, dict)):
            return True if str(direct).strip().lower() in {"true", "yes", "applicable"} else None

        words = {
            word
            for word in predicate.lower().replace("/", " ").split()
            if len(word.strip(".,;:()")) >= 4
        }
        if not words:
            return None
        searchable: list[str] = []
        for value in profile_values.values():
            if isinstance(value, (list, tuple, set)):
                searchable.extend(str(item).lower() for item in value)
            elif isinstance(value, str):
                searchable.append(value.lower())
        if not searchable:
            return None

        positive = False
        negative = False
        for value in searchable:
            overlap = len(words & set(value.split()))
            if overlap < max(1, min(3, len(words))):
                continue
            if any(marker in value for marker in ("not registered", "not in scope", "does not", "no ")):
                negative = True
            else:
                positive = True
        if negative and not positive:
            return False
        if positive:
            return True
        return None

    if scope_predicates:
        scope_answers = [predicate_state(predicate) for predicate in scope_predicates]
        if any(answer is False for answer in scope_answers):
            matched = [
                predicate
                for predicate, answer in zip(scope_predicates, scope_answers, strict=True)
                if answer is False
            ]
            return Applicability.NOT_APPLICABLE, _pass(f"{cp_id}.c1", "applicability_gate"), matched
        if any(answer is None for answer in scope_answers):
            return (
                Applicability.UNKNOWN,
                _fail(
                    f"{cp_id}.c1",
                    "applicability_gate",
                    GateDecision.ESCALATE,
                    [
                        VerificationIssue(
                            issue_id=f"{cp_id}.c1.scope-unknown",
                            code=VerificationIssueCode.INSUFFICIENT,
                            message=(
                                "A0 does not establish every scope predicate; "
                                f"unresolved predicates {scope_predicates}"
                            ),
                            retryable=False,
                        )
                    ],
                ),
                [],
            )

    matched: list[str] = []
    unknown: list[str] = []
    for condition in legal_exemptions:
        # ``FarmProfile`` is the production boundary, while mappings remain
        # supported for old fixtures and hand-written packs.  Use the normalized
        # mapping in both cases: a typed profile must not fail only when a pack
        # happens to contain an explicit legal exemption.
        answer = profile_values.get(condition)
        if answer is True:
            matched.append(condition)
        elif answer is None:
            unknown.append(condition)

    if matched:
        return Applicability.NOT_APPLICABLE, _pass(f"{cp_id}.c1", "applicability_gate"), matched
    if unknown and not pack.required_facts:
        return (
            Applicability.UNKNOWN,
            _fail(
                f"{cp_id}.c1",
                "applicability_gate",
                GateDecision.ESCALATE,
                [
                    VerificationIssue(
                        issue_id=f"{cp_id}.c1.unknown",
                        code=VerificationIssueCode.INSUFFICIENT,
                        message=(
                            "applicability undetermined and the pack defines no required "
                            f"facts to fall back on; unresolved conditions {unknown}"
                        ),
                        retryable=False,
                    )
                ],
            ),
            [],
        )
    return Applicability.APPLICABLE, _pass(f"{cp_id}.c1", "applicability_gate"), []


# --------------------------------------------------------------------------
# C2 - need formulation
# --------------------------------------------------------------------------


def c2_needs(*, cp_id: str, pack: PolicyPack) -> tuple[list[RetrievalNeed], GateReport]:
    """Derive retrieval needs from the pack. One need per required/violation fact.

    Facets are the *policy's* words plus the rule slots, never a hand-written
    hint about what the answer should be — that would encode a compliance rule
    into the query and breach the human-involvement constraint.
    """

    needs = [
        RetrievalNeed(
            fact_type="required_fact",
            query_facets=[fact, pack.rule_slots.action, pack.rule_slots.object],
        )
        for fact in pack.required_facts
    ]
    needs.extend(
        RetrievalNeed(fact_type="violation_fact", query_facets=[fact, pack.rule_slots.object])
        for fact in pack.violation_facts
    )

    if needs:
        return needs, _pass(f"{cp_id}.c2", "need_formulation_gate")
    return needs, _fail(
        f"{cp_id}.c2",
        "need_formulation_gate",
        GateDecision.ESCALATE,
        [
            VerificationIssue(
                issue_id=f"{cp_id}.c2.noneed",
                code=VerificationIssueCode.UNTRANSLATABLE,
                message="policy pack yields no retrievable fact; nothing to check",
                retryable=False,
            )
        ],
    )


# --------------------------------------------------------------------------
# C3 - retrieval
# --------------------------------------------------------------------------


def c3_retrieve(
    *,
    cp_id: str,
    needs: list[RetrievalNeed],
    index: CaseEvidenceIndex,
    config: RetrievalConfig,
    config_name: str,
) -> tuple[list[RetrievalTrace], GateReport]:
    traces = [
        index.retrieve(build_query(*need.query_facets), config=config, config_name=config_name)
        for need in needs
    ]
    empty = [trace.query for trace in traces if not trace.selected]
    if not empty:
        return traces, _pass(f"{cp_id}.c3", "retrieval_gate")

    return traces, _fail(
        f"{cp_id}.c3",
        "retrieval_gate",
        GateDecision.RETRY,
        [
            VerificationIssue(
                issue_id=f"{cp_id}.c3.empty",
                code=VerificationIssueCode.INSUFFICIENT,
                message=f"{len(empty)} need(s) returned no candidate evidence",
                retryable=True,
                retrieval_need=RetrievalNeed(
                    fact_type="broadened", query_facets=[empty[0][:200] or cp_id]
                ),
            )
        ],
    )


# --------------------------------------------------------------------------
# C4 - argument assembly
# --------------------------------------------------------------------------


def _deterministic_findings(
    traces: list[RetrievalTrace], index: CaseEvidenceIndex
) -> tuple[list[str], list[str]]:
    """Split retrieved evidence into self-signed and foreign-signed ids.

    This is the offline stand-in for the model's evidence reading. It makes no
    claim about whether the content satisfies the requirement — only about who
    signed it, which is mechanically determinable.
    """

    self_signed: list[str] = []
    foreign: list[str] = []
    for trace in traces:
        for item in trace.selected:
            atom = index.atoms[item.evidence_id]
            target = (
                self_signed
                if atom.identity.state is EvidenceIdentityState.SELF
                else foreign
            )
            if item.evidence_id not in target:
                target.append(item.evidence_id)
    return self_signed, foreign


def c4_assemble(
    *,
    case_id: str,
    cp_id: str,
    pack: PolicyPack,
    anchors: list[str],
    applicability: Applicability,
    na_conditions: list[str],
    traces: list[RetrievalTrace],
    index: CaseEvidenceIndex,
    backend: LLMBackend | None,
) -> tuple[AuditArgument, GateReport, bool]:
    """Build the typed argument. Returns ``(argument, gate, synthetic)``."""

    self_signed, foreign = _deterministic_findings(traces, index)
    claims: list[AuditClaim] = [
        AuditClaim(
            claim_id="c-policy",
            claim_type=ClaimType.POLICY,
            proposition={
                "requirement": pack.rule_slots.action,
                "subject": pack.rule_slots.subject,
                "deontic": pack.rule_slots.deontic,
            },
            premises=[
                ClaimPremise(
                    source_type=PremiseSourceType.POLICY_SOURCE,
                    source_id=span.source_id,
                    relation=ClaimRelation.REQUIRES,
                )
                for span in pack.authoritative_spans
                if span.source_id in anchors or not anchors
            ]
            or [
                ClaimPremise(
                    source_type=PremiseSourceType.POLICY_SOURCE,
                    source_id=pack.authoritative_spans[0].source_id,
                    relation=ClaimRelation.REQUIRES,
                )
            ],
        )
    ]

    if applicability is Applicability.NOT_APPLICABLE:
        claims.append(
            AuditClaim(
                claim_id="c-applicability",
                claim_type=ClaimType.APPLICABILITY,
                proposition={"applicable": False, "conditions": na_conditions},
                premises=[
                    ClaimPremise(
                        source_type=PremiseSourceType.DETERMINISTIC_RESULT,
                        source_id="profile.na_conditions",
                        relation=ClaimRelation.EXCEPTS,
                    )
                ],
            )
        )
    else:
        claims.append(
            AuditClaim(
                claim_id="c-applicability",
                claim_type=ClaimType.APPLICABILITY,
                proposition={"applicable": applicability is Applicability.APPLICABLE},
                premises=[
                    ClaimPremise(
                        source_type=PremiseSourceType.DETERMINISTIC_RESULT,
                        source_id="profile.na_conditions",
                        relation=ClaimRelation.SUPPORTS,
                    )
                ],
            )
        )

    synthetic = True
    unread = False
    unlabelled_reply = False
    verdict = FinalLabel.NOT_APPLICABLE if applicability is Applicability.NOT_APPLICABLE else None
    sufficiency = Sufficiency.SUFFICIENT if verdict else Sufficiency.UNKNOWN

    if verdict is None:
        if backend is not None:
            reading, synthetic = _model_reading(
                backend=backend, pack=pack, traces=traces, index=index, cp_id=cp_id
            )
        else:
            reading = None

        if reading is not None:
            supported = [eid for eid in reading.get("supporting_evidence_ids", []) if eid in index.atoms]
            contrary = [eid for eid in reading.get("contrary_evidence_ids", []) if eid in index.atoms]
            claimed = str(reading.get("label", "")).strip()
            verdict = (
                FinalLabel(claimed)
                if claimed in {item.value for item in FinalLabel}
                else None
            )
        else:
            # No model reading was obtained. The previous behaviour here was
            # ``COMPLIANT if self_signed else NON_COMPLIANT`` — "the farm produced
            # its own paperwork, therefore it complied". Measured over three cases
            # that rule returned 1 for 98% of cells while every gate reported PASS,
            # because it is structurally valid and substantively empty.
            #
            # Whether a document *satisfies* a requirement is exactly the judgement
            # this node exists to make, and without a reading it has not been made.
            # So no substantive verdict is fabricated: the retrieved atoms are still
            # attached as evidence so the trail shows what was found, but the
            # argument carries no candidate label and C7 will refuse to emit one.
            supported, contrary = self_signed, []
            verdict = None
            unread = True

        if supported:
            claims.append(
                AuditClaim(
                    claim_id="c-evidence",
                    claim_type=ClaimType.EVIDENCE,
                    proposition={"fact": "; ".join(pack.required_facts)[:400] or pack.rule_slots.action},
                    premises=[
                        ClaimPremise(
                            source_type=PremiseSourceType.CASE_EVIDENCE,
                            source_id=evidence_id,
                            relation=ClaimRelation.SUPPORTS,
                        )
                        for evidence_id in supported
                    ],
                )
            )
        if contrary:
            claims.append(
                AuditClaim(
                    claim_id="c-counter",
                    claim_type=ClaimType.COUNTER_EVIDENCE,
                    proposition={"fact": "; ".join(pack.violation_facts)[:400] or "contrary indication"},
                    premises=[
                        ClaimPremise(
                            source_type=PremiseSourceType.CASE_EVIDENCE,
                            source_id=evidence_id,
                            relation=ClaimRelation.CONTRADICTS,
                        )
                        for evidence_id in contrary
                    ],
                )
            )

        if verdict is None and not unread:
            # A reply came back but carried no usable label. Falling back to 0
            # here was the same defect in a different disguise: the offline
            # backend's default reply has no ``label`` key at all, so every one of
            # 120 cells became a 0 — a constant classifier again, just the other
            # constant. An answer that does not say which of 1/0/N/A it is has not
            # answered the question, so it is treated as no reading rather than as
            # a finding against the farm. Whatever evidence claims the reply did
            # cite stay on the record; only the verdict is withheld.
            unread = True
            unlabelled_reply = True
        sufficiency = (
            Sufficiency.UNKNOWN
            if unread
            else Sufficiency.CONFLICTING
            if contrary and supported
            else Sufficiency.SUFFICIENT
            if supported
            else Sufficiency.INSUFFICIENT
        )
        if verdict is FinalLabel.COMPLIANT and sufficiency is not Sufficiency.SUFFICIENT:
            # Let the validator report this rather than repairing it here: a
            # silently corrected label hides that the reading was inconsistent.
            pass

    claims.append(
        AuditClaim(
            claim_id="c-verdict",
            claim_type=ClaimType.VERDICT,
            proposition={"label": verdict.value if verdict else "UNREAD"},
            depends_on=[claim.claim_id for claim in claims],
        )
    )

    argument = AuditArgument(
        argument_id=f"{case_id}.{cp_id}".replace("/", "-"),
        case_id=case_id,
        cp_id=cp_id,
        claims=claims,
        candidate_label=verdict,
        sufficiency=sufficiency,
    )

    gate = _pass(f"{cp_id}.c4", "argument_assembly_gate")
    if unread:
        # BLOCK, not ESCALATE. There is no reading to review, so escalation has
        # nothing to hand a reviewer; the cell must be recorded as unanswered.
        gate = _fail(
            f"{cp_id}.c4",
            "argument_assembly_gate",
            GateDecision.BLOCK,
            [
                VerificationIssue(
                    issue_id=f"{cp_id}.c4.unread",
                    code=VerificationIssueCode.INSUFFICIENT,
                    message=(
                        "the reply carried no usable label, so it did not answer "
                        "which of 1/0/N/A applies; an unlabelled reply is not a "
                        "finding against the farm"
                        if unlabelled_reply
                        else "no model reading of the evidence was obtained, so whether "
                        "the requirement is satisfied has not been determined; refusing "
                        "to infer a verdict from document authorship alone"
                    ),
                    # Not retryable: retrieving more evidence cannot help when the
                    # missing step is reading it. This is fixed by configuring a
                    # backend, not by another pass through the loop.
                    retryable=False,
                )
            ],
        )
    elif foreign and not self_signed and verdict is FinalLabel.COMPLIANT:
        gate = _fail(
            f"{cp_id}.c4",
            "argument_assembly_gate",
            GateDecision.ESCALATE,
            [
                VerificationIssue(
                    issue_id=f"{cp_id}.c4.foreignonly",
                    code=VerificationIssueCode.IDENTITY_MISMATCH,
                    message=(
                        "the only retrieved evidence is signed by another establishment; "
                        "compliance cannot rest on it"
                    ),
                    retryable=False,
                    artifact_ids=foreign[:8],
                )
            ],
        )
    return argument, gate, synthetic


def _model_reading(
    *,
    backend: LLMBackend,
    pack: PolicyPack,
    traces: list[RetrievalTrace],
    index: CaseEvidenceIndex,
    cp_id: str,
) -> tuple[dict[str, Any] | None, bool]:
    """Ask the backend to read the retrieved evidence against the policy text.

    The prompt contains only: the statute's own requirement wording (from the
    pack), the retrieved atoms with their ids, and the output schema. It contains
    no compliance rule, no worked example and no hint about the expected label —
    the competition forbids encoding domain rules in prompts, and a hint would
    also make the measurement meaningless.
    """

    lines: list[str] = []
    for trace in traces:
        for item in trace.selected:
            atom = index.atoms[item.evidence_id]
            lines.append(
                f"[{item.evidence_id}] track={atom.track} signer={atom.identity.state.value}\n"
                f"{atom.content[:1200]}"
            )
    if not lines:
        return None, True

    system = (
        "You are an auditor. Decide only from the policy text and the evidence given. "
        "Cite evidence by its bracketed id. If the evidence does not establish the "
        "requirement, say so instead of assuming. Reply with one JSON object."
    )
    user = (
        f"POLICY REQUIREMENT (verbatim from the rules):\n{pack.rule_slots.action}\n"
        f"SUBJECT: {pack.rule_slots.subject}\nDEONTIC: {pack.rule_slots.deontic}\n"
        f"CONDITIONS: {pack.rule_slots.conditions}\n\n"
        f"FACTS THE RULE REQUIRES: {pack.required_facts}\n"
        f"FACTS THAT WOULD BREACH IT: {pack.violation_facts}\n\n"
        f"EVIDENCE:\n" + "\n\n".join(lines) + "\n\n"
        'Reply as {"label": "1"|"0"|"N/A", "supporting_evidence_ids": [...], '
        '"contrary_evidence_ids": [...], "reasoning": "..."}'
    )

    try:
        payload = backend.complete_json(system, user)
    except LLMError:
        return None, True
    if not isinstance(payload, dict):
        return None, True
    return payload, bool(payload.get("synthetic", False))


# --------------------------------------------------------------------------
# C7 - decision emission
# --------------------------------------------------------------------------


def c7_decide(
    *,
    argument: AuditArgument,
    applicability: Applicability,
    gate_report_ids: list[str],
    review_required: bool,
    reasoning: str,
) -> FinalDecision | None:
    """Emit the FinalDecision, or ``None`` when no verdict was ever proposed.

    The domain model enforces the three-value invariants, so an inconsistent
    combination raises here rather than reaching the submission file. The frozen
    rule "missing evidence maps to 0 but keeps the insufficient marker" is
    implemented as ``basis=MISSING_REQUIRED_EVIDENCE`` plus
    ``review_required=True`` — the score gets a 0, the audit trail keeps the
    distinction between "we found a breach" and "we found nothing".

    That rule is about *evidence* the farm did not produce. It does not extend to a
    cell where the pipeline never read the evidence at all: returning 0 there would
    charge the farm for our own failure and make the run look complete. Such a cell
    returns ``None`` and is recorded as blocked.
    """

    if argument.candidate_label is None:
        return None

    supporting: list[str] = []
    contrary: list[str] = []
    for claim in argument.claims:
        for premise in claim.premises:
            if premise.source_type is PremiseSourceType.CASE_EVIDENCE:
                if premise.relation is ClaimRelation.CONTRADICTS:
                    contrary.append(premise.source_id)
                elif premise.source_id not in contrary:
                    supporting.append(premise.source_id)
            elif (
                premise.source_type is PremiseSourceType.DETERMINISTIC_RESULT
                and premise.relation is ClaimRelation.EXCEPTS
            ):
                # A0's explicit scope fact is the evidence for N/A.  It is not a
                # document atom, but it is still an auditable SafeId and must be
                # carried into FinalDecision.supporting_evidence_ids rather than
                # causing a valid N/A to be downgraded to label 0.
                supporting.append(premise.source_id)

    supporting = [eid for eid in dict.fromkeys(supporting) if eid not in set(contrary)]
    contrary = list(dict.fromkeys(contrary))

    label = argument.candidate_label
    sufficiency = argument.sufficiency

    if label is FinalLabel.NOT_APPLICABLE:
        basis = DecisionBasis.EXPLICIT_NON_APPLICABILITY
        sufficiency = Sufficiency.SUFFICIENT
        if not supporting:
            # N/A needs a citation; the deterministic-result premise is not case
            # evidence, so fall back to 0 rather than emit an invalid N/A.
            label = FinalLabel.NON_COMPLIANT
            basis = DecisionBasis.MISSING_REQUIRED_EVIDENCE
            sufficiency = Sufficiency.INSUFFICIENT
            review_required = True
    elif label is FinalLabel.COMPLIANT:
        basis = DecisionBasis.COMPLIANT_EVIDENCE
        if sufficiency is not Sufficiency.SUFFICIENT or not supporting:
            label = FinalLabel.NON_COMPLIANT
            basis = DecisionBasis.MISSING_REQUIRED_EVIDENCE
            sufficiency = Sufficiency.INSUFFICIENT
            review_required = True
    else:
        if contrary:
            basis = DecisionBasis.VIOLATION_EVIDENCE
            supporting = supporting or contrary
            contrary = [eid for eid in contrary if eid not in set(supporting)]
        else:
            basis = DecisionBasis.MISSING_REQUIRED_EVIDENCE
            sufficiency = Sufficiency.INSUFFICIENT
            review_required = True

    return FinalDecision(
        case_id=argument.case_id,
        cp_id=argument.cp_id,
        label=label,
        applicability=(
            Applicability.NOT_APPLICABLE
            if label is FinalLabel.NOT_APPLICABLE
            else Applicability.APPLICABLE
        ),
        sufficiency=sufficiency,
        basis=basis,
        supporting_evidence_ids=supporting,
        contrary_evidence_ids=contrary,
        argument_id=argument.argument_id,
        gate_report_ids=gate_report_ids or [f"{argument.argument_id}.c0"],
        review_required=review_required,
        reasoning_summary=reasoning or f"{basis.value} for {argument.cp_id}",
    )


# --------------------------------------------------------------------------
# the loop
# --------------------------------------------------------------------------


def _label_text(argument: AuditArgument) -> str:
    """Render a possibly-absent candidate label for traces.

    ``"UNREAD"`` rather than ``""`` or ``"0"``: a trace that shows an empty string
    reads like a formatting bug, and one that shows 0 reads like a finding.
    """

    return argument.candidate_label.value if argument.candidate_label else "UNREAD"


def adjudicate(
    *,
    case_id: str,
    cp_id: str,
    pack: PolicyPack,
    anchor_section_ids: list[str],
    graph: NormGraph,
    profile: FarmProfile | Mapping[str, Any],
    index: CaseEvidenceIndex,
    backend: LLMBackend | None = None,
    validator: ArgumentValidator | None = None,
    config_name: str = "full_identity_aware",
    policy_source_ids: set[str] | None = None,
) -> AdjudicationResult:
    """Run C0-C7 for one (case, checking point) pair."""

    validator = validator or ArgumentValidator()
    config = EVIDENCE_CONFIGS[config_name]
    result = AdjudicationResult(case_id=case_id, cp_id=cp_id, decision=None)

    anchors, gate = c0_bind_anchor(cp_id=cp_id, anchor_section_ids=anchor_section_ids, graph=graph)
    result.traces.append(NodeTrace("C0", gate, {"admitted_anchors": anchors}))
    if gate.decision is GateDecision.BLOCK:
        result.blocked_at = "C0"
        return result

    applicability, gate, na_conditions = c1_applicability(cp_id=cp_id, pack=pack, profile=profile)
    result.traces.append(
        NodeTrace("C1", gate, {"applicability": applicability.value, "na_conditions": na_conditions})
    )
    if applicability is Applicability.UNKNOWN:
        # Scope uncertainty is a review case, not an invitation to continue as
        # though the CP were applicable.  Stop before C2-C7 so an automated run
        # cannot turn an unresolved A0 fact into a scored 0/1.  The C6 marker is
        # the handoff point for the eventual human-review queue.
        review_gate = _fail(
            f"{cp_id}.c6.scope",
            "scope_manual_review_gate",
            GateDecision.ESCALATE,
            [
                VerificationIssue(
                    issue_id=f"{cp_id}.c6.scope-review",
                    code=VerificationIssueCode.INSUFFICIENT,
                    message="scope applicability is UNKNOWN; manual A0 review is required before adjudication",
                    retryable=False,
                )
            ],
        )
        result.traces.append(
            NodeTrace("C6", review_gate, {"manual_review_required": True, "reason": "scope_unknown"})
        )
        result.blocked_at = "C6"
        return result

    needs, gate = c2_needs(cp_id=cp_id, pack=pack)
    result.traces.append(NodeTrace("C2", gate, {"n_needs": len(needs)}))

    traces: list[RetrievalTrace] = []
    if needs:
        traces, gate = c3_retrieve(
            cp_id=cp_id, needs=needs, index=index, config=config, config_name=config_name
        )
        result.traces.append(NodeTrace("C3", gate, {"n_traces": len(traces)}))
        result.retrieval.extend(traces)

    argument, gate, synthetic = c4_assemble(
        case_id=case_id,
        cp_id=cp_id,
        pack=pack,
        anchors=anchors,
        applicability=applicability,
        na_conditions=na_conditions,
        traces=traces,
        index=index,
        backend=backend,
    )
    result.synthetic = synthetic
    result.traces.append(NodeTrace("C4", gate, {"candidate_label": _label_text(argument)}))
    if gate.decision is GateDecision.BLOCK:
        # C4 blocks when no reading of the evidence was obtained. Stopping here
        # rather than validating an argument with no proposed verdict keeps the
        # blocked cell attributable to the node that actually failed.
        result.blocked_at = "C4"
        return result

    context = ValidationContext(
        case_id=case_id,
        evidence=dict(index.atoms),
        policy_source_ids=set(policy_source_ids or {span.source_id for span in pack.authoritative_spans}),
        deterministic_result_ids={"profile.na_conditions"},
    )
    validation = validator.validate(argument, context)
    result.traces.append(NodeTrace("C5", validation, {"n_issues": len(validation.issues)}))

    if validation.decision is GateDecision.BLOCK:
        result.blocked_at = "C5"
        return result

    repairs = 0
    while validation.decision is GateDecision.RETRY and repairs < MAX_REPAIRS:
        repairs += 1
        repair_needs = [issue.retrieval_need for issue in validation.issues if issue.retrieval_need]
        if not repair_needs:
            break
        extra, retry_gate = c3_retrieve(
            cp_id=f"{cp_id}.r{repairs}",
            needs=repair_needs,
            index=index,
            config=config,
            config_name=config_name,
        )
        result.retrieval.extend(extra)
        traces = [*traces, *extra]
        argument, assembly_gate, synthetic = c4_assemble(
            case_id=case_id,
            cp_id=cp_id,
            pack=pack,
            anchors=anchors,
            applicability=applicability,
            na_conditions=na_conditions,
            traces=traces,
            index=index,
            backend=backend,
        )
        result.synthetic = result.synthetic and synthetic
        validation = validator.validate(argument, context)
        result.traces.append(
            NodeTrace(
                f"C6.r{repairs}",
                validation,
                {
                    "retrieval_gate": retry_gate.decision.value,
                    "assembly_gate": assembly_gate.decision.value,
                    "candidate_label": _label_text(argument),
                },
            )
        )

    review_required = validation.decision is not GateDecision.PASS or any(
        trace.gate.decision is not GateDecision.PASS for trace in result.traces
    )
    reasoning = (
        f"{_label_text(argument)} via {len(result.retrieval)} retrieval call(s); "
        f"validator={validation.decision.value}"
        + (f"; issues={[issue.code.value for issue in validation.issues]}" if validation.issues else "")
    )

    decision = c7_decide(
        argument=argument,
        applicability=applicability,
        gate_report_ids=[trace.gate.gate_id for trace in result.traces],
        review_required=review_required,
        reasoning=reasoning,
    )
    if decision is None:
        # C7 declined: the argument proposed no verdict. Recorded as blocked so the
        # cell is counted as unanswered rather than silently scored.
        result.blocked_at = "C7"
        return result
    result.decision = decision
    result.traces.append(
        NodeTrace(
            "C7",
            _pass(f"{cp_id}.c7", "decision_emission_gate"),
            {
                "label": decision.label.value,
                "basis": decision.basis.value,
                "review_required": decision.review_required,
                "missing_cause": (
                    MissingEvidenceCause.EVIDENCE_NOT_PRESENT.value
                    if decision.basis is DecisionBasis.MISSING_REQUIRED_EVIDENCE
                    else None
                ),
            },
        )
    )
    return result
