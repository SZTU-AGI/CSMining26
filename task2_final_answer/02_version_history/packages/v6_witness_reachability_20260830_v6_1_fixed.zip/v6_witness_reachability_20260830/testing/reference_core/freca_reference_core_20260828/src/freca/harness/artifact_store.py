"""Hash-verified filesystem artifact storage with append-only run events."""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any

from pydantic import ValidationError

from freca.domain.errors import (
    ArtifactConflictError,
    ArtifactNotFoundError,
    CorruptArtifactError,
)
from freca.domain.models import (
    ArtifactEnvelope,
    ArtifactRecord,
    ArtifactRef,
    RunEvent,
)
from freca.governance.hashing import canonical_json_bytes, normalize_for_hash, sha256_digest


def _jsonable(value: Any) -> Any:
    return normalize_for_hash(value)


def _canonical_bytes(value: Any) -> bytes:
    return canonical_json_bytes(value)


def _pretty_bytes(value: Any) -> bytes:
    return (
        json.dumps(
            _jsonable(value),
            ensure_ascii=False,
            sort_keys=True,
            indent=2,
        )
        + "\n"
    ).encode("utf-8")


class FileArtifactStore:
    """Single-process artifact store.

    Artifact records are immutable: writing the same id with the same content is
    idempotent, while writing different content under an existing id fails.
    """

    def __init__(self, root: str | Path):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def put(self, envelope: ArtifactEnvelope, payload: Any) -> ArtifactRef:
        normalized_payload = _jsonable(payload)
        payload_hash = sha256_digest(normalized_payload)
        relative_path = Path(envelope.artifact_type) / f"{envelope.artifact_id}.json"
        target = self._resolve_under_root(relative_path)
        stored_envelope = envelope.model_copy(update={"payload_path": relative_path.as_posix()})
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            existing_record = self.get(envelope.artifact_type, envelope.artifact_id)
            same_payload = existing_record.payload_sha256 == payload_hash
            same_context = self._envelope_identity(
                existing_record.envelope
            ) == self._envelope_identity(stored_envelope)
            if not (same_payload and same_context):
                raise ArtifactConflictError(
                    f"artifact {envelope.artifact_type}/{envelope.artifact_id} "
                    "already exists with different content"
                )
            return ArtifactRef(
                artifact_id=existing_record.envelope.artifact_id,
                artifact_type=existing_record.envelope.artifact_type,
                record_path=existing_record.envelope.payload_path or relative_path.as_posix(),
                payload_sha256=existing_record.payload_sha256,
            )

        record = ArtifactRecord(
            envelope=stored_envelope,
            payload_sha256=payload_hash,
            payload=normalized_payload,
        )
        self._atomic_write(target, _pretty_bytes(record))

        return ArtifactRef(
            artifact_id=envelope.artifact_id,
            artifact_type=envelope.artifact_type,
            record_path=relative_path.as_posix(),
            payload_sha256=payload_hash,
        )

    def get(self, artifact_type: str, artifact_id: str) -> ArtifactRecord:
        safe_envelope = ArtifactEnvelope(
            artifact_id=artifact_id,
            artifact_type=artifact_type,
            run_id="validation",
            producer_node="artifact_store",
            producer_version="validation",
            config_hash="sha256:" + ("0" * 64),
        )
        relative_path = Path(safe_envelope.artifact_type) / f"{safe_envelope.artifact_id}.json"
        target = self._resolve_under_root(relative_path)
        if not target.exists():
            raise ArtifactNotFoundError(f"artifact not found: {artifact_type}/{artifact_id}")

        try:
            raw = json.loads(target.read_text(encoding="utf-8"))
            record = ArtifactRecord.model_validate(raw)
        except (OSError, json.JSONDecodeError, ValidationError) as error:
            raise CorruptArtifactError(f"cannot parse artifact {target}") from error

        if record.envelope.artifact_type != artifact_type:
            raise CorruptArtifactError("artifact type does not match storage path")
        if record.envelope.artifact_id != artifact_id:
            raise CorruptArtifactError("artifact id does not match storage path")
        if record.payload_sha256 != sha256_digest(record.payload):
            raise CorruptArtifactError("artifact payload hash mismatch")
        return record

    def exists(self, artifact_type: str, artifact_id: str) -> bool:
        try:
            self.get(artifact_type, artifact_id)
        except ArtifactNotFoundError:
            return False
        return True

    def append_event(self, event: RunEvent) -> Path:
        relative_path = Path("runs") / event.run_id / "events.jsonl"
        target = self._resolve_under_root(relative_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        existing_events = self.read_events(event.run_id)
        expected_sequence = 0 if not existing_events else existing_events[-1].sequence + 1
        if event.sequence != expected_sequence:
            raise ValueError(
                f"event sequence must be {expected_sequence} for run {event.run_id}, "
                f"got {event.sequence}"
            )
        encoded = _canonical_bytes(event) + b"\n"
        with target.open("ab") as stream:
            stream.write(encoded)
            stream.flush()
            os.fsync(stream.fileno())
        return target

    def read_events(self, run_id: str) -> list[RunEvent]:
        safe_envelope = ArtifactEnvelope(
            artifact_id="events",
            artifact_type=run_id,
            run_id="validation",
            producer_node="artifact_store",
            producer_version="validation",
            config_hash="sha256:" + ("0" * 64),
        )
        target = self._resolve_under_root(
            Path("runs") / safe_envelope.artifact_type / "events.jsonl"
        )
        if not target.exists():
            return []

        events: list[RunEvent] = []
        try:
            for line in target.read_text(encoding="utf-8").splitlines():
                if line.strip():
                    events.append(RunEvent.model_validate_json(line))
        except (OSError, ValidationError) as error:
            raise CorruptArtifactError(f"cannot parse event log {target}") from error
        return events

    @staticmethod
    def _envelope_identity(envelope: ArtifactEnvelope) -> dict[str, Any]:
        """Return fields that determine logical artifact identity.

        Creation time and storage path are physical metadata and intentionally do
        not make a repeated write a different logical artifact.
        """

        return envelope.model_dump(
            mode="json",
            exclude={"created_at", "payload_path"},
        )

    def _resolve_under_root(self, relative_path: Path) -> Path:
        target = (self.root / relative_path).resolve()
        try:
            target.relative_to(self.root)
        except ValueError as error:
            raise ValueError(f"path escapes artifact root: {relative_path}") from error
        return target

    @staticmethod
    def _atomic_write(target: Path, encoded: bytes) -> None:
        temporary_path: Path | None = None
        try:
            with tempfile.NamedTemporaryFile(
                mode="wb",
                dir=target.parent,
                prefix=f".{target.name}.",
                suffix=".tmp",
                delete=False,
            ) as stream:
                temporary_path = Path(stream.name)
                stream.write(encoded)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary_path, target)
        finally:
            if temporary_path is not None and temporary_path.exists():
                temporary_path.unlink()
