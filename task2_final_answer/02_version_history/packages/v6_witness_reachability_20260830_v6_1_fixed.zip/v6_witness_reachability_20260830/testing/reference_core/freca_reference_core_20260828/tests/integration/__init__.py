"""Integration tests over locally available official competition inputs."""
