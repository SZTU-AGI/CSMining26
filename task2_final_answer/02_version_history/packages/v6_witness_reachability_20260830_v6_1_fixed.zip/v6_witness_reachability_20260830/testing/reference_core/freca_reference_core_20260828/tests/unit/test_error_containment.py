from __future__ import annotations

import unittest

from freca.audit.semantic_taint import (
    SemanticTaint,
    TaintKind,
    build_decisive_path_certificate,
    propagate_taint,
)
from freca.audit.transformation_conservation import (
    TransitionKind,
    audit_transformation_conservation,
)
from freca.evidence.lineage_cluster import EvidenceLineageItem, cluster_evidence_lineage

HASH_A = "sha256:" + ("a" * 64)
HASH_B = "sha256:" + ("b" * 64)


class ConservationTests(unittest.TestCase):
    def test_decisive_unmapped_input_blocks_transition(self) -> None:
        report = audit_transformation_conservation(
            transition_kind=TransitionKind.AST_TO_ARGUMENT_GRAPH,
            input_ids=["logic-a", "logic-b"],
            output_ids=["stmt-a"],
            mapping={"logic-a": ["stmt-a"]},
            decisive_input_ids={"logic-b"},
        )
        self.assertEqual(report.status, "BLOCK")
        self.assertEqual(report.decisive_unmapped_ids, ["logic-b"])

    def test_reasoned_nondecisive_exclusion_is_conserved(self) -> None:
        report = audit_transformation_conservation(
            transition_kind=TransitionKind.SOURCE_TO_EVIDENCE_ATOM,
            input_ids=["source-a", "source-b"],
            output_ids=["evidence-a"],
            mapping={"source-a": ["evidence-a"]},
            exclusions={"source-b": ["NON_SUBSTANTIVE_SYSTEM_FILE"]},
        )
        self.assertEqual(report.status, "PASS")


class TaintTests(unittest.TestCase):
    def test_taint_propagates_to_every_downstream_decisive_root(self) -> None:
        taint = SemanticTaint(
            taint_id="taint-1",
            origin_artifact_id="policy-unit",
            origin_layer=1,
            kind=TaintKind.OMITTED_DECISIVE_SOURCE,
        )
        edges = {
            "policy-unit": ["norm-event"],
            "norm-event": ["contract"],
            "contract": ["case-evaluation-a", "case-evaluation-b"],
        }
        roots = {
            "case-evaluation-a": ["root-a"],
            "case-evaluation-b": ["root-b"],
        }
        record = propagate_taint(taint, edges, roots)
        self.assertEqual(record.reached_decisive_root_ids, ["root-a", "root-b"])
        self.assertTrue(record.bounded)

    def test_path_certificate_records_all_shortest_paths_within_bound(self) -> None:
        certificate = build_decisive_path_certificate(
            source_artifact_id="source",
            target_root_id="root",
            dependency_edges={
                "source": ["left", "right"],
                "left": ["fold-left"],
                "right": ["fold-right"],
            },
            artifact_root_ids={"fold-left": ["root"], "fold-right": ["root"]},
        )
        self.assertEqual(len(certificate.minimal_source_to_fold_paths), 2)
        self.assertTrue(certificate.complete_within_bound)


class LineageTests(unittest.TestCase):
    def test_copies_and_derivatives_form_one_independence_cluster(self) -> None:
        clusters = cluster_evidence_lineage(
            [
                EvidenceLineageItem(evidence_id="e1", source_sha256=HASH_A),
                EvidenceLineageItem(evidence_id="e2", source_sha256=HASH_A),
                EvidenceLineageItem(
                    evidence_id="e3",
                    source_sha256=HASH_B,
                    represented_from_evidence_ids=["e1"],
                ),
            ]
        )
        self.assertEqual(len(clusters), 1)
        self.assertEqual(clusters[0].independent_source_count, 1)
        self.assertEqual(clusters[0].evidence_ids, ["e1", "e2", "e3"])


if __name__ == "__main__":
    unittest.main()
