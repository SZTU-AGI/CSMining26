"""P0-P2: case-level consistency and submission assembly.

``case_consistency`` reports contradictions across the 41 verdicts of one case;
``submission`` writes and gates the graded workbook. They are separate modules
because the first is diagnostic and the second is a deliverable, and only the
second is allowed to invent a cell value.
"""

from freca.consistency.case_consistency import (
    CaseVerdict,
    ConsistencyFinding,
    ConsistencyReport,
    ConsistencyRule,
    check_all,
    check_case,
    verdict_from_result,
)
from freca.consistency.submission import (
    BLOCKED_FILL,
    CP_IDS,
    EXPECTED_HEADER,
    SubmissionError,
    SubmissionReport,
    assemble_submission,
    verify_submission,
)

__all__ = [
    "BLOCKED_FILL",
    "CP_IDS",
    "EXPECTED_HEADER",
    "CaseVerdict",
    "ConsistencyFinding",
    "ConsistencyReport",
    "ConsistencyRule",
    "SubmissionError",
    "SubmissionReport",
    "assemble_submission",
    "check_all",
    "check_case",
    "verdict_from_result",
    "verify_submission",
]
