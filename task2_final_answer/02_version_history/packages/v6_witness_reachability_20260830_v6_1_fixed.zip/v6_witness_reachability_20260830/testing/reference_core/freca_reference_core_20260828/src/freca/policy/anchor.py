"""R0.4 / R0.5: anchor each checking point to norm sections, and measure it.

The checking-point sheet is four rows by 41 columns: Element header, subsection
title, checking-point text, checking-point id. Verified 2026-07-31. Many
checking-point cells are **incomplete clauses** — CP3 is just "the area of the
premises that is registered for export operations" — so the query is always
built as ``subsection title + checking point text``. Using the cell alone loses
the governing verb and makes the query unanchorable.

Three configurations are exposed so the contribution of each policy-chain
component is measurable independently of the evidence chain:

======  ==================================================================
``PA``  BM25 over all sections. Baseline.
``PB``  BM25 restricted to sections admitted by the scope/subject gate.
``PC``  ``PB`` plus norm-graph subject closure (general provisions such as
        ``11-2`` are retained through ``APPLIES_VIA`` instead of pruned).
======  ==================================================================

``PC`` differs from ``PB`` only in the gate's treatment of subject-less general
provisions, which is exactly the ablation the first draft got wrong.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path

from freca.domain.policy_enums import ActorRole, NormScope, SubjectResolution
from freca.policy.norm_graph import NormGraph
from freca.policy.sectionize import NormSection
from freca.retrieval.bm25 import BM25Index

ANCHOR_CONFIGS = ("PA", "PB", "PC")

# The seven checking points frozen on 2026-07-31 for the first vertical slice.
# Each was chosen for a distinct failure mode, not for Element balance.
SLICE_CPS: tuple[str, ...] = ("CP2", "CP10", "CP22", "CP23", "CP26", "CP38", "CP41")


@dataclass(slots=True)
class CheckingPoint:
    cp_id: str
    element: str
    subsection: str
    text: str

    @property
    def query(self) -> str:
        return f"{self.subsection} {self.text}".strip()


@dataclass(slots=True)
class AnchorResult:
    cp_id: str
    config: str
    ranking: list[str]
    scores: list[float]
    pool_size: int

    @property
    def top1(self) -> str | None:
        return self.ranking[0] if self.ranking else None

    def tied_at_top(self) -> list[str]:
        """Section ids sharing the top score.

        Reported because genuine ties are the diagnostic signature of the
        parallel-obligation problem: a tie means the lexical layer has no
        information left to give and the subject gate is doing the work.
        """

        if not self.scores:
            return []
        best = self.scores[0]
        return [
            section_id
            for section_id, score in zip(self.ranking, self.scores, strict=False)
            if abs(score - best) < 1e-9
        ]


def load_checking_points(xlsx_path: str | Path) -> list[CheckingPoint]:
    """Read the one-sheet checking-point workbook, forward-filling merged cells."""

    import openpyxl

    worksheet = openpyxl.load_workbook(xlsx_path, data_only=True).active
    if worksheet is None:  # pragma: no cover - defensive
        raise ValueError("checking point workbook has no active sheet")

    element = subsection = ""
    points: list[CheckingPoint] = []
    for column in range(1, worksheet.max_column + 1):
        cp_id = worksheet.cell(4, column).value
        if not cp_id:
            continue
        element = worksheet.cell(1, column).value or element
        subsection = worksheet.cell(2, column).value or subsection
        points.append(
            CheckingPoint(
                cp_id=str(cp_id).strip(),
                element=str(element).strip(),
                subsection=str(subsection).strip(),
                text=str(worksheet.cell(3, column).value or "").strip(),
            )
        )
    return points


def _pool_for_config(graph: NormGraph, config: str) -> set[str]:
    if config == "PA":
        return set(graph.nodes)

    verdicts = graph.gate(
        target_scope=NormScope.REGISTERED_ESTABLISHMENT,
        target_role=ActorRole.OCCUPIER,
    )
    if config == "PB":
        # Ablated closure: a section whose subject could not be resolved from its
        # own text is dropped. This reproduces the over-pruning failure on 11-2.
        return {
            section_id
            for section_id, verdict in verdicts.items()
            if verdict.admitted and verdict.resolution is not SubjectResolution.UNRESOLVED
        }
    if config == "PC":
        return {sid for sid, verdict in verdicts.items() if verdict.admitted}
    raise ValueError(f"unknown anchor config: {config}")


def anchor_checking_points(
    sections: dict[str, NormSection],
    checking_points: list[CheckingPoint],
    *,
    configs: tuple[str, ...] = ANCHOR_CONFIGS,
    top_k: int = 5,
) -> dict[str, list[AnchorResult]]:
    """Return ``config -> [AnchorResult]`` for every checking point."""

    graph = NormGraph(sections)
    index = BM25Index(
        {sid: f"{section.title}\n{section.text}" for sid, section in sections.items()}
    )

    results: dict[str, list[AnchorResult]] = {}
    for config in configs:
        pool = _pool_for_config(graph, config)
        per_config: list[AnchorResult] = []
        for point in checking_points:
            hits = index.score(point.query, allowed=pool)[:top_k]
            per_config.append(
                AnchorResult(
                    cp_id=point.cp_id,
                    config=config,
                    ranking=[hit.doc_id for hit in hits],
                    scores=[round(hit.score, 4) for hit in hits],
                    pool_size=len(pool),
                )
            )
        results[config] = per_config
    return results


def out_of_scope_rate(
    results: list[AnchorResult], graph: NormGraph
) -> tuple[int, list[str]]:
    """Count checking points whose top-1 anchor is scope-incompatible.

    This is a **label-free** diagnostic and is reported as such. It is *not*
    anchor accuracy: no gold CP-to-section mapping exists yet, so any claim of
    "accuracy" would be unfounded. See ``docs/policy-chain-design-freeze.md``.
    """

    offenders: list[str] = []
    for result in results:
        top = result.top1
        if top is None:
            offenders.append(result.cp_id)
            continue
        node = graph.nodes[top]
        if node.scope not in (NormScope.REGISTERED_ESTABLISHMENT, NormScope.GENERAL):
            offenders.append(result.cp_id)
        elif node.subjects and ActorRole.OCCUPIER not in node.subjects:
            offenders.append(result.cp_id)
    return len(offenders), offenders


def dump_anchor_run(
    output_dir: str | Path,
    sections: dict[str, NormSection],
    checking_points: list[CheckingPoint],
    results: dict[str, list[AnchorResult]],
) -> dict[str, str]:
    """Persist everything needed to reproduce the anchoring measurement.

    ``docs/policy-chain-design-freeze.md`` §7 requires these artefacts before the
    observation may be described as an experiment rather than as a development
    note, so the dump is part of the module rather than a notebook side effect.
    """

    directory = Path(output_dir)
    directory.mkdir(parents=True, exist_ok=True)
    graph = NormGraph(sections)

    written: dict[str, str] = {}

    sections_path = directory / "norm_sections.jsonl"
    with sections_path.open("w", encoding="utf-8") as stream:
        for section in sections.values():
            stream.write(json.dumps(section.to_dict(), ensure_ascii=False) + "\n")
    written["sections"] = str(sections_path)

    queries_path = directory / "cp_queries.jsonl"
    with queries_path.open("w", encoding="utf-8") as stream:
        for point in checking_points:
            stream.write(
                json.dumps({**asdict(point), "query": point.query}, ensure_ascii=False)
                + "\n"
            )
    written["queries"] = str(queries_path)

    graph_path = directory / "norm_graph.json"
    graph_path.write_text(
        json.dumps(graph.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8"
    )
    written["graph"] = str(graph_path)

    gate_path = directory / "gate_verdicts.jsonl"
    with gate_path.open("w", encoding="utf-8") as stream:
        for verdict in graph.gate().values():
            stream.write(json.dumps(verdict.to_dict(), ensure_ascii=False) + "\n")
    written["gate"] = str(gate_path)

    summary: dict[str, object] = {}
    for config, config_results in results.items():
        ranking_path = directory / f"ranking_{config}.jsonl"
        with ranking_path.open("w", encoding="utf-8") as stream:
            for result in config_results:
                stream.write(
                    json.dumps(
                        {
                            **asdict(result),
                            "tied_at_top": result.tied_at_top(),
                        },
                        ensure_ascii=False,
                    )
                    + "\n"
                )
        written[f"ranking_{config}"] = str(ranking_path)
        count, offenders = out_of_scope_rate(config_results, graph)
        summary[config] = {
            "pool_size": config_results[0].pool_size if config_results else 0,
            "out_of_scope_top1": count,
            "out_of_scope_cps": offenders,
            "n_checking_points": len(config_results),
        }

    summary_path = directory / "anchor_summary.json"
    summary_path.write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    written["summary"] = str(summary_path)
    return written
