"""Auditable section occurrences and deterministic legal hierarchy parsing."""

from __future__ import annotations

import re
from collections import defaultdict
from dataclasses import dataclass, field

from freca.governance.hashing import sha256_digest
from freca.policy.schemas_v2 import (
    LineClass,
    PolicyLine,
    PolicyLocator,
    PolicyPage,
    PolicyParseIssue,
    PolicySpanSegment,
    PolicyUnit,
    PolicyUnitType,
    SectionOccurrence,
)

_SECTION = re.compile(r"^\s*(?P<id>\d{1,2}-\d{1,3}[A-Z]?)\s+(?P<title>.+?)\s*$")
_TOC_TRAILER = re.compile(r"\.{4,}\s*\d+\s*$")
_STRUCTURAL = re.compile(
    r"^(?P<kind>Chapter|Part|Division|Subdivision)\s+(?P<number>\d+[A-Z]?)—(?P<title>.+)$"
)
_ENUM = re.compile(r"^(?P<indent>\s*)\((?P<label>\d{1,2}[A-Z]?|[a-z]{1,4})\)\s+(?P<text>.*)$")
_NOTE = re.compile(r"^\s*(?P<kind>Note(?:\s+\d+)?|Example)\s*:\s*(?P<text>.*)$", re.I)
_DEFINITION = re.compile(
    r"^\s{8,}(?P<term>[A-Za-z][A-Za-z’' ,()\-]{0,100}?)\s+"
    r"(?P<operator>means|includes)(?::|\s+)(?P<text>.*)$",
    re.I,
)
_ROMAN = re.compile(r"^[ivxl]+$")
_TABLE_HEADER = re.compile(r"^\s*Item\s+Column\s+1\b.*\bColumn\s+2\b", re.I)
_NON_CONTENT = {
    LineClass.BLANK,
    LineClass.RUNNING_HEADER,
    LineClass.RUNNING_FOOTER,
    LineClass.PAGE_NUMBER,
    LineClass.TOC_ENTRY,
}


@dataclass(slots=True)
class _UnitDraft:
    unit_id: str
    citation: str
    unit_type: PolicyUnitType
    title: str | None
    label: str | None
    parent_id: str | None
    context_unit_ids: list[str]
    normative: bool
    own_lines: list[PolicyLine] = field(default_factory=list)
    full_lines: list[PolicyLine] = field(default_factory=list)
    child_ids: list[str] = field(default_factory=list)


def build_section_occurrences(
    lines: list[PolicyLine],
) -> tuple[list[SectionOccurrence], list[PolicyParseIssue], dict[str, str]]:
    toc_titles = _toc_titles(lines)
    occurrences: list[SectionOccurrence] = []
    issues: list[PolicyParseIssue] = []
    body_start_indexes: list[int] = []
    for index, line in enumerate(lines):
        if line.classification is LineClass.TOC_ENTRY:
            match = _SECTION.match(line.raw_text)
            if match:
                occurrences.append(
                    SectionOccurrence(
                        occurrence_id=f"occ-toc-{match.group('id')}-{line.physical_page}",
                        section_id=match.group("id"),
                        page_start=line.physical_page,
                        title_line_ids=[line.line_id],
                        body_line_ids=[],
                        occurrence_role="TOC",
                        selection_reasons=["PAGE_CLASSIFIED_AS_TOC"],
                    )
                )
        elif line.classification is LineClass.RUNNING_HEADER:
            match = re.match(r"^Section\s+(\d{1,2}-\d{1,3}[A-Z]?)$", line.normalized_text)
            if match:
                occurrences.append(
                    SectionOccurrence(
                        occurrence_id=f"occ-header-{match.group(1)}-{line.physical_page}",
                        section_id=match.group(1),
                        page_start=line.physical_page,
                        title_line_ids=[line.line_id],
                        body_line_ids=[],
                        occurrence_role="RUNNING_HEADER",
                        selection_reasons=["TOP_WINDOW_RUNNING_SECTION_HEADER"],
                    )
                )
        elif line.classification is LineClass.SECTION_HEADING:
            body_start_indexes.append(index)

    for position, start in enumerate(body_start_indexes):
        line = lines[start]
        match = _SECTION.match(line.raw_text)
        if match is None:
            continue
        section_id = match.group("id")
        first_title = " ".join(match.group("title").split())
        expected = toc_titles.get(section_id)
        title_ids = [line.line_id]
        title = first_title
        cursor = start + 1
        if expected:
            while _normalized_title(title) != _normalized_title(expected) and cursor < len(lines):
                candidate = lines[cursor]
                if candidate.classification is not LineClass.BODY or not candidate.normalized_text:
                    break
                combined = f"{title} {candidate.normalized_text}".strip()
                if not _normalized_title(expected).startswith(_normalized_title(combined)):
                    break
                title = combined
                title_ids.append(candidate.line_id)
                cursor += 1
            if _normalized_title(title) != _normalized_title(expected):
                issues.append(
                    PolicyParseIssue(
                        issue_code="L1_TITLE_TOC_MISMATCH",
                        severity="WARNING",
                        raw_excerpt=f"{section_id} {title}"[:500],
                        details={"expected_title": expected},
                    )
                )
        next_start = (
            body_start_indexes[position + 1]
            if position + 1 < len(body_start_indexes)
            else len(lines)
        )
        body_lines = [
            candidate.line_id
            for candidate in lines[cursor:next_start]
            if candidate.classification not in _NON_CONTENT
            and candidate.classification is not LineClass.STRUCTURAL_HEADING
        ]
        occurrences.append(
            SectionOccurrence(
                occurrence_id=f"occ-body-{section_id}-{line.physical_page}",
                section_id=section_id,
                page_start=line.physical_page,
                title_line_ids=title_ids,
                body_line_ids=body_lines,
                occurrence_role="BODY",
                selection_reasons=[
                    "BODY_SECTION_HEADING",
                    "TOC_TITLE_CHECKED" if expected else "NO_TOC_TITLE",
                ],
            )
        )

    by_section: dict[str, list[SectionOccurrence]] = defaultdict(list)
    for occurrence in occurrences:
        if occurrence.occurrence_role == "BODY":
            by_section[occurrence.section_id].append(occurrence)
    for section_id, bodies in by_section.items():
        if len(bodies) > 1:
            issues.append(
                PolicyParseIssue(
                    issue_code="L1_DUPLICATE_BODY_SECTION",
                    severity="FATAL",
                    raw_excerpt=section_id,
                    details={"occurrence_ids": [item.occurrence_id for item in bodies]},
                )
            )
        if any(not item.body_line_ids for item in bodies):
            issues.append(
                PolicyParseIssue(
                    issue_code="L1_EMPTY_BODY_SECTION",
                    severity="FATAL",
                    raw_excerpt=section_id,
                )
            )
    return occurrences, issues, toc_titles


def build_policy_units(
    *,
    lines: list[PolicyLine],
    pages: list[PolicyPage],
    occurrences: list[SectionOccurrence],
    source_pdf_sha256: str,
) -> tuple[list[PolicyUnit], list[PolicyParseIssue]]:
    line_by_id = {line.line_id: line for line in lines}
    printed = {page.physical_page: page.printed_page_label for page in pages}
    position = {line.line_id: index for index, line in enumerate(lines)}
    body_occurrences = sorted(
        (item for item in occurrences if item.occurrence_role == "BODY"),
        key=lambda item: position[item.title_line_ids[0]],
    )
    structural = _structural_units(lines, printed, source_pdf_sha256)
    drafts: list[_UnitDraft] = [draft for _index, draft in structural]
    issues: list[PolicyParseIssue] = []

    for occurrence in body_occurrences:
        heading_index = position[occurrence.title_line_ids[0]]
        context = [draft for index, draft in structural if index < heading_index]
        active_context = _active_structural_context(context)
        section_lines = [
            line_by_id[item] for item in occurrence.title_line_ids + occurrence.body_line_ids
        ]
        section_id = _safe_unit_id(occurrence.section_id)
        title_text = " ".join(
            line.normalized_text for line in section_lines[: len(occurrence.title_line_ids)]
        )
        title = (
            _SECTION.match(title_text).group("title") if _SECTION.match(title_text) else title_text
        )
        section = _UnitDraft(
            unit_id=section_id,
            citation=occurrence.section_id,
            unit_type=PolicyUnitType.SECTION,
            title=title,
            label=occurrence.section_id,
            parent_id=active_context[-1].unit_id if active_context else None,
            context_unit_ids=[item.unit_id for item in active_context],
            normative=True,
            own_lines=[line_by_id[item] for item in occurrence.title_line_ids],
            full_lines=section_lines,
        )
        drafts.append(section)
        _parse_section_children(
            section, [line_by_id[item] for item in occurrence.body_line_ids], drafts, issues
        )

    by_id = {draft.unit_id: draft for draft in drafts}
    for draft in drafts:
        if draft.parent_id in by_id and draft.unit_id not in by_id[draft.parent_id].child_ids:
            by_id[draft.parent_id].child_ids.append(draft.unit_id)
    units = [_freeze(draft, printed, source_pdf_sha256) for draft in drafts]
    return units, issues


def _parse_section_children(
    section: _UnitDraft,
    body_lines: list[PolicyLine],
    drafts: list[_UnitDraft],
    issues: list[PolicyParseIssue],
) -> None:
    stack: list[_UnitDraft] = [section]
    counters: defaultdict[str, int] = defaultdict(int)
    indent_by_sibling_group: dict[tuple[str, PolicyUnitType], int] = {}
    active_table: _UnitDraft | None = None
    for line in body_lines:
        if active_table is not None:
            enum_after_table = _ENUM.match(line.raw_text)
            closes_table = (
                enum_after_table is not None
                and enum_after_table.group("label")[0].isdigit()
                and len(enum_after_table.group("indent").expandtabs(8)) <= 12
            )
            if not closes_table:
                active_table.own_lines.append(line)
                active_table.full_lines.append(line)
                for ancestor in stack[1:-1]:
                    if line not in ancestor.full_lines:
                        ancestor.full_lines.append(line)
                continue
            active_table = None

        if _TABLE_HEADER.match(line.raw_text):
            counters[PolicyUnitType.TABLE.value] += 1
            parent_index = max(
                (
                    index
                    for index, item in enumerate(stack)
                    if item.unit_type is PolicyUnitType.SUBSECTION
                ),
                default=0,
            )
            parent = stack[parent_index]
            citation = f"{parent.citation}:table:{counters[PolicyUnitType.TABLE.value]}"
            active_table = _UnitDraft(
                unit_id=_safe_unit_id(citation),
                citation=citation,
                unit_type=PolicyUnitType.TABLE,
                title="Layout table",
                label=None,
                parent_id=parent.unit_id,
                context_unit_ids=[*parent.context_unit_ids, parent.unit_id],
                normative=parent.normative,
                own_lines=[line],
                full_lines=[line],
            )
            drafts.append(active_table)
            parent.child_ids.append(active_table.unit_id)
            stack = [*stack[: parent_index + 1], active_table]
            issues.append(
                PolicyParseIssue(
                    issue_code="L1_TABLE_PARSE_UNCERTAIN",
                    severity="WARNING",
                    unit_id=active_table.unit_id,
                    raw_excerpt=line.raw_text[:500],
                    details={"fallback": "RAW_TABLE_BLOCK_PRESERVED"},
                )
            )
            continue

        definition = _DEFINITION.match(line.raw_text)
        if definition:
            parent_index = max(
                (
                    index
                    for index, item in enumerate(stack)
                    if item.unit_type is PolicyUnitType.SUBSECTION
                ),
                default=0,
            )
            parent = stack[parent_index]
            term = " ".join(definition.group("term").split())
            citation = f"{parent.citation}:def:{_slug(term)}"
            draft = _UnitDraft(
                unit_id=_safe_unit_id(citation),
                citation=citation,
                unit_type=PolicyUnitType.DEFINITION_ITEM,
                title=term,
                label=None,
                parent_id=parent.unit_id,
                context_unit_ids=[*parent.context_unit_ids, parent.unit_id],
                normative=parent.normative,
                own_lines=[line],
                full_lines=[line],
            )
            if any(item.unit_id == draft.unit_id for item in drafts):
                issues.append(
                    PolicyParseIssue(
                        issue_code="L1_DUPLICATE_DEFINITION_TERM",
                        severity="WARNING",
                        unit_id=parent.unit_id,
                        raw_excerpt=line.raw_text[:500],
                    )
                )
                parent.own_lines.append(line)
                continue
            drafts.append(draft)
            parent.child_ids.append(draft.unit_id)
            stack = [*stack[: parent_index + 1], draft]
            continue

        note = _NOTE.match(line.raw_text)
        if note:
            kind = note.group("kind").casefold()
            unit_type = (
                PolicyUnitType.EXAMPLE if kind.startswith("example") else PolicyUnitType.NOTE
            )
            counters[unit_type.value] += 1
            parent_index = max(
                (
                    index
                    for index, item in enumerate(stack)
                    if item.unit_type is PolicyUnitType.SUBSECTION
                ),
                default=0,
            )
            parent = stack[parent_index]
            citation = f"{parent.citation}:{unit_type.value.lower()}:{counters[unit_type.value]}"
            draft = _UnitDraft(
                unit_id=_safe_unit_id(citation),
                citation=citation,
                unit_type=unit_type,
                title=note.group("kind"),
                label=None,
                parent_id=parent.unit_id,
                context_unit_ids=[*parent.context_unit_ids, parent.unit_id],
                normative=False,
                own_lines=[line],
                full_lines=[line],
            )
            drafts.append(draft)
            parent.child_ids.append(draft.unit_id)
            stack = [*stack[: parent_index + 1], draft]
            continue

        match = _ENUM.match(line.raw_text)
        if match:
            label = match.group("label")
            unit_type, parent_level = _enum_type(label, stack)
            parent = stack[parent_level]
            indent = len(match.group("indent").expandtabs(8))
            indent_key = (parent.unit_id, unit_type)
            expected_indent = indent_by_sibling_group.get(indent_key)
            continuation_like_numeric_reference = (
                unit_type is PolicyUnitType.SUBSECTION
                and expected_indent is not None
                and indent > expected_indent + 2
                and match.group("text")[:1].islower()
            )
            # Layout shifts by up to five columns across verso/recto pages in the
            # fixed compilation (notably 4-7A(2)(a) versus (b)). A larger shift
            # is instead characteristic of a wrapped citation such as a line
            # beginning "(2) of this instrument" inside subsection (1).
            if continuation_like_numeric_reference or (
                expected_indent is not None and abs(indent - expected_indent) > 5
            ):
                current = stack[-1]
                current.own_lines.append(line)
                for ancestor in stack[1:]:
                    if line not in ancestor.full_lines:
                        ancestor.full_lines.append(line)
                continue
            while len(stack) > parent_level + 1:
                stack.pop()
            parent = stack[-1]
            indent_by_sibling_group.setdefault(indent_key, indent)
            citation = f"{parent.citation}({label})"
            draft = _UnitDraft(
                unit_id=_safe_unit_id(citation),
                citation=citation,
                unit_type=unit_type,
                title=None,
                label=label,
                parent_id=parent.unit_id,
                context_unit_ids=[*parent.context_unit_ids, parent.unit_id],
                normative=parent.normative,
                own_lines=[line],
                full_lines=[line],
            )
            if any(item.unit_id == draft.unit_id for item in drafts):
                issues.append(
                    PolicyParseIssue(
                        issue_code="L1_ENUM_LABEL_AMBIGUOUS",
                        severity="WARNING",
                        unit_id=parent.unit_id,
                        raw_excerpt=line.raw_text[:500],
                    )
                )
                parent.own_lines.append(line)
                continue
            drafts.append(draft)
            parent.child_ids.append(draft.unit_id)
            stack.append(draft)
            for ancestor in stack[1:-1]:
                ancestor.full_lines.append(line)
            continue

        current = stack[-1]
        current.own_lines.append(line)
        for ancestor in stack[1:]:
            if line not in ancestor.full_lines:
                ancestor.full_lines.append(line)


def _enum_type(label: str, stack: list[_UnitDraft]) -> tuple[PolicyUnitType, int]:
    if label[0].isdigit():
        return PolicyUnitType.SUBSECTION, 0
    if stack[-1].unit_type in {
        PolicyUnitType.DEFINITION_ITEM,
        PolicyUnitType.NOTE,
        PolicyUnitType.EXAMPLE,
    }:
        return PolicyUnitType.PARAGRAPH, len(stack) - 1
    if _ROMAN.fullmatch(label) and any(
        item.unit_type is PolicyUnitType.PARAGRAPH for item in stack
    ):
        parent = max(
            index for index, item in enumerate(stack) if item.unit_type is PolicyUnitType.PARAGRAPH
        )
        return PolicyUnitType.SUBPARAGRAPH, parent
    parent = max(
        (
            index
            for index, item in enumerate(stack)
            if item.unit_type
            in {
                PolicyUnitType.SUBSECTION,
                PolicyUnitType.DEFINITION_ITEM,
                PolicyUnitType.NOTE,
                PolicyUnitType.EXAMPLE,
            }
        ),
        default=0,
    )
    return PolicyUnitType.PARAGRAPH, parent


def _structural_units(
    lines: list[PolicyLine],
    printed: dict[int, str | None],
    source_hash: str,
) -> list[tuple[int, _UnitDraft]]:
    results: list[tuple[int, _UnitDraft]] = []
    stack: list[_UnitDraft] = []
    rank = {"Chapter": 0, "Part": 1, "Division": 2, "Subdivision": 3}
    type_by_kind = {
        "Chapter": PolicyUnitType.CHAPTER,
        "Part": PolicyUnitType.PART,
        "Division": PolicyUnitType.DIVISION,
        "Subdivision": PolicyUnitType.SUBDIVISION,
    }
    for index, line in enumerate(lines):
        if line.classification is not LineClass.STRUCTURAL_HEADING:
            continue
        match = _STRUCTURAL.match(line.normalized_text)
        if match is None:
            continue
        kind = match.group("kind")
        while len(stack) > rank[kind]:
            stack.pop()
        citation = "/".join([*(item.citation for item in stack), f"{kind} {match.group('number')}"])
        draft = _UnitDraft(
            unit_id=_safe_unit_id(citation),
            citation=citation,
            unit_type=type_by_kind[kind],
            title=match.group("title").strip(),
            label=match.group("number"),
            parent_id=stack[-1].unit_id if stack else None,
            context_unit_ids=[item.unit_id for item in stack],
            normative=False,
            own_lines=[line],
            full_lines=[line],
        )
        results.append((index, draft))
        stack.append(draft)
    return results


def _active_structural_context(context: list[_UnitDraft]) -> list[_UnitDraft]:
    active: dict[PolicyUnitType, _UnitDraft] = {}
    ranks = {
        PolicyUnitType.CHAPTER: 0,
        PolicyUnitType.PART: 1,
        PolicyUnitType.DIVISION: 2,
        PolicyUnitType.SUBDIVISION: 3,
    }
    for item in context:
        rank = ranks[item.unit_type]
        active = {kind: value for kind, value in active.items() if ranks[kind] < rank}
        active[item.unit_type] = item
    return [active[kind] for kind in sorted(active, key=lambda kind: ranks[kind])]


def _freeze(
    draft: _UnitDraft,
    printed: dict[int, str | None],
    source_hash: str,
) -> PolicyUnit:
    own_text = "\n".join(line.raw_text for line in draft.own_lines).strip()
    full_text = "\n".join(line.raw_text for line in draft.full_lines).strip()
    locator = _locator(draft.full_lines or draft.own_lines, printed)
    payload = {
        "unit_id": draft.unit_id,
        "citation": draft.citation,
        "unit_type": draft.unit_type,
        "title": draft.title,
        "label": draft.label,
        "own_raw_text": own_text,
        "full_raw_text": full_text,
        "normalized_text": " ".join(own_text.split()),
        "context_unit_ids": draft.context_unit_ids,
        "locator": locator,
        "parent_id": draft.parent_id,
        "child_ids": draft.child_ids,
        "normative": draft.normative,
        "source_pdf_sha256": source_hash,
    }
    return PolicyUnit(**payload, unit_sha256=sha256_digest(payload))


def _locator(lines: list[PolicyLine], printed: dict[int, str | None]) -> PolicyLocator:
    if not lines:
        raise ValueError("cannot create a locator without source lines")
    ordered = sorted(lines, key=lambda line: (line.physical_page, line.page_line_index))
    groups: list[list[PolicyLine]] = []
    for line in ordered:
        if (
            not groups
            or line.physical_page != groups[-1][-1].physical_page
            or line.page_line_index != groups[-1][-1].page_line_index + 1
        ):
            groups.append([line])
        else:
            groups[-1].append(line)
    segments = [
        PolicySpanSegment(
            physical_page=group[0].physical_page,
            page_line_start=group[0].page_line_index,
            page_line_end=group[-1].page_line_index,
            raw_char_start=group[0].raw_char_start,
            raw_char_end=group[-1].raw_char_end,
        )
        for group in groups
    ]
    labels = [
        label
        for page in dict.fromkeys(line.physical_page for line in ordered)
        if (label := printed.get(page)) is not None
    ]
    return PolicyLocator(segments=segments, printed_page_labels=labels)


def _toc_titles(lines: list[PolicyLine]) -> dict[str, str]:
    titles: dict[str, str] = {}
    pending_id: str | None = None
    pending_parts: list[str] = []
    for line in lines:
        if line.classification is not LineClass.TOC_ENTRY:
            if pending_id:
                titles[pending_id] = " ".join(pending_parts).strip()
                pending_id, pending_parts = None, []
            continue
        match = _SECTION.match(line.raw_text)
        if match:
            if pending_id:
                titles[pending_id] = " ".join(pending_parts).strip()
            pending_id = match.group("id")
            pending_parts = [_TOC_TRAILER.sub("", match.group("title")).strip()]
            if _TOC_TRAILER.search(line.raw_text):
                titles[pending_id] = " ".join(pending_parts).strip()
                pending_id, pending_parts = None, []
        elif pending_id:
            fragment = _TOC_TRAILER.sub("", line.normalized_text).strip()
            if fragment:
                pending_parts.append(fragment)
            if _TOC_TRAILER.search(line.raw_text):
                titles[pending_id] = " ".join(pending_parts).strip()
                pending_id, pending_parts = None, []
    if pending_id:
        titles[pending_id] = " ".join(pending_parts).strip()
    return titles


def _normalized_title(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", value.casefold()).strip()


def _safe_unit_id(citation: str) -> str:
    token = re.sub(r"[^A-Za-z0-9._-]+", "-", citation).strip("-")
    value = f"rules2021-{token}"
    if len(value) > 128:
        value = f"rules2021-{sha256_digest(citation).split(':', 1)[1][:32]}"
    return value


def _slug(value: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", value.casefold()).strip("-")
    return slug or sha256_digest(value).split(":", 1)[1][:16]
