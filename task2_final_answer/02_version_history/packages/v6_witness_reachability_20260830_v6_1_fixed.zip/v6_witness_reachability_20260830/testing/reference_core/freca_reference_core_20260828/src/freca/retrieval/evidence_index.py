"""Evidence-side retrieval: hybrid recall, fusion, reranking, source-aware selection.

Why this module mirrors the teammate pipeline's vocabulary
----------------------------------------------------------
The classmate's ``CSMining26-Task2-agent-pipeline`` already reports a retrieval
ablation over five variants (``bm25_only``, ``vector_only``, ``weighted_hybrid``,
``rrf_reranker_no_mmr``, ``full_retrieval``) with ``rrf_k=60``,
``mmr_lambda=0.65``, ``same_source_penalty=0.5``. Those exact names, defaults and
semantics are reproduced here so that a number from his run and a number from
this run are comparable rather than merely adjacent. Combining the two results —
which is what the teacher asked for — is only meaningful if "RRF" means the same
operation on both sides; renaming it would silently break the comparison.

What is *added* on top of his stack, and why
--------------------------------------------
Three things this task needs that a generic RAG configuration does not provide:

1. **Identity-aware selection.** An evidence atom signed by a different
   registered establishment can be lexically perfect and still legally
   irrelevant. Identity therefore enters *selection*, not just post-hoc
   filtering: ``identity_penalty`` demotes non-SELF atoms instead of deleting
   them, because a FOREIGN atom is the correct answer to "is there any evidence
   at all" and the wrong answer to "did the occupier do it".
2. **Source-aware diversity.** Following the same source-aware MMR idea, but the
   penalty is applied over ``(doc_id, track, locator)`` because this corpus
   repeats near-identical rows inside one workbook: without the penalty the top-k
   collapses onto ten rows of one dispatch docket.
3. **Deterministic dense retrieval with no network.** ``HashingVectorIndex`` is a
   seeded hashing vectoriser, not a learned embedder. It is here so the *plumbing*
   of hybrid retrieval can be exercised and ablated offline on the server; it is
   labelled ``synthetic_dense`` in every artefact precisely so a good score from
   it is never mistaken for a semantic-retrieval result.

Retrieval quality here is measured by *citation-level* diagnostics (does the
selected set contain an atom whose locator a human can check, from at least
``min_unique_sources`` distinct documents), not by recall against a gold
evidence set — no such gold set exists yet, and inventing one from this
pipeline's own output would be circular.
"""

from __future__ import annotations

import hashlib
import math
import re
from collections import Counter
from dataclasses import dataclass, field, replace
from enum import Enum

from freca.domain.enums import EvidenceIdentityState
from freca.domain.models import EvidenceAtom
from freca.retrieval.bm25 import BM25Index, ScoredHit, reciprocal_rank_fusion, tokenize

#: Dimensionality of the offline hashing vectoriser. 2**14 keeps collisions rare
#: enough for 30k atoms while staying cheap to build per case.
HASHING_DIMENSIONS = 1 << 14


class RecallMode(str, Enum):
    BM25 = "bm25"
    VECTOR = "vector"
    HYBRID = "hybrid"


class FusionMode(str, Enum):
    NONE = "none"
    WEIGHTED = "weighted"
    RRF = "rrf"


class RerankerMode(str, Enum):
    NONE = "none"
    LEXICAL = "lexical"


class SelectorMode(str, Enum):
    TOP_K = "top_k"
    SOURCE_AWARE_MMR = "source_aware_mmr"


@dataclass(slots=True, frozen=True)
class RetrievalConfig:
    """Defaults deliberately equal to the teammate pipeline's ``config.yaml``."""

    recall_mode: RecallMode = RecallMode.HYBRID
    fusion_mode: FusionMode = FusionMode.RRF
    reranker_mode: RerankerMode = RerankerMode.LEXICAL
    selector_mode: SelectorMode = SelectorMode.SOURCE_AWARE_MMR
    bm25_weight: float = 0.5
    vector_weight: float = 0.5
    rrf_k: int = 60
    candidate_limit: int = 40
    top_k: int = 8
    mmr_lambda: float = 0.65
    same_source_penalty: float = 0.5
    same_track_penalty: float = 0.15
    same_location_penalty: float = 0.1
    min_unique_sources: int = 2
    #: Demotion applied to atoms not signed by the audited establishment.
    identity_penalty: float = 0.35
    #: When true, inadmissible-identity atoms are excluded from candidates
    #: entirely. Kept switchable because it is an ablation, not a fact.
    drop_foreign_identity: bool = False

    def fingerprint(self) -> dict[str, object]:
        return {
            "recall_mode": self.recall_mode.value,
            "fusion_mode": self.fusion_mode.value,
            "reranker_mode": self.reranker_mode.value,
            "selector_mode": self.selector_mode.value,
            "bm25_weight": self.bm25_weight,
            "vector_weight": self.vector_weight,
            "rrf_k": self.rrf_k,
            "candidate_limit": self.candidate_limit,
            "top_k": self.top_k,
            "mmr_lambda": self.mmr_lambda,
            "same_source_penalty": self.same_source_penalty,
            "same_track_penalty": self.same_track_penalty,
            "same_location_penalty": self.same_location_penalty,
            "min_unique_sources": self.min_unique_sources,
            "identity_penalty": self.identity_penalty,
            "drop_foreign_identity": self.drop_foreign_identity,
        }


#: The five variants the teammate already has numbers for, plus two that isolate
#: the identity dimension this pipeline adds. ``full_retrieval`` is the shared
#: reference point between the two codebases.
EVIDENCE_CONFIGS: dict[str, RetrievalConfig] = {
    "bm25_only": RetrievalConfig(
        recall_mode=RecallMode.BM25,
        fusion_mode=FusionMode.NONE,
        reranker_mode=RerankerMode.NONE,
        selector_mode=SelectorMode.TOP_K,
        identity_penalty=0.0,
    ),
    "vector_only": RetrievalConfig(
        recall_mode=RecallMode.VECTOR,
        fusion_mode=FusionMode.NONE,
        reranker_mode=RerankerMode.NONE,
        selector_mode=SelectorMode.TOP_K,
        identity_penalty=0.0,
    ),
    "weighted_hybrid": RetrievalConfig(
        fusion_mode=FusionMode.WEIGHTED,
        reranker_mode=RerankerMode.NONE,
        selector_mode=SelectorMode.TOP_K,
        identity_penalty=0.0,
    ),
    "rrf_reranker_no_mmr": RetrievalConfig(
        selector_mode=SelectorMode.TOP_K,
        identity_penalty=0.0,
    ),
    "full_retrieval": RetrievalConfig(identity_penalty=0.0),
    #: ``full_retrieval`` + identity demotion. Isolates exactly the contribution
    #: of treating signature identity as a retrieval signal.
    "full_identity_aware": RetrievalConfig(),
    #: The over-pruning counterpart: deleting rather than demoting. Expected to
    #: lose the "no admissible evidence exists" finding, which is the point.
    "full_identity_hard_filter": RetrievalConfig(drop_foreign_identity=True),
}


def _hash_vector(tokens: list[str], dimensions: int = HASHING_DIMENSIONS) -> dict[int, float]:
    """Seeded hashing vectoriser with L2 normalisation.

    Uses blake2b rather than ``hash()`` because ``hash()`` is salted per process
    and would make runs irreproducible across restarts.
    """

    counts: Counter[int] = Counter()
    for token in tokens:
        digest = hashlib.blake2b(token.encode("utf-8"), digest_size=8).digest()
        counts[int.from_bytes(digest, "big") % dimensions] += 1
    if not counts:
        return {}
    norm = math.sqrt(sum(value * value for value in counts.values()))
    return {index: value / norm for index, value in counts.items()}


def cosine(left: dict[int, float], right: dict[int, float]) -> float:
    if not left or not right:
        return 0.0
    smaller, larger = (left, right) if len(left) <= len(right) else (right, left)
    return sum(value * larger.get(index, 0.0) for index, value in smaller.items())


class HashingVectorIndex:
    """Deterministic offline dense index. Not a semantic embedder — see module docstring."""

    backend_name = "synthetic_dense_hashing_v1"

    def __init__(self, documents: dict[str, str]) -> None:
        self.doc_ids = list(documents)
        self._vectors = {
            doc_id: _hash_vector(tokenize(documents[doc_id])) for doc_id in self.doc_ids
        }

    def score(self, query: str, *, allowed: set[str] | None = None) -> list[ScoredHit]:
        query_vector = _hash_vector(tokenize(query))
        scored: list[tuple[int, str, float]] = []
        for position, doc_id in enumerate(self.doc_ids):
            if allowed is not None and doc_id not in allowed:
                continue
            scored.append((position, doc_id, cosine(query_vector, self._vectors[doc_id])))
        scored.sort(key=lambda row: (-row[2], row[0]))
        return [
            ScoredHit(doc_id=doc_id, score=score, rank=rank)
            for rank, (_position, doc_id, score) in enumerate(scored, start=1)
        ]


def _minmax(hits: list[ScoredHit]) -> dict[str, float]:
    """Normalise to [0,1] so BM25 and cosine can be weighted without one dominating."""

    if not hits:
        return {}
    scores = [hit.score for hit in hits]
    low, high = min(scores), max(scores)
    if high - low < 1e-12:
        return {hit.doc_id: 1.0 for hit in hits}
    return {hit.doc_id: (hit.score - low) / (high - low) for hit in hits}


def _lexical_rerank(query: str, atoms: dict[str, EvidenceAtom], order: list[str]) -> list[str]:
    """Token-overlap rerank: cheap, deterministic, and needs no cross-encoder.

    Recorded as ``lexical`` in artefacts. A real cross-encoder would replace this
    function without touching its callers; keeping the seam explicit is what makes
    "did the reranker help" answerable later.
    """

    query_terms = set(tokenize(query))
    if not query_terms:
        return order

    def key(evidence_id: str) -> tuple[float, int]:
        terms = set(tokenize(atoms[evidence_id].content))
        if not terms:
            return (0.0, order.index(evidence_id))
        overlap = len(query_terms & terms)
        coverage = overlap / len(query_terms)
        precision = overlap / len(terms)
        return (-(0.7 * coverage + 0.3 * precision), order.index(evidence_id))

    return sorted(order, key=key)


@dataclass(slots=True)
class SelectedEvidence:
    evidence_id: str
    score: float
    rank: int
    penalties: dict[str, float] = field(default_factory=dict)

    def to_dict(self) -> dict[str, object]:
        return {
            "evidence_id": self.evidence_id,
            "score": round(self.score, 6),
            "rank": self.rank,
            "penalties": {name: round(value, 4) for name, value in self.penalties.items()},
        }


@dataclass(slots=True)
class RetrievalTrace:
    """Everything needed to explain, replay and ablate one retrieval call."""

    query: str
    config_name: str
    config: RetrievalConfig
    n_candidates: int
    selected: list[SelectedEvidence]
    dense_backend: str
    unique_sources: int
    unique_tracks: int
    identity_states: dict[str, int]
    diversity_satisfied: bool

    @property
    def evidence_ids(self) -> list[str]:
        return [item.evidence_id for item in self.selected]

    def to_dict(self) -> dict[str, object]:
        return {
            "query": self.query,
            "config_name": self.config_name,
            "config": self.config.fingerprint(),
            "n_candidates": self.n_candidates,
            "selected": [item.to_dict() for item in self.selected],
            "dense_backend": self.dense_backend,
            "unique_sources": self.unique_sources,
            "unique_tracks": self.unique_tracks,
            "identity_states": self.identity_states,
            "diversity_satisfied": self.diversity_satisfied,
        }


def _location_key(atom: EvidenceAtom) -> str:
    locator = atom.locator
    parts = [
        locator.sheet or "",
        str(locator.table_index if locator.table_index is not None else ""),
        str(locator.page if locator.page is not None else ""),
    ]
    return "|".join(parts)


class CaseEvidenceIndex:
    """Per-case retrieval over evidence atoms.

    Built per case rather than per corpus because every decision is scoped to one
    case: a corpus-wide index would make cross-case leakage possible, and V0's
    leakage check exists precisely because that failure would be invisible in the
    accuracy number.
    """

    def __init__(self, atoms: list[EvidenceAtom]) -> None:
        self.atoms: dict[str, EvidenceAtom] = {atom.evidence_id: atom for atom in atoms}
        texts = {
            evidence_id: f"{atom.track} {atom.source_type} {atom.content}"
            for evidence_id, atom in self.atoms.items()
        }
        self.bm25 = BM25Index(texts)
        self.dense = HashingVectorIndex(texts)

    def __len__(self) -> int:
        return len(self.atoms)

    # -- candidate generation ------------------------------------------------

    def _candidates(self, query: str, config: RetrievalConfig, allowed: set[str] | None) -> list[str]:
        limit = config.candidate_limit
        if config.recall_mode is RecallMode.BM25:
            return [hit.doc_id for hit in self.bm25.score(query, allowed=allowed)[:limit]]
        if config.recall_mode is RecallMode.VECTOR:
            return [hit.doc_id for hit in self.dense.score(query, allowed=allowed)[:limit]]

        lexical = self.bm25.score(query, allowed=allowed)[:limit]
        dense = self.dense.score(query, allowed=allowed)[:limit]

        if config.fusion_mode is FusionMode.RRF:
            fused = reciprocal_rank_fusion(
                [[hit.doc_id for hit in lexical], [hit.doc_id for hit in dense]],
                k=config.rrf_k,
            )
            return [hit.doc_id for hit in fused[:limit]]

        if config.fusion_mode is FusionMode.WEIGHTED:
            lexical_scores = _minmax(lexical)
            dense_scores = _minmax(dense)
            combined: dict[str, float] = {}
            for evidence_id in set(lexical_scores) | set(dense_scores):
                combined[evidence_id] = (
                    config.bm25_weight * lexical_scores.get(evidence_id, 0.0)
                    + config.vector_weight * dense_scores.get(evidence_id, 0.0)
                )
            order = sorted(combined.items(), key=lambda pair: (-pair[1], pair[0]))
            return [evidence_id for evidence_id, _score in order[:limit]]

        # FusionMode.NONE with HYBRID recall: concatenate, lexical first.
        seen: dict[str, None] = {}
        for hit in [*lexical, *dense]:
            seen.setdefault(hit.doc_id, None)
        return list(seen)[:limit]

    # -- selection ----------------------------------------------------------

    def _select_source_aware(
        self, order: list[str], config: RetrievalConfig
    ) -> list[SelectedEvidence]:
        """Greedy source-aware MMR with identity demotion.

        Relevance is the reciprocal of the incoming rank, which keeps the selector
        independent of whichever scorer produced the order — otherwise switching
        fusion mode would silently change the diversity trade-off too, and the
        ablation would confound two changes.
        """

        base = {evidence_id: 1.0 / (index + 1) for index, evidence_id in enumerate(order)}
        # Content vectors are cached: the redundancy term compares every remaining
        # candidate against every chosen one, so recomputing them inside the loop
        # would be O(k * n) hashing passes over the same strings.
        vectors = {
            evidence_id: _hash_vector(tokenize(self.atoms[evidence_id].content))
            for evidence_id in order
        }
        chosen: list[SelectedEvidence] = []
        used_docs: Counter[str] = Counter()
        used_tracks: Counter[str] = Counter()
        used_locations: Counter[str] = Counter()
        remaining = list(order)

        while remaining and len(chosen) < config.top_k:
            best_id: str | None = None
            best_score = -math.inf
            best_penalties: dict[str, float] = {}

            for evidence_id in remaining:
                atom = self.atoms[evidence_id]
                penalties: dict[str, float] = {}
                score = config.mmr_lambda * base[evidence_id]

                if used_docs[atom.doc_id]:
                    penalties["same_source"] = config.same_source_penalty * used_docs[atom.doc_id]
                if used_tracks[atom.track]:
                    penalties["same_track"] = config.same_track_penalty * used_tracks[atom.track]
                location = _location_key(atom)
                if location and used_locations[location]:
                    penalties["same_location"] = (
                        config.same_location_penalty * used_locations[location]
                    )
                if config.identity_penalty and atom.identity.state is not EvidenceIdentityState.SELF:
                    penalties["identity"] = config.identity_penalty

                if chosen:
                    redundancy = max(
                        cosine(vectors[evidence_id], vectors[picked.evidence_id])
                        for picked in chosen
                    )
                    penalties["redundancy"] = (1.0 - config.mmr_lambda) * redundancy

                score -= sum(penalties.values())
                if score > best_score:
                    best_id, best_score, best_penalties = evidence_id, score, penalties

            if best_id is None:  # pragma: no cover - defensive
                break
            atom = self.atoms[best_id]
            chosen.append(
                SelectedEvidence(
                    evidence_id=best_id,
                    score=best_score,
                    rank=len(chosen) + 1,
                    penalties=best_penalties,
                )
            )
            used_docs[atom.doc_id] += 1
            used_tracks[atom.track] += 1
            location = _location_key(atom)
            if location:
                used_locations[location] += 1
            remaining.remove(best_id)

        return chosen

    def retrieve(
        self,
        query: str,
        *,
        config_name: str = "full_identity_aware",
        config: RetrievalConfig | None = None,
        allowed_ids: set[str] | None = None,
    ) -> RetrievalTrace:
        resolved = config or EVIDENCE_CONFIGS[config_name]
        pool = set(self.atoms) if allowed_ids is None else set(allowed_ids) & set(self.atoms)

        if resolved.drop_foreign_identity:
            pool = {
                evidence_id
                for evidence_id in pool
                if self.atoms[evidence_id].identity.state
                in (EvidenceIdentityState.SELF, EvidenceIdentityState.UNKNOWN)
            }

        candidates = self._candidates(query, resolved, pool or None)
        if resolved.reranker_mode is RerankerMode.LEXICAL:
            candidates = _lexical_rerank(query, self.atoms, candidates)

        if resolved.selector_mode is SelectorMode.SOURCE_AWARE_MMR:
            selected = self._select_source_aware(candidates, resolved)
        else:
            selected = [
                SelectedEvidence(evidence_id=evidence_id, score=1.0 / (index + 1), rank=index + 1)
                for index, evidence_id in enumerate(candidates[: resolved.top_k])
            ]

        picked_atoms = [self.atoms[item.evidence_id] for item in selected]
        unique_sources = len({atom.doc_id for atom in picked_atoms})
        states = Counter(atom.identity.state.value for atom in picked_atoms)
        return RetrievalTrace(
            query=query,
            config_name=config_name if config is None else f"{config_name}(custom)",
            config=resolved,
            n_candidates=len(candidates),
            selected=selected,
            dense_backend=self.dense.backend_name,
            unique_sources=unique_sources,
            unique_tracks=len({atom.track for atom in picked_atoms}),
            identity_states=dict(states),
            diversity_satisfied=unique_sources >= min(resolved.min_unique_sources, len(picked_atoms) or 1),
        )


def with_top_k(config: RetrievalConfig, top_k: int) -> RetrievalConfig:
    return replace(config, top_k=top_k)


_WHITESPACE = re.compile(r"\s+")


def build_query(*facets: str) -> str:
    """Join query facets, deduplicating repeated phrases.

    Facet order is preserved because BM25 is order-insensitive but the reranker's
    coverage term is not, and a stable query string is required for the prompt
    hash to be meaningful.
    """

    seen: dict[str, None] = {}
    for facet in facets:
        cleaned = _WHITESPACE.sub(" ", (facet or "").strip())
        if cleaned:
            seen.setdefault(cleaned, None)
    return " ".join(seen)
