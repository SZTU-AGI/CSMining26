"""Dependency-free BM25 (Okapi) plus reciprocal rank fusion.

Implemented in-package on purpose: the JupyterLab server may have no outbound
network access, and a 60-line scorer removes an install step from the critical
path. Behaviour matches ``rank_bm25.BM25Okapi`` with ``k1=1.5, b=0.75``.

Ties are broken by first-seen order so that rankings are reproducible; this
matters because on the policy side genuine score ties occur (``11-5``/``11-7``/
``11-8`` all score identically for CP22) and an unstable tiebreak would make the
measurement irreproducible.
"""

from __future__ import annotations

import math
import re
from collections import Counter
from dataclasses import dataclass

_TOKEN = re.compile(r"[a-z0-9]+")

# Deliberately small. Domain words such as "record", "establishment" or "pest"
# must stay: they carry the signal. Only closed-class words are removed.
STOPWORDS: frozenset[str] = frozenset(
    """a an the of to and or in for is are be been being that this these those with
    at any all as on by from its it must may where which who whom whose not no nor
    such other than then there their they them if into upon under over out about""".split()
)


def tokenize(text: str, *, drop_stopwords: bool = True, min_length: int = 3) -> list[str]:
    tokens = _TOKEN.findall(text.lower())
    if drop_stopwords:
        return [t for t in tokens if t not in STOPWORDS and len(t) >= min_length]
    return tokens


@dataclass(slots=True)
class ScoredHit:
    doc_id: str
    score: float
    rank: int


class BM25Index:
    """Okapi BM25 over a fixed document collection."""

    def __init__(
        self,
        documents: dict[str, str],
        *,
        k1: float = 1.5,
        b: float = 0.75,
    ) -> None:
        self.k1 = k1
        self.b = b
        self.doc_ids: list[str] = list(documents)
        self._tf: list[Counter[str]] = []
        self._lengths: list[int] = []
        document_frequency: Counter[str] = Counter()

        for doc_id in self.doc_ids:
            tokens = tokenize(documents[doc_id])
            counts = Counter(tokens)
            self._tf.append(counts)
            self._lengths.append(len(tokens))
            document_frequency.update(counts.keys())

        self.n_docs = len(self.doc_ids)
        self.avg_length = (sum(self._lengths) / self.n_docs) if self.n_docs else 0.0
        self._idf = {
            term: math.log(1.0 + (self.n_docs - freq + 0.5) / (freq + 0.5))
            for term, freq in document_frequency.items()
        }

    def score(self, query: str, *, allowed: set[str] | None = None) -> list[ScoredHit]:
        """Rank documents for ``query``, optionally restricted to ``allowed`` ids."""

        terms = tokenize(query)
        scores: list[tuple[int, float]] = []
        for index, doc_id in enumerate(self.doc_ids):
            if allowed is not None and doc_id not in allowed:
                continue
            counts = self._tf[index]
            length = self._lengths[index]
            denominator_base = self.k1 * (
                1.0 - self.b + self.b * (length / self.avg_length if self.avg_length else 0.0)
            )
            total = 0.0
            for term in terms:
                frequency = counts.get(term)
                if not frequency:
                    continue
                total += self._idf.get(term, 0.0) * (
                    frequency * (self.k1 + 1.0) / (frequency + denominator_base)
                )
            scores.append((index, total))

        scores.sort(key=lambda pair: (-pair[1], pair[0]))
        return [
            ScoredHit(doc_id=self.doc_ids[index], score=score, rank=rank)
            for rank, (index, score) in enumerate(scores, start=1)
        ]


def reciprocal_rank_fusion(
    rankings: list[list[str]], *, k: int = 60
) -> list[ScoredHit]:
    """Fuse several rankings. ``k=60`` follows Cormack et al. (2009).

    Kept identical to the teammate pipeline's ``rrf_k: 60`` so that a shared
    retrieval configuration means the same thing in both codebases.
    """

    totals: dict[str, float] = {}
    first_seen: dict[str, int] = {}
    counter = 0
    for ranking in rankings:
        for position, doc_id in enumerate(ranking, start=1):
            totals[doc_id] = totals.get(doc_id, 0.0) + 1.0 / (k + position)
            if doc_id not in first_seen:
                first_seen[doc_id] = counter
                counter += 1

    ordered = sorted(totals.items(), key=lambda pair: (-pair[1], first_seen[pair[0]]))
    return [
        ScoredHit(doc_id=doc_id, score=score, rank=rank)
        for rank, (doc_id, score) in enumerate(ordered, start=1)
    ]
