# A0 → V0 实施顺序冻结

> 日期：2026-08-01  
> 状态：A0、scope 三值门、7CP 子集入口和 V0 基础评测已编码。  
> 立即安全修复：synthetic fallback 不得进入正式评测或提交。

## 0.1 当前 as-built 状态

已实现：

- `FarmProfile` 从身份状态为 `SELF` 的证据抽取，保留字段 provenance、冲突和 unknown fields；
- `PolicyPack` 主字段为 `scope_predicates`、`required_facts`、`violation_facts`、`explicit_legal_exemptions`，旧字段仅作迁移兼容；
- C1 明确否定进入 `NOT_APPLICABLE`，缺失/冲突进入 C6 人工复核；
- C7 将 A0 的显式非适用事实作为可审计支持证据，避免错误降级成 `0`；
- `audit --cp-ids CP2 CP10 CP22 CP23 CP26 CP38 CP41` 支持冻结的 7CP 垂直切片；
- `evaluate` 生成 `summary.json`、`predictions.jsonl`、`stage_metrics.json`、`error_cases.jsonl` 和 `v0_report.json`；
- 模型调用的 exact prompt、response、model/config/prompt hash 写入 `model_calls.jsonl`。

当前真实三案例冒烟已观察到 `APPLICABLE` 和 `UNKNOWN`；`NOT_APPLICABLE` 的代码路径由三值夹具覆盖，但真实样本中仍需通过人工 gold/法规 scope 复核确认，不得用默认值补齐。

## 1. 为什么 A0 必须先于文档

当前两项实测改变了业务语义：

1. 40 个 PolicyPack 的 `explicit_na_conditions` 均为空，N/A 在现有链中不可达；
2. 官方任务定义中的 N/A 主要取决于检查点是否属于农场注册经营范围，而不是法规条文本身是否含 `does not apply`。

因此，若现在画“最终架构”，会把已知错误的 N/A 路径固化进组会材料。A0 完成并跑通至少一个
APPLICABLE、一个 NOT_APPLICABLE、一个 UNKNOWN 场景后，流程图才有资格称为 as-built 架构。

## 2. A0 的职责

A0 不直接作最终合规判定，只构建有出处的农场画像并回答适用性所需事实。

```text
FarmProfile
  case_id
  registered_entity
  registration_number
  registration_status
  registered_commodities
  registered_activities
  registered_facilities
  endorsements_or_conditions
  effective_period
  identity_conflicts
  unknown_fields
  field_provenance
```

每个字段必须包含 evidence ids/locators、解析状态和冲突，不能把多个来源静默合并成一个值。

## 3. N/A 的新判定路径

PolicyPack 将适用性拆为：

```text
scope_predicates
required_facts
violation_facts
explicit_legal_exemptions
```

其中 `scope_predicates` 由 CP 描述、任务定义和法规 scope 共同确定；
`explicit_legal_exemptions` 只表示法条中的明确豁免，不能继续承担全部 N/A 逻辑。

```text
scope predicate 被 A0 已验证事实明确否定
  → NOT_APPLICABLE → N/A

scope predicate 被明确满足
  → APPLICABLE → 进入证据充分性和 1/0 判定

A0 缺字段或字段冲突
  → UNKNOWN → C6/人工复核，禁止直接 N/A
```

## 4. 必须改成 typed interface

`adjudicate()` 不再接收裸 dict，至少接收：

```text
PolicyPack
FarmProfile
ApplicabilityAssessment
VerifiedEvidenceSet
GateReports
```

`ApplicabilityAssessment` 输出：

```text
APPLICABLE / NOT_APPLICABLE / UNKNOWN
evaluated_predicates
supporting_profile_fields
evidence_ids
unresolved_fields
conflicts
review_required
```

## 5. synthetic 退化路径的立即硬门

当前 120 个判定全部 `synthetic=True`、98% 为 1，说明 fallback 在空转。

仅警告不足够，冻结规则：

```text
evaluation/production mode:
  synthetic_rate > 0
  → RUN_INVALID + BLOCK_EXPORT

development mode:
  synthetic 允许用于接口测试
  → 输出必须标记 synthetic
  → fallback 不得默认判 1，应返回 BLOCKED/UNKNOWN
```

P2 为比赛格式把 blocked 单元格填 0 时：

- 逐格保存 `blocked=true`；
- 该 0 不得计入模型预测准确率；
- summary 同时报告 submission-filled score 与 decision coverage；
- 只要存在 synthetic，提交文件必须有醒目的 invalid-run 标记或禁止生成正式文件。

## 6. A0 验收测试

至少包含：

1. 注册范围明确包含某 CP 所需活动 → APPLICABLE；
2. 注册范围明确排除该活动 → NOT_APPLICABLE；
3. 范围字段缺失 → UNKNOWN，不得 N/A；
4. 两份来源对商品/活动冲突 → UNKNOWN + review；
5. foreign 证据不能修改 FarmProfile 主体字段；
6. related/supplier 证据只能填允许的角色字段；
7. 每个非空 profile 字段都有 provenance；
8. N/A 必须引用 A0 字段和 scope predicate；
9. synthetic fallback 不能产生正式 `1`；
10. production run 含 synthetic 时 P2 被阻断。

## 7. 已完成顺序与下一阶段

```text
已完成：
0. synthetic export hard gate
1. A0 FarmProfile schema + builder
2. A0 verifier / conflict handling
3. scope-predicate applicability evaluator
4. C1 UNKNOWN → C6 scope review gate
5. C7 explicit A0 N/A 链
6. V0：coverage、类别分布、synthetic、perturbation、leakage
7. exact model-call audit
8. 更新架构文档与当前实现流程图

服务器下一步：
9. 运行 M0/E0–E3/R0/R1，确认依赖和输入路径
10. 运行 3×7 real-backend slice
11. 使用 human gold 运行 V0
12. 复核 blocked/synthetic/coverage 后扩展至 100×41
```

当前真实样本已经确认 `APPLICABLE` 和 `UNKNOWN` 可达；`NOT_APPLICABLE` 的代码
路径已由夹具和确定性 C7 测试覆盖，但真实样本是否应标为 N/A，仍必须由 CP-specific
scope predicate 与人工 gold 确认，不能用默认值补齐。
