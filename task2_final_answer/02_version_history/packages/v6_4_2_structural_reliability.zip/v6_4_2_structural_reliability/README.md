# FRECA V6.4.2 — structural reliability closure + parallel eval20

## Why this patch exists

The focused `case-023 / CP12` diagnostic showed:

- ER1 structural design witness was DIRECT and truth-bearing;
- temporal status was `NOT_REQUIRED`;
- the only blocking failure was `INFORMATION_RELIABILITY_UNRESOLVED`;
- ER2 was already accepted TRUE.

The root cause was that a deterministic structural aggregate inherited the mixed
text-level nature of its representative paragraph (`PHYSICAL_DESIGN_FEATURE` +
`PROCEDURE_STATEMENT`).  The common reliability gate then treated the aggregate
as partly non-actual even though the structural operator had already established
an actual grounded design fact.

V6.4.2 does **not** bypass the reliability gate.  Instead, the structural
operator emits the typed record nature of the derived fact itself, e.g.
`PHYSICAL_DESIGN_FEATURE`, `EQUIPMENT_CONDITION`, `RISK_CONTROL_OUTCOME`, etc.
The ordinary V2 reliability assessor then decides PASS/UNRESOLVED as usual.

Local regression:

- V6.1 semantic closure: 7/7 PASS
- V6.4 precision/structural regression: 36/36 PASS
- case-023 CP12 ER1 structural witness -> common reliability assessor: PASS

## Eval20 parallelism

`run_eval20_v6_4_2_parallel.sh` defaults to **4 parallel workers**, each handling
5 of the fixed 20 held-out cases.  Override with `FRECA_EVAL_WORKERS=2` if the
DeepSeek endpoint starts returning rate-limit errors.

The held-out list excludes the five debug cases and uses CP1/CP12/CP26/CP35.
CP15 remains outside the main eval until IF_THEN/N/A applicability is formally
implemented.
