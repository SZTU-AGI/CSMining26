#!/usr/bin/env bash
set -Eeuo pipefail
V61="${V61:-/home/MeggieYu/freca/v6_1_release/v6_witness_reachability_20260830}"
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$V61/code"
for f in fast_final_adjudicator_v6_6.py fast_final_adjudicator_v6_6_2.py summarize_v6_6_2.py finalize_v6_6_2_submission.py run_v6_6_2_smoke_parallel.sh run_v6_6_2_full_parallel.sh; do
 cp -f "$HERE/$f" "$V61/code/$f"
done
chmod +x \
 "$V61/code/fast_final_adjudicator_v6_6.py" \
 "$V61/code/fast_final_adjudicator_v6_6_2.py" \
 "$V61/code/summarize_v6_6_2.py" \
 "$V61/code/finalize_v6_6_2_submission.py" \
 "$V61/code/run_v6_6_2_smoke_parallel.sh" \
 "$V61/code/run_v6_6_2_full_parallel.sh"
python -m py_compile \
 "$V61/code/fast_final_adjudicator_v6_6.py" \
 "$V61/code/fast_final_adjudicator_v6_6_2.py" \
 "$V61/code/summarize_v6_6_2.py" \
 "$V61/code/finalize_v6_6_2_submission.py"
echo 'V6.6.2 hybrid forced-N/A gate installed.'
echo 'Existing V6.6 element outputs will be reused by fingerprint.'
