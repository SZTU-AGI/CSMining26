# V6.6.2 hybrid forced N/A gate

Purpose: address systematic underproduction of N/A by the V6.6 primary 0/1/N/A adjudicator without hard-coding CP-specific verdict rules.

- Reuses unchanged V6.6 element outputs by fingerprint/cache.
- Automatically discovers applicability candidates from official CP text and automatically retrieved policy conditional language.
- Runs a dedicated applicability-only model pass even if the primary model did not propose N/A.
- N/A requires grounded positive non-applicability evidence plus an independent countercheck with no applicability counterevidence.
- Any primary-model N/A not confirmed by the forced gate is demoted to 0.
- No CP-number-to-N/A rule table is used.

Run smoke first:
`bash run_v6_6_2_smoke_parallel.sh`

If credible N/A appears, run full:
`FRECA_FINAL_WORKERS=4 bash run_v6_6_2_full_parallel.sh`
