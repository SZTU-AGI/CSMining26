# V6.5.2 cumulative final + N/A smoke fix

Fixes the V6.5.1 smoke launcher failure:
- installs `production_runner_v6_5_final.py` into both `core_v1` and `$V61/code`;
- uses `$V61/code/production_runner_v6_5_final.py` explicitly;
- builds `--contract-dir` and all `--cp CP1 ... --cp CP41` options as shell-array elements;
- performs hard preflight checks before launching workers;
- clears the prior broken smoke directory by default.

No proof/applicability semantics are changed relative to V6.5 final.
