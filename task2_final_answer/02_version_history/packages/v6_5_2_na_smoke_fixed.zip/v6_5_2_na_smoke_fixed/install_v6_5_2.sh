#!/usr/bin/env bash
set -Eeuo pipefail
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
CORE="${FRECA_PROJECT_ROOT:-/home/MeggieYu/freca/core_v1}"
V61="${V61:-/home/MeggieYu/freca/v6_1_release/v6_witness_reachability_20260830}"
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP="$CORE/backups/v6_5_2_before_$STAMP"
mkdir -p "$BACKUP" "$V61/code"

core_files=(
  evidence_nature_v1.py evidence_reasoning_v2.py fact_candidate_v1.py
  coverage_policy_v2.py proof_gate_applicability_v2.py
  structured_witness_v6_3.py semantic_replay_v6_1.py applicability_v6_5.py
  production_runner_v6_5_final.py finalize_v6_5_submission.py v6_5_final_selftest.py
)
for f in "${core_files[@]}"; do
  if [[ -f "$CORE/$f" ]]; then cp -a "$CORE/$f" "$BACKUP/$f"; fi
  cp -a "$HERE/files/$f" "$CORE/$f"
done

v61_files=(
  structured_witness_v6_3.py semantic_replay_v6_1.py applicability_v6_5.py
  production_runner_v6_5_final.py finalize_v6_5_submission.py v6_5_final_selftest.py
  run_full4100_v6_5_parallel.sh monitor_full4100_v6_5.sh
  summarize_na_smoke_v6_5.py run_na_smoke_v6_5_2_parallel.sh
)
for f in "${v61_files[@]}"; do
  cp -a "$HERE/files/$f" "$V61/code/$f"
done
chmod +x "$V61/code/run_full4100_v6_5_parallel.sh" \
         "$V61/code/monitor_full4100_v6_5.sh" \
         "$V61/code/run_na_smoke_v6_5_2_parallel.sh" \
         "$V61/code/summarize_na_smoke_v6_5.py"

# Fail hard if the final runner did not land in both expected locations.
for p in "$CORE/production_runner_v6_5_final.py" "$V61/code/production_runner_v6_5_final.py"; do
  [[ -f "$p" ]] || { echo "INSTALL FAILED: missing $p" >&2; exit 2; }
done

cd "$CORE"
PYTHONPATH="$CORE:$V61/code" conda run --no-capture-output -n freca-core python v6_5_final_selftest.py

echo "V6.5.2 cumulative final + N/A smoke installed."
echo "Backup: $BACKUP"
echo "Runner(core): $CORE/production_runner_v6_5_final.py"
echo "Runner(V61):  $V61/code/production_runner_v6_5_final.py"
echo "Smoke: bash $V61/code/run_na_smoke_v6_5_2_parallel.sh"
