# FRECA V6.4.3 — scoped structural reliability

V6.4.2 correctly closed `case-023 / CP12 / ER1`, but applied the derived-record evidence-nature override to every structural witness family. That regressed previously stable CP1/CP26/CP35 proof admission.

V6.4.3 narrows the override to exactly one family:

- `aggregate_kind == HOLISTIC_MULTI_SECTION_SUPPORT`
- `relation == SUPPORT`

This is the CP12 ER1 holistic design aggregate. All CP1 scope witnesses, CP26 station-condition witnesses, CP12 maintenance witnesses, and CP35 risk witnesses retain their V6.4 evidence nature/reliability behavior.

The included `v6_4_3_scope_selftest.py` verifies this scope directly. The eval20 runner defaults to 4 parallel workers (5 cases each).
