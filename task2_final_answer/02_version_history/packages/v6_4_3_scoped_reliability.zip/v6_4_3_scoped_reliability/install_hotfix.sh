#!/usr/bin/env bash
set -euo pipefail
: "${V61:?Set V61 to /home/MeggieYu/freca/v6_1_release/v6_witness_reachability_20260830}"
CORE="${FRECA_PROJECT_ROOT:-/home/MeggieYu/freca/core_v1}"
SRC="$(cd "$(dirname "$0")" && pwd)/files"
STAMP="$(date +%Y%m%d_%H%M%S)"
mkdir -p "$V61/backups/v6_4_3_$STAMP" "$CORE/backup_v6_4_3_$STAMP"
for f in structured_witness_v6_3.py; do
  [[ -f "$V61/code/$f" ]] && cp -p "$V61/code/$f" "$V61/backups/v6_4_3_$STAMP/$f"
  [[ -f "$CORE/$f" ]] && cp -p "$CORE/$f" "$CORE/backup_v6_4_3_$STAMP/$f"
  cp "$SRC/$f" "$V61/code/$f"
  cp "$SRC/$f" "$CORE/$f"
done
for f in production_runner_v6_4_3.py replay_full_batch_v6_4_3.py v6_4_precision_regression_selftest.py \
         v6_4_3_scope_selftest.py run_eval20_v6_4_3_parallel.sh replay_eval20_v6_4_3.sh eval20_cases_v6_3.txt; do
  cp "$SRC/$f" "$V61/code/$f"
done
cp "$SRC/production_runner_v6_4_3.py" "$CORE/production_runner_v6_4_3.py"
chmod +x "$V61/code/production_runner_v6_4_3.py" "$CORE/production_runner_v6_4_3.py" \
  "$V61/code/run_eval20_v6_4_3_parallel.sh" "$V61/code/replay_eval20_v6_4_3.sh" "$V61/code/v6_4_3_scope_selftest.py"
python -m py_compile "$V61/code/structured_witness_v6_3.py" "$V61/code/production_runner_v6_4_3.py" \
  "$V61/code/replay_full_batch_v6_4_3.py" "$V61/code/v6_4_3_scope_selftest.py"
cd "$V61/code"
PYTHONPATH=. python v6_1_semantic_closure_selftest.py
PYTHONPATH=. python v6_4_3_scope_selftest.py
echo "V6.4.3 scoped structural-reliability hotfix installed."
echo "V61 backup: $V61/backups/v6_4_3_$STAMP"
echo "CORE backup: $CORE/backup_v6_4_3_$STAMP"
echo "Parallel eval default: FRECA_EVAL_WORKERS=4"
