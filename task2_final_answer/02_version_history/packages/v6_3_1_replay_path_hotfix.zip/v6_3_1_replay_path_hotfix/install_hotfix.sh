#!/usr/bin/env bash
set -euo pipefail
: "${V61:?Set V61 to /home/MeggieYu/freca/v6_1_release/v6_witness_reachability_20260830}"
SRC="$(cd "$(dirname "$0")" && pwd)/files/replay_full_batch_v6_3.py"
DST="$V61/code/replay_full_batch_v6_3.py"
STAMP="$(date +%Y%m%d_%H%M%S)"
if [ -f "$DST" ]; then
  cp -p "$DST" "$DST.v6_3_pathbug_backup_$STAMP"
fi
cp "$SRC" "$DST"
python -m py_compile "$DST"
echo "V6.3.1 replay path hotfix installed."
echo "Patched: $DST"
