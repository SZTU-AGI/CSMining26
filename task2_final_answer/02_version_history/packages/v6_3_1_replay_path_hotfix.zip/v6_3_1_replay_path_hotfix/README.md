# V6.3.1 replay path hotfix

Fixes a coordinate path parsing bug in `replay_full_batch_v6_3.py`.

The V6.3 script incorrectly used:

```python
cp = initial_path.parents[2].name
case = initial_path.parents[3].name
```

For a path shaped as:

```text
<run-root>/tasks/case-023/CP1/initial/requirement_result.json
```

that produced `case=tasks` and `cp=case-023`, causing all 25 coordinates to become `MISSING_INPUT`.

V6.3.1 parses the coordinate relative to `--run-root`, yielding `case=case-023`, `cp=CP1`.

No API rerun is required.
