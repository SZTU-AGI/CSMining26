#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
import sys

import production_runner_v2
import proof_standard_v1_1 as proof_v1
import semantic_replay_v6_1
import structured_witness_v6_3


def load(p: Path):
    return json.loads(p.read_text(encoding='utf-8'))


def aid(row: dict) -> str:
    try:
        return proof_v1.alignment_id(row)
    except Exception:
        return str(row.get('alignment_id') or row.get('fact_candidate_id') or row.get('evidence_id') or '')


def short(s, n=280):
    s=' '.join(str(s or '').split())
    return s if len(s)<=n else s[:n]+'...'


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--run-root', type=Path, required=True)
    ap.add_argument('--contracts', type=Path, required=True)
    ap.add_argument('--case', default='case-023')
    ap.add_argument('--cp', default='CP12')
    ap.add_argument('--output', type=Path, default=None)
    args=ap.parse_args()

    rr_path=args.run_root/'tasks'/args.case/args.cp/'initial'/'requirement_result.json'
    chunks_path=args.run_root/'cases'/args.case/'evidence_chunks.json'
    contract_path=args.contracts/f'{args.cp}.json'
    for p in [rr_path,chunks_path,contract_path]:
        if not p.exists():
            raise SystemExit(f'MISSING: {p}')

    rr0=load(rr_path); chunks=load(chunks_path); contract=load(contract_path)
    replayed,replay_audit=semantic_replay_v6_1.replay_requirement_result(rr0)
    enriched,struct_audit=structured_witness_v6_3.enrich_requirement_result(replayed,chunks)
    root=production_runner_v2.build_layer7_v2(requirement_result=enriched, contract=contract)
    outcome,fold=production_runner_v2.build_outcome_and_fold(root,contract)

    aligns=enriched.get('alignments') or []
    lookup={}
    for r in aligns:
        for k in {aid(r), str(r.get('fact_candidate_id') or ''), str(r.get('evidence_id') or ''), str(r.get('alignment_evidence_id') or '')}:
            if k: lookup[k]=r

    payload={
        'case':args.case,'cp':args.cp,
        'outcome':outcome.get('common_internal_outcome'),
        'fold_label':fold.get('label'),'fold_finality':fold.get('finality'),
        'semantic_replay_validation_failures':replay_audit.get('validation_failure_count',0),
        'structural_audit':struct_audit,
        'requirement_reports':[],
    }

    print(f'# V6.4.1 focused diagnostic: {args.case} / {args.cp}')
    print('Outcome:', payload['outcome'], 'Fold:', payload['fold_label'], payload['fold_finality'])
    print('Structural injected:', struct_audit.get('injected_count',0))

    for rep in root['proof'].get('requirement_reports',[]):
        rid=rep.get('requirement_id')
        print('\n##',rid)
        print('raw_state=',rep.get('raw_state'),'accepted_state=',rep.get('accepted_state'))
        item={'requirement_id':rid,'raw_state':rep.get('raw_state'),'accepted_state':rep.get('accepted_state'),'support':{},'attack':{}}
        for direction,key in [('SUPPORT','support_proof'),('ATTACK','attack_proof')]:
            pr=rep.get(key) or {}
            print(direction, 'accepted=',pr.get('accepted_direction'), 'status=',pr.get('status'))
            print('  failures=',pr.get('failure_codes') or pr.get('proof_failure_codes') or [])
            print('  temporal=',pr.get('temporal_status'),'reliability=',pr.get('reliability_status'),'coverage=',pr.get('coverage_status'))
            ids=pr.get('basis_artifact_ids') or []
            if not ids:
                ids=pr.get('basis_evidence_ids') or []
            bases=[]
            for x in ids:
                r=lookup.get(str(x))
                if not r: continue
                rec={
                    'relation':r.get('relation'),'reason_code':r.get('reason_code'),
                    'evidence_id':r.get('evidence_id'),'fact_candidate_id':r.get('fact_candidate_id'),
                    'quote':r.get('exact_quote') or r.get('semantic_context'),
                    'structural':bool(r.get('structural_witness_key')),
                    'temporal_relation':r.get('temporal_relation'),
                    'information_reliability':r.get('information_reliability'),
                    'argument_truth_bearing':r.get('argument_truth_bearing'),
                    'argument_admission_channel':r.get('argument_admission_channel'),
                }
                bases.append(rec)
                print('  BASIS',rec['relation'],rec['reason_code'],rec['evidence_id'], 'structural='+str(rec['structural']))
                print('    quote:',short(rec['quote']))
                print('    temporal:',rec['temporal_relation'],'reliability:',rec['information_reliability'])
            item['support' if direction=='SUPPORT' else 'attack']={
                'proof':pr,'bases':bases,
            }

        # show structural witnesses for this requirement even if they were rejected before basis formation
        sw=[r for r in aligns if r.get('requirement_id')==rid and r.get('structural_witness_key')]
        print('  structural candidates=',len(sw))
        item['structural_candidates']=[]
        for r in sw:
            rec={k:r.get(k) for k in ['relation','reason_code','evidence_id','exact_quote','semantic_context','argument_truth_bearing','argument_admission_channel','predicate_compatibility','temporal_relation','information_reliability','structural_witness_key','derived_from_evidence_ids']}
            item['structural_candidates'].append(rec)
            print('  STRUCT',rec['relation'],rec['reason_code'],'TB=',rec['argument_truth_bearing'],'channel=',rec['argument_admission_channel'])
            print('    evidence=',rec['evidence_id'])
            print('    quote=',short(rec['exact_quote']))
            print('    temporal=',rec['temporal_relation'],'reliability=',rec['information_reliability'])
        payload['requirement_reports'].append(item)

    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        print('\nSaved:',args.output)

if __name__=='__main__': main()
