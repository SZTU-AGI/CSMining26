# V6.4.1 focused CP12 diagnostic

Zero-API diagnostic for the remaining `case-023 / CP12` UNKNOWN after V6.4.
It replays deterministic semantics and prints proof failure, temporal/reliability state,
and all structural candidates for ER1/ER2. It does not mutate production files.
