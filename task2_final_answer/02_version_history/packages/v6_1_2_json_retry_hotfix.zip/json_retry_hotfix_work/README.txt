FRECA V6.1.1 JSON retry hotfix

Problem:
- deepseek_json retried malformed JSON with an identical prompt at temperature=0.
- The provider could return byte-identical malformed JSON on every attempt.

Fix:
- Keep deterministic temperature=0.
- On retry attempts (>1), append a strict JSON syntax-correction instruction to the user prompt.
- This changes the request/cache key without changing the requested semantics.

Install:
  unzip -q v6_1_2_json_retry_hotfix.zip -d /home/MeggieYu/freca/v6_1_2_json_retry_hotfix
  export V61=/home/MeggieYu/freca/v6_1_release/v6_witness_reachability_20260830
  bash /home/MeggieYu/freca/v6_1_2_json_retry_hotfix/install_hotfix.sh
