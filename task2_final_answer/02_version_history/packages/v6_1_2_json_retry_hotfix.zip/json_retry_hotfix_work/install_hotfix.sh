#!/usr/bin/env bash
set -euo pipefail
: "${V61:?Set V61 first, e.g. export V61=/home/MeggieYu/freca/v6_1_release/v6_witness_reachability_20260830}"
HERE="$(cd "$(dirname "$0")" && pwd)"
TS="$(date +%Y%m%d_%H%M%S)"
for dst in "$V61/code/freca_core_v1.py" /home/MeggieYu/freca/core_v1/freca_core_v1.py; do
  if [[ -f "$dst" ]]; then
    cp -p "$dst" "$dst.before_json_retry_hotfix_$TS"
    cp "$HERE/freca_core_v1.py" "$dst"
    python -m py_compile "$dst"
    echo "patched: $dst"
  else
    echo "skip missing: $dst"
  fi
done
echo "JSON retry hotfix installed."
