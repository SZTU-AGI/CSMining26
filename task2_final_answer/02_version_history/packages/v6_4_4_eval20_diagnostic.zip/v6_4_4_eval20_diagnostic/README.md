# V6.4.4 eval20 diagnostic

Zero-API diagnostic only. No production semantics are changed.

- `diagnose_eval20_v6_4_4.py`: rebuilds V6.4.3 proof for all 80 coordinates, expands 5 UNKNOWN blockers and accepted SUPPORT/ATTACK bases for all CONFLICTING coordinates.
- `probe_benchmark_gold_v6_4_4.py`: inspects the local project for benchmark/gold label artifacts so accuracy/F1 can be computed next.
