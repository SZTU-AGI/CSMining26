#!/usr/bin/env bash
set -euo pipefail
V61="${V61:-/home/MeggieYu/freca/v6_1_release/v6_witness_reachability_20260830}"
ROOT="$(cd "$(dirname "$0")" && pwd)"
cp "$ROOT/files/diagnose_eval20_v6_4_4.py" "$V61/code/"
cp "$ROOT/files/probe_benchmark_gold_v6_4_4.py" "$V61/code/"
chmod +x "$V61/code/diagnose_eval20_v6_4_4.py" "$V61/code/probe_benchmark_gold_v6_4_4.py"
echo "V6.4.4 eval20 diagnostic installed (zero-API, no semantic changes)."
